export type AppMode = 'rider' | 'driver';

export type AppView = 
  | 'home' 
  | 'my_rides' 
  | 'wallet' 
  | 'drive_with_zolta'
  | 'trailer_hiring'
  | 'towing'
  | 'asset_owner'
  | 'safety' 
  | 'support' 
  | 'settings' 
  | 'invite' 
  | 'driver_earnings' 
  | 'driver_documents'
  | 'ride_preferences';

export type RideCategory = 
  | 'ride'
  | 'rider' 
  | 'comfort' 
  | 'xl' 
  | 'scooter'
  | 'bakkie'
  | 'courier';

export type DriverGenderPreference = 'any' | 'female' | 'male';

export interface RidePreferences {
  driverPreference: DriverGenderPreference;
  language: 'Xhosa' | 'English' | 'Afrikaans' | 'Sesotho';
  music: 'Amapiano' | 'Gqom' | 'Gospel' | 'Quiet ride';
  chatLevel: 'Chatty' | 'Quiet' | 'Only directions';
  stopAtSpaza: boolean;
  shareTripFamily: boolean;
  femaleDriverAtNight: boolean;
  avoidGravelRoads: boolean;
}

export interface RideCategoryInfo {
  id: RideCategory;
  name: string;
  subtitle: string;
  basePriceMultiplier: number;
  fixedDefaultPrice?: number;
  capacity: string;
  icon: string;
  badge?: string;
  carExample: string;
}

export interface LocationPoint {
  id?: string;
  name?: string;
  address: string;
  lat: number;
  lng: number;
  shortName?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  shortName?: string;
  displayName?: string;
  phone: string;
  email: string;
  avatar: string;
  rating: number;
  totalTrips: number;
  mode: AppMode;
  isDriverVerified: boolean;
  walletBalance: number;
  gender?: 'male' | 'female';
  joinedDate?: string;
  ridePreferences?: RidePreferences;
  vehicleType?: RideCategory;
  driverDetails?: {
    carModel: string;
    carColor: string;
    licensePlate: string;
    carType: RideCategory;
    vehicleType?: RideCategory;
    earningsToday: number;
    tripsToday: number;
    acceptanceRate: number;
    rating: number;
    gender: 'male' | 'female';
    documents: {
      licenseUploaded: boolean;
      rcUploaded: boolean;
      insuranceUploaded: boolean;
      photoUploaded: boolean;
    };
  };
}

export type RideStatus = 
  | 'searching' 
  | 'driver_assigned' 
  | 'driver_arrived' 
  | 'in_progress' 
  | 'completed' 
  | 'cancelled';

export interface Bid {
  id: string;
  rideId: string;
  driverId: string;
  driverName: string;
  driverGender: 'male' | 'female';
  driverAvatar: string;
  driverRating: number;
  driverTrips: number;
  driverCar: string;
  driverPlate: string;
  driverDistanceKm: number;
  driverEtaMins: number;
  amount: number;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
  message?: string;
}

export interface RideRequest {
  id: string;
  riderId: string;
  riderName: string;
  riderRating: number;
  riderPhone: string;
  riderAvatar: string;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  distanceKm: number;
  durationMins: number;
  category: RideCategory;
  genderPreference: DriverGenderPreference;
  preferences?: RidePreferences;
  offeredFare: number;
  suggestedFare: number;
  currency: string;
  comments: string;
  passengerCount: number;
  paymentMethod: 'cash' | 'card' | 'wallet' | 'payshap';
  status: RideStatus;
  cancellationReason?: string;
  bids: Bid[];
  acceptedBidId?: string;
  acceptedDriver?: {
    id: string;
    name: string;
    gender: 'male' | 'female';
    phone: string;
    avatar: string;
    rating: number;
    carModel: string;
    carColor: string;
    licensePlate: string;
    currentLocation: { lat: number; lng: number };
  };
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  driverRouteProgress?: number; // 0 to 100%
  driverEtaMins?: number;
  ratingGiven?: number;
  tipGiven?: number;
  feedbackTags?: string[];
}

export interface ChatMessage {
  id: string;
  rideId: string;
  senderId: string;
  senderName: string;
  senderRole: 'rider' | 'driver' | 'support';
  text: string;
  timestamp: number;
}

export interface WalletTransaction {
  id: string;
  type: 'topup' | 'ride_payment' | 'driver_earning' | 'bonus';
  amount: number;
  description: string;
  date: string;
  timestamp: number;
  status: 'completed' | 'pending';
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

export interface OwnerBidOffer {
  id: string;
  ownerId: string;
  ownerName: string;
  ownerPhone: string;
  assetType: 'towing' | 'trailer';
  assetName?: string;
  price: number;
  eta: string; // e.g. "20 mins" or "Available Today"
  rating?: number;
  jobsCount?: number;
  isVerified?: boolean;
  note?: string;
  status?: 'pending' | 'accepted' | 'rejected';
  createdAt: number | string;
}

export interface TowingRequestDoc {
  id: string;
  requesterId: string;
  requesterName: string;
  requesterPhone: string;
  pickupAddress: string;
  dropAddress: string;
  pickupLatLng?: { lat: number; lng: number };
  dropLatLng?: { lat: number; lng: number };
  vehicleType: string; // Car, Bakkie, Truck, Bike
  problem: string; // Engine, Flat Tyre, Accident, Battery, Stuck, Need Tow
  photos?: string[];
  status: 'pending' | 'offers_received' | 'accepted' | 'declined' | 'completed' | 'cancelled';
  createdAt: any;
  offers: OwnerBidOffer[];
  acceptedOffer?: OwnerBidOffer;
  acceptedBy?: string;
  offeredPrice?: number;
}

export interface TrailerRequestDoc {
  id: string;
  requesterId: string;
  requesterName: string;
  requesterPhone: string;
  trailerType: string; // Luggage Trailer, Utility Trailer, Car Transporter, Bike Rack, Fridge Trailer
  durationType: 'hours' | 'days' | 'weeks' | 'months';
  durationQty: number;
  startDateTime: string;
  loadDesc: string;
  pickup: string;
  drop: string;
  pickupLatLng?: { lat: number; lng: number };
  dropLatLng?: { lat: number; lng: number };
  status: 'pending' | 'offers_received' | 'accepted' | 'declined' | 'completed' | 'cancelled';
  createdAt: any;
  offers: OwnerBidOffer[];
  acceptedOffer?: OwnerBidOffer;
  acceptedBy?: string;
  offeredPrice?: number;
}

export type TowingType =
  | 'Breakdown'
  | 'Accident Rollback'
  | 'Battery Jump'
  | 'Flat Tyre'
  | 'Emergency Recovery'
  | 'Accident'
  | 'Stuck'
  | 'Need Tow';

export type TrailerType =
  | 'Luggage'
  | 'Utility'
  | 'Car Transporter'
  | 'Flatbed'
  | 'Double-Axle'
  | 'Box / Enclosed'
  | 'Camping'
  | 'Luggage Trailer'
  | 'Utility Trailer'
  | 'Bike Rack'
  | 'Fridge Trailer';

export type HireDuration = 'Hourly' | 'Daily' | 'Weekly' | 'Monthly' | 'hours' | 'days' | 'weeks' | 'months' | 'hour' | 'day' | 'week' | 'month';

export interface TowingAssetRequest {
  id: string;
  type: 'towing';
  towingType: TowingType;
  problemType?: string;
  location: string;
  dropLocation?: string;
  pickupAddress?: string;
  dropAddress?: string;
  gpsLocation?: { lat: number; lng: number };
  vehicleDetails: {
    makeModel: string;
    color: string;
    plate: string;
  };
  phone: string;
  userName: string;
  requesterId?: string;
  description?: string;
  photos?: string[];
  offeredPrice?: number;
  offers?: OwnerBidOffer[];
  status: 'pending' | 'offers_received' | 'accepted' | 'declined' | 'completed' | 'cancelled';
  createdAt: number | string;
  acceptedBy?: string;
  assignedTruck?: string;
  acceptedOffer?: OwnerBidOffer;
}

export interface TrailerAssetRequest {
  id: string;
  type: 'trailer';
  trailerType: TrailerType | string;
  hireDuration: HireDuration | string;
  durationType?: 'hours' | 'days' | 'weeks' | 'months';
  durationQty?: number;
  startDateTime?: string;
  loadDesc?: string;
  pickup?: string;
  drop?: string;
  deliveryChoice?: 'fetch' | 'deliver' | 'Will Fetch' | 'Delivery';
  location: string;
  gpsLocation?: { lat: number; lng: number };
  trailerId?: string;
  trailerName?: string;
  ownerName?: string;
  ownerPhone?: string;
  phone: string;
  userName: string;
  requesterId?: string;
  totalAmount?: number;
  offeredPrice?: number;
  deposit?: number;
  offers?: OwnerBidOffer[];
  status: 'pending' | 'offers_received' | 'accepted' | 'declined' | 'completed' | 'cancelled';
  createdAt: number | string;
  acceptedBy?: string;
  acceptedOffer?: OwnerBidOffer;
}

export type AssetRequest = TowingAssetRequest | TrailerAssetRequest;

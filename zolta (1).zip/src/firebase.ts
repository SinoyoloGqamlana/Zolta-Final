import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeFirestore, getFirestore, setLogLevel } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';
import defaultJsonConfig from '../firebase-applet-config.json';

// Silence internal retry/unavailability logs from the Firestore transport layer
try {
  setLogLevel('silent');
} catch {}

const activeConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || defaultJsonConfig.apiKey,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || defaultJsonConfig.authDomain,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || defaultJsonConfig.projectId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || defaultJsonConfig.storageBucket,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || defaultJsonConfig.messagingSenderId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || defaultJsonConfig.appId,
};

const databaseId = defaultJsonConfig.firestoreDatabaseId || '(default)';

export const app = getApps().length > 0 ? getApp() : initializeApp(activeConfig);

let firestoreInstance;
try {
  firestoreInstance = initializeFirestore(
    app,
    {
      experimentalForceLongPolling: true,
    },
    databaseId
  );
} catch {
  try {
    firestoreInstance = getFirestore(app, databaseId);
  } catch {
    firestoreInstance = getFirestore(app);
  }
}

export const db = firestoreInstance;
export const auth = getAuth(app);
export const storage = getStorage(app);
export const rdb = null;

export default { app, auth, db, storage, rdb };



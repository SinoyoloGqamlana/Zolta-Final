import { RideCategory, UserProfile } from '../types';

export type NormalizedRideCategory = 'ride' | 'comfort' | 'xl' | 'bakkie' | 'scooter' | 'courier';

/**
 * Normalizes any category string or alias to one of the 6 canonical categories:
 * 'ride', 'comfort', 'xl', 'bakkie', 'scooter', 'courier'
 */
export function normalizeCategory(cat?: string | null): NormalizedRideCategory {
  if (!cat) return 'ride';
  const c = String(cat).toLowerCase().trim();
  if (c === 'ride' || c === 'rider') return 'ride';
  if (c === 'comfort') return 'comfort';
  if (c === 'xl') return 'xl';
  if (c === 'bakkie') return 'bakkie';
  if (c === 'scooter') return 'scooter';
  if (c === 'courier') return 'courier';
  return 'ride';
}

/**
 * Extracts and normalizes the driver's vehicleType from their profile
 */
export function getDriverVehicleType(user?: UserProfile | null): NormalizedRideCategory {
  if (!user) return 'ride';
  const raw =
    user.driverDetails?.vehicleType ||
    user.driverDetails?.carType ||
    user.vehicleType ||
    'ride';
  return normalizeCategory(raw);
}

/**
 * Checks if a ride request's category matches the driver's vehicle type exactly.
 * Rule: When rider requests "Scooter", only drivers with vehicleType = Scooter must see that request.
 * Same for Bakkie, Courier, Ride, Comfort, XL.
 */
export function matchCategoryToVehicle(
  requestCategory?: string | null,
  driverVehicleType?: string | null
): boolean {
  if (!requestCategory || !driverVehicleType) return false;
  return normalizeCategory(requestCategory) === normalizeCategory(driverVehicleType);
}

export const CATEGORY_DISPLAY_NAMES: Record<NormalizedRideCategory, string> = {
  ride: 'Ride',
  comfort: 'Comfort',
  xl: 'XL',
  bakkie: 'Bakkie',
  scooter: 'Scooter',
  courier: 'Courier',
};

import { AssetRequest, TowingAssetRequest, TrailerAssetRequest, OwnerBidOffer } from '../types';

const ASSET_REQUESTS_KEY = 'zolta_asset_requests';

/**
 * Get all asset requests from localStorage
 */
export function getStoredAssetRequests(): AssetRequest[] {
  try {
    const raw = localStorage.getItem(ASSET_REQUESTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.warn('Failed to parse asset requests from localStorage:', e);
    return [];
  }
}

/**
 * Save all asset requests to localStorage and dispatch custom event for instant cross-component updates
 */
export function saveStoredAssetRequests(requests: AssetRequest[]): void {
  try {
    localStorage.setItem(ASSET_REQUESTS_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent('zolta_asset_requests_updated', { detail: requests }));
  } catch (e) {
    console.warn('Failed to save asset requests to localStorage:', e);
  }
}

/**
 * Add a new asset request (Towing or Trailer)
 */
export function addAssetRequest(request: AssetRequest): void {
  const existing = getStoredAssetRequests();
  // Remove if matching id exists
  const filtered = existing.filter((r) => r.id !== request.id);
  const updated = [request, ...filtered];
  saveStoredAssetRequests(updated);
}

/**
 * Add or update an owner offer on an asset request
 */
export function addOwnerOfferToAssetRequest(requestId: string, offer: OwnerBidOffer): AssetRequest[] {
  const existing = getStoredAssetRequests();
  const updated = existing.map((r) => {
    if (r.id === requestId) {
      const currentOffers = Array.isArray(r.offers) ? [...r.offers] : [];
      const matchIdx = currentOffers.findIndex((o) => o.ownerId === offer.ownerId || o.ownerName === offer.ownerName);
      if (matchIdx >= 0) {
        currentOffers[matchIdx] = { ...currentOffers[matchIdx], ...offer, createdAt: Date.now() };
      } else {
        currentOffers.push({ ...offer, createdAt: Date.now() });
      }
      return {
        ...r,
        offers: currentOffers,
        status: 'offers_received' as const,
      };
    }
    return r;
  });
  saveStoredAssetRequests(updated);
  return updated;
}

/**
 * Accept an owner offer on an asset request
 */
export function acceptOwnerOfferInStorage(requestId: string, offer: OwnerBidOffer): AssetRequest[] {
  const existing = getStoredAssetRequests();
  const updated = existing.map((r) => {
    if (r.id === requestId) {
      const currentOffers = (r.offers || []).map((o) => ({
        ...o,
        status: (o.id === offer.id || o.ownerId === offer.ownerId ? 'accepted' : 'rejected') as any,
      }));
      return {
        ...r,
        status: 'accepted' as const,
        acceptedBy: offer.ownerName,
        acceptedOffer: offer,
        offers: currentOffers,
      };
    }
    return r;
  });
  saveStoredAssetRequests(updated);
  return updated;
}

/**
 * Update the status of an asset request
 */
export function updateAssetRequestStatus(
  requestId: string,
  status: 'accepted' | 'declined' | 'completed' | 'pending' | 'cancelled' | 'offers_received',
  acceptedBy?: string
): AssetRequest[] {
  const existing = getStoredAssetRequests();
  const updated = existing.map((r) =>
    r.id === requestId
      ? {
          ...r,
          status: status as any,
          ...(acceptedBy ? { acceptedBy } : {}),
        }
      : r
  );
  saveStoredAssetRequests(updated);
  return updated;
}


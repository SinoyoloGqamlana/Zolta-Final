import {
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  onSnapshot,
  orderBy,
  serverTimestamp,
  Unsubscribe
} from 'firebase/firestore';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, auth, storage } from '../firebase';
import {
  RideRequest,
  RideStatus,
  LocationPoint,
  RideCategory,
  RidePreferences,
  OwnerBidOffer,
  TowingRequestDoc,
  TrailerRequestDoc,
} from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

let hasReportedQuotaExceeded = false;
let isQuotaExceeded = false;

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  const isUnavailable =
    errMsg.toLowerCase().includes('unavailable') ||
    errMsg.toLowerCase().includes('offline') ||
    errMsg.toLowerCase().includes('could not reach') ||
    errMsg.toLowerCase().includes('failed-precondition');
  const isQuota = errMsg.toLowerCase().includes('quota') || errMsg.toLowerCase().includes('resource-exhausted');
  
  if (isQuota) {
    isQuotaExceeded = true;
    if (!hasReportedQuotaExceeded) {
      hasReportedQuotaExceeded = true;
      console.warn('Firestore Daily Quota has been reached on free tier. Switching to local resilient fallback mode.');
    }
  }

  const errInfo: FirestoreErrorInfo = {
    error: errMsg,
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  if (!isQuota && !isUnavailable) {
    console.error('Firestore Error:', JSON.stringify(errInfo));
  } else if (isUnavailable) {
    console.warn('Firestore connection state notice (offline/reconnecting):', errMsg);
  }
  return errInfo;
}

/**
 * Updates user current GPS location in Firestore
 */
export async function updateUserLocationInFirestore(uid: string, lat: number, lng: number) {
  if (!db || !uid || isQuotaExceeded) return;
  try {
    const userDoc = doc(db, 'users', uid);
    await setDoc(userDoc, {
      currentLat: lat,
      currentLng: lng,
      lastLocationUpdate: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
  }
}

/**
 * Saves Ride Preferences in Firestore
 */
export async function saveUserPreferencesInFirestore(uid: string, preferences: any) {
  if (!db || !uid || isQuotaExceeded) return;
  try {
    const userDoc = doc(db, 'users', uid);
    await setDoc(userDoc, {
      ridePreferences: preferences,
      genderPreference: preferences.driverPreference || 'any',
      lastPreferencesUpdate: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
  }
}

/**
 * Creates a real-time ride request in Firestore
 */
export async function createRealtimeRideRequest(params: {
  rideId: string;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  category: RideCategory;
  offeredFare: number;
  suggestedFare: number;
  comments: string;
  passengerCount: number;
  riderName: string;
  riderPhone: string;
  riderAvatar?: string;
  paymentMethod?: 'cash' | 'card' | 'wallet' | 'payshap';
  preferences?: RidePreferences;
}): Promise<string> {
  const currentUid = auth?.currentUser?.uid || 'rider_' + Math.random().toString(36).substring(2, 8);

  const commissionRate = 0.10;
  const total = Number(params.offeredFare || 25);
  const zoltaCommission = Number((total * commissionRate).toFixed(2));
  const paystackFee = params.paymentMethod === 'card' ? Number((total * 0.029 + 1.0).toFixed(2)) : 0;
  const driverPayout = Number(Math.max(0, total - zoltaCommission - paystackFee).toFixed(2));

  const tripPayload = {
    tripId: params.rideId,
    serviceType: params.category,
    category: params.category,
    pickup: {
      address: params.pickup.address || 'Ngaba Ngaba Crescent, Ilitha Park',
      shortName: params.pickup.shortName || 'Ilitha Park',
      lat: params.pickup.lat || -34.0456,
      lng: params.pickup.lng || 18.6656,
    },
    destination: {
      address: params.dropoff.address || 'Khayelitsha Mall',
      shortName: params.dropoff.shortName || 'Khayelitsha Mall',
      lat: params.dropoff.lat || -34.0385,
      lng: params.dropoff.lng || 18.6655,
    },
    total,
    zoltaCommission,
    driverPayout,
    paystackFee,
    commissionRate,
    currency: 'ZAR',
    status: 'pending',
    userId: currentUid,
    riderId: currentUid,
    riderName: params.riderName,
    riderPhone: params.riderPhone,
    paymentMethod: params.paymentMethod || 'cash',
    comments: params.comments || '',
    passengerCount: params.passengerCount || 1,
    preferences: params.preferences || null,
    ridePreferences: params.preferences || null,
    genderPreference: params.preferences?.driverPreference || 'any',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (db && !isQuotaExceeded) {
    try {
      // 1. Primary trips/{id} record
      const tripDocRef = doc(db, 'trips', params.rideId);
      await setDoc(tripDocRef, tripPayload, { merge: true });

      // 2. rides/{id} collection for driver matching
      const ridesDocRef = doc(db, 'rides', params.rideId);
      await setDoc(ridesDocRef, tripPayload, { merge: true });

      // 3. rideRequests/{id} for backward compatibility
      const rideDocRef = doc(db, 'rideRequests', params.rideId);
      await setDoc(rideDocRef, tripPayload, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `rides/${params.rideId}`);
    }
  }

  return params.rideId;
}

/**
 * Updates ride request preferences in Firestore
 */
export async function updateRidePreferencesInFirestore(rideId: string, preferences: RidePreferences) {
  if (!db || !rideId || isQuotaExceeded) return;
  try {
    const payload = {
      preferences,
      ridePreferences: preferences,
      genderPreference: preferences.driverPreference || 'any',
      updatedAt: serverTimestamp(),
    };
    await updateDoc(doc(db, 'rideRequests', rideId), payload);
    await updateDoc(doc(db, 'trips', rideId), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `rideRequests/${rideId}`);
  }
}

/**
 * Driver accepts ride in Firestore
 */
export async function driverAcceptRideInFirestore(rideId: string, driverInfo: {
  driverId: string;
  driverName: string;
  driverPhone: string;
  carModel: string;
  licensePlate: string;
  carColor?: string;
  rating?: number;
  avatar?: string;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'rideRequests', rideId);
    await updateDoc(docRef, {
      status: 'accepted',
      driverId: driverInfo.driverId,
      acceptedDriver: {
        id: driverInfo.driverId,
        name: driverInfo.driverName,
        phone: driverInfo.driverPhone,
        carModel: driverInfo.carModel,
        licensePlate: driverInfo.licensePlate,
        carColor: driverInfo.carColor || 'Silver',
        rating: driverInfo.rating || 4.95,
        avatar: driverInfo.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      },
      acceptedAt: serverTimestamp(),
    });

    // Sync trips/{id}
    await updateDoc(doc(db, 'trips', rideId), {
      status: 'accepted',
      driverId: driverInfo.driverId,
      updatedAt: serverTimestamp(),
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, `rideRequests/${rideId}`);
  }
}

/**
 * Updates ride status in Firestore
 */
export async function updateRideStatusInFirestore(
  rideId: string,
  status: RideStatus,
  extraPayload?: Record<string, any>
) {
  if (!db || isQuotaExceeded) return;
  try {
    const rideRef = doc(db, 'rideRequests', rideId);
    await updateDoc(rideRef, {
      status,
      ...(extraPayload || {}),
      updatedAt: serverTimestamp(),
    });

    const tripRef = doc(db, 'trips', rideId);
    await updateDoc(tripRef, {
      status,
      ...(extraPayload || {}),
      updatedAt: serverTimestamp(),
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, `rideRequests/${rideId}`);
  }
}

/**
 * Subscribes to real-time updates for a single ride and its driver offers
 */
export function subscribeToRideRequest(
  rideId: string,
  callback: (data: any) => void
): Unsubscribe {
  if (!db || isQuotaExceeded) {
    return () => {};
  }
  try {
    const rideRef = doc(db, 'rideRequests', rideId);
    const offersRef = collection(db, 'rideRequests', rideId, 'driversOffers');

    let rideData: any = null;
    let offersData: any[] = [];

    const notify = () => {
      if (rideData) {
        const docBids = rideData.bids || [];
        const combinedBids = [...docBids, ...offersData];
        const uniqueBidsMap = new Map();
        combinedBids.forEach((b) => {
          if (b && b.id) uniqueBidsMap.set(b.id, b);
        });
        callback({
          ...rideData,
          bids: Array.from(uniqueBidsMap.values()),
        });
      }
    };

    const unsubRide = onSnapshot(
      rideRef,
      (docSnap) => {
        if (docSnap.exists()) {
          rideData = { id: docSnap.id, ...docSnap.data() };
          notify();
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `rideRequests/${rideId}`);
      }
    );

    const unsubOffers = onSnapshot(
      offersRef,
      (snapshot) => {
        offersData = [];
        snapshot.forEach((d) => {
          offersData.push({ id: d.id, ...d.data() });
        });
        notify();
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `rideRequests/${rideId}/driversOffers`);
      }
    );

    return () => {
      unsubRide();
      unsubOffers();
    };
  } catch {
    return () => {};
  }
}

/**
 * Submits a driver offer / bid into Firestore driversOffers subcollection
 */
export async function submitDriverOfferInFirestore(rideId: string, offerData: any) {
  if (!db || !rideId || isQuotaExceeded) return;
  try {
    const offerDocRef = doc(db, 'rideRequests', rideId, 'driversOffers', offerData.id || `offer_${Date.now()}`);
    await setDoc(offerDocRef, {
      ...offerData,
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `rideRequests/${rideId}/driversOffers`);
  }
}

/**
 * Subscribes to available pending ride requests near driver from Firestore 'rides' and 'rideRequests'
 */
export function subscribeToAvailableRides(
  callback: (rides: any[]) => void
): Unsubscribe {
  if (!db || isQuotaExceeded) {
    callback([]);
    return () => {};
  }
  try {
    const ridesRef = collection(db, 'rides');
    const qRides = query(
      ridesRef,
      where('status', 'in', ['pending', 'searching', 'bidding'])
    );

    const unsubRides = onSnapshot(
      qRides,
      (snapshot) => {
        const items: any[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          items.push({
            id: d.id,
            rideId: d.id,
            tripId: d.id,
            ...data,
            pickup: data.pickup || { address: 'Pickup Location', shortName: 'Pickup' },
            dropoff: data.dropoff || data.destination || { address: 'Dropoff Location', shortName: 'Dropoff' },
            offeredFare: data.offeredFare || data.total || 50,
            category: data.category || data.serviceType || 'ride',
            riderName: data.riderName || 'Rider',
            status: data.status || 'pending',
          });
        });
        items.sort((a, b) => (b.createdAt?.toMillis?.() || b.createdAt || 0) - (a.createdAt?.toMillis?.() || a.createdAt || 0));
        callback(items);
      },
      () => {
        // Fallback to rideRequests collection
        try {
          const legacyRef = collection(db, 'rideRequests');
          const qLegacy = query(legacyRef, where('status', 'in', ['pending', 'searching', 'bidding']));
          onSnapshot(qLegacy, (snap) => {
            const items: any[] = [];
            snap.forEach((d) => {
              const data = d.data();
              items.push({
                id: d.id,
                rideId: d.id,
                tripId: d.id,
                ...data,
                pickup: data.pickup || { address: 'Pickup Location', shortName: 'Pickup' },
                dropoff: data.dropoff || data.destination || { address: 'Dropoff Location', shortName: 'Dropoff' },
                offeredFare: data.offeredFare || data.total || 50,
                category: data.category || data.serviceType || 'ride',
                riderName: data.riderName || 'Rider',
                status: data.status || 'pending',
              });
            });
            callback(items);
          }, () => callback([]));
        } catch {
          callback([]);
        }
      }
    );

    return unsubRides;
  } catch {
    callback([]);
    return () => {};
  }
}

/**
 * Uploads a document to Firebase Storage
 */
export async function uploadDocumentToFirebase(
  uid: string,
  docKey: string,
  file: File
): Promise<{ storagePath: string; downloadUrl: string; fileName: string }> {
  const path = `drivers/${uid}/${docKey}_${Date.now()}_${file.name}`;
  try {
    if (storage) {
      const sRef = storageRef(storage, path);
      await uploadBytes(sRef, file);
      const url = await getDownloadURL(sRef);
      return { storagePath: path, downloadUrl: url, fileName: file.name };
    }
  } catch (err) {
    console.warn('Firebase Storage upload notice, falling back to path metadata:', err);
  }

  // Graceful fallback with valid storage path metadata
  return {
    storagePath: path,
    downloadUrl: '',
    fileName: file.name,
  };
}

/**
 * Saves a driver registration to Firestore `drivers` and `users` collections
 */
export async function saveDriverToFirestore(driverData: {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  vehicleType: string;
  carMakeModel: string;
  carYear: string;
  licensePlate: string;
  carColor: string;
  gender: string;
  identityDoc: string;
  licenseDoc: string;
  pdpDoc: string;
  vehicleRegDoc: string;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const driverRef = doc(db, 'drivers', driverData.id);
    await setDoc(driverRef, {
      ...driverData,
      isVerified: true,
      status: 'active',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });

    const userRef = doc(db, 'users', driverData.id);
    await setDoc(userRef, {
      id: driverData.id,
      name: driverData.name,
      email: driverData.email,
      phone: driverData.phone,
      mode: 'driver',
      isDriverVerified: true,
      vehicleType: driverData.vehicleType,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `drivers/${driverData.id}`);
  }
}

/**
 * Creates or saves a Towing Request in Firestore `towingRequests` collection
 */
export async function createTowingRequestInFirestore(req: Partial<TowingRequestDoc>): Promise<string> {
  const reqId = req.id || `TOW-${Math.floor(1000 + Math.random() * 9000)}`;
  const currentUid = auth?.currentUser?.uid || req.requesterId || `user_${Date.now()}`;
  
  const payload: TowingRequestDoc = {
    id: reqId,
    requesterId: currentUid,
    requesterName: req.requesterName || 'Motorist',
    requesterPhone: req.requesterPhone || '+27 82 000 0000',
    pickupAddress: req.pickupAddress || 'Breakdown Location',
    dropAddress: req.dropAddress || 'Destination Repair Shop',
    pickupLatLng: req.pickupLatLng || { lat: -33.9249, lng: 18.4241 },
    dropLatLng: req.dropLatLng || { lat: -33.9350, lng: 18.4350 },
    vehicleType: req.vehicleType || 'Car',
    problem: req.problem || 'Breakdown',
    photos: req.photos || [],
    status: 'pending',
    offers: req.offers || [],
    offeredPrice: req.offeredPrice || 450,
    createdAt: serverTimestamp(),
  };

  if (db && !isQuotaExceeded) {
    try {
      const docRef = doc(db, 'towingRequests', reqId);
      await setDoc(docRef, payload, { merge: true });

      // Also record in trips for global ledger
      const tripRef = doc(db, 'trips', reqId);
      await setDoc(tripRef, {
        tripId: reqId,
        serviceType: 'towing',
        category: 'towing',
        pickup: { address: payload.pickupAddress, ...payload.pickupLatLng },
        destination: { address: payload.dropAddress, ...payload.dropLatLng },
        total: payload.offeredPrice || 450,
        status: 'pending',
        riderId: payload.requesterId,
        riderName: payload.requesterName,
        riderPhone: payload.requesterPhone,
        createdAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `towingRequests/${reqId}`);
    }
  }
  return reqId;
}

export async function saveTowingRequestToFirestore(towingData: any) {
  return createTowingRequestInFirestore(towingData);
}

/**
 * Creates or saves a Trailer Request in Firestore `trailerRequests` collection
 */
export async function createTrailerRequestInFirestore(req: Partial<TrailerRequestDoc>): Promise<string> {
  const reqId = req.id || `TRL-${Math.floor(1000 + Math.random() * 9000)}`;
  const currentUid = auth?.currentUser?.uid || req.requesterId || `user_${Date.now()}`;

  const payload: TrailerRequestDoc = {
    id: reqId,
    requesterId: currentUid,
    requesterName: req.requesterName || 'Client',
    requesterPhone: req.requesterPhone || '+27 82 000 0000',
    trailerType: req.trailerType || 'Luggage Trailer',
    durationType: req.durationType || 'days',
    durationQty: req.durationQty || 1,
    startDateTime: req.startDateTime || 'Today (Immediate)',
    loadDesc: req.loadDesc || 'Luggage / Boxes',
    pickup: req.pickup || 'Pickup Location',
    drop: req.drop || 'Dropoff / Area of Use',
    pickupLatLng: req.pickupLatLng || { lat: -33.9249, lng: 18.4241 },
    dropLatLng: req.dropLatLng || { lat: -33.9350, lng: 18.4350 },
    status: 'pending',
    offers: req.offers || [],
    offeredPrice: req.offeredPrice || 250,
    createdAt: serverTimestamp(),
  };

  if (db && !isQuotaExceeded) {
    try {
      const docRef = doc(db, 'trailerRequests', reqId);
      await setDoc(docRef, payload, { merge: true });

      // Fallback compatibility doc
      const legacyRef = doc(db, 'trailer_requests', reqId);
      await setDoc(legacyRef, payload, { merge: true });

      // Also record in trips for global ledger
      const tripRef = doc(db, 'trips', reqId);
      await setDoc(tripRef, {
        tripId: reqId,
        serviceType: 'trailer',
        category: 'trailer',
        pickup: { address: payload.pickup, ...payload.pickupLatLng },
        destination: { address: payload.drop, ...payload.dropLatLng },
        total: payload.offeredPrice || 250,
        status: 'pending',
        riderId: payload.requesterId,
        riderName: payload.requesterName,
        riderPhone: payload.requesterPhone,
        createdAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `trailerRequests/${reqId}`);
    }
  }
  return reqId;
}

/**
 * Subscribes to all real-time towing requests from Firestore `towingRequests`
 */
export function subscribeToTowingRequests(callback: (requests: TowingRequestDoc[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'towingRequests');
    return onSnapshot(colRef, (snapshot) => {
      const items: TowingRequestDoc[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        items.push({
          id: d.id,
          requesterId: data.requesterId || '',
          requesterName: data.requesterName || data.userName || 'Requester',
          requesterPhone: data.requesterPhone || data.userPhone || data.phone || '+27 82 000 0000',
          pickupAddress: data.pickupAddress || data.location || 'Breakdown Location',
          dropAddress: data.dropAddress || 'Destination',
          pickupLatLng: data.pickupLatLng || data.gpsLocation,
          dropLatLng: data.dropLatLng,
          vehicleType: data.vehicleType || (data.carDetails?.makeModel ? 'Car' : 'Vehicle'),
          problem: data.problem || data.problemType || 'Breakdown',
          photos: data.photos || [],
          status: data.status || 'pending',
          offers: Array.isArray(data.offers) ? data.offers : (Array.isArray(data.towerOffers) ? data.towerOffers : []),
          acceptedOffer: data.acceptedOffer,
          acceptedBy: data.acceptedBy || data.assignedTruck,
          offeredPrice: data.offeredPrice || 450,
          createdAt: data.createdAt,
        });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'towingRequests');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Subscribes to single towing request by ID
 */
export function subscribeToSingleTowingRequest(
  requestId: string,
  callback: (request: TowingRequestDoc | null) => void
): Unsubscribe {
  if (!db || !requestId || isQuotaExceeded) return () => {};
  try {
    const docRef = doc(db, 'towingRequests', requestId);
    return onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        callback({
          id: docSnap.id,
          requesterId: data.requesterId || '',
          requesterName: data.requesterName || data.userName || 'Requester',
          requesterPhone: data.requesterPhone || data.userPhone || data.phone || '+27 82 000 0000',
          pickupAddress: data.pickupAddress || data.location || 'Breakdown Location',
          dropAddress: data.dropAddress || 'Destination',
          pickupLatLng: data.pickupLatLng || data.gpsLocation,
          dropLatLng: data.dropLatLng,
          vehicleType: data.vehicleType || 'Car',
          problem: data.problem || data.problemType || 'Breakdown',
          photos: data.photos || [],
          status: data.status || 'pending',
          offers: Array.isArray(data.offers) ? data.offers : (Array.isArray(data.towerOffers) ? data.towerOffers : []),
          acceptedOffer: data.acceptedOffer,
          acceptedBy: data.acceptedBy || data.assignedTruck,
          offeredPrice: data.offeredPrice || 450,
          createdAt: data.createdAt,
        });
      } else {
        callback(null);
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, `towingRequests/${requestId}`);
    });
  } catch {
    return () => {};
  }
}

/**
 * Subscribes to all real-time trailer requests from Firestore `trailerRequests`
 */
export function subscribeToTrailerRequests(callback: (requests: TrailerRequestDoc[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'trailerRequests');
    return onSnapshot(colRef, (snapshot) => {
      const items: TrailerRequestDoc[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        items.push({
          id: d.id,
          requesterId: data.requesterId || data.riderId || '',
          requesterName: data.requesterName || data.riderName || 'Client',
          requesterPhone: data.requesterPhone || data.riderPhone || data.phone || '+27 82 000 0000',
          trailerType: data.trailerType || data.trailerName || 'Luggage Trailer',
          durationType: data.durationType || (data.hireDurationType ? data.hireDurationType + 's' : 'days') as any,
          durationQty: data.durationQty || data.hireUnits || 1,
          startDateTime: data.startDateTime || data.timestamp || 'Immediate',
          loadDesc: data.loadDesc || 'Cargo / General Goods',
          pickup: data.pickup || data.location || 'Pickup Location',
          drop: data.drop || 'Usage Area',
          pickupLatLng: data.pickupLatLng,
          dropLatLng: data.dropLatLng,
          status: data.status || 'pending',
          offers: Array.isArray(data.offers) ? data.offers : (Array.isArray(data.ownerOffers) ? data.ownerOffers : []),
          acceptedOffer: data.acceptedOffer,
          acceptedBy: data.acceptedBy || data.ownerName,
          offeredPrice: data.offeredPrice || data.totalAmount || 250,
          createdAt: data.createdAt,
        });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'trailerRequests');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Subscribes to single trailer request by ID
 */
export function subscribeToSingleTrailerRequest(
  requestId: string,
  callback: (request: TrailerRequestDoc | null) => void
): Unsubscribe {
  if (!db || !requestId || isQuotaExceeded) return () => {};
  try {
    const docRef = doc(db, 'trailerRequests', requestId);
    return onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        callback({
          id: docSnap.id,
          requesterId: data.requesterId || data.riderId || '',
          requesterName: data.requesterName || data.riderName || 'Client',
          requesterPhone: data.requesterPhone || data.riderPhone || data.phone || '+27 82 000 0000',
          trailerType: data.trailerType || data.trailerName || 'Luggage Trailer',
          durationType: data.durationType || (data.hireDurationType ? data.hireDurationType + 's' : 'days') as any,
          durationQty: data.durationQty || data.hireUnits || 1,
          startDateTime: data.startDateTime || data.timestamp || 'Immediate',
          loadDesc: data.loadDesc || 'Cargo / General Goods',
          pickup: data.pickup || data.location || 'Pickup Location',
          drop: data.drop || 'Usage Area',
          pickupLatLng: data.pickupLatLng,
          dropLatLng: data.dropLatLng,
          status: data.status || 'pending',
          offers: Array.isArray(data.offers) ? data.offers : (Array.isArray(data.ownerOffers) ? data.ownerOffers : []),
          acceptedOffer: data.acceptedOffer,
          acceptedBy: data.acceptedBy || data.ownerName,
          offeredPrice: data.offeredPrice || data.totalAmount || 250,
          createdAt: data.createdAt,
        });
      } else {
        callback(null);
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, `trailerRequests/${requestId}`);
    });
  } catch {
    return () => {};
  }
}

/**
 * Submits or updates an Owner Offer on a Towing or Trailer Request (like driver bidding)
 * If the owner already submitted an offer, it updates it in the offers array without creating a duplicate.
 */
export async function submitOwnerOfferToRequest(
  collectionName: 'towingRequests' | 'trailerRequests',
  requestId: string,
  offer: OwnerBidOffer
): Promise<void> {
  if (!db || !requestId || isQuotaExceeded) return;
  try {
    const docRef = doc(db, collectionName, requestId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) return;

    const data = snap.data();
    const existingOffers: OwnerBidOffer[] = Array.isArray(data.offers) ? [...data.offers] : [];

    // Check if owner already has an offer in the array
    const existingIndex = existingOffers.findIndex(
      (o) => o.ownerId === offer.ownerId || (o.ownerName === offer.ownerName && o.ownerPhone === offer.ownerPhone)
    );

    if (existingIndex >= 0) {
      // Update existing offer (up/down bidding)
      existingOffers[existingIndex] = {
        ...existingOffers[existingIndex],
        ...offer,
        createdAt: Date.now(),
      };
    } else {
      // Add new offer
      existingOffers.push({
        ...offer,
        createdAt: Date.now(),
      });
    }

    await updateDoc(docRef, {
      offers: existingOffers,
      status: 'offers_received',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${collectionName}/${requestId}`);
  }
}

/**
 * Requester accepts an Owner's offer
 * Marks the request as accepted, assigns acceptedOffer, marks other offers rejected
 */
export async function acceptOwnerOfferOnRequest(
  collectionName: 'towingRequests' | 'trailerRequests',
  requestId: string,
  selectedOffer: OwnerBidOffer
): Promise<void> {
  if (!db || !requestId || isQuotaExceeded) return;
  try {
    const docRef = doc(db, collectionName, requestId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) return;

    const data = snap.data();
    const existingOffers: OwnerBidOffer[] = Array.isArray(data.offers) ? [...data.offers] : [];

    const updatedOffers = existingOffers.map((o) => ({
      ...o,
      status: (o.id === selectedOffer.id || o.ownerId === selectedOffer.ownerId ? 'accepted' : 'rejected') as any,
    }));

    await updateDoc(docRef, {
      offers: updatedOffers,
      acceptedOffer: selectedOffer,
      acceptedBy: selectedOffer.ownerName,
      status: 'accepted',
      updatedAt: serverTimestamp(),
    });

    // Also update trips record if exists
    try {
      const tripRef = doc(db, 'trips', requestId);
      await updateDoc(tripRef, {
        status: 'accepted',
        driverId: selectedOffer.ownerId,
        driverName: selectedOffer.ownerName,
        driverPhone: selectedOffer.ownerPhone,
        total: selectedOffer.price,
        updatedAt: serverTimestamp(),
      });
    } catch {}
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${collectionName}/${requestId}`);
  }
}

/**
 * Declines / cancels a towing or trailer request
 */
export async function cancelOrDeclineAssetRequest(
  collectionName: 'towingRequests' | 'trailerRequests',
  requestId: string,
  newStatus: 'cancelled' | 'declined' = 'cancelled'
): Promise<void> {
  if (!db || !requestId || isQuotaExceeded) return;
  try {
    const docRef = doc(db, collectionName, requestId);
    await updateDoc(docRef, {
      status: newStatus,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${collectionName}/${requestId}`);
  }
}

/**
 * Saves a Towing Company registration to Firestore `assetOwners` collection
 */
export async function saveTowingCompanyToFirestore(companyData: {
  id: string;
  companyName: string;
  contactPerson: string;
  phone: string;
  fleetSize: string;
  coverageArea: string;
  is247: boolean;
  servicesOffered: string[];
  rating: number;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'assetOwners', companyData.id);
    await setDoc(docRef, {
      ...companyData,
      type: 'towing',
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `assetOwners/${companyData.id}`);
  }
}

/**
 * Subscribes to real-time asset owners from Firestore `assetOwners` collection
 */
export function subscribeToAssetOwners(callback: (owners: any[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'assetOwners');
    return onSnapshot(colRef, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'assetOwners');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Saves a trailer to Firestore `trailers` collection
 */
export async function saveTrailerToFirestore(trailerData: {
  id: string;
  name: string;
  kind: string;
  size: string;
  imageUrl: string;
  pricePerHour: number;
  pricePerDay: number;
  pricePerWeek: number;
  pricePerMonth: number;
  location: string;
  deposit: number;
  deliveryAvailable: boolean;
  deliveryFee: number;
  ownerName: string;
  ownerPhone: string;
  rating: number;
  totalTrips: number;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'trailers', trailerData.id);
    await setDoc(docRef, {
      ...trailerData,
      createdAt: serverTimestamp(),
    }, { merge: true });

    // Also record in assetOwners
    const assetRef = doc(db, 'assetOwners', trailerData.id);
    await setDoc(assetRef, {
      id: trailerData.id,
      name: trailerData.name,
      ownerName: trailerData.ownerName,
      ownerPhone: trailerData.ownerPhone,
      type: 'trailer',
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trailers/${trailerData.id}`);
  }
}

/**
 * Subscribes to real-time trailers from Firestore `trailers` collection
 */
export function subscribeToTrailers(callback: (trailers: any[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'trailers');
    return onSnapshot(colRef, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'trailers');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Saves a trailer hire booking to Firestore `trailer_requests` / `trips` collection
 */
export async function saveTrailerBookingToFirestore(bookingData: {
  id: string;
  trailerId: string;
  trailerName: string;
  ownerName: string;
  ownerPhone: string;
  hireDurationType: string;
  hireUnits: number;
  hireDeliveryChoice: string;
  totalAmount: number;
  offeredPrice?: number;
  ownerOffers?: any[];
  deposit: number;
  riderId: string;
  riderName: string;
  riderPhone?: string;
  status: string;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'trailerRequests', bookingData.id);
    await setDoc(docRef, {
      ...bookingData,
      serviceType: 'trailer_hiring',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });

    // Also save in trips
    const tripRef = doc(db, 'trips', bookingData.id);
    await setDoc(tripRef, {
      ...bookingData,
      serviceType: 'trailer_hiring',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trailerRequests/${bookingData.id}`);
  }
}

/**
 * Subscribes to real-time trailer hire requests from Firestore
 */
export function subscribeToTrailerBookings(callback: (bookings: any[]) => void): Unsubscribe {
  return subscribeToTrailerRequests((list) => {
    callback(list as any);
  });
}

/**
 * Updates status of a towing request in Firestore
 */
export async function updateTowingRequestStatus(
  requestId: string,
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled',
  extraData?: Record<string, any>
) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'towingRequests', requestId);
    await updateDoc(docRef, {
      status,
      ...(extraData || {}),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `towingRequests/${requestId}`);
  }
}

/**
 * Updates status of a trailer hire request in Firestore
 */
export async function updateTrailerHireRequestStatus(
  requestId: string,
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled',
  extraData?: Record<string, any>
) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'trailerRequests', requestId);
    await updateDoc(docRef, {
      status,
      ...(extraData || {}),
      updatedAt: serverTimestamp(),
    }).catch(async () => {
      const fallbackRef = doc(db, 'trailer_requests', requestId);
      await updateDoc(fallbackRef, {
        status,
        ...(extraData || {}),
        updatedAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trailerRequests/${requestId}`);
  }
}

/**
 * Initializes/Syncs user profile, wallet balance, and trips count in Firestore
 */
export async function syncUserWalletAndTrips(uid: string, walletBalance: number, totalTrips: number) {
  if (!db || !uid || isQuotaExceeded) return;
  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, {
      walletBalance,
      totalTrips,
      lastActive: serverTimestamp(),
    }, { merge: true });

    const walletRef = doc(db, 'wallets', uid);
    await setDoc(walletRef, {
      uid,
      balance: walletBalance,
      currency: 'ZAR',
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
  }
}

/**
 * Subscribes to real-time trips and wallet for a given user UID from Firestore
 */
export function subscribeUserTripsAndWallet(
  uid: string,
  onUpdate: (data: { tripsCount: number; walletBalance: number; userTrips: RideRequest[] }) => void
): Unsubscribe {
  if (!db || !uid || isQuotaExceeded) {
    onUpdate({ tripsCount: 0, walletBalance: 0, userTrips: [] });
    return () => {};
  }

  try {
    let currentTrips: RideRequest[] = [];
    let currentBalance: number = 0;

    const tripsRef = collection(db, 'trips');
    const qTrips = query(tripsRef, where('userId', '==', uid));

    const unsubTrips = onSnapshot(
      qTrips,
      (snapshot) => {
        currentTrips = [];
        snapshot.forEach((d) => {
          currentTrips.push({ id: d.id, ...d.data() } as RideRequest);
        });
        onUpdate({ tripsCount: currentTrips.length, walletBalance: currentBalance, userTrips: currentTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `trips (user=${uid})`);
      }
    );

    const walletRef = doc(db, 'wallets', uid);
    const unsubWallet = onSnapshot(
      walletRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (typeof data.balance === 'number') {
            currentBalance = data.balance;
          } else if (typeof data.walletBalance === 'number') {
            currentBalance = data.walletBalance;
          }
        }
        onUpdate({ tripsCount: currentTrips.length, walletBalance: currentBalance, userTrips: currentTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `wallets/${uid}`);
      }
    );

    const userRef = doc(db, 'users', uid);
    const unsubUser = onSnapshot(
      userRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (typeof data.walletBalance === 'number' && currentBalance === 0) {
            currentBalance = data.walletBalance;
          }
        }
        onUpdate({ tripsCount: currentTrips.length, walletBalance: currentBalance, userTrips: currentTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `users/${uid}`);
      }
    );

    return () => {
      unsubTrips();
      unsubWallet();
      unsubUser();
    };
  } catch {
    return () => {};
  }
}

/**
 * Subscribes to real-time daily earnings and trips count for a driver from Firestore `trips` collection
 */
export function subscribeDriverDailyEarnings(
  driverId: string,
  onUpdate: (data: { earningsToday: number; tripsToday: number; totalEarnings: number; totalTrips: number }) => void
): Unsubscribe {
  if (!db || !driverId || isQuotaExceeded) {
    onUpdate({ earningsToday: 0, tripsToday: 0, totalEarnings: 0, totalTrips: 0 });
    return () => {};
  }

  try {
    const tripsRef = collection(db, 'trips');
    const qDriverTrips = query(tripsRef, where('driverId', '==', driverId));

    return onSnapshot(
      qDriverTrips,
      (snapshot) => {
        let earningsToday = 0;
        let tripsToday = 0;
        let totalEarnings = 0;
        let totalTrips = 0;

        const now = new Date();
        const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

        snapshot.forEach((d) => {
          const trip = d.data();
          const fare = Number(trip.offeredFare || trip.amount || trip.fare || 0);
          let tripTime = 0;

          if (trip.createdAt?.toMillis) {
            tripTime = trip.createdAt.toMillis();
          } else if (typeof trip.createdAt === 'number') {
            tripTime = trip.createdAt;
          } else if (trip.date) {
            tripTime = new Date(trip.date).getTime();
          }

          totalTrips += 1;
          totalEarnings += fare;

          if (tripTime >= startOfDay) {
            earningsToday += fare;
            tripsToday += 1;
          }
        });

        onUpdate({ earningsToday, tripsToday, totalEarnings, totalTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `trips (driver=${driverId})`);
        onUpdate({ earningsToday: 0, tripsToday: 0, totalEarnings: 0, totalTrips: 0 });
      }
    );
  } catch {
    return () => {};
  }
}

export async function updateOwnerRatingInFirestore(
  ownerId: string,
  rating: number,
  tags: string[],
  comment: string,
  serviceType: 'towing' | 'trailer'
): Promise<boolean> {
  if (!db || isQuotaExceeded) return true;
  try {
    const reviewsRef = collection(db, 'ownerReviews');
    await addDoc(reviewsRef, {
      ownerId,
      rating,
      tags,
      comment,
      serviceType,
      createdAt: serverTimestamp(),
    });

    const ownerRef = doc(db, 'assetOwners', ownerId);
    const ownerSnap = await getDoc(ownerRef);
    if (ownerSnap.exists()) {
      const currentData = ownerSnap.data();
      const currentRating = currentData.rating || 4.8;
      const currentTrips = currentData.jobsCount || 42;
      const newCount = currentTrips + 1;
      const newRating = Number(((currentRating * currentTrips + rating) / newCount).toFixed(1));

      await updateDoc(ownerRef, {
        rating: newRating,
        jobsCount: newCount,
        updatedAt: serverTimestamp(),
      });
    }
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `ownerReviews`);
    return false;
  }
}

export {
  paystackInit,
  calculateCommissionSplit,
  recordPaystackSuccessInFirestore,
  runPaystackCommissionTest
} from './paystackService';

import { auth, db } from '../firebase';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as fbSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { UserProfile } from '../types';

export const AUTH_TOKEN_KEY = 'zolta_auth_token';
export const AUTH_USER_KEY = 'zolta_user_profile';

export const googleProvider = new GoogleAuthProvider();

export interface AuthResult {
  success: boolean;
  user?: UserProfile;
  error?: string;
}

// Convert raw Firebase error codes into human-friendly messages
export function formatAuthError(error: any): string {
  const code = error?.code || '';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
      return 'Incorrect email or password. Please check your credentials.';
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Please sign in.';
    case 'auth/weak-password':
      return 'Password should be at least 6 characters.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a moment and try again.';
    case 'auth/network-request-failed':
      return 'Network connection error. Please check your internet.';
    case 'auth/popup-closed-by-user':
      return 'Google sign-in popup was closed.';
    default:
      return error?.message || 'Authentication failed. Please try again.';
  }
}

// Sync user record to Firestore 'users' & 'wallets' collections
export async function syncUserToFirestore(user: UserProfile): Promise<void> {
  try {
    const userRef = doc(db, 'users', user.id);
    await setDoc(
      userRef,
      {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        mode: user.mode,
        rating: user.rating,
        avatar: user.avatar,
        walletBalance: user.walletBalance || 0,
        lastLoginAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    const walletRef = doc(db, 'wallets', user.id);
    const walletSnap = await getDoc(walletRef);
    if (!walletSnap.exists()) {
      await setDoc(walletRef, {
        userId: user.id,
        balance: 0,
        createdAt: serverTimestamp(),
      });
    }
  } catch (err) {
    console.warn('Firestore user sync fallback (offline or demo mode):', err);
  }
}

// Email/Password Sign In (Free, Zero-Billing Firebase Spark Tier)
export async function loginWithEmail(email: string, pass: string): Promise<AuthResult> {
  try {
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    const uid = cred.user.uid;
    const displayName = cred.user.displayName || email.split('@')[0];
    const userEmail = cred.user.email || email;

    const userProfile: UserProfile = {
      id: uid,
      name: displayName,
      email: userEmail,
      phone: cred.user.phoneNumber || '',
      mode: 'rider',
      rating: 5.0,
      totalTrips: 0,
      isDriverVerified: false,
      avatar: cred.user.photoURL || '',
      walletBalance: 0,
      joinedDate: 'August 2026',
    };

    localStorage.setItem(AUTH_TOKEN_KEY, 'zolta_jwt_' + uid + '_' + Date.now());
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(userProfile));
    await syncUserToFirestore(userProfile);

    return { success: true, user: userProfile };
  } catch (error: any) {
    return { success: false, error: formatAuthError(error) };
  }
}

// Email/Password Registration (Free, Zero-Billing Firebase Spark Tier)
export async function registerWithEmail(name: string, email: string, pass: string): Promise<AuthResult> {
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    const uid = cred.user.uid;

    const userProfile: UserProfile = {
      id: uid,
      name: name || email.split('@')[0],
      email: email,
      phone: '',
      mode: 'rider',
      rating: 5.0,
      totalTrips: 0,
      isDriverVerified: false,
      avatar: cred.user?.photoURL || '',
      walletBalance: 0,
      joinedDate: 'August 2026',
    };

    localStorage.setItem(AUTH_TOKEN_KEY, 'zolta_jwt_' + uid + '_' + Date.now());
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(userProfile));
    await syncUserToFirestore(userProfile);

    return { success: true, user: userProfile };
  } catch (error: any) {
    return { success: false, error: formatAuthError(error) };
  }
}

// Send Password Reset Email (Free, Zero-Billing Firebase Spark Tier)
export async function resetPasswordEmail(email: string): Promise<AuthResult> {
  try {
    await sendPasswordResetEmail(auth, email);
    return { success: true };
  } catch (error: any) {
    return { success: false, error: formatAuthError(error) };
  }
}

// Google Sign In
export async function loginWithGoogle(): Promise<AuthResult> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    if (!result.user) {
      return { success: false, error: 'Google sign in was not completed' };
    }
    const uid = result.user.uid;
    const email = result.user.email || '';
    const displayName = result.user.displayName || (email ? email.split('@')[0] : 'ZOLTA User');
    const photo = result.user.photoURL || '';

    const userProfile: UserProfile = {
      id: uid,
      name: displayName,
      email: email,
      phone: result.user.phoneNumber || '',
      mode: 'rider',
      rating: 5.0,
      totalTrips: 0,
      isDriverVerified: false,
      avatar: photo,
      walletBalance: 0,
      joinedDate: 'August 2026',
    };

    localStorage.setItem(AUTH_TOKEN_KEY, 'zolta_google_jwt_' + uid);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(userProfile));
    await syncUserToFirestore(userProfile);

    return { success: true, user: userProfile };
  } catch (error: any) {
    return { success: false, error: formatAuthError(error) };
  }
}

// Phone Number OTP Verification (Local Instant Validation)
export async function verifyPhoneOtp(phone: string, otpCode: string): Promise<AuthResult> {
  if (!otpCode || otpCode.length < 4) {
    return { success: false, error: 'Please enter a valid 4-digit code' };
  }

  const uid = 'phone_' + phone.replace(/\D/g, '');
  const userProfile: UserProfile = {
    id: uid,
    name: phone,
    phone: phone,
    email: `${phone.replace(/\D/g, '')}@zolta.co.za`,
    mode: 'rider',
    rating: 5.0,
    totalTrips: 0,
    isDriverVerified: false,
    avatar: '',
    walletBalance: 0,
    joinedDate: 'August 2026',
  };

  localStorage.setItem(AUTH_TOKEN_KEY, 'zolta_phone_jwt_' + uid);
  localStorage.setItem(AUTH_USER_KEY, JSON.stringify(userProfile));
  await syncUserToFirestore(userProfile);

  return { success: true, user: userProfile };
}

// Logout
export async function performSignOut(): Promise<void> {
  try {
    await fbSignOut(auth);
  } catch {}
  localStorage.removeItem(AUTH_TOKEN_KEY);
  localStorage.removeItem(AUTH_USER_KEY);
  localStorage.removeItem('zolta_active_ride');
}

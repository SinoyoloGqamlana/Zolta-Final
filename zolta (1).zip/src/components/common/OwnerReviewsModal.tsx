import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, X, Check, ShieldCheck, ThumbsUp, MessageSquare } from 'lucide-react';

interface OwnerReviewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  rating?: number;
  jobsCount?: number;
  ownerName?: string;
}

const DEMO_REVIEWS = [
  {
    id: 'rev_1',
    user: 'Siyabonga Mkhize',
    rating: 5,
    date: '2 days ago',
    comment: 'Arrived within 12 minutes on the N2 highway! Hydraulic rollback was clean and driver was very professional.',
    tags: ['On Time', 'Professional', 'Quick Dispatch'],
  },
  {
    id: 'rev_2',
    user: 'Theresa Van Zyl',
    rating: 5,
    date: '5 days ago',
    comment: 'Venter 7ft trailer was clean, sealed and roadworthy tested. Smoothest rental process ever.',
    tags: ['Good Equipment', 'Clean Trailer', 'Professional'],
  },
  {
    id: 'rev_3',
    user: 'David Ndlovu',
    rating: 4.8,
    date: '1 week ago',
    comment: 'Great communication and fair pricing for car transporter hire.',
    tags: ['Friendly Service', 'Good Equipment'],
  },
];

export const OwnerReviewsModal: React.FC<OwnerReviewsModalProps> = ({
  isOpen,
  onClose,
  rating = 4.9,
  jobsCount = 43,
  ownerName = 'Verified ZOLTA Operator',
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 15 }}
          className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full border border-amber-300 shadow-2xl space-y-4 text-neutral-900 select-none font-sans max-h-[85vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-[#FFCC00] text-black flex items-center justify-center font-black">
                <Star className="w-5 h-5 fill-black" />
              </div>
              <div>
                <h3 className="font-black text-base text-neutral-900 leading-tight">
                  Verified Owner Reviews
                </h3>
                <p className="text-[10px] font-mono text-neutral-500">
                  {ownerName} • South Africa 🇿🇦
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition"
            >
              <X className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

          {/* Rating Big Badge Banner */}
          <div className="bg-neutral-900 text-white rounded-2xl p-4 flex items-center justify-between border border-neutral-800">
            <div>
              <div className="flex items-center gap-1.5 text-[#FFCC00] font-mono font-black text-2xl">
                <Star className="w-6 h-6 fill-[#FFCC00]" />
                <span>{rating.toFixed(1)}</span>
              </div>
              <p className="text-xs text-neutral-300 font-mono mt-0.5">
                Based on {jobsCount} Completed Community Jobs
              </p>
            </div>
            <div className="flex items-center gap-1 bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full text-[10px] font-bold font-mono border border-emerald-500/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% VERIFIED</span>
            </div>
          </div>

          {/* Reviews List */}
          <div className="space-y-3 pt-1">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-500 block">
              Recent Customer Ratings & Feedback
            </span>

            {DEMO_REVIEWS.map((rev) => (
              <div
                key={rev.id}
                className="bg-neutral-50 rounded-2xl p-3.5 border border-neutral-200 space-y-2 font-sans"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-amber-200 text-amber-900 font-black text-xs flex items-center justify-center font-mono">
                      {rev.user.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-neutral-900">{rev.user}</h4>
                      <span className="text-[9px] font-mono text-neutral-400">{rev.date}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-0.5 bg-amber-100 text-amber-950 px-2 py-0.5 rounded-lg text-xs font-mono font-black border border-amber-300">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                    <span>{rev.rating.toFixed(1)}</span>
                  </div>
                </div>

                <p className="text-xs text-neutral-700 leading-relaxed font-medium">
                  "{rev.comment}"
                </p>

                <div className="flex flex-wrap gap-1 pt-1">
                  {rev.tags.map((tag) => (
                    <span
                      key={tag}
                      className="bg-amber-100 text-amber-900 font-mono text-[9px] font-bold px-2 py-0.5 rounded-md border border-amber-200"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Close Action */}
          <button
            type="button"
            onClick={onClose}
            className="w-full bg-neutral-100 hover:bg-neutral-200 text-neutral-900 font-bold text-xs py-2.5 rounded-xl uppercase font-mono transition"
          >
            CLOSE REVIEWS
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldAlert,
  PhoneCall,
  Share2,
  CheckCircle2,
  Copy,
  Shield,
} from 'lucide-react';

export const SosModal: React.FC = () => {
  const { isSosModalOpen, setSosModalOpen, activeRide } = useApp();
  const [copiedLink, setCopiedLink] = useState(false);
  const [emergencyAlertActive, setEmergencyAlertActive] = useState(false);

  if (!isSosModalOpen) return null;

  const handleCopyLocation = () => {
    const pShort = activeRide?.pickup?.shortName || activeRide?.pickup?.address || 'Pickup';
    const dShort = activeRide?.dropoff?.shortName || activeRide?.dropoff?.address || 'Dropoff';
    const coords = activeRide
      ? `${pShort} to ${dShort}`
      : 'Sandton City, Johannesburg (-26.1076, 28.0531)';
    const liveTrackingUrl = `https://zolta.app/sos/live?ride=${activeRide?.id || 'alert'}&loc=${encodeURIComponent(coords)}`;
    navigator.clipboard?.writeText(liveTrackingUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleTriggerZoltaEmergency = () => {
    setEmergencyAlertActive(true);
  };

  const handleCallEmergency = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  return (
    <div id="zolta-sos-modal-overlay" className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white border-2 border-red-500 text-neutral-900 w-full max-w-md rounded-3xl p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          id="btn-close-sos-modal"
          onClick={() => setSosModalOpen(false)}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-black hover:bg-neutral-100 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* SOS Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-red-50 border border-red-200 flex items-center justify-center text-red-600">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-black tracking-tight text-red-600">EMERGENCY SOS</h3>
              <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                24/7
              </span>
            </div>
            <p className="text-xs text-neutral-500 font-medium">South Africa Rapid Security & Emergency Help</p>
          </div>
        </div>

        {/* Big Alert Trigger Button */}
        <div className="bg-red-50 border border-red-200 rounded-3xl p-5 mb-5 text-center relative overflow-hidden">
          <div className="flex items-center justify-center gap-1.5 text-red-700 font-bold text-xs uppercase tracking-wider mb-1">
            <Shield className="w-4 h-4 text-red-600" />
            <span>Instant Safety Broadcast</span>
          </div>

          <p className="text-xs text-neutral-600 mb-4 leading-relaxed">
            Broadcasts your live GPS coordinates to emergency contacts and nearby support agents.
          </p>

          <button
            type="button"
            id="btn-sos-trigger-dispatch"
            onClick={handleTriggerZoltaEmergency}
            className={`w-full py-3.5 px-5 rounded-2xl font-black text-xs tracking-wide flex items-center justify-center gap-2 transition active:scale-95 shadow-xs ${
              emergencyAlertActive
                ? 'bg-red-800 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>{emergencyAlertActive ? 'EMERGENCY BEACON ACTIVE' : 'BROADCAST EMERGENCY ALERT'}</span>
          </button>

          {emergencyAlertActive && (
            <div className="mt-3 p-2.5 bg-white border border-red-300 rounded-xl text-left text-xs text-red-700 flex items-center gap-2 shadow-xs">
              <CheckCircle2 className="w-4 h-4 text-red-600 flex-shrink-0" />
              <span>Live beacon transmitted. Emergency responders notified.</span>
            </div>
          )}
        </div>

        {/* Direct Speed Dial Services */}
        <div className="space-y-2.5 mb-5">
          <span className="text-[11px] font-black text-neutral-500 uppercase tracking-wider block">
            National South Africa Emergency Hotlines
          </span>

          {/* CALL ZOLTA 24/7 RAPID SECURITY */}
          <div className="bg-yellow-50 border border-yellow-300 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#FFD60A] text-black flex items-center justify-center font-black text-xs">
                Z
              </div>
              <div>
                <h4 className="font-bold text-xs text-black">ZOLTA Rapid Response</h4>
                <p className="font-mono text-[10px] text-neutral-600">0800 096 582 • Armed Backup</p>
              </div>
            </div>

            <button
              type="button"
              id="btn-call-zolta-sos"
              onClick={() => handleCallEmergency('0800096582')}
              className="bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-1.5 px-3 rounded-xl flex items-center gap-1 shadow-xs border border-yellow-300"
            >
              <PhoneCall className="w-3 h-3" />
              <span>0800 096 582</span>
            </button>
          </div>

          {/* SAPS Police 10111 */}
          <div className="bg-neutral-50 border border-neutral-200 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center font-black text-xs">
                10111
              </div>
              <div>
                <h4 className="font-bold text-xs text-black">Police Flying Squad (SAPS)</h4>
                <p className="text-[10px] text-neutral-500">Nationwide Police Rapid Response</p>
              </div>
            </div>

            <button
              type="button"
              id="btn-call-police-10111"
              onClick={() => handleCallEmergency('10111')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-1.5 px-3 rounded-xl flex items-center gap-1 shadow-xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Call 10111</span>
            </button>
          </div>

          {/* Ambulance 10177 */}
          <div className="bg-neutral-50 border border-neutral-200 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center font-black text-xs">
                10177
              </div>
              <div>
                <h4 className="font-bold text-xs text-black">Ambulance / Paramedics</h4>
                <p className="text-[10px] text-neutral-500">Medical Emergency Dispatch</p>
              </div>
            </div>

            <button
              type="button"
              id="btn-call-ambulance-10177"
              onClick={() => handleCallEmergency('10177')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-1.5 px-3 rounded-xl flex items-center gap-1 shadow-xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Call 10177</span>
            </button>
          </div>

          {/* Fire & Rescue 021 480 7700 */}
          <div className="bg-neutral-50 border border-neutral-200 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-50 border border-red-200 text-red-700 flex items-center justify-center font-black text-xs">
                FIRE
              </div>
              <div>
                <h4 className="font-bold text-xs text-black">Fire & Rescue Service</h4>
                <p className="text-[10px] text-neutral-500">021 480 7700 • Emergency Ops</p>
              </div>
            </div>

            <button
              type="button"
              id="btn-call-fire-dept"
              onClick={() => handleCallEmergency('0214807700')}
              className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-1.5 px-3 rounded-xl flex items-center gap-1 shadow-xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Call Fire</span>
            </button>
          </div>

          {/* Cell Emergency 112 */}
          <div className="bg-neutral-50 border border-neutral-200 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center font-black text-xs">
                112
              </div>
              <div>
                <h4 className="font-bold text-xs text-black">General Cell Emergency</h4>
                <p className="text-[10px] text-neutral-500">Toll-free from any cellphone</p>
              </div>
            </div>

            <button
              type="button"
              id="btn-call-112"
              onClick={() => handleCallEmergency('112')}
              className="bg-amber-500 hover:bg-amber-600 text-black font-bold text-xs py-1.5 px-3 rounded-xl flex items-center gap-1 shadow-xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Call 112</span>
            </button>
          </div>

          {/* Share Live Location link */}
          <div className="bg-neutral-50 border border-neutral-200 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#FFD60A] text-black flex items-center justify-center">
                <Share2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-black">Share Live GPS Tracking</h4>
                <p className="text-[10px] text-neutral-500">WhatsApp / SMS live pin to family</p>
              </div>
            </div>

            <button
              type="button"
              id="btn-copy-live-sos-link"
              onClick={handleCopyLocation}
              className="bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-1.5 px-3 rounded-xl flex items-center gap-1 shadow-xs border border-yellow-300"
            >
              {copiedLink ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Copied' : 'Share'}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { auth, db } from '../../firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { AppView } from '../../types';
import {
  X,
  Clock,
  Wallet,
  ShieldAlert,
  Car,
  Truck,
  Settings,
  LogOut,
  FileText,
  ChevronRight,
  ShieldCheck,
  Share2,
  Layers,
  SlidersHorizontal,
} from 'lucide-react';

export const SidebarDrawer: React.FC = () => {
  const {
    isSidebarOpen,
    setSidebarOpen,
    user,
    mode,
    setMode,
    currentView,
    setCurrentView,
    logout,
    isAuthenticated,
    setAuthModalOpen,
    ridesHistory,
  } = useApp();

  const [walletBalance, setWalletBalance] = useState<number>(0);

  useEffect(() => {
    const currentUser = auth?.currentUser;
    const uid = currentUser?.uid || user?.id;
    if (!db || !uid) {
      setWalletBalance(0);
      return;
    }

    const walletRef = doc(db, 'wallets', uid);
    const unsub = onSnapshot(
      walletRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (typeof data.balance === 'number') {
            setWalletBalance(data.balance);
          } else if (typeof data.walletBalance === 'number') {
            setWalletBalance(data.walletBalance);
          } else {
            setWalletBalance(0);
          }
        } else {
          setWalletBalance(0);
        }
      },
      (err) => {
        console.warn('Error fetching wallet doc from Firestore:', err);
        setWalletBalance(0);
      }
    );

    return () => unsub();
  }, [user?.id]);

  const formatCurrency = (val: number) => `R ${Number(val || 0).toFixed(2)}`;

  if (!isSidebarOpen) return null;

  const navigateTo = (view: AppView) => {
    if (view === 'home') {
      setMode('rider');
    }
    setCurrentView(view);
    setSidebarOpen(false);
  };

  const handleSwitchMode = (newMode: 'rider' | 'driver') => {
    setMode(newMode);
    setCurrentView('home');
    setSidebarOpen(false);
  };

  return (
    <div
      id="sidebar-drawer-overlay"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex animate-in fade-in duration-200"
      onClick={() => setSidebarOpen(false)}
    >
      <motion.div
        initial={{ x: '-100%' }}
        animate={{ x: 0 }}
        exit={{ x: '-100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white text-neutral-900 border-r border-neutral-200 w-full max-w-xs sm:max-w-sm h-full shadow-2xl flex flex-col justify-between p-5 relative overflow-y-auto"
      >
        <div>
          {/* Top Brand & Close */}
          <div className="flex items-center justify-between mb-4">
            <button
              type="button"
              onClick={() => navigateTo('home')}
              className="flex items-center gap-2 text-left"
            >
              <div className="w-8 h-8 rounded-xl bg-black text-[#FFCC00] font-black text-lg flex items-center justify-center shadow-xs">
                Z
              </div>
              <span className="font-black text-lg text-black tracking-wider font-sans">ZOLTA</span>
            </button>
            <button
              type="button"
              id="btn-close-sidebar"
              onClick={() => setSidebarOpen(false)}
              className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-xl transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* User Profile Header */}
          {isAuthenticated && (user.id || auth?.currentUser) ? (
            <div className="bg-amber-50/60 rounded-2xl p-3.5 border border-amber-200/80 mb-4">
              <div className="flex items-center gap-3 mb-3">
                {user.avatar || auth?.currentUser?.photoURL ? (
                  <img
                    src={user.avatar || auth?.currentUser?.photoURL || ''}
                    alt={user.name || 'User'}
                    className="w-11 h-11 rounded-full object-cover border-2 border-[#FFCC00] flex-shrink-0 shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-11 h-11 rounded-full bg-[#FFCC00] text-black font-black text-xl flex items-center justify-center shadow-xs flex-shrink-0 font-sans">
                    {(user?.shortName || user?.displayName?.charAt(0) || user?.name?.charAt(0) || user?.email?.charAt(0) || "Z").toUpperCase()}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-black text-sm text-neutral-900 tracking-tight truncate">
                      {user.name || auth?.currentUser?.displayName || (user.email ? user.email.split('@')[0] : 'User')}
                    </h4>
                    <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  </div>
                  <p className="text-[11px] text-neutral-500 truncate font-mono">{user.email || auth?.currentUser?.email || ''}</p>
                  <div className="mt-0.5">
                    <span className="bg-emerald-50 text-emerald-700 border border-emerald-300 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider font-mono">
                      VERIFIED USER
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Mode Toggle */}
              <div className="grid grid-cols-2 gap-1.5 bg-neutral-200/70 p-1 rounded-xl font-mono text-xs">
                <button
                  type="button"
                  id="sidebar-toggle-rider-mode"
                  onClick={() => handleSwitchMode('rider')}
                  className={`py-1.5 px-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                    mode === 'rider' && currentView === 'home'
                      ? 'bg-white text-black shadow-xs'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  <Car className="w-3.5 h-3.5" />
                  <span>Rider Mode</span>
                </button>
                <button
                  type="button"
                  id="sidebar-toggle-driver-mode"
                  onClick={() => handleSwitchMode('driver')}
                  className={`py-1.5 px-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                    mode === 'driver'
                      ? 'bg-[#FFCC00] text-black shadow-xs'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Driver Mode</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 mb-4 text-center">
              <p className="text-xs text-neutral-700 font-mono font-bold mb-2">Sign in to manage your rides & wallet</p>
              <button
                type="button"
                id="btn-sidebar-signin"
                onClick={() => {
                  setSidebarOpen(false);
                  setAuthModalOpen(true);
                }}
                className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-2.5 rounded-xl font-mono shadow-xs transition active:scale-95"
              >
                Sign In / Register
              </button>
            </div>
          )}

          {/* Navigation Menu */}
          <nav className="space-y-1.5">
            {/* My Trips */}
            <button
              type="button"
              id="menu-item-my-trips"
              onClick={() => navigateTo('my_rides')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'my_rides'
                  ? 'bg-neutral-100 border-neutral-300 font-black'
                  : 'bg-white border-neutral-100 hover:bg-neutral-50 hover:border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-neutral-100 flex items-center justify-center text-black">
                  <Clock className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-neutral-900">My Trips</span>
              </div>
              <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-black text-[11px] font-mono flex items-center justify-center shadow-xs">
                {Array.isArray(ridesHistory) ? ridesHistory.length : (user.totalTrips || 0)}
              </span>
            </button>

            {/* My Wallet */}
            <button
              type="button"
              id="menu-item-my-wallet"
              onClick={() => navigateTo('wallet')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'wallet'
                  ? 'bg-neutral-100 border-neutral-300 font-black'
                  : 'bg-white border-neutral-100 hover:bg-neutral-50 hover:border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-neutral-100 flex items-center justify-center text-black">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-neutral-900 block leading-tight">My Wallet</span>
                  <span className="text-[10px] text-neutral-500 font-mono">{formatCurrency(walletBalance)}</span>
                </div>
              </div>
              <span className="text-xs font-black text-black bg-[#FFCC00] px-2.5 py-1 rounded-xl font-mono shadow-xs">
                {formatCurrency(walletBalance)}
              </span>
            </button>

            {/* Help & Safety */}
            <button
              type="button"
              id="menu-item-help-safety"
              onClick={() => navigateTo('safety')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'safety'
                  ? 'bg-neutral-100 border-neutral-300 font-black'
                  : 'bg-white border-neutral-100 hover:bg-neutral-50 hover:border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-neutral-900">Safety Center</span>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-400" />
            </button>

            {/* Ride Preferences */}
            <button
              type="button"
              id="menu-item-ride-preferences"
              onClick={() => navigateTo('ride_preferences')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'ride_preferences'
                  ? 'bg-neutral-100 border-neutral-300 font-black'
                  : 'bg-white border-neutral-100 hover:bg-neutral-50 hover:border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold">
                  <SlidersHorizontal className="w-4 h-4 text-black" />
                </div>
                <div>
                  <span className="text-xs font-bold text-neutral-900 block leading-tight">Ride Preferences</span>
                  <span className="text-[10px] text-neutral-500 font-mono">Driver choice & comfort</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-400" />
            </button>

            {/* Drive With Zolta */}
            <button
              type="button"
              id="menu-item-drive-with-zolta"
              onClick={() => navigateTo('drive_with_zolta')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'drive_with_zolta'
                  ? 'bg-neutral-100 border-neutral-300 font-black'
                  : 'bg-neutral-50 border-neutral-200 hover:bg-neutral-100'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#FFCC00] text-black flex items-center justify-center">
                  <Car className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-black text-neutral-900 block leading-tight">Drive With Zolta</span>
                  <span className="text-[10px] text-neutral-500 font-medium font-mono">Join Verified Drivers</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500" />
            </button>

            {/* Community Services */}
            <div className="pt-2 pb-1 flex items-center justify-between px-1">
              <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase tracking-wider">
                Community Services
              </span>
            </div>

            {/* Asset Owners Portal (For Owners) */}
            <button
              type="button"
              id="menu-item-asset-owners"
              onClick={() => navigateTo('asset_owner')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'asset_owner'
                  ? 'bg-neutral-900 text-white border-neutral-900 font-black'
                  : 'bg-[#FFFBEB] border-amber-300 hover:bg-amber-100/60 shadow-2xs'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                  currentView === 'asset_owner' ? 'bg-[#FFCC00] text-black' : 'bg-neutral-900 text-[#FFCC00]'
                }`}>
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className={`text-xs font-black block leading-tight ${
                      currentView === 'asset_owner' ? 'text-white' : 'text-neutral-900'
                    }`}>
                      Asset Owners Portal
                    </span>
                    <span className="bg-[#FFCC00] text-black font-mono text-[8px] font-black px-1.5 py-0.2 rounded-md shadow-2xs">
                      OWNER
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono ${
                    currentView === 'asset_owner' ? 'text-amber-300' : 'text-amber-900 font-semibold'
                  }`}>
                    Manage Towing & Trailer Assets
                  </span>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${currentView === 'asset_owner' ? 'text-white' : 'text-neutral-400'}`} />
            </button>

            {/* Invite Friends */}
            <button
              type="button"
              id="menu-item-invite"
              onClick={() => navigateTo('invite')}
              className={`w-full flex items-center justify-between p-3 rounded-2xl transition text-left border ${
                currentView === 'invite'
                  ? 'bg-neutral-100 border-neutral-300 font-black'
                  : 'bg-white border-neutral-100 hover:bg-neutral-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-neutral-100 flex items-center justify-center text-black">
                  <Share2 className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-neutral-900">Invite Friends</span>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-400" />
            </button>
          </nav>
        </div>

        {/* Bottom Footer */}
        <div className="pt-4 border-t border-neutral-200 space-y-2">
          <div className="flex items-center justify-between px-1">
            <button
              type="button"
              id="btn-sidebar-settings"
              onClick={() => navigateTo('settings')}
              className="text-xs font-bold text-neutral-600 hover:text-black flex items-center gap-1.5 py-1.5 transition"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Settings</span>
            </button>

            <button
              type="button"
              id="btn-sidebar-privacy"
              onClick={() => navigateTo('support')}
              className="text-xs font-bold text-neutral-600 hover:text-black flex items-center gap-1.5 py-1.5 transition"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Privacy & Terms</span>
            </button>
          </div>

          <button
            type="button"
            id="btn-logout"
            onClick={() => {
              logout();
              setSidebarOpen(false);
            }}
            className="w-full text-xs font-bold text-red-600 hover:bg-red-50 py-2.5 px-3 rounded-xl flex items-center justify-between transition border border-red-200"
          >
            <div className="flex items-center gap-2">
              <LogOut className="w-3.5 h-3.5 text-red-600" />
              <span>LOGOUT</span>
            </div>
            <span className="text-[10px] font-bold text-red-500">EXIT</span>
          </button>

          <div className="flex items-center justify-between px-1 pt-1">
            <span className="text-[10px] text-neutral-400 font-mono">
              ZOLTA South Africa
            </span>
            <button
              type="button"
              id="btn-sidebar-delete-account"
              onClick={() => navigateTo('settings')}
              className="text-[11px] font-mono text-red-500 hover:text-red-700 hover:underline"
            >
              Delete Account
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

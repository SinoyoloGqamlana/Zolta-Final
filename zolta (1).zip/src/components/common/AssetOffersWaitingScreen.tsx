import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Radar,
  Star,
  Clock,
  Check,
  X,
  Plus,
  ShieldCheck,
  Phone,
  RotateCcw,
  Truck,
  Package,
  MapPin,
  Car,
  Calendar,
  AlertTriangle,
  ChevronRight,
  CheckCircle2,
} from 'lucide-react';
import { OwnerBidOffer, TowingRequestDoc, TrailerRequestDoc } from '../../types';
import {
  subscribeToSingleTowingRequest,
  subscribeToSingleTrailerRequest,
  acceptOwnerOfferOnRequest,
  cancelOrDeclineAssetRequest,
  submitOwnerOfferToRequest,
} from '../../services/firestoreService';
import {
  getStoredAssetRequests,
  acceptOwnerOfferInStorage,
  updateAssetRequestStatus,
} from '../../services/assetRequestsService';
import { RateOwnerModal } from './RateOwnerModal';

interface AssetOffersWaitingScreenProps {
  type: 'towing' | 'trailer';
  requestId: string;
  initialRequestData?: Partial<TowingRequestDoc & TrailerRequestDoc>;
  onClose: () => void;
  onAccepted?: (offer: OwnerBidOffer) => void;
}

export const AssetOffersWaitingScreen: React.FC<AssetOffersWaitingScreenProps> = ({
  type,
  requestId,
  initialRequestData,
  onClose,
  onAccepted,
}) => {
  const [requestData, setRequestData] = useState<any>(initialRequestData || null);
  const [offers, setOffers] = useState<OwnerBidOffer[]>([]);
  const [acceptedOffer, setAcceptedOffer] = useState<OwnerBidOffer | null>(null);
  const [isCompleted, setIsCompleted] = useState(false);
  const [broadcastRemaining, setBroadcastRemaining] = useState<number>(60);
  const [isTimedOut, setIsTimedOut] = useState<boolean>(false);
  const [isAccepting, setIsAccepting] = useState(false);
  const [isRatingOpen, setIsRatingOpen] = useState(false);

  // 1. Live Firestore Listener for Real-Time Offers
  useEffect(() => {
    if (!requestId) return;

    let unsub: (() => void) | undefined;

    if (type === 'towing') {
      unsub = subscribeToSingleTowingRequest(requestId, (doc) => {
        if (doc) {
          setRequestData(doc);
          if (Array.isArray(doc.offers)) {
            setOffers(doc.offers.filter((o) => o.status !== 'rejected'));
          }
          if (doc.status === 'accepted' && doc.acceptedOffer) {
            setAcceptedOffer(doc.acceptedOffer);
            setIsCompleted(true);
          }
        }
      });
    } else {
      unsub = subscribeToSingleTrailerRequest(requestId, (doc) => {
        if (doc) {
          setRequestData(doc);
          if (Array.isArray(doc.offers)) {
            setOffers(doc.offers.filter((o) => o.status !== 'rejected'));
          }
          if (doc.status === 'accepted' && doc.acceptedOffer) {
            setAcceptedOffer(doc.acceptedOffer);
            setIsCompleted(true);
          }
        }
      });
    }

    // 2. Also listen for localStorage & window custom event sync
    const handleStorageUpdate = (e: any) => {
      const stored = getStoredAssetRequests();
      const match = stored.find((r) => r.id === requestId);
      if (match) {
        setRequestData((prev: any) => ({ ...prev, ...match }));
        if (Array.isArray(match.offers)) {
          setOffers(match.offers.filter((o) => o.status !== 'rejected'));
        }
        if (match.status === 'accepted' && (match as any).acceptedOffer) {
          setAcceptedOffer((match as any).acceptedOffer);
          setIsCompleted(true);
        }
      }
    };

    window.addEventListener('zolta_asset_requests_updated', handleStorageUpdate);
    window.addEventListener('storage', handleStorageUpdate);

    // Initial check from storage
    handleStorageUpdate(null);

    return () => {
      if (unsub) unsub();
      window.removeEventListener('zolta_asset_requests_updated', handleStorageUpdate);
      window.removeEventListener('storage', handleStorageUpdate);
    };
  }, [requestId, type]);

  // Broadcast timer countdown
  useEffect(() => {
    setBroadcastRemaining(60);
    setIsTimedOut(false);

    const timer = setInterval(() => {
      setBroadcastRemaining((prev) => {
        if (prev <= 1) {
          setIsTimedOut(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [requestId]);

  // Handle Accept Offer
  const handleAcceptOffer = async (offer: OwnerBidOffer) => {
    setIsAccepting(true);
    setAcceptedOffer(offer);
    setIsCompleted(true);

    // 1. Update in Firestore
    const colName = type === 'towing' ? 'towingRequests' : 'trailerRequests';
    await acceptOwnerOfferOnRequest(colName, requestId, offer);

    // 2. Update in LocalStorage & dispatch event
    acceptOwnerOfferInStorage(requestId, offer);

    if (onAccepted) {
      onAccepted(offer);
    }
    setIsAccepting(false);
  };

  // Handle Cancel Request
  const handleCancelRequest = async () => {
    const colName = type === 'towing' ? 'towingRequests' : 'trailerRequests';
    await cancelOrDeclineAssetRequest(colName, requestId, 'cancelled');
    updateAssetRequestStatus(requestId, 'cancelled');
    onClose();
  };

  // Handle quick raise offer
  const handleRaiseOffer = async (amount: number) => {
    const currentPrice = Number(requestData?.offeredPrice || (type === 'towing' ? 450 : 250));
    const newPrice = currentPrice + amount;
    setRequestData((prev: any) => ({ ...prev, offeredPrice: newPrice }));
    setBroadcastRemaining(60);
    setIsTimedOut(false);

    // Also simulate test owner offer if none exists to give instant live feedback
    if (offers.length === 0) {
      const demoOwnerId = type === 'towing' ? 'tow_owner_01' : 'trailer_owner_01';
      const demoOffer: OwnerBidOffer = {
        id: `off_${Date.now()}`,
        ownerId: demoOwnerId,
        ownerName: type === 'towing' ? 'Kape Towing & Recovery' : 'Khayelitsha Trailer Depot',
        ownerPhone: '+27 71 884 9210',
        assetType: type,
        assetName: type === 'towing' ? 'Isuzu 4.5T Rollback' : 'Challenger 2.4m Enclosed Trailer',
        price: newPrice,
        eta: type === 'towing' ? '18 mins' : 'Ready for collection today',
        rating: 4.9,
        note: type === 'towing' ? 'Equipped with heavy-duty winch and wheel-lift' : 'Clean, locked, roadworthy tested',
        status: 'pending',
        createdAt: Date.now(),
      };
      const colName = type === 'towing' ? 'towingRequests' : 'trailerRequests';
      submitOwnerOfferToRequest(colName, requestId, demoOffer);
    }
  };

  const isTowing = type === 'towing';

  return (
    <div
      id="asset-offers-waiting-container"
      className="bg-white text-neutral-900 rounded-t-[28px] sm:rounded-2xl shadow-2xl p-4 sm:p-5 border border-neutral-200 max-h-[90vh] overflow-y-auto z-[9999]"
    >
      {/* If Accepted, show Confirmation Screen */}
      {isCompleted && acceptedOffer ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-4 py-2"
        >
          <div className="text-center py-3 bg-emerald-50 rounded-2xl border border-emerald-200 p-4">
            <div className="w-12 h-12 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-2 shadow-md">
              <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
            </div>
            <h3 className="text-lg font-black text-emerald-950">
              {isTowing ? 'Towing Operator Dispatched!' : 'Trailer Booking Confirmed!'}
            </h3>
            <p className="text-xs font-semibold text-emerald-800 mt-0.5">
              {isTowing
                ? 'Your tow truck is en route to your breakdown location.'
                : 'Your trailer is reserved and ready.'}
            </p>
          </div>

          {/* Assigned Owner Card */}
          <div className="bg-neutral-900 text-white rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-black flex items-center justify-center font-black text-base shadow-sm">
                  {isTowing ? <Truck className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-black text-sm text-white">{acceptedOffer.ownerName}</h4>
                    <span className="bg-blue-500 text-white text-[9px] px-1.5 py-0.2 rounded-full font-bold">
                      VERIFIED
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 font-mono">
                    {acceptedOffer.assetName || (isTowing ? 'Hydraulic Tow Truck' : 'Verified Trailer')}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-amber-400 font-mono font-bold block uppercase">Agreed Price</span>
                <span className="text-lg font-black text-white font-mono">R {acceptedOffer.price}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-800 text-xs">
              <div className="bg-neutral-800/80 p-2.5 rounded-xl">
                <span className="text-[10px] text-neutral-400 block font-mono">
                  {isTowing ? 'ESTIMATED ARRIVAL' : 'AVAILABILITY'}
                </span>
                <span className="font-black text-amber-400">{acceptedOffer.eta}</span>
              </div>
              <div className="bg-neutral-800/80 p-2.5 rounded-xl">
                <span className="text-[10px] text-neutral-400 block font-mono">DIRECT CONTACT</span>
                <a
                  href={`tel:${acceptedOffer.ownerPhone}`}
                  className="font-bold text-white flex items-center gap-1 hover:text-amber-400 transition"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{acceptedOffer.ownerPhone}</span>
                </a>
              </div>
            </div>

            <div className="flex gap-2 pt-1 flex-wrap">
              <a
                href={`tel:${acceptedOffer.ownerPhone}`}
                className="flex-1 min-w-[130px] bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white font-black text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm"
              >
                <Phone className="w-4 h-4" />
                <span>CALL OPERATOR</span>
              </a>
              <button
                type="button"
                id="btn-rate-owner-accepted"
                onClick={() => setIsRatingOpen(true)}
                className="flex-1 min-w-[130px] bg-[#FFCC00] hover:bg-yellow-400 active:scale-95 text-black font-mono font-black text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm cursor-pointer"
              >
                <Star className="w-4 h-4 fill-black text-black" />
                <span>RATE OWNER / ASSET</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs py-2.5 rounded-xl transition"
              >
                DONE
              </button>
            </div>
          </div>
        </motion.div>
      ) : (
        <>
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
            <div className="flex items-center gap-2.5 min-w-0 flex-1">
              <div className="relative flex-shrink-0">
                <div className="w-3.5 h-3.5 bg-amber-400 rounded-full animate-ping" />
                <div className="w-3.5 h-3.5 bg-amber-400 rounded-full absolute inset-0" />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="font-black text-sm text-neutral-900 leading-tight truncate">
                  {isTowing ? 'Requesting Towing Assistance' : 'Broadcasting Trailer Request'}
                </h4>
                <span className="text-[11px] text-neutral-600 font-medium font-mono truncate block">
                  Request #{requestId.slice(-5)} • {broadcastRemaining}s left
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button
                type="button"
                id="btn-close-asset-waiting"
                onClick={handleCancelRequest}
                className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 active:scale-95 text-neutral-700 hover:text-black flex items-center justify-center transition border border-neutral-200 cursor-pointer"
                title="Cancel Request"
              >
                <X className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Request Summary Card */}
          <div className="mt-3 p-3 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-black text-neutral-900 flex items-center gap-1.5">
                {isTowing ? <Car className="w-4 h-4 text-amber-600" /> : <Package className="w-4 h-4 text-blue-600" />}
                {isTowing
                  ? `${requestData?.vehicleType || 'Vehicle'} • ${requestData?.problem || 'Breakdown'}`
                  : `${requestData?.trailerType || 'Luggage Trailer'} • ${requestData?.durationQty || 1} ${requestData?.durationType || 'Days'}`}
              </span>
              <span className="font-mono font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-lg border border-amber-200">
                Offer R {requestData?.offeredPrice || (isTowing ? 450 : 250)}
              </span>
            </div>

            <div className="text-[11px] text-neutral-600 space-y-1">
              <div className="flex items-center gap-1.5 truncate">
                <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                <span className="truncate">
                  From: {requestData?.pickupAddress || requestData?.pickup || 'Breakdown Location'}
                </span>
              </div>
              <div className="flex items-center gap-1.5 truncate">
                <MapPin className="w-3.5 h-3.5 text-red-600 flex-shrink-0" />
                <span className="truncate">
                  To: {requestData?.dropAddress || requestData?.drop || 'Destination'}
                </span>
              </div>
              {!isTowing && requestData?.loadDesc && (
                <div className="text-[10px] text-neutral-500 italic truncate">
                  Load: {requestData.loadDesc}
                </div>
              )}
            </div>
          </div>

          {/* Live Offers Stream */}
          <div className="my-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-neutral-500 font-mono tracking-wider">
                Live Owner Offers ({offers.length})
              </span>
              <div className="flex items-center gap-1">
                <span className="text-[10px] text-neutral-400 font-bold uppercase">Raise</span>
                <button
                  type="button"
                  onClick={() => handleRaiseOffer(20)}
                  className="bg-neutral-100 hover:bg-amber-300 text-neutral-900 text-[10px] font-black px-2 py-0.5 rounded border border-neutral-200 transition active:scale-95 font-mono cursor-pointer"
                >
                  +R20
                </button>
                <button
                  type="button"
                  onClick={() => handleRaiseOffer(50)}
                  className="bg-neutral-100 hover:bg-amber-300 text-neutral-900 text-[10px] font-black px-2 py-0.5 rounded border border-neutral-200 transition active:scale-95 font-mono cursor-pointer"
                >
                  +R50
                </button>
              </div>
            </div>

            {offers.length === 0 ? (
              <div className="py-6 text-center flex flex-col items-center">
                <div className="relative w-14 h-14 flex items-center justify-center mb-2.5">
                  <div className="absolute inset-0 rounded-full bg-amber-400/20 animate-ping" />
                  <div className="absolute inset-2 rounded-full bg-amber-400/10" />
                  <div className="relative w-10 h-10 bg-white border-2 border-amber-400 text-neutral-900 rounded-full flex items-center justify-center shadow-md">
                    <Radar className="w-5 h-5 animate-spin text-amber-500" style={{ animationDuration: '3s' }} />
                  </div>
                </div>

                <p className="text-xs font-black text-neutral-900">
                  {isTowing ? 'Broadcasting to Verified Towing Operators...' : 'Broadcasting to Verified Trailer Owners...'}
                </p>
                <p className="text-[11px] text-neutral-500 mt-1 max-w-xs">
                  Asset owners nearby are viewing your request. Live quotes and availability will appear below instantly.
                </p>

                {isTimedOut && (
                  <div className="mt-3 p-3 bg-amber-50 rounded-xl border border-amber-200 w-full max-w-xs text-center space-y-2">
                    <p className="text-xs font-bold text-amber-900">
                      No response yet. Try increasing your offer to attract nearby owners faster.
                    </p>
                    <button
                      type="button"
                      onClick={() => handleRaiseOffer(30)}
                      className="px-3 py-1.5 bg-amber-400 hover:bg-amber-500 text-neutral-900 font-black text-xs rounded-xl shadow-xs transition active:scale-95 font-mono cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>RAISE +R30 & RE-BROADCAST</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                <AnimatePresence>
                  {offers.map((offer) => (
                    <motion.div
                      key={offer.id || offer.ownerId}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="bg-white border-2 border-amber-400/80 hover:border-amber-400 rounded-2xl p-3 shadow-xs space-y-2.5 transition"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-9 h-9 rounded-xl bg-neutral-900 text-white flex items-center justify-center font-black text-xs flex-shrink-0">
                            {isTowing ? <Truck className="w-4 h-4 text-amber-400" /> : <Package className="w-4 h-4 text-amber-400" />}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1">
                              <h5 className="font-black text-xs text-neutral-900 truncate">{offer.ownerName}</h5>
                              <span className="bg-emerald-500 text-white rounded-full p-0.5" title="Verified Owner">
                                <Check className="w-2 h-2 stroke-[3]" />
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[10px] text-neutral-500 font-medium">
                              <span className="flex items-center gap-0.5 text-neutral-900 font-bold bg-amber-50 px-1 py-0.2 rounded border border-amber-200">
                                <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                                {(offer.rating || 4.9).toFixed(1)}
                              </span>
                              <span className="truncate">{offer.assetName || (isTowing ? 'Tow Truck' : 'Trailer')}</span>
                            </div>
                          </div>
                        </div>

                        {/* Price Badge */}
                        <div className="text-right bg-amber-50 border border-amber-200 px-2 py-1 rounded-xl flex-shrink-0">
                          <span className="text-[8px] font-black text-amber-900 uppercase tracking-wider block">OFFER</span>
                          <div className="text-sm font-black text-neutral-900 font-mono">
                            R {offer.price}
                          </div>
                        </div>
                      </div>

                      {/* ETA & Note */}
                      <div className="flex items-center justify-between text-[11px] bg-neutral-50 p-2 rounded-xl border border-neutral-200">
                        <span className="text-neutral-600 flex items-center gap-1 font-bold">
                          <Clock className="w-3 h-3 text-amber-600" />
                          <span>{offer.eta || 'Ready Now'}</span>
                        </span>
                        {offer.note && (
                          <span className="text-[10px] text-neutral-500 italic truncate max-w-[160px]">
                            "{offer.note}"
                          </span>
                        )}
                      </div>

                      {/* Accept Action Button */}
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => handleAcceptOffer(offer)}
                          disabled={isAccepting}
                          className="flex-1 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white font-black text-xs py-2 rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>ACCEPT & CONFIRM (R {offer.price})</span>
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Footer Cancel Action */}
          <div className="pt-2 border-t border-neutral-200 flex items-center justify-between">
            <button
              type="button"
              onClick={handleCancelRequest}
              className="text-xs text-neutral-500 hover:text-red-600 font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Cancel Request</span>
            </button>
            <span className="text-[10px] text-neutral-400 font-mono">
              Safe Bidding Protection Enabled
            </span>
          </div>
        </>
      )}

      {/* Rate Owner Modal */}
      {acceptedOffer && (
        <RateOwnerModal
          isOpen={isRatingOpen}
          onClose={() => setIsRatingOpen(false)}
          ownerId={acceptedOffer.ownerId}
          ownerName={acceptedOffer.ownerName}
          assetName={acceptedOffer.assetName || (isTowing ? 'Tow Truck' : 'Trailer')}
          serviceType={type}
          onSubmitted={() => {
            setIsRatingOpen(false);
          }}
        />
      )}
    </div>
  );
};

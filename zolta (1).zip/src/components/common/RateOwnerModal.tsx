import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, X, Check, ShieldCheck, ThumbsUp, MessageSquare } from 'lucide-react';
import { updateOwnerRatingInFirestore } from '../../services/firestoreService';

interface RateOwnerModalProps {
  isOpen: boolean;
  onClose: () => void;
  ownerId?: string;
  ownerName?: string;
  assetName?: string;
  serviceType?: 'towing' | 'trailer';
  onSubmitted?: () => void;
}

const DEFAULT_TAGS = [
  'Good Equipment',
  'On Time',
  'Professional',
  'Friendly Service',
  'Clean Trailer',
  'Quick Dispatch',
];

export const RateOwnerModal: React.FC<RateOwnerModalProps> = ({
  isOpen,
  onClose,
  ownerId = 'owner_01',
  ownerName = 'Verified ZOLTA Operator',
  assetName = 'Flatbed Tow Truck',
  serviceType = 'towing',
  onSubmitted,
}) => {
  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [selectedTags, setSelectedTags] = useState<string[]>(['Good Equipment', 'On Time']);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await updateOwnerRatingInFirestore(ownerId, rating, selectedTags, comment, serviceType);
    } catch (err) {
      console.warn('Error saving rating:', err);
    }

    setIsSubmitting(false);
    setIsSuccess(true);

    setTimeout(() => {
      setIsSuccess(false);
      if (onSubmitted) onSubmitted();
      onClose();
    }, 1500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 15 }}
          className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full border border-amber-300 shadow-2xl space-y-4 text-neutral-900 select-none font-sans"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-[#FFCC00] text-black flex items-center justify-center font-black">
                <Star className="w-5 h-5 fill-black" />
              </div>
              <div>
                <h3 className="font-black text-base text-neutral-900 leading-tight">
                  Rate this Owner / Asset
                </h3>
                <p className="text-[10px] font-mono text-neutral-500">
                  {assetName} • {ownerName}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition"
            >
              <X className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

          {isSuccess ? (
            <div className="py-8 text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto shadow-md">
                <Check className="w-6 h-6 stroke-[3]" />
              </div>
              <h4 className="text-lg font-black text-emerald-950">Rating Saved!</h4>
              <p className="text-xs text-neutral-600">
                Thank you for supporting verified community asset owners in South Africa.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 font-sans">
              {/* Star Rating Bar */}
              <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 text-center space-y-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-900 block">
                  How was your experience?
                </span>
                <div className="flex items-center justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1 hover:scale-115 active:scale-95 transition"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= rating
                            ? 'fill-amber-400 text-amber-500 drop-shadow-xs'
                            : 'text-neutral-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <span className="text-xs font-black text-amber-950 font-mono block">
                  {rating === 5
                    ? '⭐ 5.0 - Excellent Service!'
                    : rating === 4
                    ? '⭐ 4.0 - Very Good'
                    : rating === 3
                    ? '⭐ 3.0 - Average'
                    : rating === 2
                    ? '⭐ 2.0 - Poor'
                    : '⭐ 1.0 - Terrible'}
                </span>
              </div>

              {/* Tag Selection Pills */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block">
                  Quick Compliment Tags
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {DEFAULT_TAGS.map((tag) => {
                    const isSelected = selectedTags.includes(tag);
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => toggleTag(tag)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold font-mono transition active:scale-95 cursor-pointer ${
                          isSelected
                            ? 'bg-[#FFCC00] text-black border border-amber-400 shadow-2xs'
                            : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                        }`}
                      >
                        {isSelected ? '✓ ' : '+ '}
                        {tag}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Comment Input */}
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block">
                  Comments / Feedback (Optional)
                </label>
                <textarea
                  rows={2}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="e.g. Driver arrived quickly with clean tow truck and took care of my car."
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-medium outline-none focus:border-black"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3 rounded-2xl uppercase font-mono shadow-md transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <ThumbsUp className="w-4 h-4" />
                <span>SAVE & SUBMIT RATING</span>
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

import React, { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  override state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public override componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[ZOLTA ErrorBoundary] Uncaught React error:', error, errorInfo);
  }

  private handleReset = () => {
    try {
      localStorage.removeItem('zolta_active_ride');
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then((regs) => {
          regs.forEach((r) => r.unregister());
        });
      }
      if ('caches' in window) {
        caches.keys().then((keys) => {
          keys.forEach((k) => caches.delete(k));
        });
      }
    } catch {}
    window.location.reload();
  };

  public override render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#FFFBEB] flex flex-col items-center justify-center p-6 text-neutral-900 font-sans">
          <div className="w-full max-w-md bg-white rounded-3xl border border-amber-200 shadow-xl p-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 border border-amber-300 text-amber-800 flex items-center justify-center mx-auto shadow-inner">
              <AlertTriangle className="w-8 h-8 stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-neutral-900">
                Application Recovered
              </h1>
              <p className="text-xs text-neutral-600 mt-2 font-medium leading-relaxed">
                ZOLTA detected an unexpected display glitch. Tap below to reload the clean interface.
              </p>
            </div>

            {this.state.error && (
              <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200 text-left font-mono text-[11px] text-neutral-600 max-h-24 overflow-y-auto break-all">
                {this.state.error.message || 'Unknown render exception'}
              </div>
            )}

            <button
              type="button"
              id="btn-recover-app"
              onClick={this.handleReset}
              className="w-full py-3.5 px-4 bg-[#FFCC00] hover:bg-[#e6b800] text-black font-black text-xs rounded-2xl flex items-center justify-center gap-2 shadow-md transition active:scale-95"
            >
              <RefreshCw className="w-4 h-4" />
              <span>RELOAD ZOLTA INTERFACE</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}


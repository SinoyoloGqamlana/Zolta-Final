import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Car,
  Bike,
  ShieldCheck,
  CheckCircle2,
  Upload,
  Users,
  Truck,
  Package,
  X,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { RideCategory } from '../../types';
import { saveDriverToFirestore } from '../../services/firestoreService';

type VehicleCategoryType = 'rider' | 'comfort' | 'xl' | 'scooter' | 'bakkie' | 'courier';

export const DriveWithZoltaView: React.FC = () => {
  const { setCurrentView, setMode, user, setDriverVehicleType } = useApp();
  const [activeRegModal, setActiveRegModal] = useState(false);
  const [regStep, setRegStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  // Form State
  const [selectedVehicleType, setSelectedVehicleType] = useState<VehicleCategoryType>('rider');
  const [fullName, setFullName] = useState(user.name || 'SGQAMLANA13');
  const [phone, setPhone] = useState(user.phone || '+27 82 555 1313');
  const [vehicleModel, setVehicleModel] = useState('Toyota Corolla Quest 1.6');
  const [licensePlate, setLicensePlate] = useState('CA 889-102');
  const [vehicleYear, setVehicleYear] = useState('2022');
  const [operatingCity, setOperatingCity] = useState('Cape Town');
  const [filesUploaded, setFilesUploaded] = useState<{ [key: string]: boolean }>({});

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
  };

  const handleOpenRegistration = (category: VehicleCategoryType) => {
    setSelectedVehicleType(category);
    if (category === 'rider') {
      setVehicleModel('Toyota Corolla Quest 1.6');
      setLicensePlate('CA 889-102');
    } else if (category === 'comfort') {
      setVehicleModel('Toyota Corolla Cross 1.8 Hybrid');
      setLicensePlate('CA 551-920');
    } else if (category === 'xl') {
      setVehicleModel('Toyota Rumion 1.5 TX 7-Seater');
      setLicensePlate('CA 442-990');
    } else if (category === 'scooter') {
      setVehicleModel('Big Boy Revival 150cc Scooter');
      setLicensePlate('CA 319-204');
    } else if (category === 'bakkie') {
      setVehicleModel('Toyota Hilux 2.4 GD-6 Single Cab');
      setLicensePlate('CA 778-311');
    } else if (category === 'courier') {
      setVehicleModel('Honda Ace 125 Delivery Bike');
      setLicensePlate('CA 662-805');
    }
    setRegStep(1);
    setSubmitted(false);
    setActiveRegModal(true);
  };

  const handleToggleDoc = (docKey: string) => {
    setFilesUploaded((prev) => ({ ...prev, [docKey]: !prev[docKey] }));
  };

  const handleCompleteReg = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    const driverId = user.id || `drv_${Date.now()}`;
    saveDriverToFirestore({
      id: driverId,
      name: fullName,
      email: user.email || `${fullName.toLowerCase().replace(/\s+/g, '')}@zolta.co.za`,
      phone,
      city: operatingCity,
      vehicleType: selectedVehicleType,
      carMakeModel: vehicleModel,
      carYear: vehicleYear,
      licensePlate,
      carColor: 'Silver',
      gender: user.gender || 'female',
      identityDoc: filesUploaded.identityDoc ? 'Uploaded' : 'Pending',
      licenseDoc: filesUploaded.licenseDoc ? 'Uploaded' : 'Pending',
      pdpDoc: filesUploaded.pdpDoc ? 'Uploaded' : 'Pending',
      vehicleRegDoc: filesUploaded.vehicleRegDoc ? 'Uploaded' : 'Pending',
    }).catch((err) => console.warn('Error saving driver to Firestore:', err));

    setDriverVehicleType(selectedVehicleType);

    setTimeout(() => {
      setMode('driver');
      setCurrentView('home');
    }, 1600);
  };

  const categoriesConfig: {
    id: VehicleCategoryType;
    name: string;
    title: string;
    subtitle: string;
    requirements: string;
    badge: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'rider',
      name: 'Rider',
      title: 'Rider (Standard Sedan)',
      subtitle: '4 Passenger Seats • Daily Commutes',
      requirements: 'Code 8 / EB License + Valid Disc',
      badge: 'STANDARD',
      icon: <Car className="w-6 h-6" />,
    },
    {
      id: 'comfort',
      name: 'Comfort',
      title: 'Comfort (Premium Sedan)',
      subtitle: 'Extra Legroom • Top Rated Driver',
      requirements: 'Code 8 License + Late Model Vehicle',
      badge: 'PREMIUM',
      icon: <Car className="w-6 h-6" />,
    },
    {
      id: 'xl',
      name: 'XL',
      title: 'XL (6-Seater / Family)',
      subtitle: '6+ Passenger Seats • Group Trips & Airport',
      requirements: 'Code 8/10 + 6-7 Seater Capacity',
      badge: '6-SEATER',
      icon: <Users className="w-6 h-6" />,
    },
    {
      id: 'scooter',
      name: 'Scooter',
      title: 'Scooter (Express Ride)',
      subtitle: 'Quick Single Passenger Commute',
      requirements: 'Code A / A1 Motorcycle License + Helmet',
      badge: 'EXPRESS',
      icon: <Bike className="w-6 h-6" />,
    },
    {
      id: 'bakkie',
      name: 'Bakkie',
      title: 'Bakkie (Goods Transport)',
      subtitle: '1-Ton Cargo • Furniture & Goods Moves',
      requirements: 'Code 8/10 + Bakkie Cargo Bed',
      badge: 'GOODS',
      icon: <Truck className="w-6 h-6" />,
    },
    {
      id: 'courier',
      name: 'Courier',
      title: 'Courier (Parcel Dispatch)',
      subtitle: 'Express Parcels & Packages Dispatch',
      requirements: 'Code A1/EB + Top Box / Courier Bag',
      badge: 'PARCEL',
      icon: <Package className="w-6 h-6" />,
    },
  ];

  return (
    <div id="drive-with-zolta-view" className="max-w-5xl mx-auto p-4 sm:p-6 pb-24 text-neutral-900 bg-[#FFFBEB] select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-amber-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-drive-with-zolta"
            onClick={handleGoToRiderPortal}
            className="w-10 h-10 rounded-2xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight font-sans">
              Driver Registration Portal
            </h1>
            <p className="font-mono text-[10px] uppercase text-neutral-500 tracking-wider">
              Safe Ride + Community Service • South Africa 🇿🇦
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => handleOpenRegistration('rider')}
          className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs px-4 py-2.5 rounded-2xl shadow-xs transition active:scale-95 font-mono"
        >
          Register Driver
        </button>
      </div>

      {/* Hero Banner */}
      <div className="bg-neutral-900 text-white rounded-[24px] p-6 sm:p-8 mb-8 relative overflow-hidden shadow-md">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 bg-[#FFCC00] text-black text-[10px] font-black px-3 py-1 rounded-full uppercase mb-3 font-mono">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>100% Verified Community Driver Network</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-2 text-white font-sans">
            Drive Safely & Earn in South Africa
          </h2>
          <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed font-sans mb-4">
            Register your vehicle across all 6 community service categories: Rider, Comfort, XL, Scooter, Bakkie, and Courier. Enjoy direct payouts, safety alerts, and transparent 10% platform rates.
          </p>
          <div className="flex flex-wrap gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5 text-[#FFCC00]">
              <CheckCircle2 className="w-4 h-4" />
              <span>Direct Bank / Paystack Payouts</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#FFCC00]">
              <CheckCircle2 className="w-4 h-4" />
              <span>South Africa ID Verified</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#FFCC00]">
              <CheckCircle2 className="w-4 h-4" />
              <span>POPIA Data Protected</span>
            </div>
          </div>
        </div>
      </div>

      {/* 6 Categories Grid in EXACT ORDER: Rider, Comfort, XL, Scooter, Bakkie, Courier */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-black uppercase tracking-wider text-neutral-800 font-mono">
            Select Your Vehicle Category (6 Types)
          </h3>
          <span className="text-[10px] font-mono text-neutral-500 uppercase">
            All 6 in Driver Portal
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categoriesConfig.map((cat, idx) => (
            <div
              key={cat.id}
              className="bg-white rounded-[24px] p-5 border border-amber-200 shadow-xs flex flex-col justify-between hover:border-amber-400 transition"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-black flex items-center justify-center">
                    {cat.icon}
                  </div>
                  <span className={`font-mono text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                    idx === 0
                      ? 'bg-[#FFCC00] text-black'
                      : idx === 1
                      ? 'bg-amber-100 text-amber-900 border border-amber-300'
                      : idx === 2
                      ? 'bg-neutral-900 text-white'
                      : idx === 3
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : idx === 4
                      ? 'bg-blue-100 text-blue-900 border border-blue-300'
                      : 'bg-purple-100 text-purple-900 border border-purple-300'
                  }`}>
                    {cat.badge}
                  </span>
                </div>

                <h4 className="text-lg font-bold text-neutral-900 mb-1 font-sans">
                  {idx + 1}. {cat.name}
                </h4>
                <p className="font-mono text-[11px] uppercase text-neutral-500 mb-3">
                  {cat.subtitle}
                </p>

                <div className="space-y-1 text-xs text-neutral-600 mb-4 bg-amber-50/50 p-3 rounded-xl border border-amber-200 font-mono">
                  <p className="font-bold text-neutral-900 flex items-center gap-1.5 text-[11px]">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                    <span>{cat.requirements}</span>
                  </p>
                </div>
              </div>

              <button
                type="button"
                id={`btn-register-${cat.id}`}
                onClick={() => handleOpenRegistration(cat.id)}
                className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3 rounded-xl shadow-xs transition active:scale-95 uppercase tracking-wider font-mono flex items-center justify-center gap-1.5"
              >
                <span>Register {cat.name}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* REGISTRATION MODAL */}
      {activeRegModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-amber-200 text-neutral-900 w-full max-w-lg rounded-[28px] p-6 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setActiveRegModal(false)}
              className="absolute top-5 right-5 p-1 text-neutral-400 hover:text-black"
            >
              <X className="w-5 h-5" />
            </button>

            {submitted ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-black text-neutral-900 font-sans">
                  Driver Registered Successfully!
                </h3>
                <p className="text-xs text-neutral-600 max-w-xs mx-auto">
                  Your vehicle ({selectedVehicleType.toUpperCase()}) has been activated in the ZOLTA Community Network. Switching to Driver Mode...
                </p>
              </div>
            ) : (
              <form onSubmit={handleCompleteReg} className="space-y-4">
                <div>
                  <span className="text-[10px] font-mono font-bold bg-[#FFCC00] text-black px-2 py-0.5 rounded-md uppercase">
                    Step {regStep} of 2 • Driver Form
                  </span>
                  <h3 className="text-xl font-bold text-neutral-900 mt-1 font-sans">
                    Register as Verified Driver
                  </h3>
                </div>

                {regStep === 1 ? (
                  <div className="space-y-3">
                    {/* DROPDOWN: Select Vehicle Type in exact order */}
                    <div>
                      <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                        Select Vehicle Type <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="select-vehicle-type"
                        value={selectedVehicleType}
                        onChange={(e) => setSelectedVehicleType(e.target.value as VehicleCategoryType)}
                        className="w-full px-3.5 py-2.5 bg-amber-50/70 border border-amber-300 rounded-xl text-xs font-bold text-neutral-900 outline-none focus:border-black font-mono"
                        required
                      >
                        <option value="rider">Rider (Standard Sedan - 4 Seats)</option>
                        <option value="comfort">Comfort (Premium Sedan - Extra Legroom)</option>
                        <option value="xl">XL (6-Seater - Family & Luggage)</option>
                        <option value="scooter">Scooter (Single Passenger Express)</option>
                        <option value="bakkie">Bakkie (Goods & Furniture Transport)</option>
                        <option value="courier">Courier (Express Parcel & Package Dispatch)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                          Mobile Phone (+27)
                        </label>
                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none focus:border-black"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                          Operating City
                        </label>
                        <select
                          value={operatingCity}
                          onChange={(e) => setOperatingCity(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                        >
                          <option value="Cape Town">Cape Town & Metro</option>
                          <option value="Johannesburg">Johannesburg & Sandton</option>
                          <option value="Pretoria">Pretoria / Tshwane</option>
                          <option value="Durban">Durban / eThekwini</option>
                          <option value="Gqeberha">Gqeberha (PE)</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                          Vehicle Model
                        </label>
                        <input
                          type="text"
                          value={vehicleModel}
                          onChange={(e) => setVehicleModel(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                          License Plate
                        </label>
                        <input
                          type="text"
                          value={licensePlate}
                          onChange={(e) => setLicensePlate(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none focus:border-black"
                          required
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setRegStep(2)}
                      className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3 rounded-xl uppercase tracking-wider transition shadow-xs mt-2 font-mono"
                    >
                      Next: Attach Verification Docs →
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-xs text-neutral-600">
                      Tap each document to attach verification documents for <strong>{selectedVehicleType.toUpperCase()}</strong>:
                    </p>

                    {[
                      { key: 'idDoc', label: 'South African ID / Passport Photo' },
                      { key: 'licenseDoc', label: "Driver's License Card (PrDP / Code 8/10/A)" },
                      { key: 'discDoc', label: 'Vehicle License Disc Photo (Valid)' },
                      { key: 'selfieDoc', label: 'Driver Clear Face Profile Photo' },
                    ].map((doc) => (
                      <button
                        key={doc.key}
                        type="button"
                        onClick={() => handleToggleDoc(doc.key)}
                        className={`w-full p-3 rounded-xl border flex items-center justify-between text-left transition ${
                          filesUploaded[doc.key]
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                            : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {filesUploaded[doc.key] ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Upload className="w-4 h-4 text-neutral-400" />
                          )}
                          <span className="text-xs font-bold">{doc.label}</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold uppercase">
                          {filesUploaded[doc.key] ? 'Attached ✓' : 'Attach'}
                        </span>
                      </button>
                    ))}

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setRegStep(1)}
                        className="w-1/3 bg-neutral-100 hover:bg-neutral-200 text-black font-bold text-xs py-3 rounded-xl font-mono"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        className="flex-1 bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3 rounded-xl uppercase tracking-wider shadow-sm transition font-mono"
                      >
                        Submit & Start Driving
                      </button>
                    </div>
                  </div>
                )}
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

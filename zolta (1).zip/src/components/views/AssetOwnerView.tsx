import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Wrench,
  Package,
  ShieldCheck,
  Zap,
  Phone,
  MapPin,
  Check,
  CheckCircle2,
  Clock,
  Car,
  Truck,
  Sparkles,
  Plus,
  X,
  Layers,
  Star,
  DollarSign,
  Activity,
  AlertTriangle,
  Send,
  Calendar,
  Image as ImageIcon,
  MessageSquare,
  ThumbsDown,
} from 'lucide-react';
import {
  getStoredAssetRequests,
  updateAssetRequestStatus,
  addOwnerOfferToAssetRequest,
} from '../../services/assetRequestsService';
import {
  subscribeToTowingRequests,
  subscribeToTrailerRequests,
  submitOwnerOfferToRequest,
  acceptOwnerOfferOnRequest,
  cancelOrDeclineAssetRequest,
  subscribeToAssetOwners,
  saveTrailerToFirestore,
  saveTowingCompanyToFirestore,
} from '../../services/firestoreService';
import {
  AssetRequest,
  TowingAssetRequest,
  TrailerAssetRequest,
  OwnerBidOffer,
  TowingRequestDoc,
  TrailerRequestDoc,
} from '../../types';
import { OwnerReviewsModal } from '../common/OwnerReviewsModal';
import { RateOwnerModal } from '../common/RateOwnerModal';

interface OwnerAsset {
  id: string;
  name: string;
  category: 'towing' | 'trailer';
  plateOrSerial: string;
  specs: string;
  location: string;
  ratePerDayOrTrip: number;
  status: 'active' | 'on_trip' | 'maintenance';
  rating: number;
  totalTrips: number;
}

const DEFAULT_OWNER_ASSETS: OwnerAsset[] = [
  {
    id: 'asset_tow_01',
    name: 'Isuzu NPR 400 Hydraulic Rollback',
    category: 'towing',
    plateOrSerial: 'CA 829-411',
    specs: '4.5 Ton Winch • Wheel-lift recovery • 24/7 Breakdown',
    location: 'Cape Town Metro & Khayelitsha',
    ratePerDayOrTrip: 450,
    status: 'active',
    rating: 4.9,
    totalTrips: 42,
  },
  {
    id: 'asset_trailer_01',
    name: 'Challenger 2.4m Enclosed Luggage Trailer',
    category: 'trailer',
    plateOrSerial: 'CF 194-820',
    specs: 'Weatherproof lockable lid • 750kg GVM • Spare wheel',
    location: 'Ilitha Park, Khayelitsha',
    ratePerDayOrTrip: 250,
    status: 'active',
    rating: 5.0,
    totalTrips: 28,
  },
];

export const AssetOwnerView: React.FC = () => {
  const { setCurrentView, setMode, user } = useApp();
  const [requests, setRequests] = useState<any[]>([]);
  const [activeFilter, setActiveFilter] = useState<'all' | 'towing' | 'trailer'>('all');
  const [acceptedToast, setAcceptedToast] = useState<string | null>(null);

  // Offer Modal State
  const [selectedReqForOffer, setSelectedReqForOffer] = useState<any | null>(null);
  const [offerPrice, setOfferPrice] = useState<number>(450);
  const [offerEta, setOfferEta] = useState<string>('20 mins');
  const [offerNote, setOfferNote] = useState<string>('');
  const [isSubmittingOffer, setIsSubmittingOffer] = useState(false);

  // Owner Assets State
  const [myAssets, setMyAssets] = useState<OwnerAsset[]>(() => {
    try {
      const stored = localStorage.getItem('zolta_my_owner_assets');
      if (stored) return JSON.parse(stored);
    } catch {}
    return DEFAULT_OWNER_ASSETS;
  });

  // Modal for registering new asset
  const [isAddAssetModalOpen, setIsAddAssetModalOpen] = useState(false);
  const [newAssetCategory, setNewAssetCategory] = useState<'towing' | 'trailer'>('towing');
  const [newAssetName, setNewAssetName] = useState('');
  const [newAssetPlate, setNewAssetPlate] = useState('');
  const [newAssetSpecs, setNewAssetSpecs] = useState('');
  const [newAssetLocation, setNewAssetLocation] = useState('Cape Town Metro');
  const [newAssetRate, setNewAssetRate] = useState('350');
  const [isSubmittingAsset, setIsSubmittingAsset] = useState(false);

  // Reviews & Rating Modals
  const [isReviewsModalOpen, setIsReviewsModalOpen] = useState(false);
  const [ratingModalReq, setRatingModalReq] = useState<any | null>(null);

  const handleBidUpDown = async (req: any, delta: number) => {
    const existingOffer = (req.offers || []).find((o: OwnerBidOffer) => o.ownerId === (user.id || 'owner_01'));
    const basePrice = existingOffer ? existingOffer.price : (Number(req.offeredPrice) || (req.type === 'towing' ? 450 : 250));
    const newPrice = Math.max(50, basePrice + delta);
    const ownerAsset = myAssets.find((a) => a.category === req.type) || myAssets[0];

    const offer: OwnerBidOffer = {
      id: `off_${Date.now()}`,
      ownerId: user.id || 'owner_01',
      ownerName: user.name || (req.type === 'towing' ? 'Kape Towing & Recovery' : 'Mkhize Trailer Rentals'),
      ownerPhone: user.phone || '+27 82 884 9210',
      assetType: req.type,
      assetName: ownerAsset?.name || (req.type === 'towing' ? 'Flatbed Tow Truck' : 'Venter 7ft Trailer'),
      price: newPrice,
      eta: req.type === 'towing' ? '15 mins' : 'Ready today',
      rating: 4.8,
      jobsCount: 127,
      isVerified: true,
      note: `Adjusted bid to R${newPrice}`,
      status: 'pending',
      createdAt: Date.now(),
    };

    const colName = req.type === 'towing' ? 'towingRequests' : 'trailerRequests';
    await submitOwnerOfferToRequest(colName, req.id, offer);
    addOwnerOfferToAssetRequest(req.id, offer);
    setAcceptedToast(`Adjusted bid to R ${newPrice}`);
    setTimeout(() => setAcceptedToast(null), 3000);
  };

  // Subscribe to live Firestore towingRequests & trailerRequests with offers
  useEffect(() => {
    // Initial local requests
    const initialStored = getStoredAssetRequests();
    const mergedMap = new Map<string, any>();
    initialStored.forEach((r) => mergedMap.set(r.id, r));

    const syncMerged = () => {
      const list = Array.from(mergedMap.values()).sort((a, b) => {
        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return timeB - timeA;
      });
      setRequests(list);
    };

    // 1. Live Firestore Towing Listener
    const unsubTowing = subscribeToTowingRequests((firestoreTows) => {
      firestoreTows.forEach((t) => {
        const item = {
          id: t.id,
          type: 'towing',
          userName: t.requesterName || (t as any).userName || 'Requester',
          phone: t.requesterPhone || (t as any).userPhone || (t as any).phone || '+27 82 000 0000',
          location: t.pickupAddress || (t as any).location || 'Breakdown Location',
          pickupAddress: t.pickupAddress || (t as any).location || 'Breakdown Location',
          dropAddress: t.dropAddress || 'Destination / Garage',
          pickupLatLng: t.pickupLatLng,
          dropLatLng: t.dropLatLng,
          vehicleType: t.vehicleType || 'Car',
          problem: t.problem || (t as any).problemType || 'Breakdown',
          photos: t.photos || [],
          offeredPrice: t.offeredPrice || 450,
          status: t.status || 'pending',
          offers: t.offers || [],
          createdAt: typeof (t as any).createdAt?.toDate === 'function'
            ? (t as any).createdAt.toDate().toISOString()
            : (t.createdAt || new Date().toISOString()),
        };
        mergedMap.set(t.id, item);
      });
      syncMerged();
    });

    // 2. Live Firestore Trailer Hire Listener
    const unsubTrailers = subscribeToTrailerRequests((firestoreTrailers) => {
      firestoreTrailers.forEach((tr) => {
        const item = {
          id: tr.id,
          type: 'trailer',
          userName: tr.requesterName || (tr as any).userName || 'Requester',
          phone: tr.requesterPhone || (tr as any).phone || '+27 82 000 0000',
          location: tr.pickup || (tr as any).location || 'Pickup Location',
          pickup: tr.pickup || 'Pickup Location',
          drop: tr.drop || 'Usage Area / Destination',
          trailerType: tr.trailerType || 'Luggage Trailer',
          durationType: tr.durationType || 'days',
          durationQty: tr.durationQty || 1,
          startDateTime: tr.startDateTime || 'Today (Immediate)',
          loadDesc: tr.loadDesc || '',
          offeredPrice: tr.offeredPrice || 250,
          status: tr.status || 'pending',
          offers: tr.offers || [],
          createdAt: typeof (tr as any).createdAt?.toDate === 'function'
            ? (tr as any).createdAt.toDate().toISOString()
            : (tr.createdAt || new Date().toISOString()),
        };
        mergedMap.set(tr.id, item);
      });
      syncMerged();
    });

    // 3. Custom window events & storage sync
    const handleUpdate = (e: any) => {
      if (e?.detail && Array.isArray(e.detail)) {
        e.detail.forEach((r: any) => mergedMap.set(r.id, r));
        syncMerged();
      }
    };

    window.addEventListener('zolta_asset_requests_updated', handleUpdate);
    window.addEventListener('storage', syncMerged);

    return () => {
      unsubTowing();
      unsubTrailers();
      window.removeEventListener('zolta_asset_requests_updated', handleUpdate);
      window.removeEventListener('storage', syncMerged);
    };
  }, []);

  // Listen to owner's registered assets in Firestore
  useEffect(() => {
    const unsubOwners = subscribeToAssetOwners((owners) => {
      if (owners && owners.length > 0) {
        const firestoreAssets: OwnerAsset[] = owners.map((o) => ({
          id: o.id,
          name: o.name || o.companyName || 'Registered Asset',
          category: (o.type === 'trailer' ? 'trailer' : 'towing') as 'towing' | 'trailer',
          plateOrSerial: o.plate || o.id.slice(-6).toUpperCase(),
          specs: o.specs || o.fleetSize || (o.servicesOffered ? o.servicesOffered.join(', ') : 'Verified Asset Unit'),
          location: o.coverageArea || o.location || 'Cape Town Metro',
          ratePerDayOrTrip: o.baseRate || (o.type === 'trailer' ? 250 : 450),
          status: 'active',
          rating: o.rating || 5.0,
          totalTrips: o.totalTrips || 12,
        }));

        setMyAssets((prev) => {
          const map = new Map<string, OwnerAsset>();
          DEFAULT_OWNER_ASSETS.forEach((a) => map.set(a.id, a));
          prev.forEach((a) => map.set(a.id, a));
          firestoreAssets.forEach((a) => map.set(a.id, a));
          const combined = Array.from(map.values());
          try {
            localStorage.setItem('zolta_my_owner_assets', JSON.stringify(combined));
          } catch {}
          return combined;
        });
      }
    });

    return () => unsubOwners();
  }, []);

  const handleGoBack = () => {
    setMode('rider');
    setCurrentView('home');
  };

  // Open Make Offer Modal
  const handleOpenOfferModal = (req: any) => {
    setSelectedReqForOffer(req);
    const existingOffer = (req.offers || []).find((o: OwnerBidOffer) => o.ownerId === (user.id || 'owner_01'));
    if (existingOffer) {
      setOfferPrice(existingOffer.price);
      setOfferEta(existingOffer.eta);
      setOfferNote(existingOffer.note || '');
    } else {
      setOfferPrice(Number(req.offeredPrice) || (req.type === 'towing' ? 450 : 250));
      setOfferEta(req.type === 'towing' ? '20 mins' : 'Ready for collection today');
      setOfferNote(req.type === 'towing' ? 'Equipped with heavy-duty rollback and winch' : 'Clean, locked, roadworthy tested');
    }
  };

  // Submit Bid / Offer from Owner to Requester
  const handleSubmitOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReqForOffer) return;

    setIsSubmittingOffer(true);
    const ownerAsset = myAssets.find((a) => a.category === selectedReqForOffer.type) || myAssets[0];

    const offer: OwnerBidOffer = {
      id: `off_${Date.now()}`,
      ownerId: user.id || 'owner_01',
      ownerName: user.name || 'Verified ZOLTA Operator',
      ownerPhone: user.phone || '+27 82 884 9210',
      assetType: selectedReqForOffer.type,
      assetName: ownerAsset?.name || (selectedReqForOffer.type === 'towing' ? 'Isuzu Hydraulic Rollback' : 'Challenger Luggage Trailer'),
      price: offerPrice,
      eta: offerEta,
      rating: 4.9,
      note: offerNote.trim(),
      status: 'pending',
      createdAt: Date.now(),
    };

    // 1. Submit to Firestore
    const colName = selectedReqForOffer.type === 'towing' ? 'towingRequests' : 'trailerRequests';
    await submitOwnerOfferToRequest(colName, selectedReqForOffer.id, offer);

    // 2. Submit to localStorage & broadcast
    addOwnerOfferToAssetRequest(selectedReqForOffer.id, offer);

    setIsSubmittingOffer(false);
    setSelectedReqForOffer(null);
    setAcceptedToast(`Offer of R ${offerPrice} sent to ${selectedReqForOffer.userName}!`);
    setTimeout(() => setAcceptedToast(null), 3500);
  };

  // Decline Request
  const handleDeclineRequest = async (req: any) => {
    const colName = req.type === 'towing' ? 'towingRequests' : 'trailerRequests';
    await cancelOrDeclineAssetRequest(colName, req.id, 'declined');
    updateAssetRequestStatus(req.id, 'declined');
    setAcceptedToast(`Request #${req.id.slice(-5)} declined.`);
    setTimeout(() => setAcceptedToast(null), 3000);
  };

  // Direct Accept Request at Requester Price
  const handleDirectAccept = async (req: any) => {
    const ownerAsset = myAssets.find((a) => a.category === req.type) || myAssets[0];
    const offer: OwnerBidOffer = {
      id: `off_${Date.now()}`,
      ownerId: user.id || 'owner_01',
      ownerName: user.name || 'Verified ZOLTA Operator',
      ownerPhone: user.phone || '+27 82 884 9210',
      assetType: req.type,
      assetName: ownerAsset?.name || (req.type === 'towing' ? 'Isuzu Hydraulic Rollback' : 'Challenger Luggage Trailer'),
      price: Number(req.offeredPrice) || (req.type === 'towing' ? 450 : 250),
      eta: req.type === 'towing' ? '15 mins' : 'Ready immediately',
      rating: 5.0,
      note: 'Direct acceptance by operator',
      status: 'accepted',
      createdAt: Date.now(),
    };

    const colName = req.type === 'towing' ? 'towingRequests' : 'trailerRequests';
    await acceptOwnerOfferOnRequest(colName, req.id, offer);
    addOwnerOfferToAssetRequest(req.id, offer);
    updateAssetRequestStatus(req.id, 'accepted', offer.ownerName);

    setAcceptedToast(`Accepted ${req.type === 'towing' ? 'Towing' : 'Trailer'} request #${req.id.slice(-5)}!`);
    setTimeout(() => setAcceptedToast(null), 3500);
  };

  // Handle register new asset
  const handleCreateAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAssetName.trim()) return;

    setIsSubmittingAsset(true);
    const assetId = `asset_${newAssetCategory}_${Date.now()}`;
    const rate = Number(newAssetRate) || (newAssetCategory === 'towing' ? 450 : 250);

    const newAsset: OwnerAsset = {
      id: assetId,
      name: newAssetName.trim(),
      category: newAssetCategory,
      plateOrSerial: newAssetPlate.trim() || 'REG-PENDING',
      specs: newAssetSpecs.trim() || (newAssetCategory === 'towing' ? 'Rollback Tow Truck' : 'Utility Trailer'),
      location: newAssetLocation.trim() || 'Cape Town Metro',
      ratePerDayOrTrip: rate,
      status: 'active',
      rating: 5.0,
      totalTrips: 0,
    };

    // Save to Firestore
    try {
      if (newAssetCategory === 'towing') {
        await saveTowingCompanyToFirestore({
          id: assetId,
          companyName: newAsset.name,
          contactPerson: user.name || 'Asset Owner',
          phone: user.phone || '071 000 0000',
          fleetSize: newAsset.specs,
          coverageArea: newAsset.location,
          is247: true,
          servicesOffered: ['Accident Towing', 'Breakdown Rollback', 'Recovery'],
          rating: 5.0,
        });
      } else {
        await saveTrailerToFirestore({
          id: assetId,
          name: newAsset.name,
          kind: 'utility',
          size: newAsset.specs,
          imageUrl: 'https://images.unsplash.com/photo-1586769852836-bc069f19e1b6?w=600&auto=format&fit=crop&q=80',
          pricePerHour: 80,
          pricePerDay: rate,
          pricePerWeek: rate * 5,
          pricePerMonth: rate * 18,
          location: newAsset.location,
          deposit: 300,
          deliveryAvailable: true,
          deliveryFee: 50,
          ownerName: user.name || 'Asset Owner',
          ownerPhone: user.phone || '071 000 0000',
          rating: 5.0,
          totalTrips: 0,
        });
      }
    } catch (err) {
      console.warn('Firestore asset save warning:', err);
    }

    const updatedAssets = [newAsset, ...myAssets];
    setMyAssets(updatedAssets);
    try {
      localStorage.setItem('zolta_my_owner_assets', JSON.stringify(updatedAssets));
    } catch {}

    setIsSubmittingAsset(false);
    setIsAddAssetModalOpen(false);
    setNewAssetName('');
    setNewAssetPlate('');
    setNewAssetSpecs('');
    setAcceptedToast(`Successfully registered ${newAsset.name}!`);
    setTimeout(() => setAcceptedToast(null), 3500);
  };

  const towingRequests = requests.filter((r) => r.type === 'towing');
  const trailerRequests = requests.filter((r) => r.type === 'trailer');

  const filteredRequests = requests.filter((r) => {
    if (activeFilter === 'towing') return r.type === 'towing';
    if (activeFilter === 'trailer') return r.type === 'trailer';
    return true;
  });

  return (
    <div id="asset-owner-view" className="max-w-4xl mx-auto p-4 sm:p-6 pb-24 text-neutral-900 bg-[#FFFBEB] select-none">
      {/* Toast Notification */}
      {acceptedToast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 text-white px-4 py-2.5 rounded-2xl shadow-xl border border-[#FFCC00] flex items-center gap-2 font-mono text-xs animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-[#FFCC00]" />
          <span>{acceptedToast}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-amber-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-asset-owner"
            onClick={handleGoBack}
            className="w-10 h-10 rounded-2xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight font-sans">
              Asset Owners Portal
            </h1>
            <p className="font-mono text-[10px] uppercase text-neutral-600 font-bold tracking-wider">
              LIVE INCOMING REQUESTS & ASSET MANAGEMENT • South Africa 🇿🇦
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Header Rating Badge requirement */}
          <button
            type="button"
            id="btn-owner-header-rating"
            onClick={() => setIsReviewsModalOpen(true)}
            className="bg-neutral-900 text-[#FFCC00] hover:bg-black px-3.5 py-2 rounded-2xl border border-amber-400/80 shadow-xs flex items-center gap-1.5 font-mono text-xs font-black transition active:scale-95 cursor-pointer"
          >
            <Star className="w-4 h-4 fill-[#FFCC00] text-[#FFCC00]" />
            <span>MY RATING: ⭐ 4.9 (43 Jobs)</span>
            <span className="text-[10px] text-amber-300 font-sans font-normal underline ml-0.5 sm:inline hidden">- tap to see reviews</span>
          </button>

          <button
            type="button"
            onClick={handleGoBack}
            className="w-9 h-9 rounded-2xl bg-[#FFCC00] text-black font-black text-base flex items-center justify-center shadow-xs"
          >
            Z
          </button>
        </div>
      </div>

      {/* Owner Console Main Dispatch Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-6 p-2 bg-neutral-900 rounded-2xl border border-neutral-800 shadow-md">
        <button
          type="button"
          id="tab-towing-dispatch"
          onClick={() => setActiveFilter('towing')}
          className={`flex items-center justify-between py-3 px-4 rounded-xl font-mono text-xs font-black transition cursor-pointer ${
            activeFilter === 'towing'
              ? 'bg-[#FFCC00] text-black shadow-sm scale-[1.01]'
              : 'text-neutral-300 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <Wrench className="w-4 h-4" />
            <span>TAB 1: Towing Dispatch</span>
          </div>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
            activeFilter === 'towing' ? 'bg-black text-[#FFCC00]' : 'bg-red-600 text-white'
          }`}>
            {towingRequests.length} Live
          </span>
        </button>

        <button
          type="button"
          id="tab-trailer-dispatch"
          onClick={() => setActiveFilter('trailer')}
          className={`flex items-center justify-between py-3 px-4 rounded-xl font-mono text-xs font-black transition cursor-pointer ${
            activeFilter === 'trailer'
              ? 'bg-[#FFCC00] text-black shadow-sm scale-[1.01]'
              : 'text-neutral-300 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            <span>TAB 2: Trailer Dispatch</span>
          </div>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
            activeFilter === 'trailer' ? 'bg-black text-[#FFCC00]' : 'bg-blue-600 text-white'
          }`}>
            {trailerRequests.length} Live
          </span>
        </button>

        <button
          type="button"
          id="tab-all-operations"
          onClick={() => setActiveFilter('all')}
          className={`flex items-center justify-between py-3 px-4 rounded-xl font-mono text-xs font-black transition cursor-pointer ${
            activeFilter === 'all'
              ? 'bg-[#FFCC00] text-black shadow-sm scale-[1.01]'
              : 'text-neutral-300 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4" />
            <span>All Operations</span>
          </div>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
            activeFilter === 'all' ? 'bg-black text-[#FFCC00]' : 'bg-neutral-700 text-white'
          }`}>
            {requests.length} Total
          </span>
        </button>
      </div>

      {/* Vetted Community Network black card */}
      <div className="bg-neutral-900 text-white rounded-[24px] p-5 sm:p-6 mb-6 shadow-sm border border-neutral-800">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
          <div className="flex items-center gap-2 text-[#FFCC00] text-xs font-mono font-bold uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>Vetted Community Network</span>
          </div>
          <div className="flex items-center gap-1.5 bg-amber-500/20 text-[#FFCC00] px-2.5 py-0.5 rounded-full font-mono text-[10px] font-bold border border-amber-500/30">
            <span className="w-2 h-2 rounded-full bg-[#FFCC00] animate-ping" />
            <span>Live Requests Active ({requests.length})</span>
          </div>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white font-sans mb-1">
          Community Equipment & Roadside Services
        </h2>
        <p className="text-xs text-neutral-300 font-sans leading-relaxed">
          Manage your registered tow trucks and rental trailers across South Africa. Submit live bidding offers and accept requests directly below.
        </p>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 1: LIVE INCOMING REQUESTS WITH BIDDING SYSTEM         */}
      {/* ------------------------------------------------------------- */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4 text-amber-800" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-neutral-900 font-sans">
                Live Incoming Requests
              </h2>
              <p className="text-[11px] font-mono text-neutral-500">
                Directly connected to requesters ({requests.length} total)
              </p>
            </div>
          </div>

          {/* Filter Chips */}
          <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-amber-200 shadow-2xs">
            <button
              type="button"
              id="filter-all-requests"
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1 rounded-lg text-[11px] font-mono font-bold transition ${
                activeFilter === 'all'
                  ? 'bg-[#FFCC00] text-black shadow-2xs font-black'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              All ({requests.length})
            </button>
            <button
              type="button"
              id="filter-towing-requests"
              onClick={() => setActiveFilter('towing')}
              className={`px-3 py-1 rounded-lg text-[11px] font-mono font-bold transition ${
                activeFilter === 'towing'
                  ? 'bg-[#FFCC00] text-black shadow-2xs font-black'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              Towing ({towingRequests.length})
            </button>
            <button
              type="button"
              id="filter-trailer-requests"
              onClick={() => setActiveFilter('trailer')}
              className={`px-3 py-1 rounded-lg text-[11px] font-mono font-bold transition ${
                activeFilter === 'trailer'
                  ? 'bg-[#FFCC00] text-black shadow-2xs font-black'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              Trailer ({trailerRequests.length})
            </button>
          </div>
        </div>

        {/* Requests List */}
        {filteredRequests.length === 0 ? (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-dashed border-amber-300 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200">
              <Clock className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-neutral-900 font-sans">
              No Incoming {activeFilter === 'all' ? 'Asset' : activeFilter === 'towing' ? 'Towing' : 'Trailer'} Requests Yet
            </h4>
            <p className="text-xs text-neutral-500 max-w-md mx-auto">
              When a requester books Towing Assistance or Trailer Hiring on their homepage, their live request will appear here instantly with full specifications and Make Offer buttons.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {filteredRequests.map((req) => {
              const isTowing = req.type === 'towing';
              const isAccepted = req.status === 'accepted';
              const isDeclined = req.status === 'declined';
              const offersList: OwnerBidOffer[] = req.offers || [];
              const myExistingOffer = offersList.find((o) => o.ownerId === (user.id || 'owner_01'));

              return (
                <div
                  key={req.id}
                  id={`asset-request-card-${req.id}`}
                  className={`bg-white rounded-2xl p-4 sm:p-5 border transition shadow-xs ${
                    isAccepted
                      ? 'border-emerald-300 bg-emerald-50/20'
                      : isDeclined
                      ? 'border-neutral-200 bg-neutral-50 opacity-60'
                      : 'border-amber-200 hover:border-amber-400'
                  }`}
                >
                  {/* Top Badge Row */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2.5 border-b border-amber-100">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`${
                          isTowing ? 'bg-red-600' : 'bg-blue-600'
                        } text-white font-mono text-[10px] font-black px-2.5 py-1 rounded-md uppercase flex items-center gap-1 shadow-2xs`}
                      >
                        {isTowing ? <Wrench className="w-3 h-3" /> : <Package className="w-3 h-3" />}
                        <span>{isTowing ? 'TOWING REQUEST' : 'TRAILER REQUEST'}</span>
                      </span>

                      {/* Main Attribute Badge */}
                      <span className="bg-neutral-900 text-[#FFCC00] font-mono text-[11px] font-black px-2.5 py-1 rounded-md">
                        {isTowing
                          ? `${req.vehicleType || 'Car'} • ${req.problem || 'Breakdown'}`
                          : `Request: ${req.trailerType || 'Luggage Trailer'} - ${req.durationQty || 1} ${req.durationType ? (req.durationType.charAt(0).toUpperCase() + req.durationType.slice(1)) : 'Days'} - R${req.offeredPrice || 750}${req.deliveryChoice === 'Need Delivery' || req.deliveryChoice === 'deliver' ? ' + delivery' : ''}`}
                      </span>

                      {!isTowing && (
                        <span className="bg-amber-100 text-amber-900 font-mono text-[10px] font-black px-2.5 py-0.5 rounded-md uppercase">
                          {req.durationQty || 1} {req.durationType || 'Days'}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono text-neutral-500">
                        {req.createdAt
                          ? new Date(req.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                          : 'Just now'}
                      </span>
                      {isAccepted ? (
                        <span className="bg-emerald-100 text-emerald-800 font-mono text-[10px] font-black px-2.5 py-0.5 rounded-md flex items-center gap-1 border border-emerald-300">
                          <Check className="w-3 h-3 stroke-[3]" />
                          <span>ACCEPTED</span>
                        </span>
                      ) : isDeclined ? (
                        <span className="bg-neutral-200 text-neutral-600 font-mono text-[10px] font-bold px-2 py-0.5 rounded-md">
                          Declined
                        </span>
                      ) : (
                        <span className="bg-amber-100 text-amber-900 font-mono text-[10px] font-bold px-2 py-0.5 rounded-md">
                          {offersList.length > 0 ? `${offersList.length} Offers Pending` : 'Pending Offers'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs mb-3.5">
                    {/* Location 1: Pickup / Breakdown */}
                    <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-neutral-500 block flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-red-500" />
                        <span>{isTowing ? 'Breakdown Location' : 'Pickup Location'}</span>
                      </span>
                      <p className="font-bold text-neutral-900 truncate">
                        {req.pickupAddress || req.pickup || req.location || 'Cape Town'}
                      </p>
                      {req.dropAddress || req.drop ? (
                        <p className="text-[10px] text-neutral-600 truncate">
                          To: {req.dropAddress || req.drop}
                        </p>
                      ) : null}
                    </div>

                    {/* Specification / Duration */}
                    <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-neutral-500 block flex items-center gap-1">
                        {isTowing ? <Car className="w-3 h-3 text-neutral-700" /> : <Calendar className="w-3 h-3 text-blue-700" />}
                        <span>{isTowing ? 'Vehicle & Issue' : 'Duration & Start Time'}</span>
                      </span>
                      <p className="font-bold text-neutral-900 truncate">
                        {isTowing
                          ? `${req.vehicleType || 'Vehicle'} (${req.problem || 'Breakdown'})`
                          : `${req.durationQty || 1} ${req.durationType || 'Days'} Duration`}
                      </p>
                      <p className="text-[10px] text-neutral-500 truncate">
                        {isTowing ? (req.description || 'Assistance requested') : (req.startDateTime || 'Immediate')}
                      </p>
                    </div>

                    {/* Requester Contact */}
                    <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-neutral-500 block flex items-center gap-1">
                        <Phone className="w-3 h-3 text-amber-600" />
                        <span>Requester Contact</span>
                      </span>
                      <p className="font-bold text-neutral-900 truncate">{req.userName || 'Client'}</p>
                      <p className="text-[10px] text-neutral-600">{req.phone || '+27 82 000 0000'}</p>
                    </div>
                  </div>

                  {/* Optional Load or Photos Info */}
                  {!isTowing && req.loadDesc && (
                    <div className="mb-3 px-3 py-2 bg-blue-50/60 rounded-xl border border-blue-200 text-xs font-mono text-blue-950">
                      <span className="font-bold">Load Details:</span> {req.loadDesc}
                    </div>
                  )}

                  {/* Driver Card style Offer Card requirement */}
                  <div className="bg-[#FFFBEB] rounded-2xl p-3.5 border border-amber-300 space-y-2 mb-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-3">
                        <img
                          src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                          alt="Owner/Company"
                          className="w-10 h-10 rounded-xl object-cover border-2 border-amber-400"
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-black text-xs text-neutral-900">
                              {myExistingOffer?.ownerName || user.name || (isTowing ? 'Kape Towing & Recovery' : 'Mkhize Trailer Rentals')}
                            </h4>
                            <span className="bg-emerald-500 text-white text-[8px] font-mono px-1.5 py-0.2 rounded-full font-bold">
                              Verified
                            </span>
                          </div>
                          <p className="text-[10px] font-mono text-neutral-700 flex items-center gap-1 mt-0.5">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                            <strong className="text-amber-950 font-black">⭐ 4.8</strong> • 127 jobs • <span className="text-emerald-700 font-bold">Verified</span>
                          </p>
                          <p className="text-[11px] font-bold text-neutral-800 mt-0.5">
                            Asset: {myExistingOffer?.assetName || (isTowing ? 'Flatbed Tow Truck' : 'Venter 7ft Trailer')}
                          </p>
                        </div>
                      </div>
                      <div className="text-right bg-white px-3 py-1.5 rounded-xl border border-amber-300 font-mono">
                        <span className="text-[9px] font-bold text-neutral-500 uppercase block">Offer</span>
                        <span className="text-sm font-black text-neutral-900">
                          R {myExistingOffer?.price || req.offeredPrice || (isTowing ? 450 : 250)}
                        </span>
                        <span className="text-[10px] text-amber-800 font-bold block">
                          ETA {myExistingOffer?.eta || (isTowing ? '15 mins' : 'Ready today')}
                        </span>
                      </div>
                    </div>

                    {/* BID UP/DOWN controls */}
                    {!isAccepted && !isDeclined && (
                      <div className="flex items-center gap-2 pt-2 border-t border-amber-200">
                        <button
                          type="button"
                          id={`btn-bid-down-${req.id}`}
                          onClick={() => handleBidUpDown(req, -20)}
                          className="flex-1 bg-white hover:bg-neutral-100 border border-neutral-300 py-1.5 rounded-xl text-[11px] font-mono font-bold text-neutral-800 active:scale-95 transition cursor-pointer"
                        >
                          -R20 BID DOWN
                        </button>
                        <button
                          type="button"
                          id={`btn-bid-up-${req.id}`}
                          onClick={() => handleBidUpDown(req, +20)}
                          className="flex-1 bg-white hover:bg-neutral-100 border border-neutral-300 py-1.5 rounded-xl text-[11px] font-mono font-bold text-neutral-800 active:scale-95 transition cursor-pointer"
                        >
                          +R20 BID UP
                        </button>
                        <button
                          type="button"
                          id={`btn-card-accept-${req.id}`}
                          onClick={() => handleDirectAccept(req)}
                          className="bg-emerald-500 hover:bg-emerald-600 text-white font-mono font-black text-xs px-3.5 py-1.5 rounded-xl uppercase shadow-2xs active:scale-95 transition cursor-pointer"
                        >
                          ACCEPT
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Footer Action Row */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-amber-100">
                    <div className="font-mono">
                      <span className="text-[10px] uppercase text-neutral-500 block font-bold">Requester's Offer</span>
                      <span className="text-lg font-black text-black font-mono">
                        R {req.offeredPrice || (isTowing ? 450 : 250)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <a
                        href={`tel:${String(req.phone || '').replace(/\s+/g, '')}`}
                        className="bg-neutral-100 hover:bg-neutral-200 text-neutral-900 px-3 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition"
                      >
                        <Phone className="w-3.5 h-3.5 text-amber-600" />
                        <span>Call</span>
                      </a>

                      {!isAccepted && !isDeclined && (
                        <>
                          <button
                            type="button"
                            onClick={() => handleDeclineRequest(req)}
                            className="bg-neutral-100 hover:bg-red-50 text-neutral-700 hover:text-red-700 px-3 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer"
                          >
                            Decline
                          </button>

                          <button
                            type="button"
                            id={`btn-make-offer-${req.id}`}
                            onClick={() => handleOpenOfferModal(req)}
                            className="bg-[#FFCC00] hover:bg-yellow-400 text-black px-4 py-2 rounded-xl text-xs font-mono font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1.5 shadow-xs cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>{myExistingOffer ? 'Update Offer' : 'Make Offer'}</span>
                          </button>

                          <button
                            type="button"
                            id={`btn-accept-direct-${req.id}`}
                            onClick={() => handleDirectAccept(req)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-mono font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1.5 shadow-xs cursor-pointer"
                            title="Accept at Requester Offer Price"
                          >
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                            <span>Direct Accept</span>
                          </button>
                        </>
                      )}

                      {isAccepted && (
                        <div className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-mono font-black uppercase flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Dispatch Confirmed</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 2: MY ASSETS & FLEET MANAGEMENT (TOW TRUCKS & TRAILERS) */}
      {/* ------------------------------------------------------------- */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-4 border-t border-amber-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-neutral-900 text-[#FFCC00] flex items-center justify-center font-bold">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-neutral-900 font-sans">
                My Registered Assets & Fleet
              </h2>
              <p className="text-[11px] font-mono text-neutral-500">
                {myAssets.length} Units Registered • Live on ZOLTA Community Network
              </p>
            </div>
          </div>

          {/* Button: + Register New Asset */}
          <button
            type="button"
            id="btn-register-new-asset"
            onClick={() => setIsAddAssetModalOpen(true)}
            className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs font-mono px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Register New Asset</span>
          </button>
        </div>

        {/* Fleet Summary Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
          <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">Total Fleet</span>
            <div className="text-xl font-black text-neutral-900 mt-0.5">{myAssets.length} Units</div>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1 mt-1">
              <Activity className="w-3 h-3" /> Ready for dispatch
            </span>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">Tow Trucks</span>
            <div className="text-xl font-black text-neutral-900 mt-0.5">
              {myAssets.filter((a) => a.category === 'towing').length} Units
            </div>
            <span className="text-[10px] text-neutral-500 font-medium mt-1 block">Rollbacks & Recovery</span>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">Rental Trailers</span>
            <div className="text-xl font-black text-neutral-900 mt-0.5">
              {myAssets.filter((a) => a.category === 'trailer').length} Units
            </div>
            <span className="text-[10px] text-neutral-500 font-medium mt-1 block">Luggage & Flatbed</span>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">Total Earnings</span>
            <div className="text-xl font-black text-neutral-900 mt-0.5">
              R {myAssets.reduce((acc, a) => acc + (a.totalTrips * a.ratePerDayOrTrip * 0.85), 0).toFixed(0)}
            </div>
            <span className="text-[10px] text-amber-700 font-bold flex items-center gap-1 mt-1">
              <DollarSign className="w-3 h-3" /> 85% Payout rate
            </span>
          </div>
        </div>

        {/* Assets Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {myAssets.map((asset) => {
            const isTow = asset.category === 'towing';
            return (
              <div
                key={asset.id}
                id={`asset-card-${asset.id}`}
                className="bg-white rounded-[22px] p-5 border border-amber-200 shadow-xs flex flex-col justify-between hover:border-amber-400 transition"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold ${
                        isTow ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                      }`}>
                        {isTow ? <Wrench className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                      </div>
                      <div>
                        <span className="bg-neutral-900 text-[#FFCC00] font-mono text-[9px] font-black px-2 py-0.5 rounded uppercase">
                          {isTow ? 'TOW TRUCK / ROLLBACK' : 'TRAILER HIRE'}
                        </span>
                        <div className="text-[10px] font-mono text-neutral-500 font-bold mt-0.5">
                          Plate: {asset.plateOrSerial}
                        </div>
                      </div>
                    </div>

                    <span className="bg-emerald-100 text-emerald-800 font-mono text-[10px] font-black px-2.5 py-1 rounded-full uppercase border border-emerald-300 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                      <span>{asset.status === 'active' ? 'Active & Ready' : asset.status}</span>
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-neutral-900 mb-1 font-sans">
                    {asset.name}
                  </h3>
                  <p className="text-xs text-neutral-600 mb-3 font-sans leading-relaxed">
                    {asset.specs}
                  </p>

                  <div className="bg-amber-50/70 p-2.5 rounded-xl border border-amber-200 text-xs font-mono text-neutral-700 space-y-1 mb-3">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500 text-[11px]">Base Rate:</span>
                      <span className="font-black text-neutral-900">R {asset.ratePerDayOrTrip} {isTow ? '/ trip' : '/ day'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-500 text-[11px]">Coverage Base:</span>
                      <span className="font-bold text-neutral-800 truncate max-w-[170px]">{asset.location}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-amber-100 text-[11px] font-mono">
                  <div className="flex items-center gap-1 text-neutral-700">
                    <Star className="w-3.5 h-3.5 fill-[#FFCC00] text-[#FFCC00]" />
                    <span className="font-bold">{asset.rating.toFixed(1)}</span>
                    <span className="text-neutral-400">({asset.totalTrips} completed)</span>
                  </div>

                  <div className="text-emerald-700 font-black">
                    Live in Network ✓
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* MODAL: MAKE OWNER BID / OFFER                                  */}
      {/* ------------------------------------------------------------- */}
      {selectedReqForOffer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-[28px] p-6 border border-amber-200 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setSelectedReqForOffer(null)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-[#FFCC00] text-black flex items-center justify-center">
                <Send className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-black text-neutral-900 font-sans">
                  Submit Owner Offer
                </h3>
                <p className="text-[11px] font-mono text-neutral-500 font-bold uppercase">
                  {selectedReqForOffer.type === 'towing' ? 'Towing Operator Dispatch' : 'Trailer Hire Quotation'}
                </p>
              </div>
            </div>

            {/* Request Snapshot */}
            <div className="bg-neutral-50 rounded-2xl p-3 border border-neutral-200 mb-4 text-xs font-mono space-y-1">
              <div className="flex items-center justify-between font-bold text-neutral-900">
                <span>{selectedReqForOffer.userName}</span>
                <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded">
                  Offered R {selectedReqForOffer.offeredPrice || (selectedReqForOffer.type === 'towing' ? 450 : 250)}
                </span>
              </div>
              <p className="text-[11px] text-neutral-600 truncate">
                Service: {selectedReqForOffer.type === 'towing'
                  ? `${selectedReqForOffer.vehicleType || 'Car'} • ${selectedReqForOffer.problem || 'Breakdown'}`
                  : `${selectedReqForOffer.trailerType || 'Luggage'} (${selectedReqForOffer.durationQty || 1} ${selectedReqForOffer.durationType || 'Days'})`}
              </p>
              <p className="text-[10px] text-neutral-500 truncate">
                Area: {selectedReqForOffer.pickupAddress || selectedReqForOffer.pickup || selectedReqForOffer.location}
              </p>
            </div>

            <form onSubmit={handleSubmitOffer} className="space-y-4 font-mono text-xs">
              {/* Offer Price Input with Quick Buttons */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                  Your Offer Price (ZAR)
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setOfferPrice((prev) => Math.max(100, prev - 50))}
                    className="h-10 px-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-900 font-black rounded-xl border border-neutral-300 active:scale-95"
                  >
                    -R50
                  </button>
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-2.5 font-bold text-neutral-500">R</span>
                    <input
                      type="number"
                      required
                      min={50}
                      step={10}
                      value={offerPrice}
                      onChange={(e) => setOfferPrice(Number(e.target.value))}
                      className="w-full h-10 pl-8 pr-3 bg-white border-2 border-amber-400 rounded-xl text-base font-black text-neutral-900 outline-none focus:border-black"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setOfferPrice((prev) => prev + 50)}
                    className="h-10 px-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-900 font-black rounded-xl border border-neutral-300 active:scale-95"
                  >
                    +R50
                  </button>
                </div>
              </div>

              {/* ETA / Availability */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                  {selectedReqForOffer.type === 'towing' ? 'Estimated Arrival Time (ETA)' : 'Availability / Collection Time'}
                </label>
                <input
                  type="text"
                  required
                  value={offerEta}
                  onChange={(e) => setOfferEta(e.target.value)}
                  placeholder={selectedReqForOffer.type === 'towing' ? 'e.g. 15-20 mins' : 'e.g. Ready for collection today'}
                  className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-bold outline-none focus:border-black"
                />
                <div className="flex gap-1.5 mt-1.5 overflow-x-auto pb-1">
                  {(selectedReqForOffer.type === 'towing'
                    ? ['15 mins', '25 mins', '35 mins', '45 mins']
                    : ['Ready Now', 'Today at 2pm', 'Tomorrow Morning', 'Delivery Available']
                  ).map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setOfferEta(preset)}
                      className="text-[10px] bg-neutral-100 hover:bg-amber-100 px-2 py-1 rounded border border-neutral-200 font-bold whitespace-nowrap cursor-pointer"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Note to Requester */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                  Note to Requester (Optional)
                </label>
                <input
                  type="text"
                  value={offerNote}
                  onChange={(e) => setOfferNote(e.target.value)}
                  placeholder={selectedReqForOffer.type === 'towing' ? 'e.g. Heavy winch equipped' : 'e.g. Clean & licensed'}
                  className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-medium outline-none focus:border-black"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmittingOffer}
                  className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black py-3.5 rounded-xl uppercase tracking-wider transition active:scale-95 shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmittingOffer ? 'Broadcasting Offer...' : `SEND OFFER (R ${offerPrice})`}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODAL: REGISTER NEW ASSET (TOW TRUCK / TRAILER)                */}
      {/* ------------------------------------------------------------- */}
      {isAddAssetModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-[28px] p-6 sm:p-8 border border-amber-200 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setIsAddAssetModalOpen(false)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-10 h-10 rounded-2xl bg-[#FFCC00] text-black flex items-center justify-center">
                <Plus className="w-5 h-5 stroke-[3]" />
              </div>
              <div>
                <h3 className="text-xl font-black text-neutral-900 font-sans">Register New Asset</h3>
                <p className="text-[11px] font-mono text-neutral-500 font-bold uppercase">
                  Add Tow Truck or Rental Trailer to Network
                </p>
              </div>
            </div>

            <form onSubmit={handleCreateAsset} className="space-y-4 font-mono text-xs">
              {/* Category Selector */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1.5">
                  Asset Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewAssetCategory('towing')}
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 font-bold transition ${
                      newAssetCategory === 'towing'
                        ? 'bg-[#FFCC00] text-black border-black/50 shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200'
                    }`}
                  >
                    <Wrench className="w-4 h-4" />
                    <span>Tow Truck / Rollback</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewAssetCategory('trailer')}
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 font-bold transition ${
                      newAssetCategory === 'trailer'
                        ? 'bg-[#FFCC00] text-black border-black/50 shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200'
                    }`}
                  >
                    <Package className="w-4 h-4" />
                    <span>Rental Trailer</span>
                  </button>
                </div>
              </div>

              {/* Asset Name / Model */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                  Asset Name & Model
                </label>
                <input
                  type="text"
                  required
                  placeholder={newAssetCategory === 'towing' ? 'e.g. Hino 300 4-Ton Rollback' : 'e.g. 3m Heavy Duty Utility Trailer'}
                  value={newAssetName}
                  onChange={(e) => setNewAssetName(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-bold outline-none focus:border-black"
                />
              </div>

              {/* Registration Plate / Serial */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                    Registration Plate
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CA 554-123"
                    value={newAssetPlate}
                    onChange={(e) => setNewAssetPlate(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-bold outline-none focus:border-black"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                    Rate (ZAR)
                  </label>
                  <input
                    type="number"
                    required
                    placeholder={newAssetCategory === 'towing' ? '450' : '250'}
                    value={newAssetRate}
                    onChange={(e) => setNewAssetRate(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-bold outline-none focus:border-black"
                  />
                </div>
              </div>

              {/* Specs & Capabilities */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                  Specifications & Equipment
                </label>
                <input
                  type="text"
                  placeholder={newAssetCategory === 'towing' ? 'e.g. 4.5 Ton winch, wheel lift, jump start booster' : 'e.g. Weatherproof lid, double axle, tie down points'}
                  value={newAssetSpecs}
                  onChange={(e) => setNewAssetSpecs(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-bold outline-none focus:border-black"
                />
              </div>

              {/* Location Base */}
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase block mb-1">
                  Location & Operating Area
                </label>
                <input
                  type="text"
                  value={newAssetLocation}
                  onChange={(e) => setNewAssetLocation(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-300 rounded-xl px-3 py-2.5 text-neutral-900 font-bold outline-none focus:border-black"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmittingAsset}
                  className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black py-3.5 rounded-xl uppercase tracking-wider transition active:scale-95 shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isSubmittingAsset ? 'Registering Asset...' : 'Confirm & Add to Live Network'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Owner Reviews Modal */}
      <OwnerReviewsModal
        isOpen={isReviewsModalOpen}
        onClose={() => setIsReviewsModalOpen(false)}
        rating={4.9}
        jobsCount={43}
        ownerName={user.name || 'Verified ZOLTA Operator'}
      />

      {/* Rate Owner Modal */}
      {ratingModalReq && (
        <RateOwnerModal
          isOpen={!!ratingModalReq}
          onClose={() => setRatingModalReq(null)}
          ownerId={ratingModalReq.ownerId || 'owner_01'}
          ownerName={ratingModalReq.ownerName || 'Verified ZOLTA Operator'}
          assetName={ratingModalReq.assetName || (ratingModalReq.type === 'towing' ? 'Flatbed Tow Truck' : 'Venter 7ft Trailer')}
          serviceType={ratingModalReq.type}
          onSubmitted={() => {
            setAcceptedToast('Rating submitted successfully!');
            setTimeout(() => setAcceptedToast(null), 3000);
          }}
        />
      )}
    </div>
  );
};

// Export alias for AssetOwnersPortal
export const AssetOwnersPortal = AssetOwnerView;
export default AssetOwnerView;

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  saveTrailerToFirestore,
  subscribeToTrailers,
  saveTrailerBookingToFirestore,
  subscribeToTrailerBookings,
  createTrailerRequestInFirestore,
} from '../../services/firestoreService';
import { addAssetRequest, updateAssetRequestStatus } from '../../services/assetRequestsService';
import { TrailerType, HireDuration } from '../../types';
import { AssetOffersWaitingScreen } from '../common/AssetOffersWaitingScreen';
import { OwnerReviewsModal } from '../common/OwnerReviewsModal';
import { RateOwnerModal } from '../common/RateOwnerModal';
import {
  ArrowLeft,
  Package,
  Calendar,
  Clock,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  Phone,
  Plus,
  Filter,
  Truck,
  Car,
  X,
  Sparkles,
  Info,
  DollarSign,
  Layers,
  Search,
  MessageSquare,
  ThumbsUp,
  XCircle,
  Star,
} from 'lucide-react';

export type TrailerKind = 'Luggage' | 'Utility' | 'Car Trailer' | 'Box / Enclosed' | 'Flatbed' | 'Camping';
export type TrailerSize = '6x4 ft' | '7x5 ft' | '8x5 ft' | '10x5 ft' | 'Double Axle' | '14x6 ft Car Hauler';

export interface TrailerItem {
  id: string;
  name: string;
  kind: TrailerKind;
  size: TrailerSize;
  imageUrl: string;
  pricePerHour: number;
  pricePerDay: number;
  pricePerWeek: number;
  pricePerMonth: number;
  location: string;
  deposit: number;
  deliveryAvailable: boolean;
  deliveryFee: number;
  ownerName: string;
  ownerPhone: string;
  rating: number;
  totalTrips: number;
}

export interface OwnerOffer {
  id: string;
  ownerName: string;
  ownerPhone: string;
  counterAmount: number;
  timestamp: string;
}

export interface TrailerBookingRecord {
  id: string;
  trailerId: string;
  trailerName: string;
  ownerName: string;
  ownerPhone: string;
  hireDurationType: 'hour' | 'day' | 'week' | 'month';
  hireUnits: number;
  hireDeliveryChoice: 'fetch' | 'deliver';
  totalAmount: number;
  offeredPrice: number;
  ownerOffers: OwnerOffer[];
  deposit: number;
  riderId: string;
  riderName: string;
  riderPhone?: string;
  status: 'pending_offers' | 'countered' | 'confirmed' | 'declined';
  timestamp?: string;
}

export const TrailerHiringView: React.FC = () => {
  const { setCurrentView, setMode, user } = useApp();

  // Active Tab: 'requester' or 'register'
  const [activeTab, setActiveTab] = useState<'requester' | 'register'>('requester');
  const [activeBiddingRequestId, setActiveBiddingRequestId] = useState<string | null>(null);

  // Custom Trailer Request State
  const [customPickupLocation, setCustomPickupLocation] = useState('Cape Town CBD');
  const [customDropLocation, setCustomDropLocation] = useState('Cape Town Metropole / Western Cape');
  const [customTrailerType, setCustomTrailerType] = useState('Luggage Trailer');
  const [customDurationType, setCustomDurationType] = useState<'hours' | 'days' | 'weeks' | 'months'>('days');
  const [customDurationQty, setCustomDurationQty] = useState<number>(3);
  const [customStartDateTime, setCustomStartDateTime] = useState('Today (Immediate)');
  const [customLoadDesc, setCustomLoadDesc] = useState('');
  const [customTrailerOfferedPrice, setCustomTrailerOfferedPrice] = useState<number>(450);
  const [showCustomForm, setShowCustomForm] = useState(true);

  // Filters & State
  const [trailers, setTrailers] = useState<TrailerItem[]>([]);
  const [selectedKind, setSelectedKind] = useState<string>('All');
  const [selectedSize, setSelectedSize] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [deliveryMode, setDeliveryMode] = useState<'fetch' | 'deliver'>('fetch');

  // Booking Modal & Offer State
  const [selectedTrailerForHire, setSelectedTrailerForHire] = useState<TrailerItem | null>(null);
  const [hireDurationType, setHireDurationType] = useState<'hour' | 'day' | 'week' | 'month'>('day');
  const [hireUnits, setHireUnits] = useState(1);
  const [hireStartDate, setHireStartDate] = useState('Today (Immediate)');
  const [hireDeliveryChoice, setHireDeliveryChoice] = useState<'fetch' | 'deliver'>('fetch');
  const [customOfferPrice, setCustomOfferPrice] = useState<number>(0);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [bookingRef, setBookingRef] = useState('');

  // Real-time Trailer Bookings & Bids State
  const [trailerBookings, setTrailerBookings] = useState<TrailerBookingRecord[]>([]);
  const [activeUserBooking, setActiveUserBooking] = useState<TrailerBookingRecord | null>(null);

  // Counter Bid Form State (Owner side)
  const [counterBidAmounts, setCounterBidAmounts] = useState<{ [bookingId: string]: number }>({});

  // Owner Registration Form State
  const [regTitle, setRegTitle] = useState('');
  const [regKind, setRegKind] = useState<TrailerKind>('Utility');
  const [regSize, setRegSize] = useState<TrailerSize>('7x5 ft');
  const [regPriceHour, setRegPriceHour] = useState('50');
  const [regPriceDay, setRegPriceDay] = useState('250');
  const [regPriceWeek, setRegPriceWeek] = useState('1200');
  const [regPriceMonth, setRegPriceMonth] = useState('4000');
  const [regLocation, setRegLocation] = useState('Cape Town');
  const [regDeposit, setRegDeposit] = useState('500');
  const [regDeliveryAvail, setRegDeliveryAvail] = useState(true);
  const [regDeliveryFee, setRegDeliveryFee] = useState('150');
  const [regOwnerName, setRegOwnerName] = useState(user.name || '');
  const [regOwnerPhone, setRegOwnerPhone] = useState(user.phone || '');
  const [regSuccess, setRegSuccess] = useState(false);

  // Real-time sync trailers with Firestore
  useEffect(() => {
    const unsub = subscribeToTrailers((liveTrailers) => {
      if (liveTrailers) {
        const list: TrailerItem[] = liveTrailers.map((tr) => ({
          id: tr.id,
          name: tr.name || 'Community Trailer',
          kind: tr.kind || 'Utility',
          size: tr.size || '7x5 ft',
          imageUrl: tr.imageUrl || 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=600&q=80',
          pricePerHour: tr.pricePerHour || 50,
          pricePerDay: tr.pricePerDay || 250,
          pricePerWeek: tr.pricePerWeek || 1200,
          pricePerMonth: tr.pricePerMonth || 4000,
          location: tr.location || 'Cape Town',
          deposit: tr.deposit || 500,
          deliveryAvailable: tr.deliveryAvailable ?? true,
          deliveryFee: tr.deliveryFee || 0,
          ownerName: tr.ownerName || 'Owner',
          ownerPhone: tr.ownerPhone || '+27 82 000 0000',
          rating: tr.rating || 5.0,
          totalTrips: tr.totalTrips || 0,
        }));
        setTrailers(list);
      }
    });
    return () => unsub();
  }, []);

  // Real-time sync trailer bookings with Firestore
  useEffect(() => {
    const unsub = subscribeToTrailerBookings((liveBookings) => {
      if (liveBookings) {
        const list: TrailerBookingRecord[] = liveBookings.map((b) => ({
          id: b.id,
          trailerId: b.trailerId,
          trailerName: b.trailerName,
          ownerName: b.ownerName,
          ownerPhone: b.ownerPhone,
          hireDurationType: b.hireDurationType || 'day',
          hireUnits: b.hireUnits || 1,
          hireDeliveryChoice: b.hireDeliveryChoice || 'fetch',
          totalAmount: b.totalAmount || 250,
          offeredPrice: b.offeredPrice || b.totalAmount || 250,
          ownerOffers: b.ownerOffers || [],
          deposit: b.deposit || 500,
          riderId: b.riderId,
          riderName: b.riderName,
          riderPhone: b.riderPhone || '+27 82 555 1313',
          status: b.status || 'pending_offers',
          timestamp: b.timestamp || 'Just now',
        }));
        setTrailerBookings(list);
        const myBooking = list.find((item) => (user.id && item.riderId === user.id) || (user.name && item.riderName === user.name));
        if (myBooking) setActiveUserBooking(myBooking);
      }
    });
    return () => unsub();
  }, [user.id, user.name]);

  const handleGoBack = () => {
    setMode('rider');
    setCurrentView('home');
  };

  // Filter Trailers
  const filteredTrailers = trailers.filter((t) => {
    let matchesKind = true;
    if (selectedKind === 'Box / Flatbed') {
      matchesKind = t.kind === 'Box / Enclosed' || t.kind === 'Flatbed';
    } else if (selectedKind !== 'All') {
      matchesKind = t.kind === selectedKind;
    }

    const matchesSize = selectedSize === 'All' || t.size === selectedSize;
    const matchesSearch =
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.kind.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesKind && matchesSize && matchesSearch;
  });

  // Calculate booking standard total
  const calculateTotal = () => {
    if (!selectedTrailerForHire) return 0;
    let base = 0;
    if (hireDurationType === 'hour') base = selectedTrailerForHire.pricePerHour * hireUnits;
    if (hireDurationType === 'day') base = selectedTrailerForHire.pricePerDay * hireUnits;
    if (hireDurationType === 'week') base = selectedTrailerForHire.pricePerWeek * hireUnits;
    if (hireDurationType === 'month') base = selectedTrailerForHire.pricePerMonth * hireUnits;

    const del = hireDeliveryChoice === 'deliver' && selectedTrailerForHire.deliveryAvailable ? selectedTrailerForHire.deliveryFee : 0;
    return base + del;
  };

  // Keep custom offer price in sync when duration/delivery changes if not yet adjusted
  useEffect(() => {
    if (selectedTrailerForHire) {
      setCustomOfferPrice(calculateTotal());
    }
  }, [selectedTrailerForHire, hireDurationType, hireUnits, hireDeliveryChoice]);

  const handleStartHire = (trailer: TrailerItem, initialDuration: 'hour' | 'day' | 'week' | 'month' = 'day') => {
    setSelectedTrailerForHire(trailer);
    setHireDeliveryChoice(deliveryMode);
    setHireUnits(1);
    setHireDurationType(initialDuration);
    setBookingSuccess(false);

    let base = trailer.pricePerDay;
    if (initialDuration === 'hour') base = trailer.pricePerHour;
    if (initialDuration === 'week') base = trailer.pricePerWeek;
    if (initialDuration === 'month') base = trailer.pricePerMonth;

    if (deliveryMode === 'deliver' && trailer.deliveryAvailable) base += trailer.deliveryFee;
    setCustomOfferPrice(base);
  };

  const handleConfirmHire = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTrailerForHire) return;

    const refCode = `ZLT-TR-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingRef(refCode);
    setBookingSuccess(true);

    const ownerRate =
      hireDurationType === 'hour' ? selectedTrailerForHire.pricePerHour :
      hireDurationType === 'day' ? selectedTrailerForHire.pricePerDay :
      hireDurationType === 'week' ? selectedTrailerForHire.pricePerWeek :
      selectedTrailerForHire.pricePerMonth;

    const finalOfferedPrice = customOfferPrice > 0 ? customOfferPrice : ownerRate;
    const newBookingRecord: TrailerBookingRecord = {
      id: refCode,
      trailerId: selectedTrailerForHire.id,
      trailerName: selectedTrailerForHire.name,
      ownerName: selectedTrailerForHire.ownerName,
      ownerPhone: selectedTrailerForHire.ownerPhone,
      hireDurationType,
      hireUnits: 1,
      hireDeliveryChoice,
      totalAmount: ownerRate,
      offeredPrice: finalOfferedPrice,
      ownerOffers: [],
      deposit: selectedTrailerForHire.deposit,
      riderId: user.id || 'rider_101',
      riderName: user.name || 'Community Member',
      riderPhone: user.phone || '+27 82 555 1313',
      status: 'pending_offers',
      timestamp: 'Just now',
    };

    setTrailerBookings([newBookingRecord, ...trailerBookings]);
    setActiveUserBooking(newBookingRecord);

    // Save to localStorage asset requests array (Requirement 2 & 3)
    const formattedDurationMap: Record<string, string> = {
      hour: 'Hourly',
      day: 'Daily',
      week: 'Weekly',
      month: 'Monthly',
    };
    const formattedDuration = formattedDurationMap[hireDurationType] || 'Daily';

    let resolvedTrailerType: TrailerType = 'Utility';
    const kindStr = selectedTrailerForHire.kind || selectedTrailerForHire.name;
    if (kindStr.includes('Luggage')) resolvedTrailerType = 'Luggage';
    else if (kindStr.includes('Car')) resolvedTrailerType = 'Car Transporter';
    else if (kindStr.includes('Flatbed')) resolvedTrailerType = 'Flatbed';
    else if (kindStr.includes('Double') || selectedTrailerForHire.size.includes('Double')) resolvedTrailerType = 'Double-Axle';
    else if (kindStr.includes('Utility')) resolvedTrailerType = 'Utility';
    else if (kindStr.includes('Box')) resolvedTrailerType = 'Flatbed';
    else resolvedTrailerType = 'Utility';

    addAssetRequest({
      id: refCode,
      type: 'trailer',
      trailerType: resolvedTrailerType,
      hireDuration: formattedDuration as HireDuration,
      deliveryChoice: hireDeliveryChoice === 'deliver' ? 'Delivery' : 'Will Fetch',
      location: selectedTrailerForHire.location || 'Cape Town',
      gpsLocation: { lat: -33.9249, lng: 18.4241 },
      trailerId: selectedTrailerForHire.id,
      trailerName: selectedTrailerForHire.name,
      ownerName: selectedTrailerForHire.ownerName,
      ownerPhone: selectedTrailerForHire.ownerPhone,
      phone: user.phone || '+27 82 555 1313',
      userName: user.name || 'Community Member',
      totalAmount: ownerRate,
      offeredPrice: finalOfferedPrice,
      deposit: selectedTrailerForHire.deposit,
      status: 'pending',
      createdAt: Date.now(),
    });

    const firestorePayload = {
      ...newBookingRecord,
      userId: user.id || 'rider_101',
      selectedRate: ownerRate,
      offerPrice: finalOfferedPrice,
      delivery: hireDeliveryChoice,
      status: 'pending',
    };

    saveTrailerBookingToFirestore(firestorePayload).catch((err) =>
      console.warn('Error saving trailer booking to Firestore:', err)
    );
  };

  // OWNER ACTION: Accept Requester Offer
  const handleOwnerAcceptOffer = (booking: TrailerBookingRecord) => {
    const updated = {
      ...booking,
      status: 'confirmed' as const,
      totalAmount: booking.offeredPrice,
    };
    setTrailerBookings((prev) => prev.map((b) => (b.id === booking.id ? updated : b)));
    saveTrailerBookingToFirestore(updated).catch(() => {});
    updateAssetRequestStatus(booking.id, 'accepted', booking.ownerName || user.name || 'Trailer Owner');
  };

  // OWNER ACTION: Submit Counter Bid
  const handleOwnerSubmitCounter = (booking: TrailerBookingRecord) => {
    const counterVal = counterBidAmounts[booking.id] || booking.offeredPrice + 30;
    const newOffer: OwnerOffer = {
      id: `off-${Date.now()}`,
      ownerName: booking.ownerName || 'Trailer Owner',
      ownerPhone: booking.ownerPhone || '+27 82 000 0000',
      counterAmount: counterVal,
      timestamp: 'Just now',
    };
    const updated: TrailerBookingRecord = {
      ...booking,
      status: 'countered' as const,
      ownerOffers: [...(booking.ownerOffers || []), newOffer],
    };
    setTrailerBookings((prev) => prev.map((b) => (b.id === booking.id ? updated : b)));
    saveTrailerBookingToFirestore(updated).catch(() => {});
  };

  // OWNER ACTION: Decline
  const handleOwnerDecline = (booking: TrailerBookingRecord) => {
    const updated = { ...booking, status: 'declined' as const };
    setTrailerBookings((prev) => prev.map((b) => (b.id === booking.id ? updated : b)));
    saveTrailerBookingToFirestore(updated).catch(() => {});
    updateAssetRequestStatus(booking.id, 'declined');
  };

  // REQUESTER ACTION: Accept Owner Counter Offer
  const handleRequesterAcceptCounter = (booking: TrailerBookingRecord, offer: OwnerOffer) => {
    const updated: TrailerBookingRecord = {
      ...booking,
      status: 'confirmed' as const,
      totalAmount: offer.counterAmount,
      offeredPrice: offer.counterAmount,
    };
    setTrailerBookings((prev) => prev.map((b) => (b.id === booking.id ? updated : b)));
    setActiveUserBooking(updated);
    saveTrailerBookingToFirestore(updated).catch(() => {});
    updateAssetRequestStatus(booking.id, 'accepted', offer.ownerName);
  };

  const handleRegisterTrailer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regTitle.trim()) return;

    const newTrailer: TrailerItem = {
      id: `tr-${Date.now()}`,
      name: regTitle,
      kind: regKind,
      size: regSize,
      imageUrl: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=600&q=80',
      pricePerHour: parseFloat(regPriceHour) || 50,
      pricePerDay: parseFloat(regPriceDay) || 250,
      pricePerWeek: parseFloat(regPriceWeek) || 1200,
      pricePerMonth: parseFloat(regPriceMonth) || 4000,
      location: regLocation,
      deposit: parseFloat(regDeposit) || 500,
      deliveryAvailable: regDeliveryAvail,
      deliveryFee: parseFloat(regDeliveryFee) || 0,
      ownerName: regOwnerName,
      ownerPhone: regOwnerPhone,
      rating: 5.0,
      totalTrips: 0,
    };

    setTrailers([newTrailer, ...trailers]);
    setRegSuccess(true);

    // Save to Firestore
    saveTrailerToFirestore(newTrailer).catch((err) =>
      console.warn('Error saving trailer to Firestore:', err)
    );

    setTimeout(() => {
      setRegSuccess(false);
      setActiveTab('requester');
      setRegTitle('');
    }, 1800);
  };

  // SUBMIT CUSTOM TRAILER REQUEST TO FIRESTORE (BIDDING FLOW)
  const handleCustomTrailerRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    const reqId = `TR-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const trailerDoc = {
      id: reqId,
      requesterId: user.id || 'rider_101',
      requesterName: user.name || 'Community Member',
      requesterPhone: user.phone || '+27 82 555 1313',
      pickup: customPickupLocation,
      drop: customDropLocation,
      trailerType: customTrailerType,
      durationType: customDurationType,
      durationQty: Number(customDurationQty) || 1,
      startDateTime: customStartDateTime,
      loadDesc: customLoadDesc || 'General goods / cargo',
      offeredPrice: customTrailerOfferedPrice,
      status: 'pending' as const,
      createdAt: Date.now(),
      offers: [],
    };

    try {
      await createTrailerRequestInFirestore(trailerDoc);
    } catch (err) {
      console.warn('Error writing trailer request to Firestore:', err);
    }

    // Also register in local asset requests
    const formattedDurationMap: Record<string, string> = {
      hours: 'Hourly',
      days: 'Daily',
      weeks: 'Weekly',
      months: 'Monthly',
    };
    const formattedDuration = formattedDurationMap[customDurationType] || 'Daily';

    let resolvedTrailerType: TrailerType = 'Utility';
    if (customTrailerType.includes('Luggage')) resolvedTrailerType = 'Luggage';
    else if (customTrailerType.includes('Car')) resolvedTrailerType = 'Car Transporter';
    else if (customTrailerType.includes('Fridge')) resolvedTrailerType = 'Flatbed';
    else if (customTrailerType.includes('Bike')) resolvedTrailerType = 'Utility';

    addAssetRequest({
      id: reqId,
      type: 'trailer',
      trailerType: resolvedTrailerType,
      hireDuration: `${customDurationQty} ${customDurationType}` as HireDuration,
      deliveryChoice: 'Will Fetch',
      location: customPickupLocation,
      gpsLocation: { lat: -33.9249, lng: 18.4241 },
      phone: user.phone || '+27 82 555 1313',
      userName: user.name || 'Community Member',
      totalAmount: customTrailerOfferedPrice,
      offeredPrice: customTrailerOfferedPrice,
      status: 'pending',
      createdAt: Date.now(),
    });

    setActiveBiddingRequestId(reqId);
  };

  return (
    <div id="trailer-hiring-view" className="w-full max-w-4xl mx-auto p-2 sm:p-3 pb-20 text-neutral-900 bg-[#FFFBEB] select-none space-y-2">
      {/* Header */}
      <div className="flex items-center justify-between mb-1 pb-1.5 border-b border-amber-200">
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="btn-back-trailer-hiring"
            onClick={handleGoBack}
            className="w-8 h-8 rounded-xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-lg sm:text-xl font-black text-neutral-900 tracking-tight font-sans leading-none">
              Trailer Hiring
            </h1>
            <p className="font-mono text-[9px] uppercase text-neutral-500 tracking-wider">
              Community Service • South Africa 🇿🇦
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoBack}
          className="w-7 h-7 rounded-xl bg-[#FFCC00] text-black font-black text-sm flex items-center justify-center shadow-xs"
        >
          Z
        </button>
      </div>

      {/* Mode Navigation Tabs (36px height, font 12px) */}
      <div className="flex rounded-xl bg-white p-1 border border-amber-200 shadow-2xs gap-1">
        <button
          type="button"
          id="tab-browse-trailers"
          onClick={() => setActiveTab('requester')}
          className={`flex-1 h-[36px] px-2 rounded-lg text-[12px] font-black uppercase tracking-wider font-mono transition flex items-center justify-center gap-1.5 ${
            activeTab === 'requester'
              ? 'bg-[#FFCC00] text-black shadow-2xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Hire a Trailer</span>
        </button>
        <button
          type="button"
          id="tab-register-trailer-owner"
          onClick={() => setActiveTab('register')}
          className={`flex-1 h-[36px] px-2 rounded-lg text-[12px] font-black uppercase tracking-wider font-mono transition flex items-center justify-center gap-1.5 ${
            activeTab === 'register'
              ? 'bg-neutral-900 text-white shadow-2xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Plus className="w-3.5 h-3.5 stroke-[3]" />
          <span>Register Trailer</span>
        </button>
      </div>

      {activeTab === 'requester' ? (
        /* ========================================================================= */
        /* REQUESTER VIEW: AssetOffersWaitingScreen / Custom Request / Browse        */
        /* ========================================================================= */
        activeBiddingRequestId ? (
          <AssetOffersWaitingScreen
            type="trailer"
            requestId={activeBiddingRequestId}
            onClose={() => setActiveBiddingRequestId(null)}
          />
        ) : (
        <div className="space-y-3">
          {/* CUSTOM TRAILER REQUEST FORM CARD */}
          <div className="bg-white rounded-2xl p-4 border border-amber-300 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#FFCC00] text-black flex items-center justify-center font-bold">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-neutral-900 font-sans">
                    Request Trailer Hire
                  </h3>
                  <p className="text-[10px] text-neutral-500 font-mono">
                    Post request to local trailer owners & receive live bids
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCustomForm(!showCustomForm)}
                className="text-[10px] font-mono font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 px-2.5 py-1 rounded-lg"
              >
                {showCustomForm ? 'Collapse Form' : 'Show Request Form'}
              </button>
            </div>

            {showCustomForm && (
              <form onSubmit={handleCustomTrailerRequest} className="space-y-3 font-sans">
                {/* Pickup & Drop Locations */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[9px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Pickup Location <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <MapPin className="w-3.5 h-3.5 text-red-500 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={customPickupLocation}
                        onChange={(e) => setCustomPickupLocation(e.target.value)}
                        placeholder="e.g. Cape Town CBD"
                        className="w-full pl-8 pr-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold outline-none focus:border-black"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[9px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Drop Location / Usage Area <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <MapPin className="w-3.5 h-3.5 text-emerald-600 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={customDropLocation}
                        onChange={(e) => setCustomDropLocation(e.target.value)}
                        placeholder="e.g. Somerset West / Western Cape"
                        className="w-full pl-8 pr-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold outline-none focus:border-black"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Trailer Type Dropdown & Duration */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[9px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Trailer Type <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={customTrailerType}
                      onChange={(e) => setCustomTrailerType(e.target.value)}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold font-mono outline-none focus:border-black cursor-pointer"
                    >
                      <option value="Luggage Trailer">Luggage Trailer (6x4 ft / enclosed)</option>
                      <option value="Utility Trailer">Utility Trailer (7x5 ft open cage)</option>
                      <option value="Car Transporter">Car Transporter / Hauler (14x6 ft)</option>
                      <option value="Bike Rack">Bike Rack / Quad Trailer</option>
                      <option value="Fridge Trailer">Fridge Trailer / Insulated Box</option>
                    </select>
                  </div>

                  {/* Duration selector: Hours / Days / Weeks / Months + quantity */}
                  <div>
                    <label className="text-[9px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Duration: Quantity & Unit <span className="text-red-500">*</span>
                    </label>
                    <div className="flex gap-2">
                      <div className="relative w-20">
                        <input
                          type="number"
                          min={1}
                          max={365}
                          value={customDurationQty}
                          onChange={(e) => setCustomDurationQty(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full px-2.5 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-mono font-black text-center outline-none focus:border-black"
                          required
                        />
                      </div>
                      <select
                        value={customDurationType}
                        onChange={(e) => setCustomDurationType(e.target.value as any)}
                        className="flex-1 px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold font-mono outline-none focus:border-black cursor-pointer uppercase"
                      >
                        <option value="hours">Hours</option>
                        <option value="days">Days</option>
                        <option value="weeks">Weeks</option>
                        <option value="months">Months</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Start Date & Time + Load Description */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[9px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Start Date & Time
                    </label>
                    <div className="relative">
                      <Calendar className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={customStartDateTime}
                        onChange={(e) => setCustomStartDateTime(e.target.value)}
                        placeholder="e.g. Today 2:00 PM"
                        className="w-full pl-8 pr-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold outline-none focus:border-black"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[9px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Load Description (Optional)
                    </label>
                    <input
                      type="text"
                      value={customLoadDesc}
                      onChange={(e) => setCustomLoadDesc(e.target.value)}
                      placeholder="e.g. Camping gear, household boxes, generator"
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold outline-none focus:border-black"
                    />
                  </div>
                </div>

                {/* Price Offer & Submit */}
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <span className="text-[9px] font-mono font-bold uppercase text-neutral-700 whitespace-nowrap">
                      Your Offer:
                    </span>
                    <button
                      type="button"
                      onClick={() => setCustomTrailerOfferedPrice((p) => Math.max(50, p - 50))}
                      className="w-8 h-8 rounded-lg bg-white border border-amber-300 font-bold text-sm text-neutral-800 hover:bg-amber-100 flex items-center justify-center"
                    >
                      -
                    </button>
                    <div className="relative w-28">
                      <span className="absolute left-2.5 top-1.5 font-mono text-xs font-bold text-neutral-500">R</span>
                      <input
                        type="number"
                        min={50}
                        value={customTrailerOfferedPrice}
                        onChange={(e) => setCustomTrailerOfferedPrice(Math.max(50, parseFloat(e.target.value) || 50))}
                        className="w-full pl-6 pr-2 py-1.5 bg-white border border-amber-300 rounded-lg font-mono text-xs font-black text-center outline-none"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setCustomTrailerOfferedPrice((p) => p + 50)}
                      className="w-8 h-8 rounded-lg bg-white border border-amber-300 font-bold text-sm text-neutral-800 hover:bg-amber-100 flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>

                  <button
                    type="submit"
                    id="btn-request-trailer-custom"
                    className="w-full sm:w-auto flex-1 bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-2.5 px-4 rounded-xl uppercase font-mono shadow-xs transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Package className="w-4 h-4" />
                    <span>REQUEST TRAILER ({customDurationQty} {customDurationType.toUpperCase()} • R{customTrailerOfferedPrice})</span>
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Active Hire Request & Counter Bids Received Panel (Compact ~80px max height) */}
          {activeUserBooking && (
            <div className="bg-white rounded-xl p-2.5 border border-amber-400 shadow-2xs space-y-1.5">
              <div className="flex items-center justify-between pb-1 border-b border-neutral-100">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                  <span className="text-[11px] font-mono font-black uppercase text-neutral-900">
                    Active Request ({activeUserBooking.id})
                  </span>
                </div>
                <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase ${
                  activeUserBooking.status === 'confirmed'
                    ? 'bg-emerald-100 text-emerald-800'
                    : activeUserBooking.status === 'countered'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-neutral-100 text-neutral-700'
                }`}>
                  {activeUserBooking.status === 'confirmed' ? '✓ Agreed' : activeUserBooking.status === 'countered' ? '⚡ Bids Received' : '⏳ Pending'}
                </span>
              </div>

              <div className="flex items-center justify-between gap-2 text-[11px] font-mono">
                <div className="min-w-0">
                  <strong className="text-[12px] font-sans text-neutral-900 font-black truncate block">{activeUserBooking.trailerName}</strong>
                  <div className="text-neutral-500 text-[10px] truncate">
                    {activeUserBooking.hireUnits} {activeUserBooking.hireDurationType} • {activeUserBooking.ownerName}
                  </div>
                </div>
                <div className="h-[32px] px-2.5 bg-amber-50 rounded-lg border border-amber-200 flex flex-col justify-center text-right flex-shrink-0">
                  <span className="text-[8px] text-neutral-500 uppercase leading-none">Offered</span>
                  <strong className="text-[12px] font-black text-black leading-tight">R{activeUserBooking.offeredPrice}</strong>
                </div>
              </div>

              {/* Owner Counter Bids Received List */}
              {activeUserBooking.ownerOffers && activeUserBooking.ownerOffers.length > 0 && (
                <div className="pt-1 border-t border-neutral-100 space-y-1">
                  <span className="text-[10px] font-mono font-black text-amber-900 uppercase block flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-600" />
                    Counter Bids ({activeUserBooking.ownerOffers.length}):
                  </span>
                  <div className="space-y-1">
                    {activeUserBooking.ownerOffers.map((off) => (
                      <div
                        key={off.id}
                        className="bg-amber-50/80 p-2 rounded-lg border border-amber-300 flex items-center justify-between gap-2"
                      >
                        <div className="font-mono text-[10px] min-w-0">
                          <span className="font-bold text-neutral-900 truncate block">{off.ownerName}</span>
                          <span className="text-[9px] text-neutral-500">{off.ownerPhone}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black font-mono text-black">R{off.counterAmount}</span>
                          {activeUserBooking.status !== 'confirmed' && (
                            <button
                              type="button"
                              onClick={() => handleRequesterAcceptCounter(activeUserBooking, off)}
                              className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-[10px] px-2 py-1 rounded-md uppercase font-mono shadow-2xs active:scale-95 flex items-center gap-1 cursor-pointer"
                            >
                              <ThumbsUp className="w-3 h-3" />
                              <span>ACCEPT</span>
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Search + Fulfillment Box (In one compact row, padding 8px) */}
          <div className="bg-white rounded-xl p-2 border border-amber-200 shadow-2xs flex items-center justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Search trailer area, kind, size..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-[36px] pl-8 pr-2 bg-neutral-50 border border-neutral-200 rounded-lg text-[12px] font-bold text-neutral-900 outline-none focus:border-black"
                />
              </div>
            </div>

            {/* Toggle: "Will Fetch" vs "Deliver" (h-28px, text-11px) */}
            <div className="flex items-center rounded-lg bg-neutral-100 p-0.5 border border-neutral-200 flex-shrink-0 h-[36px]">
              <button
                type="button"
                id="toggle-fetch-trailer"
                onClick={() => setDeliveryMode('fetch')}
                className={`h-[28px] px-2 rounded-md text-[11px] font-mono font-bold transition flex items-center gap-1 cursor-pointer ${
                  deliveryMode === 'fetch'
                    ? 'bg-[#FFCC00] text-black font-black shadow-2xs'
                    : 'text-neutral-600 hover:text-black'
                }`}
              >
                <Car className="w-3 h-3" />
                <span>Fetch</span>
              </button>
              <button
                type="button"
                id="toggle-deliver-trailer"
                onClick={() => setDeliveryMode('deliver')}
                className={`h-[28px] px-2 rounded-md text-[11px] font-mono font-bold transition flex items-center gap-1 cursor-pointer ${
                  deliveryMode === 'deliver'
                    ? 'bg-neutral-900 text-white font-black shadow-2xs'
                    : 'text-neutral-600 hover:text-black'
                }`}
              >
                <Truck className="w-3 h-3" />
                <span>Deliver</span>
              </button>
            </div>
          </div>

          {/* Type Toggle Chips (h-28px, font 11px, gap 4px, padding 6px 10px) */}
          <div className="flex items-center gap-1 overflow-x-auto pb-0.5 text-[11px] font-mono">
            <span className="text-[9px] uppercase font-bold text-neutral-500 whitespace-nowrap mr-0.5">Filter:</span>
            {[
              { id: 'All', label: 'All' },
              { id: 'Luggage', label: 'Luggage' },
              { id: 'Car Trailer', label: 'Car Trailer' },
              { id: 'Utility', label: 'Utility' },
              { id: 'Box / Flatbed', label: 'Box / Flatbed' },
              { id: 'Camping', label: 'Camping' },
            ].map((chip) => (
              <button
                key={chip.id}
                type="button"
                onClick={() => setSelectedKind(chip.id)}
                className={`h-[28px] px-[10px] py-[4px] rounded-full text-[11px] font-bold whitespace-nowrap transition border cursor-pointer ${
                  selectedKind === chip.id
                    ? 'bg-[#FFCC00] text-black border-amber-400 font-black shadow-2xs'
                    : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </div>

          {/* Compact Trailer List (No Pictures, Dense 8px padding, 6px gap) */}
          {filteredTrailers.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 text-center border border-neutral-200 shadow-xs">
              <div className="w-12 h-12 bg-amber-50 border border-[#FFCC00] text-[#FFCC00] rounded-full flex items-center justify-center mx-auto mb-3 animate-spin">
                <Sparkles className="w-6 h-6 text-[#D97706]" />
              </div>
              <h4 className="font-bold text-sm text-neutral-900 font-sans">ZOLTA Radar Scanning for Trailers...</h4>
              <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                No trailers listed in this category yet. As owners register luggage, utility, or flatbed trailers, they will appear here instantly.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {filteredTrailers.map((trailer) => (
                <div
                  key={trailer.id}
                  className="bg-white rounded-[12px] border border-neutral-200 p-2 shadow-none hover:border-amber-400 transition flex flex-col gap-[6px]"
                >
                  {/* Top Badges: font 9px height 18px */}
                  <div className="flex items-center flex-wrap gap-1">
                    <span className="h-[18px] bg-[#FFCC00] text-black font-mono text-[9px] font-black px-1.5 rounded uppercase flex items-center">
                      {trailer.kind}
                    </span>
                    <span className="h-[18px] bg-neutral-900 text-white font-mono text-[9px] font-bold px-1.5 rounded uppercase flex items-center">
                      {trailer.size}
                    </span>
                    {trailer.deliveryAvailable && (
                      <span className="h-[18px] text-[9px] font-mono text-emerald-700 font-bold bg-emerald-50 px-1.5 rounded border border-emerald-200 flex items-center">
                        Delivery +R{trailer.deliveryFee}
                      </span>
                    )}
                  </div>

                  {/* Title & Location Line */}
                  <div>
                    <h3 className="font-bold text-[13px] leading-[14px] text-neutral-900 font-sans truncate">
                      {trailer.name}
                    </h3>
                    <div className="flex items-center gap-1 text-[10px] text-neutral-500 font-mono mt-0.5">
                      <MapPin className="w-3 h-3 text-amber-600 flex-shrink-0" />
                      <span className="truncate">{trailer.location}</span>
                      <span>•</span>
                      <span>★ {trailer.rating} ({trailer.totalTrips})</span>
                      <span>•</span>
                      <span>Dep: R{trailer.deposit}</span>
                    </div>
                  </div>

                  {/* Price Row: 4 tiny equal boxes (h-32px, text-10px label + 11px bold price) & RIGHT-aligned [HIRE] button */}
                  <div className="flex items-center justify-between gap-1.5 pt-1 border-t border-neutral-100">
                    <div className="grid grid-cols-4 gap-1 flex-1 max-w-sm">
                      {[
                        { type: 'hour' as const, label: 'Hour', rate: trailer.pricePerHour },
                        { type: 'day' as const, label: 'Day', rate: trailer.pricePerDay, highlight: true },
                        { type: 'week' as const, label: 'Week', rate: trailer.pricePerWeek },
                        { type: 'month' as const, label: 'Month', rate: trailer.pricePerMonth },
                      ].map((p) => (
                        <button
                          key={p.type}
                          type="button"
                          onClick={() => handleStartHire(trailer, p.type)}
                          className={`h-[32px] px-0.5 rounded-md border text-center font-mono flex flex-col items-center justify-center transition cursor-pointer hover:bg-amber-100 active:scale-95 ${
                            p.highlight
                              ? 'bg-amber-50 border-amber-400 text-black font-black'
                              : 'bg-neutral-50 border-neutral-200 text-neutral-800'
                          }`}
                        >
                          <span className="text-[8px] text-neutral-500 font-medium leading-none">{p.label}</span>
                          <strong className="text-[11px] font-bold leading-tight">R{p.rate}</strong>
                        </button>
                      ))}
                    </div>

                    {/* RIGHT aligned small button: [HIRE] yellow black text, height 32px, width 80px, rounded */}
                    <button
                      type="button"
                      onClick={() => handleStartHire(trailer, 'day')}
                      className="h-[32px] w-[80px] bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs rounded-lg uppercase tracking-wider font-mono shadow-2xs transition active:scale-95 flex items-center justify-center flex-shrink-0 ml-auto cursor-pointer"
                    >
                      HIRE
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        )
      ) : (
        /* ========================================================================= */
        /* OWNER REGISTRATION & BIDDING CONSOLE: Kind, Size, Rates, Negotiable Bids */
        /* ========================================================================= */
        <div className="space-y-6 max-w-3xl mx-auto">
          {/* Owner Bidding Console: Incoming Requests & Bids */}
          <div className="bg-white rounded-3xl p-6 border border-amber-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <div>
                <span className="text-[10px] font-mono font-bold bg-[#FFCC00] text-black px-2.5 py-1 rounded-md uppercase">
                  Trailer Owner Console
                </span>
                <h3 className="text-xl font-black text-neutral-900 mt-1 font-sans">
                  Incoming Hire Requests & Negotiable Bids
                </h3>
              </div>
              <span className="text-xs font-mono bg-neutral-100 text-neutral-700 px-2.5 py-1 rounded-full font-bold">
                {trailerBookings.length} Request(s)
              </span>
            </div>

            {trailerBookings.length === 0 ? (
              <div className="bg-neutral-50 rounded-2xl p-8 text-center border border-neutral-200 shadow-2xs">
                <div className="w-10 h-10 bg-white border border-[#FFCC00] text-[#FFCC00] rounded-full flex items-center justify-center mx-auto mb-2 animate-spin">
                  <Sparkles className="w-5 h-5 text-[#D97706]" />
                </div>
                <h4 className="font-bold text-xs text-neutral-900 font-sans">ZOLTA Radar Scanning for Hire Bookings...</h4>
                <p className="text-[11px] text-neutral-500 mt-1">
                  No active trailer hire requests right now. New requests and negotiable bids from customers will appear here automatically.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {trailerBookings.map((b) => {
                  const currentCounter = counterBidAmounts[b.id] ?? (b.offeredPrice + 30);
                  return (
                    <div
                      key={b.id}
                      className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200 space-y-3 font-mono text-xs"
                    >
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1">
                        <div>
                          <strong className="text-sm font-sans font-black text-neutral-900 block">{b.trailerName}</strong>
                          <span className="text-[11px] text-neutral-600">
                            Requester: <strong className="text-black">{b.riderName}</strong> ({b.riderPhone}) • {b.hireUnits} {b.hireDurationType}(s)
                          </span>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          b.status === 'confirmed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : b.status === 'countered'
                            ? 'bg-amber-100 text-amber-800'
                            : b.status === 'declined'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-200 text-black'
                        }`}>
                          {b.status === 'confirmed' ? 'Accepted / Confirmed' : b.status === 'countered' ? 'Counter Bid Sent' : b.status === 'declined' ? 'Declined' : 'Offer Pending'}
                        </span>
                      </div>

                      {/* Requester Offer vs Standard */}
                      <div className="flex items-center gap-4 bg-white p-2.5 rounded-xl border border-amber-200 text-xs">
                        <div>
                          <span className="text-[9px] text-neutral-400 block uppercase">Requester Offer</span>
                          <strong className="text-sm font-black text-emerald-700">R {b.offeredPrice}</strong>
                        </div>
                        <div className="h-6 w-px bg-neutral-200" />
                        <div>
                          <span className="text-[9px] text-neutral-400 block uppercase">Standard Rate</span>
                          <strong className="text-xs font-bold text-neutral-700">R {b.totalAmount}</strong>
                        </div>
                        <div className="h-6 w-px bg-neutral-200" />
                        <div>
                          <span className="text-[9px] text-neutral-400 block uppercase">Fulfillment</span>
                          <span className="text-xs font-bold text-neutral-800">{b.hireDeliveryChoice === 'deliver' ? 'Delivery' : 'Fetch'}</span>
                        </div>
                      </div>

                      {/* Owner Bidding Action Buttons: ACCEPT / COUNTER BID [-] [+] / DECLINE */}
                      {b.status !== 'confirmed' && b.status !== 'declined' && (
                        <div className="pt-2 space-y-2 border-t border-amber-200/60">
                          {/* Counter Bid Adjustment [-] [R___] [+] */}
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold uppercase text-neutral-700">Counter Bid:</span>
                            <button
                              type="button"
                              onClick={() => setCounterBidAmounts({ ...counterBidAmounts, [b.id]: Math.max(50, currentCounter - 20) })}
                              className="w-7 h-7 rounded-lg bg-white border border-amber-300 font-black text-sm text-black flex items-center justify-center hover:bg-amber-100"
                            >
                              -
                            </button>
                            <div className="relative w-24">
                              <span className="absolute left-2 top-1 text-xs text-neutral-500 font-bold">R</span>
                              <input
                                type="number"
                                value={currentCounter}
                                onChange={(e) => setCounterBidAmounts({ ...counterBidAmounts, [b.id]: parseFloat(e.target.value) || 0 })}
                                className="w-full pl-5 pr-1 py-1 bg-white border border-amber-300 rounded-lg text-xs font-black text-center"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => setCounterBidAmounts({ ...counterBidAmounts, [b.id]: currentCounter + 20 })}
                              className="w-7 h-7 rounded-lg bg-white border border-amber-300 font-black text-sm text-black flex items-center justify-center hover:bg-amber-100"
                            >
                              +
                            </button>
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => handleOwnerAcceptOffer(b)}
                              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-2 rounded-xl uppercase shadow-xs transition active:scale-95 flex items-center justify-center gap-1"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>ACCEPT (R{b.offeredPrice})</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOwnerSubmitCounter(b)}
                              className="flex-1 bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-2 rounded-xl uppercase shadow-xs transition active:scale-95 flex items-center justify-center gap-1"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>COUNTER (R{currentCounter})</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOwnerDecline(b)}
                              className="px-3 py-2 bg-neutral-200 hover:bg-red-100 hover:text-red-700 text-neutral-700 font-bold text-xs rounded-xl uppercase transition"
                            >
                              DECLINE
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200 shadow-xs space-y-6">
          <div className="border-b border-neutral-100 pb-4">
            <span className="text-[10px] font-mono font-bold bg-[#FFCC00] text-black px-2.5 py-1 rounded-md uppercase">
              Owner Portal
            </span>
            <h3 className="text-2xl font-black text-neutral-900 mt-2 font-sans">
              Register Your Trailer for Community Hire
            </h3>
            <p className="text-xs text-neutral-600 mt-1">
              Monetize your luggage, utility, or car trailer across South Africa. Set your own hour/day/week/month rates and offer optional delivery.
            </p>
          </div>

          {regSuccess ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-black text-neutral-900 font-sans">
                Trailer Registered Successfully!
              </h3>
              <p className="text-xs text-neutral-600 max-w-xs mx-auto">
                Your trailer is now listed live on the ZOLTA Hiring Grid for South African community members.
              </p>
            </div>
          ) : (
            <form onSubmit={handleRegisterTrailer} className="space-y-4 font-sans">
              {/* Title & Kind */}
              <div>
                <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                  Trailer Title / Model <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Venter 7ft Utility Trailer with Jockey Wheel"
                  value={regTitle}
                  onChange={(e) => setRegTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Kind */}
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Trailer Kind <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={regKind}
                    onChange={(e) => setRegKind(e.target.value as TrailerKind)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black font-mono"
                  >
                    <option value="Luggage">Luggage Trailer</option>
                    <option value="Utility">Utility / Furniture Trailer</option>
                    <option value="Car Trailer">Car Trailer / Transporter</option>
                    <option value="Box / Enclosed">Box / Enclosed Trailer</option>
                    <option value="Flatbed">Flatbed Machinery Trailer</option>
                    <option value="Camping">Camping / 4x4 Bush Trailer</option>
                  </select>
                </div>

                {/* Size */}
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Trailer Size <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={regSize}
                    onChange={(e) => setRegSize(e.target.value as TrailerSize)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black font-mono"
                  >
                    <option value="6x4 ft">6x4 ft (Standard Luggage)</option>
                    <option value="7x5 ft">7x5 ft (Medium Utility)</option>
                    <option value="8x5 ft">8x5 ft (High-Sided Mover)</option>
                    <option value="10x5 ft">10x5 ft (Large Flatbed)</option>
                    <option value="Double Axle">Double Axle (Heavy Duty)</option>
                    <option value="14x6 ft Car Hauler">14x6 ft Car Hauler</option>
                  </select>
                </div>
              </div>

              {/* 4 Pricing Inputs: Hour, Day, Week, Month */}
              <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 space-y-3">
                <span className="text-[10px] font-mono font-bold uppercase text-neutral-800 block">
                  Set Your Hire Rates (ZAR)
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div>
                    <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">Per Hour (R)</label>
                    <input
                      type="number"
                      value={regPriceHour}
                      onChange={(e) => setRegPriceHour(e.target.value)}
                      className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold font-mono outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">Per Day (R)</label>
                    <input
                      type="number"
                      value={regPriceDay}
                      onChange={(e) => setRegPriceDay(e.target.value)}
                      className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold font-mono outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">Per Week (R)</label>
                    <input
                      type="number"
                      value={regPriceWeek}
                      onChange={(e) => setRegPriceWeek(e.target.value)}
                      className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold font-mono outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">Per Month (R)</label>
                    <input
                      type="number"
                      value={regPriceMonth}
                      onChange={(e) => setRegPriceMonth(e.target.value)}
                      className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold font-mono outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Location & Deposit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Pickup Location / Yard Address
                  </label>
                  <input
                    type="text"
                    value={regLocation}
                    onChange={(e) => setRegLocation(e.target.value)}
                    placeholder="e.g. Khayelitsha, Cape Town"
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Refundable Deposit (R)
                  </label>
                  <input
                    type="number"
                    value={regDeposit}
                    onChange={(e) => setRegDeposit(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none focus:border-black"
                    required
                  />
                </div>
              </div>

              {/* Delivery Available Yes/No + Fee */}
              <div className="p-3.5 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-neutral-900 block">Delivery Available?</span>
                    <span className="text-[10px] font-mono text-neutral-500">Can you tow & deliver trailer to client?</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setRegDeliveryAvail(!regDeliveryAvail)}
                    className={`px-3 py-1.5 rounded-xl font-mono text-xs font-black transition ${
                      regDeliveryAvail ? 'bg-[#FFCC00] text-black shadow-xs' : 'bg-neutral-200 text-neutral-700'
                    }`}
                  >
                    {regDeliveryAvail ? 'YES (Available)' : 'NO (Pickup Only)'}
                  </button>
                </div>

                {regDeliveryAvail && (
                  <div>
                    <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Delivery Surcharge Fee (R)
                    </label>
                    <input
                      type="number"
                      value={regDeliveryFee}
                      onChange={(e) => setRegDeliveryFee(e.target.value)}
                      placeholder="150"
                      className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none"
                    />
                  </div>
                )}
              </div>

              {/* Owner Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Owner Name
                  </label>
                  <input
                    type="text"
                    value={regOwnerName}
                    onChange={(e) => setRegOwnerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Contact Phone (+27)
                  </label>
                  <input
                    type="tel"
                    value={regOwnerPhone}
                    onChange={(e) => setRegOwnerPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none focus:border-black"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3.5 rounded-xl uppercase tracking-wider font-mono shadow-xs transition active:scale-95 mt-2"
              >
                Register Trailer & List on ZOLTA
              </button>
            </form>
          )}
        </div>
        </div>
      )}

      {/* BOOKING MODAL */}
      {selectedTrailerForHire && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-amber-200 text-neutral-900 w-full max-w-lg rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setSelectedTrailerForHire(null)}
              className="absolute top-4 right-4 p-1 text-neutral-400 hover:text-black"
            >
              <X className="w-5 h-5" />
            </button>

            {bookingSuccess ? (
              <div className="py-6 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-black text-neutral-900 font-sans">
                  Booking Request Sent!
                </h3>
                <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 font-mono text-xs text-left space-y-1">
                  <p className="font-bold text-black">Ref: {bookingRef}</p>
                  <p className="text-neutral-700">Trailer: {selectedTrailerForHire.name}</p>
                  <p className="text-neutral-700">Owner: {selectedTrailerForHire.ownerName} ({selectedTrailerForHire.ownerPhone})</p>
                  <p className="text-neutral-700">Fulfillment: {hireDeliveryChoice === 'deliver' ? 'Delivery to Client' : 'Client Fetch'}</p>
                  <p className="text-emerald-700 font-black text-sm pt-1">Total Offered: R {customOfferPrice + (hireDeliveryChoice === 'deliver' && selectedTrailerForHire.deliveryAvailable ? selectedTrailerForHire.deliveryFee : 0)}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedTrailerForHire(null)}
                  className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3.5 rounded-xl uppercase tracking-wider font-mono shadow-xs transition"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleConfirmHire} className="space-y-4 font-sans">
                <div>
                  <span className="text-[10px] font-mono font-black bg-[#FFCC00] text-black px-2 py-0.5 rounded-md uppercase">
                    Trailer Hire Request
                  </span>
                  <h3 className="text-lg font-bold text-neutral-900 mt-1 font-sans leading-snug">
                    {selectedTrailerForHire.name}
                  </h3>
                  <p className="text-xs text-neutral-500 font-mono">
                    {selectedTrailerForHire.kind} • {selectedTrailerForHire.size} • {selectedTrailerForHire.location}
                  </p>
                </div>

                {/* Duration Type Selector */}
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                    Duration Period:
                  </label>
                  <div className="grid grid-cols-4 gap-1.5 font-mono text-xs">
                    {[
                      { type: 'hour' as const, label: 'Hour', rate: selectedTrailerForHire.pricePerHour },
                      { type: 'day' as const, label: 'Day', rate: selectedTrailerForHire.pricePerDay },
                      { type: 'week' as const, label: 'Week', rate: selectedTrailerForHire.pricePerWeek },
                      { type: 'month' as const, label: 'Month', rate: selectedTrailerForHire.pricePerMonth },
                    ].map((d) => (
                      <button
                        key={d.type}
                        type="button"
                        onClick={() => {
                          setHireDurationType(d.type);
                          setCustomOfferPrice(d.rate);
                        }}
                        className={`py-2 px-1 rounded-xl text-center border transition ${
                          hireDurationType === d.type
                            ? 'bg-[#FFCC00] text-black border-amber-400 font-black shadow-xs'
                            : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                      >
                        <span className="block text-[9px] uppercase leading-none mb-0.5">{d.label}</span>
                        <strong className="text-xs">R{d.rate}</strong>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Owner Rate Display */}
                <div className="flex items-center justify-between p-2.5 bg-neutral-100 rounded-xl font-mono text-xs">
                  <span className="text-neutral-600 font-medium">Owner Standard Rate:</span>
                  <strong className="font-bold text-neutral-900">
                    R{
                      hireDurationType === 'hour' ? selectedTrailerForHire.pricePerHour :
                      hireDurationType === 'day' ? selectedTrailerForHire.pricePerDay :
                      hireDurationType === 'week' ? selectedTrailerForHire.pricePerWeek :
                      selectedTrailerForHire.pricePerMonth
                    }
                  </strong>
                </div>

                {/* IN-DRIVE NEGOTIATION: YOUR OFFER [-] [R320] [+] (Min = R50) */}
                <div className="p-3.5 bg-amber-100/80 rounded-2xl border border-amber-300 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-black uppercase text-amber-900 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      YOUR OFFER (ZAR)
                    </span>
                    <span className="text-[10px] font-mono text-neutral-600">Min: R50</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setCustomOfferPrice((prev) => Math.max(50, prev - 20))}
                      className="w-10 h-10 rounded-xl bg-white border border-amber-300 font-black text-xl text-neutral-800 hover:bg-amber-200 flex items-center justify-center transition active:scale-95 shadow-2xs cursor-pointer"
                    >
                      -
                    </button>
                    <div className="flex-1 relative">
                      <span className="absolute left-3.5 top-2.5 font-mono text-xs font-bold text-neutral-500">R</span>
                      <input
                        type="number"
                        min={50}
                        value={customOfferPrice}
                        onChange={(e) => setCustomOfferPrice(Math.max(50, parseFloat(e.target.value) || 50))}
                        className="w-full pl-8 pr-3 py-2 bg-white border border-amber-300 rounded-xl font-mono text-base font-black text-neutral-900 outline-none focus:border-black text-center"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setCustomOfferPrice((prev) => prev + 20)}
                      className="w-10 h-10 rounded-xl bg-white border border-amber-300 font-black text-xl text-neutral-800 hover:bg-amber-200 flex items-center justify-center transition active:scale-95 shadow-2xs cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Fulfillment Delivery Toggle: [Will Fetch] [Deliver +R180] */}
                {(() => {
                  const deliveryFee = selectedTrailerForHire.deliveryFee || (selectedTrailerForHire as any).delivery_price || 200;
                  const calculatedTotal = customOfferPrice + (hireDeliveryChoice === 'deliver' ? deliveryFee : 0);
                  return (
                    <>
                      <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 space-y-2">
                        <span className="text-[10px] font-mono font-bold uppercase text-neutral-700 block">
                          Fulfillment Delivery:
                        </span>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setHireDeliveryChoice('fetch')}
                            className={`flex-1 py-2 px-3 rounded-xl border text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                              hireDeliveryChoice === 'fetch'
                                ? 'bg-[#FFCC00] text-black border-amber-400 font-black shadow-xs'
                                : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <Car className="w-3.5 h-3.5" />
                            <span>Will Fetch</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setHireDeliveryChoice('deliver')}
                            className={`flex-1 py-2 px-3 rounded-xl border text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                              hireDeliveryChoice === 'deliver'
                                ? 'bg-[#FFCC00] text-black border-amber-400 font-black shadow-xs'
                                : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                            }`}
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>Deliver (+R{deliveryFee})</span>
                          </button>
                        </div>
                      </div>

                      {/* Total Summary Row */}
                      <div className="flex items-center justify-between p-3.5 bg-neutral-900 text-white rounded-2xl font-mono">
                        <div>
                          <span className="text-[10px] uppercase text-neutral-400 block">Total Request Amount</span>
                          <span className="text-xl font-black text-[#FFCC00]">
                            R {calculatedTotal}.00
                          </span>
                        </div>
                        <span className="text-xs text-neutral-400">Deposit: R{selectedTrailerForHire.deposit}</span>
                      </div>

                      {/* Buttons: [CANCEL small] [REQUEST WITH R___ yellow] */}
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setSelectedTrailerForHire(null)}
                          className="bg-neutral-100 hover:bg-neutral-200 text-black font-bold text-xs py-2.5 px-4 rounded-xl font-mono transition cursor-pointer"
                        >
                          CANCEL
                        </button>
                        <button
                          type="submit"
                          className="flex-1 bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-2.5 px-4 rounded-xl uppercase tracking-wider font-mono shadow-xs transition active:scale-95 text-center cursor-pointer"
                        >
                          REQUEST WITH R{calculatedTotal}
                        </button>
                      </div>
                    </>
                  );
                })()}
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  saveTowingRequestToFirestore,
  subscribeToTowingRequests,
  saveTowingCompanyToFirestore,
  createTowingRequestInFirestore,
} from '../../services/firestoreService';
import { addAssetRequest, updateAssetRequestStatus } from '../../services/assetRequestsService';
import { TowingType } from '../../types';
import { AssetOffersWaitingScreen } from '../common/AssetOffersWaitingScreen';
import { OwnerReviewsModal } from '../common/OwnerReviewsModal';
import { RateOwnerModal } from '../common/RateOwnerModal';
import {
  ArrowLeft,
  Wrench,
  ShieldCheck,
  MapPin,
  Clock,
  CheckCircle2,
  Phone,
  AlertTriangle,
  Car,
  Truck,
  Battery,
  Disc,
  LifeBuoy,
  Plus,
  Radio,
  FileText,
  Building,
  Layers,
  ChevronRight,
  Sparkles,
  Camera,
  Upload,
  X,
  Star,
} from 'lucide-react';

export type ProblemType =
  | 'Breakdown'
  | 'Accident Rollback'
  | 'Battery Jump'
  | 'Flat Tyre'
  | 'Emergency Recovery'
  | 'Accident'
  | 'Battery'
  | 'Stuck'
  | 'Need Tow';

export type VehicleCategory = 'Car' | 'Bakkie' | 'Truck' | 'Bike';

export interface TowerOffer {
  id: string;
  towerName: string;
  towerPhone: string;
  counterAmount: number;
  timestamp: string;
}

export interface TowingDispatchRecord {
  id: string;
  userName: string;
  userPhone: string;
  location: string;
  problemType: ProblemType;
  carDetails: {
    makeModel: string;
    color: string;
    plate: string;
  };
  description: string;
  timestamp: string;
  status: 'Pending Operator' | 'Dispatched & En-Route' | 'Arrived on Scene' | 'Completed' | 'Countered' | 'Declined';
  assignedTruck: string;
  eta: string;
  offeredPrice?: number;
  towerOffers?: TowerOffer[];
}

export interface RegisteredTowingCompany {
  id: string;
  companyName: string;
  contactPerson: string;
  phone: string;
  fleetSize: string;
  coverageArea: string;
  is247: boolean;
  servicesOffered: ProblemType[];
  rating: number;
}

export const TowingAssistanceView: React.FC = () => {
  const { setCurrentView, setMode, user } = useApp();

  // Active View Tab: 'request' | 'dispatch_console' | 'register_company'
  const [activeTab, setActiveTab] = useState<'request' | 'dispatch_console' | 'register_company'>('request');
  const [isReviewsModalOpen, setIsReviewsModalOpen] = useState(false);

  // Request Form State
  const [selectedVehicleType, setSelectedVehicleType] = useState<VehicleCategory>('Car');
  const [selectedProblem, setSelectedProblem] = useState<ProblemType>('Breakdown');
  const [userName, setUserName] = useState(user.name || '');
  const [userPhone, setUserPhone] = useState(user.phone || '');
  const [userLocation, setUserLocation] = useState('N2 Highway near Cape Town CBD');
  const [dropLocation, setDropLocation] = useState('Tygerberg Auto Repairs, Bellville');
  const [carMakeModel, setCarMakeModel] = useState('Toyota Corolla Quest');
  const [carColor, setCarColor] = useState('White');
  const [carPlate, setCarPlate] = useState('CA 889-102');
  const [problemDescription, setProblemDescription] = useState('');
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);

  // Bidding & Live Waiting State
  const [activeBiddingRequestId, setActiveBiddingRequestId] = useState<string | null>(null);
  const [customOfferPrice, setCustomOfferPrice] = useState<number>(450);
  const [counterBidAmounts, setCounterBidAmounts] = useState<{ [dispatchId: string]: number }>({});
  const [activeUserDispatch, setActiveUserDispatch] = useState<TowingDispatchRecord | null>(null);

  // Live Dispatches State (Company View)
  const [dispatches, setDispatches] = useState<TowingDispatchRecord[]>([]);

  const [activeRequestSubmitted, setActiveRequestSubmitted] = useState(false);

  // Towing Company Registration Form State
  const [companies, setCompanies] = useState<RegisteredTowingCompany[]>([]);
  const [regCompanyName, setRegCompanyName] = useState('');
  const [regContactPerson, setRegContactPerson] = useState('');
  const [regCompanyPhone, setRegCompanyPhone] = useState('+27 ');
  const [regFleetSize, setRegFleetSize] = useState('1-3 Rollback Trucks');
  const [regCoverageArea, setRegCoverageArea] = useState('');
  const [regIs247, setRegIs247] = useState(true);
  const [regServices, setRegServices] = useState<ProblemType[]>([
    'Accident',
    'Breakdown',
    'Flat Tyre',
    'Battery',
    'Stuck',
    'Need Tow',
  ]);
  const [companyRegSuccess, setCompanyRegSuccess] = useState(false);

  // Live sync towing requests with Firestore
  useEffect(() => {
    const unsub = subscribeToTowingRequests((liveRequests) => {
      if (liveRequests) {
        const list: TowingDispatchRecord[] = liveRequests.map((req) => ({
          id: req.id,
          userName: req.requesterName || (req as any).userName || 'Client',
          userPhone: req.requesterPhone || (req as any).userPhone || '+27 82 000 0000',
          location: req.pickupAddress || (req as any).location || 'Cape Town',
          problemType: (req.problem as any) || (req as any).problemType || 'Breakdown',
          carDetails: (req as any).carDetails || { makeModel: 'Vehicle', color: 'White', plate: 'CA 000' },
          description: (req as any).description || '',
          timestamp: 'Just now',
          status: 'Pending Operator' as const,
          assignedTruck: req.acceptedBy || (req as any).assignedTruck || 'Rollback Operator #1',
          eta: '10-15 mins',
          offeredPrice: req.offeredPrice || 450,
          towerOffers: (req.offers as any) || (req as any).towerOffers || [],
        }));
        setDispatches(list);
        const myDisp = list.find((d) => (user.name && d.userName === user.name) || (user.phone && d.userPhone === user.phone));
        if (myDisp) setActiveUserDispatch(myDisp);
      }
    });
    return () => unsub();
  }, [user.name, user.phone]);

  const handleGoBack = () => {
    setMode('rider');
    setCurrentView('home');
  };

  // Toggle problem type in request & update default offer
  const handleSelectProblem = (problem: ProblemType) => {
    setSelectedProblem(problem);
    if (problem === 'Accident Rollback' || problem === 'Accident') setCustomOfferPrice(650);
    else if (problem === 'Breakdown') setCustomOfferPrice(450);
    else if (problem === 'Flat Tyre' || problem === 'Battery Jump' || problem === 'Battery') setCustomOfferPrice(300);
    else if (problem === 'Emergency Recovery') setCustomOfferPrice(550);
    else setCustomOfferPrice(400);
  };

  // Toggle service offered in company registration
  const handleToggleService = (service: ProblemType) => {
    setRegServices((prev) =>
      prev.includes(service) ? prev.filter((s) => s !== service) : [...prev, service]
    );
  };

  // TOWER ACTION: Accept Requester Towing Offer
  const handleTowerAcceptOffer = (disp: TowingDispatchRecord) => {
    const updated: TowingDispatchRecord = {
      ...disp,
      status: 'Dispatched & En-Route',
    };
    setDispatches((prev) => prev.map((d) => (d.id === disp.id ? updated : d)));
    saveTowingRequestToFirestore(updated).catch(() => {});
    updateAssetRequestStatus(disp.id, 'accepted', user.name || 'Towing Operator');
  };

  // TOWER ACTION: Submit Counter Bid
  const handleTowerSubmitCounter = (disp: TowingDispatchRecord) => {
    const counterVal = counterBidAmounts[disp.id] || (disp.offeredPrice ? disp.offeredPrice + 50 : 500);
    const newOffer: TowerOffer = {
      id: `tow-off-${Date.now()}`,
      towerName: user.name || 'Verified Towing Operator',
      towerPhone: user.phone || '+27 82 000 0000',
      counterAmount: counterVal,
      timestamp: 'Just now',
    };
    const updated: TowingDispatchRecord = {
      ...disp,
      status: 'Countered',
      towerOffers: [...(disp.towerOffers || []), newOffer],
    };
    setDispatches((prev) => prev.map((d) => (d.id === disp.id ? updated : d)));
    saveTowingRequestToFirestore(updated).catch(() => {});
  };

  // TOWER ACTION: Decline
  const handleTowerDecline = (disp: TowingDispatchRecord) => {
    const updated: TowingDispatchRecord = { ...disp, status: 'Declined' };
    setDispatches((prev) => prev.map((d) => (d.id === disp.id ? updated : d)));
    saveTowingRequestToFirestore(updated).catch(() => {});
    updateAssetRequestStatus(disp.id, 'declined');
  };

  // REQUESTER ACTION: Accept Tower Counter Offer
  const handleRequesterAcceptCounter = (disp: TowingDispatchRecord, offer: TowerOffer) => {
    const updated: TowingDispatchRecord = {
      ...disp,
      status: 'Dispatched & En-Route',
      offeredPrice: offer.counterAmount,
    };
    setDispatches((prev) => prev.map((d) => (d.id === disp.id ? updated : d)));
    setActiveUserDispatch(updated);
    saveTowingRequestToFirestore(updated).catch(() => {});
    updateAssetRequestStatus(disp.id, 'accepted', offer.towerName);
  };

  // Submit Roadside Towing Request -> Creates Firestore Doc & Starts Live Bidding
  const handleRequestTowing = async (e: React.FormEvent) => {
    e.preventDefault();
    const reqId = `tow_${Date.now()}`;

    // 1. Create in Firestore towingRequests collection
    const docData = {
      id: reqId,
      requesterId: user.id || 'rider_101',
      requesterName: userName || user.name || 'Client',
      requesterPhone: userPhone || user.phone || '+27 82 000 0000',
      pickupLatLng: { lat: -33.9249, lng: 18.4241 },
      dropLatLng: { lat: -33.8900, lng: 18.5200 },
      pickupAddress: userLocation,
      dropAddress: dropLocation,
      vehicleType: selectedVehicleType,
      problem: selectedProblem,
      photos: uploadedPhotos,
      offeredPrice: customOfferPrice,
      status: 'pending' as const,
      createdAt: Date.now(),
      offers: [],
    };

    await createTowingRequestInFirestore(docData).catch((err) => {
      console.warn('Firestore doc create warning:', err);
    });

    // 2. Save to localStorage asset requests array
    addAssetRequest({
      id: reqId,
      type: 'towing',
      towingType: selectedProblem as TowingType,
      problemType: selectedProblem,
      location: userLocation,
      pickupAddress: userLocation,
      dropAddress: dropLocation,
      gpsLocation: { lat: -33.9249, lng: 18.4241 },
      vehicleDetails: {
        makeModel: carMakeModel,
        color: carColor,
        plate: carPlate,
      },
      phone: userPhone || user.phone || '+27 82 000 0000',
      userName: userName || user.name || 'Client',
      description: problemDescription,
      offeredPrice: customOfferPrice,
      status: 'pending',
      createdAt: Date.now(),
      offers: [],
    });

    // 3. Open Live Bidding Radar
    setActiveBiddingRequestId(reqId);
  };

  // Register New Towing Company
  const handleRegisterCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regCompanyName.trim() || !regContactPerson.trim()) return;

    const newCompany: RegisteredTowingCompany = {
      id: `tow-co-${Date.now()}`,
      companyName: regCompanyName,
      contactPerson: regContactPerson,
      phone: regCompanyPhone,
      fleetSize: regFleetSize,
      coverageArea: regCoverageArea,
      is247: regIs247,
      servicesOffered: regServices,
      rating: 5.0,
    };

    setCompanies([newCompany, ...companies]);
    setCompanyRegSuccess(true);

    // Persist to Firestore
    saveTowingCompanyToFirestore(newCompany).catch((err) =>
      console.warn('Error saving towing company to Firestore:', err)
    );

    setTimeout(() => {
      setCompanyRegSuccess(false);
      setActiveTab('dispatch_console');
      setRegCompanyName('');
      setRegContactPerson('');
    }, 1800);
  };

  // Problem Type Icons and descriptions
  const PROBLEM_OPTIONS: { type: ProblemType; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      type: 'Breakdown',
      label: 'Breakdown',
      icon: <Wrench className="w-5 h-5" />,
      desc: 'Mechanical failure or engine breakdown',
    },
    {
      type: 'Accident Rollback',
      label: 'Accident Rollback',
      icon: <AlertTriangle className="w-5 h-5" />,
      desc: 'Accident scene flatbed rollback & insurance recovery',
    },
    {
      type: 'Battery Jump',
      label: 'Battery Jump',
      icon: <Battery className="w-5 h-5" />,
      desc: 'Flat battery jump start or test',
    },
    {
      type: 'Flat Tyre',
      label: 'Flat Tyre',
      icon: <Disc className="w-5 h-5" />,
      desc: 'Puncture repair or spare wheel fitment',
    },
    {
      type: 'Emergency Recovery',
      label: 'Emergency Recovery',
      icon: <LifeBuoy className="w-5 h-5" />,
      desc: 'Mud, sand, ditch or off-road winch recovery',
    },
  ];

  return (
    <div id="towing-assistance-view" className="max-w-5xl mx-auto p-4 sm:p-6 pb-24 text-neutral-900 bg-[#FFFBEB] select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-amber-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-towing"
            onClick={handleGoBack}
            className="w-10 h-10 rounded-2xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight font-sans">
              Towing & Breakdown
            </h1>
            <p className="font-mono text-[10px] uppercase text-neutral-500 tracking-wider">
              24/7 Community Roadside Assistance • South Africa 🇿🇦
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Top Header Rating requirement */}
          <button
            type="button"
            id="btn-towing-header-rating"
            onClick={() => setIsReviewsModalOpen(true)}
            className="bg-neutral-900 text-[#FFCC00] hover:bg-black px-3.5 py-2 rounded-2xl border border-amber-400/80 shadow-xs flex items-center gap-1.5 font-mono text-xs font-black transition active:scale-95 cursor-pointer"
          >
            <Star className="w-4 h-4 fill-[#FFCC00] text-[#FFCC00]" />
            <span>MY RATING: ⭐ 4.9 (43 Jobs)</span>
            <span className="text-[10px] text-amber-300 font-sans font-normal underline ml-0.5 sm:inline hidden">- tap to see reviews</span>
          </button>

          <button
            type="button"
            onClick={handleGoBack}
            className="w-9 h-9 rounded-2xl bg-[#FFCC00] text-black font-black text-base flex items-center justify-center shadow-xs"
          >
            Z
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex rounded-2xl bg-white p-1.5 border border-amber-200 mb-6 shadow-xs">
        <button
          type="button"
          id="tab-request-towing"
          onClick={() => {
            setActiveTab('request');
            setActiveRequestSubmitted(false);
          }}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-black uppercase tracking-wider font-mono transition flex items-center justify-center gap-2 ${
            activeTab === 'request'
              ? 'bg-[#FFCC00] text-black shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Wrench className="w-4 h-4" />
          <span>Request Roadside Tow</span>
        </button>

        <button
          type="button"
          id="tab-company-dispatch-view"
          onClick={() => setActiveTab('dispatch_console')}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-black uppercase tracking-wider font-mono transition flex items-center justify-center gap-2 ${
            activeTab === 'dispatch_console'
              ? 'bg-neutral-900 text-white shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Radio className="w-4 h-4 text-[#FFCC00] animate-pulse" />
          <span>Company Dispatch View</span>
        </button>

        <button
          type="button"
          id="tab-register-towing-company"
          onClick={() => setActiveTab('register_company')}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-black uppercase tracking-wider font-mono transition flex items-center justify-center gap-2 ${
            activeTab === 'register_company'
              ? 'bg-amber-100 text-amber-900 border border-amber-300 shadow-xs font-bold'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Register Towing Company</span>
        </button>
      </div>

      {/* TAB 1: REQUEST ROADSIDE & TOWING */}
      {activeTab === 'request' && (
        <>
          {activeBiddingRequestId ? (
            <AssetOffersWaitingScreen
              type="towing"
              requestId={activeBiddingRequestId}
              onClose={() => setActiveBiddingRequestId(null)}
            />
          ) : activeRequestSubmitted ? (
            /* Active Live Dispatch Card */
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200 shadow-md max-w-xl mx-auto space-y-5">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-neutral-900 font-sans">
                      Rollback Tow Dispatched!
                    </h3>
                    <p className="font-mono text-xs text-neutral-500">Live Status: En-Route</p>
                  </div>
                </div>
                <span className="bg-[#FFCC00] text-black font-mono text-xs font-black px-3 py-1 rounded-full uppercase">
                  ETA 12 MINS
                </span>
              </div>

              {/* Operator details & Offered Price */}
              <div className="bg-amber-50/80 rounded-2xl p-4 border border-amber-200 space-y-2 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-neutral-500 uppercase font-bold">Problem Type:</span>
                  <strong className="text-black bg-white px-2 py-0.5 rounded border border-amber-200">{selectedProblem}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 uppercase font-bold">Vehicle:</span>
                  <strong className="text-neutral-900">{carMakeModel} ({carColor}) • {carPlate}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 uppercase font-bold">Location:</span>
                  <span className="text-neutral-900 font-bold truncate max-w-xs">{userLocation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 uppercase font-bold">Your Offer Price:</span>
                  <strong className="text-emerald-700 font-black text-sm">R {activeUserDispatch?.offeredPrice || customOfferPrice}</strong>
                </div>
              </div>

              {/* Tower Counter Offers List */}
              {activeUserDispatch?.towerOffers && activeUserDispatch.towerOffers.length > 0 && (
                <div className="pt-2 border-t border-neutral-100 space-y-2">
                  <span className="text-[11px] font-mono font-black text-amber-900 uppercase block flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    Towing Operator Counter Bids Received ({activeUserDispatch.towerOffers.length}):
                  </span>
                  <div className="space-y-2">
                    {activeUserDispatch.towerOffers.map((off) => (
                      <div
                        key={off.id}
                        className="bg-amber-100/70 p-3 rounded-2xl border border-amber-300 flex items-center justify-between gap-3"
                      >
                        <div className="font-mono text-xs">
                          <span className="font-bold text-neutral-900 block">{off.towerName}</span>
                          <span className="text-[10px] text-neutral-600">Proposed Counter Tariff</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-base font-black font-mono text-black">R {off.counterAmount}</span>
                          <button
                            type="button"
                            onClick={() => handleRequesterAcceptCounter(activeUserDispatch, off)}
                            className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs px-3.5 py-2 rounded-xl uppercase font-mono shadow-xs active:scale-95 flex items-center gap-1"
                          >
                            <span>ACCEPT BID</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2.5">
                <a
                  href="tel:+27829914410"
                  className="flex-1 bg-neutral-900 hover:bg-black text-white font-mono text-xs font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-xs"
                >
                  <Phone className="w-4 h-4 text-[#FFCC00]" />
                  <span>Call Tow Driver (+27 82 991 4410)</span>
                </a>
                <button
                  type="button"
                  onClick={() => setActiveTab('dispatch_console')}
                  className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-mono text-xs font-black py-3.5 px-4 rounded-xl shadow-xs"
                >
                  View Company Dispatch
                </button>
              </div>
            </div>
          ) : (
            /* Request Form with 6 Problem Toggles & Details */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left 2 Cols: Form */}
              <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-7 border border-amber-200 shadow-xs space-y-5">
                <div>
                  <h3 className="text-xl font-black text-neutral-900 font-sans">
                    Request Immediate Towing or Roadside Help
                  </h3>
                  <p className="text-xs text-neutral-500 font-sans mt-0.5">
                    Select vehicle type, problem, and confirm breakdown & drop-off locations.
                  </p>
                </div>

                {/* VEHICLE TYPE SELECTOR */}
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-2">
                    Vehicle Type to Tow <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {([
                      { type: 'Car', label: 'Car / Sedan', icon: '🚗' },
                      { type: 'Bakkie', label: 'Bakkie / SUV', icon: '🛻' },
                      { type: 'Truck', label: 'Truck / Van', icon: '🚚' },
                      { type: 'Bike', label: 'Motorbike', icon: '🏍️' },
                    ] as { type: VehicleCategory; label: string; icon: string }[]).map((v) => {
                      const isSelected = selectedVehicleType === v.type;
                      return (
                        <button
                          key={v.type}
                          type="button"
                          onClick={() => setSelectedVehicleType(v.type)}
                          className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-1 ${
                            isSelected
                              ? 'bg-[#FFCC00] border-amber-400 text-black shadow-xs font-black'
                              : 'bg-neutral-50 hover:bg-amber-50/40 border-neutral-200 text-neutral-700'
                          }`}
                        >
                          <span className="text-xl">{v.icon}</span>
                          <span className="text-xs font-bold">{v.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* TOGGLES FOR TYPE OF PROBLEM: Accident, Breakdown, Flat Tyre, Battery, Stuck, Need Tow */}
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-2">
                    Type of Problem (Tap to Select) <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {([
                      {
                        type: 'Breakdown',
                        label: 'Breakdown',
                        icon: <Wrench className="w-5 h-5" />,
                        desc: 'Mechanical failure or engine breakdown',
                      },
                      {
                        type: 'Accident Rollback',
                        label: 'Accident Rollback',
                        icon: <AlertTriangle className="w-5 h-5" />,
                        desc: 'Accident scene rollback recovery',
                      },
                      {
                        type: 'Battery Jump',
                        label: 'Battery Jump',
                        icon: <Battery className="w-5 h-5" />,
                        desc: 'Flat battery jump start or test',
                      },
                      {
                        type: 'Flat Tyre',
                        label: 'Flat Tyre',
                        icon: <Disc className="w-5 h-5" />,
                        desc: 'Puncture repair or wheel fitment',
                      },
                      {
                        type: 'Emergency Recovery',
                        label: 'Emergency Recovery',
                        icon: <LifeBuoy className="w-5 h-5" />,
                        desc: 'Mud, sand, ditch or winch recovery',
                      },
                    ] as { type: ProblemType; label: string; icon: React.ReactNode; desc: string }[]).map((prob) => {
                      const isSelected = selectedProblem === prob.type;
                      return (
                        <button
                          key={prob.type}
                          type="button"
                          id={`toggle-problem-${prob.type.toLowerCase().replace(/\s+/g, '-')}`}
                          onClick={() => handleSelectProblem(prob.type)}
                          className={`p-3 rounded-2xl border text-left transition flex flex-col justify-between gap-1.5 ${
                            isSelected
                              ? 'bg-[#FFCC00] border-amber-400 text-black shadow-xs font-black scale-[1.02]'
                              : 'bg-neutral-50 hover:bg-amber-50/40 border-neutral-200 text-neutral-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                              isSelected ? 'bg-black text-[#FFCC00]' : 'bg-white text-neutral-800 border border-neutral-200'
                            }`}>
                              {prob.icon}
                            </div>
                            {isSelected && (
                              <CheckCircle2 className="w-4 h-4 text-black fill-[#FFCC00]" />
                            )}
                          </div>
                          <div>
                            <span className="text-xs font-bold block">{prob.label}</span>
                            <span className={`text-[10px] font-sans block leading-tight ${isSelected ? 'text-neutral-900' : 'text-neutral-500'}`}>
                              {prob.desc}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <form onSubmit={handleRequestTowing} className="space-y-4 font-sans">
                  {/* User Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                        Your Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                        Contact Phone (+27) <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        value={userPhone}
                        onChange={(e) => setUserPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none focus:border-black"
                        required
                      />
                    </div>
                  </div>

                  {/* Breakdown Location & Drop Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                        Breakdown Location (Pickup) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <MapPin className="w-4 h-4 text-red-500 absolute left-3.5 top-3" />
                        <input
                          type="text"
                          value={userLocation}
                          onChange={(e) => setUserLocation(e.target.value)}
                          placeholder="e.g. N2 Highway near Airport, Cape Town"
                          className="w-full pl-10 pr-4 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                        Drop-Off Destination (Garage / Home) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <MapPin className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3" />
                        <input
                          type="text"
                          value={dropLocation}
                          onChange={(e) => setDropLocation(e.target.value)}
                          placeholder="e.g. Tygerberg Auto Repairs, Bellville"
                          className="w-full pl-10 pr-4 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Car Details: Make/Model, Color, Plate */}
                  <div className="bg-amber-50/60 p-3.5 rounded-2xl border border-amber-200 space-y-2.5">
                    <span className="text-[10px] font-mono font-bold uppercase text-neutral-800 block">
                      Vehicle Information
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div>
                        <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">
                          Car Make & Model
                        </label>
                        <input
                          type="text"
                          value={carMakeModel}
                          onChange={(e) => setCarMakeModel(e.target.value)}
                          placeholder="e.g. Toyota Corolla Quest"
                          className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold outline-none"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">
                          Color
                        </label>
                        <input
                          type="text"
                          value={carColor}
                          onChange={(e) => setCarColor(e.target.value)}
                          placeholder="e.g. White / Silver"
                          className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold outline-none"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[9px] font-mono text-neutral-500 uppercase block mb-1">
                          License Plate
                        </label>
                        <input
                          type="text"
                          value={carPlate}
                          onChange={(e) => setCarPlate(e.target.value)}
                          placeholder="e.g. CA 889-102"
                          className="w-full px-2.5 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold font-mono outline-none"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                      Problem Description / Notes (Optional)
                    </label>
                    <textarea
                      rows={2}
                      value={problemDescription}
                      onChange={(e) => setProblemDescription(e.target.value)}
                      placeholder="Brief details (e.g. engine overheated, broken steering, stuck on highway shoulder)..."
                      className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                    />
                  </div>

                  {/* PHOTOS UPLOAD (OPTIONAL) */}
                  <div className="p-3 bg-neutral-50 rounded-2xl border border-dashed border-neutral-300 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold uppercase text-neutral-700 flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5 text-neutral-500" />
                        Breakdown Scene Photos (Optional)
                      </span>
                      <label className="cursor-pointer bg-white hover:bg-neutral-100 border border-neutral-300 px-3 py-1 rounded-xl text-[10px] font-mono font-bold text-neutral-800 flex items-center gap-1 shadow-2xs">
                        <Upload className="w-3 h-3" />
                        <span>Add Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              const fakeUrl = URL.createObjectURL(e.target.files[0]);
                              setUploadedPhotos((prev) => [...prev, fakeUrl]);
                            }
                          }}
                        />
                      </label>
                    </div>
                    {uploadedPhotos.length > 0 && (
                      <div className="flex gap-2 overflow-x-auto pt-1">
                        {uploadedPhotos.map((url, idx) => (
                          <div key={idx} className="relative w-14 h-14 rounded-xl overflow-hidden border border-amber-300 shrink-0">
                            <img src={url} alt="Breakdown preview" className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => setUploadedPhotos((prev) => prev.filter((_, i) => i !== idx))}
                              className="absolute top-0.5 right-0.5 w-4 h-4 bg-black/70 text-white rounded-full flex items-center justify-center"
                            >
                              <X className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* IN-DRIVE NEGOTIABLE OFFER FOR TOWING */}
                  <div className="p-4 bg-amber-100/80 rounded-2xl border border-amber-300 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-black uppercase text-amber-900 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                        Your Offered Towing Price (ZAR)
                      </span>
                      <span className="text-[10px] font-mono text-neutral-600">Standard: R450</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setCustomOfferPrice((prev) => Math.max(150, prev - 50))}
                        className="w-10 h-10 rounded-xl bg-white border border-amber-300 font-black text-lg text-neutral-800 hover:bg-amber-200 flex items-center justify-center transition active:scale-95 shadow-2xs"
                      >
                        -
                      </button>
                      <div className="flex-1 relative">
                        <span className="absolute left-3.5 top-2.5 font-mono text-xs font-bold text-neutral-500">R</span>
                        <input
                          type="number"
                          value={customOfferPrice}
                          onChange={(e) => setCustomOfferPrice(parseFloat(e.target.value) || 0)}
                          className="w-full pl-8 pr-3 py-2 bg-white border border-amber-300 rounded-xl font-mono text-base font-black text-neutral-900 outline-none focus:border-black text-center"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => setCustomOfferPrice((prev) => prev + 50)}
                        className="w-10 h-10 rounded-xl bg-white border border-amber-300 font-black text-lg text-neutral-800 hover:bg-amber-200 flex items-center justify-center transition active:scale-95 shadow-2xs"
                      >
                        +
                      </button>
                    </div>
                    <p className="text-[10px] font-mono text-amber-800">
                      💡 Offer your price. Nearby tow truck operators will bid or accept live!
                    </p>
                  </div>

                  <button
                    type="submit"
                    id="btn-dispatch-towing"
                    className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-4 rounded-xl uppercase tracking-wider font-mono shadow-xs transition active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Truck className="w-4 h-4" />
                    <span>REQUEST TOWING (OFFER R{customOfferPrice})</span>
                  </button>
                </form>
              </div>

              {/* Right Col: Info & Tariffs */}
              <div className="space-y-4">
                <div className="bg-neutral-900 text-white rounded-3xl p-6 shadow-md flex flex-col justify-between space-y-4">
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-white/10 text-[#FFCC00] flex items-center justify-center mb-3">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-white font-sans">
                      Verified Towing Network
                    </h3>
                    <p className="text-xs text-neutral-300 font-sans leading-relaxed mt-2">
                      All registered operators use calibrated rollbacks, carry goods-in-transit insurance, and follow regulated standard South African roadside rates.
                    </p>
                  </div>

                  <div className="space-y-2 pt-4 border-t border-neutral-800 font-mono text-xs">
                    <div className="flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>Accident & Insurance Towing</span>
                    </div>
                    <div className="flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>Damage-Free Flatbed Rollback</span>
                    </div>
                    <div className="flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>Direct Driver Phone & ETA</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-5 border border-amber-200 shadow-xs space-y-2 font-mono text-xs">
                  <span className="text-[10px] uppercase text-neutral-500 font-bold block">
                    Tariff Guideline
                  </span>
                  <div className="flex justify-between py-1 border-b border-neutral-100">
                    <span className="text-neutral-600">Base Callout:</span>
                    <strong className="text-neutral-900">R 450.00</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-neutral-100">
                    <span className="text-neutral-600">Per Km Towing:</span>
                    <strong className="text-neutral-900">R 18.00 / km</strong>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-neutral-600">Jump Start / Tyre:</span>
                    <strong className="text-neutral-900">R 250 - R 350</strong>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* TAB 2: OPERATOR DISPATCH CONSOLE (What the Towing Company Sees) */}
      {activeTab === 'dispatch_console' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 border border-amber-200 shadow-xs flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <h3 className="text-lg font-black text-neutral-900 font-sans">
                  Towing Operator Live Dispatch Console
                </h3>
              </div>
              <p className="text-xs text-neutral-500 font-sans mt-0.5">
                Here is exactly what the towing company and rollback drivers receive when a user requests assistance.
              </p>
            </div>
            <span className="bg-emerald-100 text-emerald-800 font-mono text-xs font-bold px-3 py-1 rounded-full uppercase border border-emerald-300">
              {dispatches.length} Active Dispatch
            </span>
          </div>

          {dispatches.length === 0 ? (
            <div className="bg-neutral-50 rounded-3xl p-12 text-center border border-neutral-200 shadow-xs">
              <div className="w-12 h-12 bg-white border border-[#FFCC00] text-[#FFCC00] rounded-full flex items-center justify-center mx-auto mb-3 animate-spin">
                <Sparkles className="w-6 h-6 text-[#D97706]" />
              </div>
              <h4 className="font-bold text-sm text-neutral-900 font-sans">ZOLTA Radar Scanning for Towing & Roadside Requests...</h4>
              <p className="text-xs text-neutral-500 mt-1">
                No active roadside or breakdown requests nearby. Real-time dispatches from stranded motorists will appear here immediately.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {dispatches.map((disp) => (
                <div
                  key={disp.id}
                  className="bg-white rounded-3xl p-6 border-2 border-amber-300 shadow-xs space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-100 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="bg-neutral-900 text-white font-mono text-xs font-bold px-2.5 py-1 rounded-lg">
                        {disp.id}
                      </span>
                      <span className="bg-[#FFCC00] text-black font-mono text-xs font-black px-2.5 py-1 rounded-lg uppercase">
                        Problem: {disp.problemType}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-neutral-500">Received {disp.timestamp}</span>
                  </div>

                  {/* Grid showing User Name, Phone, Location, Problem Type, Car Details, Description */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                    {/* User & Contact */}
                    <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-200 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">User & Contact</span>
                      <p className="font-bold text-neutral-900 text-sm font-sans">{disp.userName}</p>
                      <p className="text-neutral-700 flex items-center gap-1.5 font-bold">
                        <Phone className="w-3.5 h-3.5 text-amber-600" />
                        <span>{disp.userPhone}</span>
                      </p>
                    </div>

                    {/* Location */}
                    <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-200 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">Breakdown Location</span>
                      <p className="text-neutral-900 font-bold flex items-start gap-1">
                        <MapPin className="w-3.5 h-3.5 text-red-500 flex-shrink-0 mt-0.5" />
                        <span>{disp.location}</span>
                      </p>
                    </div>

                    {/* Car Details */}
                    <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-200 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-bold block">Vehicle Details</span>
                      <p className="text-neutral-900 font-bold">{disp.carDetails.makeModel}</p>
                      <p className="text-neutral-600">Color: {disp.carDetails.color} • Plate: <strong className="text-black">{disp.carDetails.plate}</strong></p>
                    </div>
                  </div>

                  {/* Description Box */}
                  <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 font-mono text-xs">
                    <span className="text-[10px] text-neutral-500 uppercase font-bold block mb-1">
                      Situation Description / Notes:
                    </span>
                    <p className="text-neutral-900 font-sans font-medium">{disp.description}</p>
                  </div>

                  {/* Offered Price & Towing Bidding Console */}
                  <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 font-mono">
                      <div>
                        <span className="text-[10px] text-neutral-500 uppercase font-bold block">
                          Client Offered Towing Tariff:
                        </span>
                        <span className="text-lg font-black text-[#D97706]">
                          R {disp.offeredPrice || 450}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-neutral-700">Status:</span>
                        <span className="bg-[#FFCC00] text-black font-mono text-xs font-black px-2.5 py-1 rounded-full uppercase">
                          {disp.status}
                        </span>
                      </div>
                    </div>

                    {/* Bidding Controls for Towing Operator */}
                    <div className="pt-2 border-t border-amber-200/60 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-1.5 flex-1">
                        <span className="text-[10px] font-mono font-bold text-neutral-600 uppercase">Counter:</span>
                        <button
                          type="button"
                          onClick={() => {
                            const curr = counterBidAmounts[disp.id] || (disp.offeredPrice ? disp.offeredPrice + 50 : 500);
                            setCounterBidAmounts({ ...counterBidAmounts, [disp.id]: Math.max(150, curr - 50) });
                          }}
                          className="w-8 h-8 rounded-lg bg-white border border-neutral-300 font-bold text-black hover:bg-neutral-100 flex items-center justify-center text-sm shadow-2xs"
                        >
                          -
                        </button>
                        <div className="relative flex-1 max-w-[110px]">
                          <span className="absolute left-2.5 top-1.5 text-xs font-mono font-bold text-neutral-400">R</span>
                          <input
                            type="number"
                            value={counterBidAmounts[disp.id] !== undefined ? counterBidAmounts[disp.id] : (disp.offeredPrice ? disp.offeredPrice + 50 : 500)}
                            onChange={(e) => setCounterBidAmounts({ ...counterBidAmounts, [disp.id]: parseFloat(e.target.value) || 0 })}
                            className="w-full pl-6 pr-2 py-1 bg-white border border-neutral-300 rounded-lg text-xs font-mono font-black text-black outline-none focus:border-black"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const curr = counterBidAmounts[disp.id] || (disp.offeredPrice ? disp.offeredPrice + 50 : 500);
                            setCounterBidAmounts({ ...counterBidAmounts, [disp.id]: curr + 50 });
                          }}
                          className="w-8 h-8 rounded-lg bg-white border border-neutral-300 font-bold text-black hover:bg-neutral-100 flex items-center justify-center text-sm shadow-2xs"
                        >
                          +
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleTowerAcceptOffer(disp)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-xs font-black px-3 py-2 rounded-xl uppercase transition active:scale-95 shadow-xs"
                        >
                          ACCEPT (R{disp.offeredPrice || 450})
                        </button>
                        <button
                          type="button"
                          onClick={() => handleTowerSubmitCounter(disp)}
                          className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-mono text-xs font-black px-3 py-2 rounded-xl uppercase transition active:scale-95 shadow-xs"
                        >
                          COUNTER BID
                        </button>
                        <button
                          type="button"
                          onClick={() => handleTowerDecline(disp)}
                          className="bg-neutral-200 hover:bg-neutral-300 text-neutral-800 font-mono text-xs font-bold px-3 py-2 rounded-xl uppercase transition"
                        >
                          DECLINE
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Operator Actions */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="flex items-center gap-2 text-xs font-mono text-neutral-600">
                      <Truck className="w-4 h-4 text-emerald-600" />
                      <span>Assigned: <strong>{disp.assignedTruck}</strong> (ETA {disp.eta})</span>
                    </div>

                    <div className="flex gap-2">
                      <a
                        href={`tel:${disp.userPhone.replace(/\s+/g, '')}`}
                        className="bg-neutral-900 hover:bg-black text-white text-xs font-bold font-mono px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-xs"
                      >
                        <Phone className="w-3.5 h-3.5 text-[#FFCC00]" />
                        <span>Call Client</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => alert(`Dispatch ${disp.id} marked as Completed!`)}
                        className="bg-[#FFCC00] hover:bg-yellow-400 text-black text-xs font-black font-mono px-4 py-2 rounded-xl shadow-xs"
                      >
                        Mark Completed ✓
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: REGISTER TOWING COMPANY */}
      {activeTab === 'register_company' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200 shadow-xs max-w-2xl mx-auto space-y-6">
          <div className="border-b border-neutral-100 pb-4">
            <span className="text-[10px] font-mono font-bold bg-[#FFCC00] text-black px-2.5 py-1 rounded-md uppercase">
              Operator Portal
            </span>
            <h3 className="text-2xl font-black text-neutral-900 mt-2 font-sans">
              Register Your Towing & Breakdown Fleet
            </h3>
            <p className="text-xs text-neutral-600 mt-1">
              Join South Africa&apos;s verified roadside network. Receive instant rollback dispatch requests directly to your operators.
            </p>
          </div>

          {companyRegSuccess ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-black text-neutral-900 font-sans">
                Towing Company Registered!
              </h3>
              <p className="text-xs text-neutral-600 max-w-xs mx-auto">
                Your towing company has been verified and added to the live ZOLTA Roadside Network.
              </p>
            </div>
          ) : (
            <form onSubmit={handleRegisterCompany} className="space-y-4 font-sans">
              {/* Company Name */}
              <div>
                <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                  Company Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Cape Peninsula Rollbacks & Towing (Pty) Ltd"
                  value={regCompanyName}
                  onChange={(e) => setRegCompanyName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                  required
                />
              </div>

              {/* Contact Person & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Contact Person Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Sipho Ndlovu"
                    value={regContactPerson}
                    onChange={(e) => setRegContactPerson(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    24/7 Hotline Phone (+27) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={regCompanyPhone}
                    onChange={(e) => setRegCompanyPhone(e.target.value)}
                    placeholder="+27 82 991 4410"
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold font-mono outline-none focus:border-black"
                    required
                  />
                </div>
              </div>

              {/* Fleet Size & Coverage Area */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Fleet Size <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={regFleetSize}
                    onChange={(e) => setRegFleetSize(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black font-mono"
                  >
                    <option value="1-3 Rollback Trucks">1-3 Rollback Trucks</option>
                    <option value="4-8 Rollback Trucks">4-8 Rollback Trucks</option>
                    <option value="6-12 Heavy Duty Fleet">6-12 Heavy Duty Fleet</option>
                    <option value="15+ Nationwide Fleet">15+ Nationwide Fleet</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-1">
                    Coverage Area <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={regCoverageArea}
                    onChange={(e) => setRegCoverageArea(e.target.value)}
                    placeholder="e.g. Cape Town Metro, N2 & Southern Suburbs"
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-bold outline-none focus:border-black"
                    required
                  />
                </div>
              </div>

              {/* 24/7 Service Toggle */}
              <div className="p-3.5 bg-neutral-50 rounded-2xl border border-neutral-200 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-neutral-900 block">24/7 Emergency Service?</span>
                  <span className="text-[10px] font-mono text-neutral-500">Available day and night 365 days</span>
                </div>
                <button
                  type="button"
                  onClick={() => setRegIs247(!regIs247)}
                  className={`px-3 py-1.5 rounded-xl font-mono text-xs font-black transition ${
                    regIs247 ? 'bg-[#FFCC00] text-black shadow-xs' : 'bg-neutral-200 text-neutral-700'
                  }`}
                >
                  {regIs247 ? '24/7 (YES)' : 'Daytime Only'}
                </button>
              </div>

              {/* Services Offered Toggles */}
              <div>
                <label className="text-[10px] font-mono font-bold uppercase text-neutral-700 block mb-2">
                  Services Offered Toggles (Tap to toggle)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(['Accident', 'Breakdown', 'Flat Tyre', 'Battery', 'Stuck', 'Need Tow'] as ProblemType[]).map((srv) => {
                    const isOffered = regServices.includes(srv);
                    return (
                      <button
                        key={srv}
                        type="button"
                        onClick={() => handleToggleService(srv)}
                        className={`p-2.5 rounded-xl border text-xs font-mono font-bold transition flex items-center justify-between ${
                          isOffered
                            ? 'bg-neutral-900 text-white border-black font-black'
                            : 'bg-white text-neutral-500 border-neutral-200 hover:bg-neutral-50'
                        }`}
                      >
                        <span>{srv}</span>
                        {isOffered && <CheckCircle2 className="w-3.5 h-3.5 text-[#FFCC00]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3.5 rounded-xl uppercase tracking-wider font-mono shadow-xs transition active:scale-95 mt-2"
              >
                Register Towing Fleet on ZOLTA
              </button>
            </form>
          )}
        </div>
      )}

      {/* Owner Reviews Modal */}
      <OwnerReviewsModal
        isOpen={isReviewsModalOpen}
        onClose={() => setIsReviewsModalOpen(false)}
        rating={4.9}
        jobsCount={43}
        ownerName={user.name || 'Verified ZOLTA Towing Operator'}
      />
    </div>
  );
};

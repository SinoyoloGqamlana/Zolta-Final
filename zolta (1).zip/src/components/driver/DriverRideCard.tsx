import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { RideRequest, RidePreferences } from '../../types';
import { useApp, DEFAULT_RIDE_PREFERENCES } from '../../context/AppContext';
import {
  Star,
  Check,
  ArrowUpRight,
  Plus,
  Minus,
  User,
  Users,
  ShieldCheck,
  Globe,
  Music,
  MessageSquare,
  ShoppingBag,
  Share2,
  Moon,
  MapPin,
  Sliders,
} from 'lucide-react';
import { db } from '../../firebase';
import { doc, onSnapshot } from 'firebase/firestore';

interface DriverRideCardProps {
  ride: RideRequest;
}

export const DriverRideCard: React.FC<DriverRideCardProps> = ({ ride }) => {
  const { driverSubmitBid, driverAcceptDirect } = useApp();
  const [isCountering, setIsCountering] = useState(false);
  const [customBidAmount, setCustomBidAmount] = useState((ride?.offeredFare || 50) + 10);
  const [driverComment, setDriverComment] = useState('');
  const [riderProfile, setRiderProfile] = useState<{
    totalTrips?: number;
    rating?: number;
    createdAt?: any;
    joinedDate?: string;
    ridePreferences?: RidePreferences;
  } | null>(null);

  useEffect(() => {
    if (!db || !ride?.riderId) return;
    const userRef = doc(db, 'users', ride.riderId);
    const unsub = onSnapshot(
      userRef,
      (docSnap) => {
        if (docSnap.exists()) {
          setRiderProfile(docSnap.data() as any);
        }
      },
      () => {
        // Silent error handle
      }
    );
    return () => unsub();
  }, [ride?.riderId]);

  const handleSendCustomBid = () => {
    if (ride?.id) {
      driverSubmitBid(ride.id, customBidAmount, driverComment || undefined);
    }
    setIsCountering(false);
  };

  const totalTrips = typeof riderProfile?.totalTrips === 'number'
    ? riderProfile.totalTrips
    : (typeof (ride as any)?.riderTrips === 'number' ? (ride as any).riderTrips : 0);

  let joinedYear = 2024;
  if (riderProfile?.createdAt) {
    if (typeof riderProfile.createdAt.toDate === 'function') {
      joinedYear = riderProfile.createdAt.toDate().getFullYear();
    } else {
      const d = new Date(riderProfile.createdAt);
      if (!isNaN(d.getTime())) {
        joinedYear = d.getFullYear();
      }
    }
  } else if (riderProfile?.joinedDate) {
    const d = new Date(riderProfile.joinedDate);
    if (!isNaN(d.getTime())) {
      joinedYear = d.getFullYear();
    }
  }

  const riderRating = typeof riderProfile?.rating === 'number'
    ? riderProfile.rating
    : (typeof ride?.riderRating === 'number' ? ride.riderRating : 5.0);

  const pickupAddress = ride?.pickup?.address || (ride as any)?.pickupAddress || '';
  const dropoffAddress = ride?.dropoff?.address || (ride as any)?.dropoffAddress || '';

  const shortPickup = ride?.pickup?.shortName || (pickupAddress ? pickupAddress.split(',')[0] : '') || 'Pickup location';
  const shortDropoff = ride?.dropoff?.shortName || (dropoffAddress ? dropoffAddress.split(',')[0] : '') || 'Dropoff destination';

  const offeredFare = typeof ride?.offeredFare === 'number' ? ride.offeredFare : (Number((ride as any)?.fare) || 50);

  const prefs: RidePreferences = {
    ...DEFAULT_RIDE_PREFERENCES,
    ...(riderProfile?.ridePreferences || {}),
    ...(ride?.preferences || {}),
    ...((ride as any)?.ridePreferences || {}),
    ...(ride?.genderPreference && ride.genderPreference !== 'any' ? { driverPreference: ride.genderPreference } : {}),
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-white text-neutral-900 rounded-2xl p-2.5 border border-neutral-200 shadow-xs relative overflow-hidden transition hover:border-neutral-300"
    >
      {/* Rider Info Header & Big Yellow Price Badge */}
      <div className="flex items-center justify-between gap-1 mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <img
            src={ride?.riderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
            alt={ride?.riderName || 'Rider'}
            referrerPolicy="no-referrer"
            className="w-8 h-8 rounded-full object-cover border border-neutral-200 flex-shrink-0"
          />
          <div className="min-w-0">
            <div className="flex items-center gap-1">
              <h4 className="font-black text-xs text-neutral-900 truncate">
                {ride?.riderName || 'Rider'}
              </h4>
              <span
                className="bg-blue-500 text-white rounded-full inline-flex items-center justify-center w-3.5 h-3.5 flex-shrink-0"
                title="Verified Rider"
              >
                <Check className="w-2 h-2 stroke-[3]" />
              </span>
            </div>
            {/* Safety Badge under rider name */}
            <p className="text-[9px] text-neutral-500 font-bold leading-tight truncate">
              {totalTrips} trips • Joined {joinedYear} • Verified
            </p>
            {/* Rating and payment info */}
            <div className="flex items-center gap-1.5 text-[10px] font-bold text-neutral-700 mt-0.5">
              <span className="flex items-center gap-0.5 text-neutral-900 bg-amber-50 px-1 py-0.2 rounded border border-amber-200">
                <Star className="w-2.5 h-2.5 fill-[#FFD60A] text-[#FFD60A]" />
                {(riderRating || 5.0).toFixed(1)}
              </span>
              <span className="text-neutral-500 bg-neutral-100 px-1 py-0.2 rounded border border-neutral-200 uppercase text-[9px]">
                {ride?.paymentMethod || 'CASH'}
              </span>
            </div>
          </div>
        </div>

        {/* Offered Fare Display */}
        <div className="text-right bg-amber-50 border border-amber-200 px-2 py-1 rounded-xl flex-shrink-0">
          <span className="text-[8px] font-black text-amber-800 uppercase tracking-wider block">RIDER OFFERS</span>
          <div className="text-sm sm:text-base font-black text-black font-mono leading-tight">
            R {offeredFare}
          </div>
        </div>
      </div>

      {/* Route (Shortened) */}
      <div className="text-[11px] font-bold text-neutral-800 bg-neutral-50 px-2 py-1.5 rounded-lg border border-neutral-200 flex items-center gap-1 truncate mb-1.5">
        <span className="text-emerald-700 truncate">{shortPickup}</span>
        <span className="text-neutral-400">→</span>
        <span className="text-red-700 truncate">{shortDropoff}</span>
      </div>

      {/* Duration & Category Row */}
      <div className="flex items-center justify-between text-[10px] font-bold text-neutral-500 mb-1.5 px-0.5">
        <span>{ride?.durationMins || 10} min • {ride?.distanceKm || 4} km</span>
        <span className="text-[8px] font-black uppercase bg-neutral-100 text-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200">
          {(ride?.category || 'RIDE').toUpperCase()}
        </span>
      </div>

      {/* Rider Preferences Strip (Visible BEFORE accepting) */}
      <div className="bg-amber-50/50 border border-amber-200/70 rounded-lg p-1.5 mb-2 space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[9px] font-black uppercase text-amber-900 tracking-wider flex items-center gap-1">
            <Sliders className="w-2.5 h-2.5 text-amber-700" />
            Rider Preferences
          </span>
          {prefs.stopAtSpaza && (
            <span className="bg-[#FFD60A] text-black font-black text-[8px] px-1.5 py-0.5 rounded flex items-center gap-0.5 border border-yellow-500/40">
              <ShoppingBag className="w-2.5 h-2.5 stroke-[2.5]" />
              Spaza Stop (+R5)
            </span>
          )}
        </div>

        {/* Preferences Chips */}
        <div className="flex flex-wrap gap-1">
          {/* Driver Preference (Female/Male/All) */}
          <div
            className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold border ${
              prefs.driverPreference === 'female'
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : prefs.driverPreference === 'male'
                ? 'bg-blue-50 border-blue-200 text-blue-800'
                : 'bg-white border-neutral-200 text-neutral-800'
            }`}
            title="Driver gender preference"
          >
            {prefs.driverPreference === 'female' ? (
              <ShieldCheck className="w-2.5 h-2.5 text-rose-600 stroke-[2.5]" />
            ) : prefs.driverPreference === 'male' ? (
              <User className="w-2.5 h-2.5 text-blue-600 stroke-[2.5]" />
            ) : (
              <Users className="w-2.5 h-2.5 text-neutral-600 stroke-[2.5]" />
            )}
            <span>
              {prefs.driverPreference === 'female'
                ? 'Female Driver'
                : prefs.driverPreference === 'male'
                ? 'Male Driver'
                : 'All Drivers'}
            </span>
          </div>

          {/* Language */}
          <div
            className="inline-flex items-center gap-1 bg-white border border-neutral-200 text-neutral-800 px-1.5 py-0.5 rounded text-[9px] font-bold"
            title="Preferred Language"
          >
            <Globe className="w-2.5 h-2.5 text-emerald-600 stroke-[2.5]" />
            <span>{prefs.language || 'Xhosa'}</span>
          </div>

          {/* Music */}
          <div
            className="inline-flex items-center gap-1 bg-white border border-neutral-200 text-neutral-800 px-1.5 py-0.5 rounded text-[9px] font-bold"
            title="Music Choice"
          >
            <Music className="w-2.5 h-2.5 text-purple-600 stroke-[2.5]" />
            <span>{prefs.music || 'Amapiano'}</span>
          </div>

          {/* Chat Level */}
          <div
            className="inline-flex items-center gap-1 bg-white border border-neutral-200 text-neutral-800 px-1.5 py-0.5 rounded text-[9px] font-bold"
            title="Conversation preference"
          >
            <MessageSquare className="w-2.5 h-2.5 text-amber-600 stroke-[2.5]" />
            <span>{prefs.chatLevel || 'Chatty'}</span>
          </div>

          {/* Safety Kasi: Share Trip */}
          {prefs.shareTripFamily && (
            <div
              className="inline-flex items-center gap-1 bg-emerald-50 border border-emerald-200 text-emerald-800 px-1.5 py-0.5 rounded text-[9px] font-bold"
              title="Rider shares trip with family"
            >
              <Share2 className="w-2.5 h-2.5 text-emerald-600 stroke-[2.5]" />
              <span>Share Trip</span>
            </div>
          )}

          {/* Safety Kasi: Female priority at night */}
          {prefs.femaleDriverAtNight && (
            <div
              className="inline-flex items-center gap-1 bg-indigo-50 border border-indigo-200 text-indigo-800 px-1.5 py-0.5 rounded text-[9px] font-bold"
              title="Female driver priority at night"
            >
              <Moon className="w-2.5 h-2.5 text-indigo-600 stroke-[2.5]" />
              <span>Female Night</span>
            </div>
          )}

          {/* Safety Kasi: Avoid gravel */}
          {prefs.avoidGravelRoads && (
            <div
              className="inline-flex items-center gap-1 bg-amber-100 border border-amber-300 text-amber-900 px-1.5 py-0.5 rounded text-[9px] font-bold"
              title="Avoid unpaved / gravel roads"
            >
              <MapPin className="w-2.5 h-2.5 text-amber-700 stroke-[2.5]" />
              <span>Avoid Gravel</span>
            </div>
          )}
        </div>
      </div>

      {/* Rider Note if any */}
      {ride?.comments && (
        <p className="text-[10px] text-neutral-600 bg-amber-50/50 border border-amber-100 p-1.5 rounded mb-1.5 italic">
          &quot;{ride.comments}&quot;
        </p>
      )}

      {/* Counter Offer Box */}
      {isCountering ? (
        <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-2 mb-1 space-y-1.5">
          <span className="text-[11px] font-bold text-neutral-900 block">Offer Counter Fare (ZAR)</span>
          
          <div className="flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => setCustomBidAmount((p) => Math.max(offeredFare, p - 5))}
              className="w-7 h-7 rounded-lg bg-white hover:bg-neutral-100 border border-neutral-300 flex items-center justify-center font-bold text-black shadow-xs"
            >
              <Minus className="w-3 h-3" />
            </button>
            <div className="text-lg font-black text-black font-mono">R {customBidAmount}</div>
            <button
              type="button"
              onClick={() => setCustomBidAmount((p) => p + 5)}
              className="w-7 h-7 rounded-lg bg-white hover:bg-neutral-100 border border-neutral-300 flex items-center justify-center font-bold text-black shadow-xs"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>

          <div className="flex gap-1 justify-center">
            {[10, 20, 30].map((plus) => (
              <button
                key={plus}
                type="button"
                onClick={() => setCustomBidAmount(offeredFare + plus)}
                className="text-[10px] font-bold bg-white hover:bg-neutral-100 border border-neutral-300 px-1.5 py-0.5 rounded text-black shadow-xs"
              >
                +R{plus} (R{offeredFare + plus})
              </button>
            ))}
          </div>

          <input
            type="text"
            placeholder="Quick note (e.g. 2 mins away, AC on)"
            value={driverComment}
            onChange={(e) => setDriverComment(e.target.value)}
            className="w-full bg-white border border-neutral-300 rounded-lg px-2 py-1 text-xs text-black outline-none placeholder:text-neutral-400"
          />

          <div className="flex gap-1.5 pt-0.5">
            <button
              type="button"
              onClick={() => setIsCountering(false)}
              className="flex-1 text-xs font-bold text-neutral-600 py-1 hover:text-black"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSendCustomBid}
              className="flex-1 bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-1 px-2 rounded-lg shadow-xs"
            >
              Send R {customBidAmount}
            </button>
          </div>
        </div>
      ) : (
        /* Action Buttons: Accept Direct vs Counter Offer - 50% more compact h-8 buttons */
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            id={`btn-driver-counter-${ride?.id || 'req'}`}
            onClick={() => setIsCountering(true)}
            className="h-8 bg-neutral-100 hover:bg-neutral-200 border border-neutral-200 text-neutral-900 font-bold text-xs px-2 rounded-lg flex items-center justify-center gap-1 transition active:scale-95 shadow-xs"
          >
            <ArrowUpRight className="w-3 h-3 text-neutral-800" />
            <span>Counter</span>
          </button>

          <button
            type="button"
            id={`btn-driver-accept-${ride?.id || 'req'}`}
            onClick={() => ride?.id && driverAcceptDirect(ride.id)}
            className="h-8 bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs px-2 rounded-lg flex items-center justify-center gap-1 shadow-xs transition active:scale-95"
          >
            <Check className="w-3 h-3 stroke-[3]" />
            <span>Accept R {offeredFare}</span>
          </button>
        </div>
      )}
    </motion.div>
  );
};

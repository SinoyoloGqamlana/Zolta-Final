import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DriverRideCard } from './DriverRideCard';
import { DriverActiveTrip } from './DriverActiveTrip';
import { DriverEarningsModal } from './DriverEarningsModal';
import { DriverVerificationModal } from './DriverVerificationModal';
import { InteractiveMap } from '../map/InteractiveMap';
import {
  Power,
  ShieldCheck,
  Sparkles,
  ShieldAlert,
  Car,
  Bike,
  Truck,
  Package,
  Users,
} from 'lucide-react';
import {
  getDriverVehicleType,
  matchCategoryToVehicle,
  CATEGORY_DISPLAY_NAMES,
  NormalizedRideCategory,
} from '../../services/categoryService';

const CATEGORIES_LIST: { id: NormalizedRideCategory; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'ride', label: 'Ride', icon: Car },
  { id: 'comfort', label: 'Comfort', icon: Car },
  { id: 'xl', label: 'XL', icon: Users },
  { id: 'bakkie', label: 'Bakkie', icon: Truck },
  { id: 'scooter', label: 'Scooter', icon: Bike },
  { id: 'courier', label: 'Courier', icon: Package },
];

export const DriverDashboard: React.FC = () => {
  const {
    driverOnline,
    setDriverOnline,
    driverFeedRides,
    activeRide,
    user,
    setDriverVehicleType,
    setVerificationModalOpen,
    setSosModalOpen,
    setMode,
    setCurrentView,
  } = useApp();

  const [isEarningsOpen, setEarningsOpen] = useState(false);

  // Active driver vehicle category (Ride, Comfort, XL, Bakkie, Scooter, Courier)
  const driverVehicleType = getDriverVehicleType(user);

  // Filter incoming requests in Driver Portal by matching request.category to driver.vehicleType
  const filteredDriverRides = driverFeedRides.filter((ride) =>
    matchCategoryToVehicle(ride.category, driverVehicleType)
  );

  // Switch back to passenger/rider portal
  const handleSwitchToRider = () => {
    setMode('rider');
    setCurrentView('home');
  };

  // If driver has an active trip assigned/in-progress
  const isDrivingActive = activeRide && ['driver_assigned', 'driver_arrived', 'in_progress'].includes(activeRide.status);

  const earningsToday = user.driverDetails?.earningsToday ?? 0;
  const tripsToday = user.driverDetails?.tripsToday ?? 0;

  return (
    <div id="driver-dashboard-view" className="relative w-full min-h-[calc(100vh-56px)] bg-white text-neutral-900 flex flex-col">
      {/* Top Driver Status & Stats Header */}
      <div className="bg-white border-b border-neutral-200 px-4 py-3 sticky top-14 z-30 shadow-xs">
        <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Online/Offline Toggle */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-toggle-driver-online"
              onClick={() => setDriverOnline(!driverOnline)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full font-black text-xs transition shadow-xs ${
                driverOnline
                  ? 'bg-[#FFD60A] text-black ring-2 ring-yellow-400'
                  : 'bg-neutral-100 text-neutral-600 border border-neutral-300'
              }`}
            >
              <span className={`w-2.5 h-2.5 rounded-full ${driverOnline ? 'bg-black animate-ping' : 'bg-neutral-400'}`} />
              <span>{driverOnline ? 'ONLINE • ACCEPTING TRIPS' : 'OFFLINE'}</span>
            </button>
          </div>

          {/* Quick Metrics & Modals */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-open-driver-earnings"
              onClick={() => setEarningsOpen(true)}
              className="bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 text-black px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition"
            >
              <span>Today: <strong>R {(earningsToday || 0).toFixed(0)}</strong> ({tripsToday} trips)</span>
            </button>

            <button
              type="button"
              id="btn-open-driver-docs"
              onClick={() => setVerificationModalOpen(true)}
              className="bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 text-neutral-800 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Verification</span>
            </button>

            <button
              type="button"
              id="btn-driver-sos"
              onClick={() => setSosModalOpen(true)}
              className="bg-red-50 border border-red-300 hover:bg-red-100 text-red-600 px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1 transition"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>SOS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Body */}
      {isDrivingActive ? (
        <div className="flex-1 flex flex-col">
          {/* Background Map while driving */}
          <div className="h-64 sm:h-80 w-full relative">
            <InteractiveMap
              pickup={activeRide.pickup}
              dropoff={activeRide.dropoff}
              activeRide={activeRide}
            />
          </div>
          <div className="flex-1 bg-white">
            <DriverActiveTrip />
          </div>
        </div>
      ) : (
        <div className="flex-1 max-w-4xl w-full mx-auto p-4 space-y-4">
          {/* Driver Vehicle Type Selector Bar */}
          <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-3 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-extrabold uppercase text-neutral-500 tracking-wider">
                Active Vehicle Category
              </span>
              <span className="text-xs font-black px-2 py-0.5 bg-[#FFD60A] text-black rounded-lg">
                {CATEGORY_DISPLAY_NAMES[driverVehicleType]}
              </span>
            </div>
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
              {CATEGORIES_LIST.map((cat) => {
                const IconComponent = cat.icon;
                const isSelected = driverVehicleType === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    id={`btn-driver-category-${cat.id}`}
                    onClick={() => setDriverVehicleType(cat.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition border ${
                      isSelected
                        ? 'bg-black text-[#FFD60A] border-black shadow-xs font-black'
                        : 'bg-white text-neutral-700 hover:bg-neutral-100 border-neutral-200'
                    }`}
                  >
                    <IconComponent className={`w-3.5 h-3.5 ${isSelected ? 'text-[#FFD60A]' : 'text-neutral-500'}`} />
                    <span>{cat.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {!driverOnline ? (
            <div className="bg-neutral-50 rounded-3xl p-10 text-center border border-neutral-200 shadow-xs my-6 flex flex-col items-center">
              <div className="w-16 h-16 bg-white border border-neutral-200 text-neutral-400 rounded-full flex items-center justify-center mb-3">
                <Power className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-black text-neutral-900">You are currently Offline</h3>
              <p className="text-xs text-neutral-500 mt-1 max-w-xs mb-5">
                Switch to Online above to receive live nearby {CATEGORY_DISPLAY_NAMES[driverVehicleType]} requests.
              </p>
              <button
                type="button"
                onClick={() => setDriverOnline(true)}
                className="bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs px-6 py-3 rounded-2xl shadow-sm transition transform active:scale-95"
              >
                Go Online Now
              </button>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-3 px-1">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <h3 className="text-sm font-extrabold text-neutral-900">
                    Live Nearby {CATEGORY_DISPLAY_NAMES[driverVehicleType]} Requests ({filteredDriverRides.length})
                  </h3>
                </div>
                <span className="text-xs text-neutral-500 font-medium">Sorted by distance</span>
              </div>

              {filteredDriverRides.length === 0 ? (
                <div className="bg-neutral-50 rounded-3xl p-10 text-center border border-neutral-200 shadow-xs flex flex-col items-center justify-center my-2">
                  <div className="w-14 h-14 bg-amber-50 border border-amber-200 text-neutral-800 rounded-full flex items-center justify-center mx-auto mb-3 shadow-xs">
                    <Car className="w-7 h-7 stroke-[2.5]" />
                  </div>
                  <h4 className="font-extrabold text-sm text-neutral-900">
                    No ride requests nearby
                  </h4>
                  <p className="text-xs text-neutral-500 mt-1 max-w-xs">
                    Stay online, requests will appear here
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredDriverRides.map((ride, idx) => (
                    <DriverRideCard key={`${ride.id || 'driver_ride'}_${idx}`} ride={ride} />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      <DriverEarningsModal isOpen={isEarningsOpen} onClose={() => setEarningsOpen(false)} />
      <DriverVerificationModal />
    </div>
  );
};


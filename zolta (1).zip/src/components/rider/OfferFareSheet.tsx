import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LocationPoint, RideCategory, DriverGenderPreference } from '../../types';
import { calculateDistanceKm, calculateSuggestedFare, calculateDurationMins } from '../../services/geoService';
import { Minus, Plus, MessageSquare, CreditCard, Banknote, Wallet, Users, ArrowLeft, Zap, Info, ShieldCheck, UserCheck } from 'lucide-react';
import { GenderChoiceModal } from './GenderChoiceModal';

interface OfferFareSheetProps {
  pickup: LocationPoint;
  dropoff: LocationPoint;
  category: RideCategory;
  onBack: () => void;
  onRequestRide: (params: {
    pickup: LocationPoint;
    dropoff: LocationPoint;
    category: RideCategory;
    offeredFare: number;
    suggestedFare: number;
    comments: string;
    passengerCount: number;
    paymentMethod: 'cash' | 'card' | 'payshap';
  }) => void;
}

export const OfferFareSheet: React.FC<OfferFareSheetProps> = ({
  pickup,
  dropoff,
  category,
  onBack,
  onRequestRide,
}) => {
  const { user, setGenderModalOpen, isGenderModalOpen } = useApp();
  const [selectedGender, setSelectedGender] = useState<DriverGenderPreference>(
    user.ridePreferences?.driverPreference || 'any'
  );
  const distanceKm = calculateDistanceKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
  const durationMins = calculateDurationMins(distanceKm);
  const suggested = calculateSuggestedFare(distanceKm, category);

  const [fare, setFare] = useState(suggested);
  const [passengers, setPassengers] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'payshap'>('cash');
  const [comment, setComment] = useState('');

  const quickComments = ['Have luggage 🧳', 'Need change 💵', 'Waiting at gate 🏨', 'Fragile load 📦'];

  const handleIncrement = (amount: number) => {
    setFare((prev) => Math.min(300, Math.max(30, prev + amount)));
  };

  const handleFindDriver = () => {
    onRequestRide({
      pickup,
      dropoff,
      category,
      offeredFare: fare,
      suggestedFare: suggested,
      comments: comment,
      passengerCount: passengers,
      paymentMethod,
    });
  };

  return (
    <div id="offer-fare-sheet" className="bg-neutral-950 text-white rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 border-t sm:border border-neutral-800 max-h-[88vh] overflow-y-auto">
      {/* Top Header with Back */}
      <div className="flex items-center justify-between mb-3">
        <button
          type="button"
          id="btn-back-to-whereto"
          onClick={onBack}
          className="p-2 -ml-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-full transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h4 className="font-extrabold text-sm text-white">Offer Your Fare</h4>
          <p className="text-[11px] text-neutral-400">{distanceKm} km • ~{durationMins} min</p>
        </div>
        <div className="w-8" />
      </div>

      {/* Signature ZOLTA Price Counter */}
      <div className="bg-black border-2 border-[#FFD60A] rounded-3xl p-5 text-center mb-4 relative overflow-hidden zolta-shield-glow">
        <span className="text-xs font-bold text-[#FFD60A] uppercase tracking-wider block mb-1">
          Your Offered Price (ZAR)
        </span>

        {/* Big Amount */}
        <div className="flex items-center justify-center gap-4 my-2">
          <button
            type="button"
            id="btn-fare-minus"
            onClick={() => handleIncrement(-10)}
            className="w-12 h-12 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-white font-black text-xl shadow-md border border-neutral-700 flex items-center justify-center transition active:scale-90"
          >
            <Minus className="w-5 h-5" />
          </button>

          <div className="text-4xl sm:text-5xl font-black text-white font-mono tracking-tight">
            R {fare}
          </div>

          <button
            type="button"
            id="btn-fare-plus"
            onClick={() => handleIncrement(10)}
            className="w-12 h-12 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-white font-black text-xl shadow-md border border-neutral-700 flex items-center justify-center transition active:scale-90"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Increment Chips */}
        <div className="flex justify-center gap-2 mt-3">
          {[3, 5, 10].map((inc) => (
            <button
              key={inc}
              type="button"
              id={`btn-inc-${inc}`}
              onClick={() => handleIncrement(inc)}
              className="bg-neutral-900 hover:bg-neutral-800 text-[#FFD60A] text-xs font-black px-3 py-1 rounded-full border border-[#FFD60A]/40 shadow-sm transition"
            >
              +R {inc}
            </button>
          ))}
        </div>

        {/* Suggested price guide */}
        <div className="mt-3 flex items-center justify-center gap-1.5 text-[11px] font-semibold text-neutral-400">
          <Info className="w-3.5 h-3.5 text-[#FFD60A]" />
          <span>Recommended fare in Johannesburg is <strong className="text-white">R {suggested}</strong></span>
        </div>
      </div>

      {/* Gender Choice & Safety Strip */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {/* Gender Preference Button */}
        <button
          type="button"
          id="btn-open-gender-choice"
          onClick={() => setGenderModalOpen(true)}
          className="bg-neutral-900 hover:bg-neutral-800 p-3 rounded-2xl border border-neutral-800 flex items-center justify-between text-left transition"
        >
          <div>
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Driver Gender</span>
            <span className="text-xs font-black text-white flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-[#FFD60A]" />
              {selectedGender === 'female' ? 'Women Only 👩' : selectedGender === 'male' ? 'Male Drivers' : 'Any Gender'}
            </span>
          </div>
          <span className="text-[9px] font-bold bg-neutral-800 text-[#FFD60A] px-2 py-0.5 rounded-full">
            Filter
          </span>
        </button>

        {/* Safety Protection Pill */}
        <div className="bg-neutral-900 p-3 rounded-2xl border border-neutral-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Driver Safety</span>
            <span className="text-xs font-black text-[#FFD60A] flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Only</span>
            </span>
          </div>
          <span className="text-[9px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded-full">
            100%
          </span>
        </div>
      </div>

      {/* Payment Method & Passengers */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Payment */}
        <div className="bg-neutral-900 p-3 rounded-2xl border border-neutral-800">
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Payment Method</span>
          <div className="flex gap-1">
            <button
              type="button"
              id="pay-method-cash"
              onClick={() => setPaymentMethod('cash')}
              className={`flex-1 py-1.5 px-1 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition ${
                paymentMethod === 'cash' ? 'bg-[#FFD60A] text-black font-black' : 'bg-black text-neutral-300 border border-neutral-800'
              }`}
            >
              <Banknote className="w-3 h-3" />
              <span>Cash</span>
            </button>
            <button
              type="button"
              id="pay-method-card"
              onClick={() => setPaymentMethod('card')}
              className={`flex-1 py-1.5 px-1 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition ${
                paymentMethod === 'card' ? 'bg-[#FFD60A] text-black font-black' : 'bg-black text-neutral-300 border border-neutral-800'
              }`}
            >
              <CreditCard className="w-3 h-3" />
              <span>Card</span>
            </button>
            <button
              type="button"
              id="pay-method-payshap"
              onClick={() => setPaymentMethod('payshap')}
              className={`flex-1 py-1.5 px-1 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition ${
                paymentMethod === 'payshap' ? 'bg-[#FFD60A] text-black font-black' : 'bg-black text-neutral-300 border border-neutral-800'
              }`}
            >
              <Zap className="w-3 h-3" />
              <span>PayShap</span>
            </button>
          </div>
        </div>

        {/* Passenger Count */}
        <div className="bg-neutral-900 p-3 rounded-2xl border border-neutral-800">
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Passengers</span>
          <div className="flex justify-between gap-1">
            {[1, 2, 3, 4].map((num) => (
              <button
                key={num}
                type="button"
                id={`btn-passengers-${num}`}
                onClick={() => setPassengers(num)}
                className={`w-8 h-7 rounded-xl text-xs font-bold flex items-center justify-center transition ${
                  passengers === num ? 'bg-[#FFD60A] text-black font-black' : 'bg-black text-neutral-400 border border-neutral-800'
                }`}
              >
                {num}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Driver Comment / Options */}
      <div className="mb-5">
        <div className="flex items-center gap-1.5 mb-2">
          <MessageSquare className="w-3.5 h-3.5 text-neutral-400" />
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Note for Driver</span>
        </div>
        <input
          type="text"
          id="input-rider-comment"
          placeholder="e.g. Near main gate, 1 luggage, waiting at reception..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="w-full bg-neutral-900 border border-neutral-800 rounded-2xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#FFD60A] focus:ring-1 focus:ring-[#FFD60A] mb-2"
        />

        {/* Quick Comment Chips */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {quickComments.map((qc, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setComment(qc)}
              className="bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-[11px] font-semibold px-2.5 py-1 rounded-full whitespace-nowrap border border-neutral-800 transition"
            >
              {qc}
            </button>
          ))}
        </div>
      </div>

      {/* Find Driver Main ZOLTA Button */}
      <button
        type="button"
        id="btn-find-driver"
        onClick={handleFindDriver}
        className="w-full bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-base py-4 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-xl transition transform active:scale-[0.98]"
      >
        <Zap className="w-5 h-5 fill-black" />
        <span>Offer Fare R {fare} • Find Drivers</span>
      </button>

      {/* Gender Choice Modal Mount */}
      {isGenderModalOpen && (
        <GenderChoiceModal
          selectedGender={selectedGender}
          onSelectGender={(g) => setSelectedGender(g)}
          onClose={() => setGenderModalOpen(false)}
        />
      )}
    </div>
  );
};


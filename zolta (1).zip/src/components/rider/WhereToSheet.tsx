import React, { useState } from 'react';
import { LocationPoint, RideCategory } from '../../types';
import { POPULAR_LOCATIONS, CATEGORIES_DATA, searchPlaces, calculateDistanceKm, calculateSuggestedFare } from '../../services/geoService';
import { MapPin, Navigation, Search, Users, Car, ChevronRight, Clock, ShieldCheck, Bike, Truck, Package } from 'lucide-react';

interface WhereToSheetProps {
  pickup: LocationPoint;
  dropoff?: LocationPoint;
  category: RideCategory;
  onSelectPickup: (loc: LocationPoint) => void;
  onSelectDropoff: (loc: LocationPoint) => void;
  onSelectCategory: (cat: RideCategory) => void;
  onProceedToOffer: () => void;
}

export const WhereToSheet: React.FC<WhereToSheetProps> = ({
  pickup,
  dropoff,
  category,
  onSelectPickup,
  onSelectDropoff,
  onSelectCategory,
  onProceedToOffer,
}) => {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationPoint[]>(POPULAR_LOCATIONS);
  const [isSearchingDropoff, setIsSearchingDropoff] = useState(false);

  const handleSearchChange = async (text: string) => {
    setQuery(text);
    if (text.trim().length > 0) {
      const res = await searchPlaces(text);
      setSearchResults(res);
    } else {
      setSearchResults(POPULAR_LOCATIONS);
    }
  };

  const handleSelectPlace = (place: LocationPoint) => {
    onSelectDropoff(place);
    setIsSearchingDropoff(false);
    setQuery('');
  };

  const selectedCatInfo = CATEGORIES_DATA.find((c) => c.id === category) || CATEGORIES_DATA[0];

  return (
    <div id="where-to-sheet" className="bg-neutral-950 text-white rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 border-t sm:border border-neutral-800 max-h-[85vh] overflow-y-auto">
      {/* Grab Handle */}
      <div className="w-12 h-1.5 bg-neutral-700 rounded-full mx-auto mb-4" />

      {/* Origin & Destination Cards with 16px spacing */}
      <div className="my-4 space-y-4">
        {/* Pickup Card */}
        <div className="w-full min-h-[80px] bg-white text-neutral-900 p-4 rounded-[16px] border-2 border-[#E0E0E0] shadow-md flex items-center gap-3.5">
          <div className="w-4 h-4 rounded-full bg-[#10B981] ring-4 ring-emerald-100 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-0.5">Pickup Location</span>
            <input
              type="text"
              id="input-pickup-address"
              value={pickup?.shortName || pickup?.address || ''}
              readOnly
              className="w-full bg-transparent font-bold text-[18px] text-neutral-900 outline-none truncate leading-tight"
            />
          </div>
          <MapPin className="w-6 h-6 text-emerald-600 flex-shrink-0" />
        </div>

        {/* Dropoff Card */}
        <div className="w-full min-h-[80px] bg-white text-neutral-900 p-4 rounded-[16px] border-2 border-[#E0E0E0] shadow-md flex items-center gap-3.5">
          <div className="w-4 h-4 rounded-full bg-[#EF4444] ring-4 ring-red-100 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-0.5">Where to?</span>
            <input
              type="text"
              id="input-dropoff-search"
              placeholder="Search destination, mall or landmark..."
              value={isSearchingDropoff ? query : dropoff ? (dropoff?.shortName || dropoff?.address || '') : ''}
              onFocus={() => setIsSearchingDropoff(true)}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full bg-transparent font-bold text-[18px] text-neutral-900 outline-none placeholder:text-neutral-400 placeholder:font-normal truncate leading-tight"
            />
          </div>
          {isSearchingDropoff ? (
            <button
              type="button"
              onClick={() => {
                setIsSearchingDropoff(false);
                setQuery('');
              }}
              className="text-xs font-bold bg-[#FFD60A] text-black px-3 py-1.5 rounded-xl hover:bg-yellow-400"
            >
              Done
            </button>
          ) : (
            <Search className="w-6 h-6 text-neutral-400" />
          )}
        </div>
      </div>

      {/* Autocomplete Suggestions if active */}
      {isSearchingDropoff && (
        <div className="mb-4 bg-neutral-900 rounded-2xl p-2 border border-neutral-800 max-h-56 overflow-y-auto">
          <span className="text-[11px] font-bold text-neutral-400 px-3 py-1 block uppercase">Suggested Places</span>
          {searchResults.map((place, idx) => (
            <button
              key={idx}
              type="button"
              id={`place-result-${idx}`}
              onClick={() => handleSelectPlace(place)}
              className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-neutral-800 flex items-start gap-2.5 transition"
            >
              <MapPin className="w-4 h-4 text-[#FFD60A] mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-bold text-xs text-white truncate">{place?.shortName || (place?.address ? place.address.split(',')[0] : '') || 'Place'}</p>
                <p className="text-[11px] text-neutral-400 truncate">{place?.address || ''}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Ride Category Selector - 6 ZOLTA Types */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block">
            Select Vehicle Type
          </span>
          <span className="text-[10px] text-[#FFD60A] font-mono font-bold">6 Options</span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 sm:gap-2">
          {CATEGORIES_DATA.map((cat) => {
            const isSelected = category === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                id={`cat-select-${cat.id}`}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex flex-col items-center text-center p-2 rounded-2xl border transition relative ${
                  isSelected
                    ? 'bg-neutral-900 border-[#FFD60A] ring-2 ring-[#FFD60A] shadow-md'
                    : 'bg-neutral-900/60 border-neutral-800 hover:bg-neutral-800 text-neutral-300'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-sm my-1 ${
                  isSelected ? 'bg-[#FFD60A] text-black' : 'bg-neutral-800 text-neutral-300'
                }`}>
                  {cat.id === 'scooter' ? (
                    <Bike className="w-4 h-4" />
                  ) : cat.id === 'xl' ? (
                    <Users className="w-4 h-4" />
                  ) : cat.id === 'bakkie' ? (
                    <Truck className="w-4 h-4" />
                  ) : cat.id === 'courier' ? (
                    <Package className="w-4 h-4" />
                  ) : (
                    <Car className="w-4 h-4" />
                  )}
                </div>
                <span className={`font-black text-[10px] sm:text-[11px] leading-tight truncate w-full ${
                  isSelected ? 'text-[#FFD60A]' : 'text-white'
                }`}>
                  {cat.name}
                </span>
                <span className="text-[9px] text-neutral-400 font-medium truncate w-full">
                  {cat.capacity}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Vehicle Info Note */}
      <div className="bg-neutral-900 p-3 rounded-2xl border border-neutral-800 flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-1.5">
            <h5 className="font-bold text-xs text-white">{selectedCatInfo.name}</h5>
            <span className="text-[10px] text-neutral-400 font-mono">• {selectedCatInfo.subtitle}</span>
          </div>
          <p className="text-[11px] text-neutral-400 mt-0.5">{selectedCatInfo.carExample}</p>
        </div>
        <span className="text-[10px] font-bold bg-neutral-800 border border-neutral-700 px-2.5 py-1 rounded-full text-[#FFD60A]">
          {selectedCatInfo.capacity}
        </span>
      </div>

      {/* Proceed Button */}
      <button
        type="button"
        id="btn-proceed-to-fare"
        disabled={!dropoff}
        onClick={onProceedToOffer}
        className="w-full bg-[#FFD60A] hover:bg-yellow-400 disabled:opacity-30 disabled:cursor-not-allowed text-black font-black text-sm py-4 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-xl transition transform active:scale-[0.98]"
      >
        <span>Offer Your Fare</span>
        <ChevronRight className="w-4 h-4 stroke-[3]" />
      </button>
    </div>
  );
};


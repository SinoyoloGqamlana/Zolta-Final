import React from 'react';
import { RideCategory } from '../../types';

import rideImg from '../../assets/images/ride_vw_polo_1787995390609.jpg';
import comfortImg from '../../assets/images/comfort_corolla_quest_1787995404262.jpg';
import xlImg from '../../assets/images/xl_orange_triber_1787995419231.jpg';
import bakkieImg from '../../assets/images/bakkie_red_hilux_1787995431740.jpg';
import scooterImg from '../../assets/images/scooter_red_vespa_1787995448235.jpg';
import courierImg from '../../assets/images/courier_white_hatch_1787995462509.jpg';

interface VehicleIconProps {
  category: RideCategory;
  className?: string;
  isSelected?: boolean;
}

export const VEHICLE_DESCRIPTIONS: Record<RideCategory, string> = {
  ride: 'White VW Polo Hatchback',
  rider: 'White VW Polo Hatchback',
  comfort: 'Silver Toyota Corolla Quest Sedan',
  xl: 'Orange Renault Triber 7-Seater',
  bakkie: 'Red Toyota Hilux Double Cab Bakkie',
  scooter: 'Red Vespa Scooter',
  courier: 'White Mazda Delivery Hatch',
};

const CATEGORY_IMAGES: Record<RideCategory, string> = {
  ride: rideImg,
  rider: rideImg,
  comfort: comfortImg,
  xl: xlImg,
  bakkie: bakkieImg,
  scooter: scooterImg,
  courier: courierImg,
};

export const VehicleGraphic: React.FC<VehicleIconProps> = ({
  category,
  className = 'w-12 h-12',
  isSelected = false,
}) => {
  const imgSrc = CATEGORY_IMAGES[category] || rideImg;
  const description = VEHICLE_DESCRIPTIONS[category] || 'Vehicle';

  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      <img
        src={imgSrc}
        alt={description}
        className="w-[48px] h-[48px] min-w-[48px] min-h-[48px] object-contain rounded-md mix-blend-multiply transition-transform duration-150 active:scale-95"
        style={{ mixBlendMode: 'multiply' }}
        loading="eager"
      />
    </div>
  );
};

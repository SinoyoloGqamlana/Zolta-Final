import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  AppMode,
  AppView,
  UserProfile,
  RideRequest,
  Bid,
  ChatMessage,
  WalletTransaction,
  EmergencyContact,
  LocationPoint,
  RideCategory,
  RideStatus,
  DriverGenderPreference,
  RidePreferences,
} from '../types';
import { normalizeCategory, getDriverVehicleType, matchCategoryToVehicle } from '../services/categoryService';
import { POPULAR_LOCATIONS, calculateDistanceKm, calculateDurationMins, calculateSuggestedFare, generateRoutePoints } from '../services/geoService';
import { audioService } from '../services/audioService';
import { db, rdb, auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, setDoc, getDoc, collection, addDoc, updateDoc } from 'firebase/firestore';
import { ref, set, update } from 'firebase/database';
import {
  createRealtimeRideRequest,
  driverAcceptRideInFirestore,
  submitDriverOfferInFirestore,
  subscribeToAvailableRides,
  subscribeToRideRequest,
  recordPaystackSuccessInFirestore,
  updateUserLocationInFirestore,
  saveUserPreferencesInFirestore,
  updateRidePreferencesInFirestore,
  syncUserWalletAndTrips,
  subscribeUserTripsAndWallet,
  subscribeDriverDailyEarnings,
} from '../services/firestoreService';

const STORAGE_KEY_USER = 'zolta_user_profile_v2';
const STORAGE_KEY_RIDES = 'zolta_rides_history_v2';
const STORAGE_KEY_WALLET = 'zolta_wallet_txs_v2';
const STORAGE_KEY_CONTACTS = 'zolta_emergency_contacts_v2';

export const DEFAULT_RIDE_PREFERENCES: RidePreferences = {
  driverPreference: 'any',
  language: 'Xhosa',
  music: 'Amapiano',
  chatLevel: 'Chatty',
  stopAtSpaza: false,
  shareTripFamily: true,
  femaleDriverAtNight: true,
  avoidGravelRoads: false,
};

// Clean Initial ZOLTA User Profile
const DEFAULT_RIDER: UserProfile = {
  id: '',
  name: '',
  phone: '',
  email: '',
  avatar: '',
  rating: 5.0,
  totalTrips: 0,
  mode: 'rider',
  isDriverVerified: false,
  walletBalance: 0,
};

const DEFAULT_DRIVER_PROFILE: UserProfile = {
  id: '',
  name: '',
  phone: '',
  email: '',
  avatar: '',
  rating: 5.0,
  totalTrips: 0,
  mode: 'driver',
  isDriverVerified: false,
  walletBalance: 0,
  gender: 'male',
  driverDetails: {
    carModel: 'Toyota Starlet',
    carColor: 'Silver',
    licensePlate: 'GP 101 ZL',
    carType: 'rider',
    earningsToday: 0,
    tripsToday: 0,
    acceptanceRate: 100,
    rating: 5.0,
    gender: 'male',
    documents: {
      licenseUploaded: false,
      rcUploaded: false,
      insuranceUploaded: false,
      photoUploaded: false,
    },
  },
};

// Initial Driver pool removed - only real Firestore drivers will offer/accept
const SIMULATED_DRIVERS: any[] = [];

interface AppContextType {
  user: UserProfile;
  mode: AppMode;
  currentView: AppView;
  showSplash: boolean;
  showOnboarding: boolean;
  isSidebarOpen: boolean;
  isAuthModalOpen: boolean;
  isVoiceCallModalOpen: boolean;
  isChatModalOpen: boolean;
  isSafetyModalOpen: boolean;
  isSosModalOpen: boolean;
  isGenderModalOpen: boolean;
  isPreferencesModalOpen: boolean;
  isReceiptModalOpen: boolean;
  isRatingModalOpen: boolean;
  isVerificationModalOpen: boolean;
  activeRide: RideRequest | null;
  ridesHistory: RideRequest[];
  driverFeedRides: RideRequest[];
  chatMessages: ChatMessage[];
  walletTransactions: WalletTransaction[];
  emergencyContacts: EmergencyContact[];
  driverOnline: boolean;
  currentLocation: LocationPoint;
  voiceCallData: { active: boolean; targetName: string; targetRole: string; durationSec: number; isMuted: boolean; isSpeaker: boolean };
  fullMap: boolean;
  voiceListening: boolean;
  voiceTranscript: string;
  voiceEnabled: boolean;
  isAuthenticated: boolean;

  // Setters & UI controls
  finishSplash: () => void;
  finishOnboarding: () => void;
  setMode: (mode: AppMode) => void;
  setCurrentView: (view: AppView) => void;
  goBack: () => void;
  setSidebarOpen: (open: boolean) => void;
  setAuthModalOpen: (open: boolean) => void;
  setVoiceCallModalOpen: (open: boolean) => void;
  setChatModalOpen: (open: boolean) => void;
  setSafetyModalOpen: (open: boolean) => void;
  setSosModalOpen: (open: boolean) => void;
  setGenderModalOpen: (open: boolean) => void;
  setPreferencesModalOpen: (open: boolean) => void;
  setReceiptModalOpen: (open: boolean) => void;
  setRatingModalOpen: (open: boolean) => void;
  setVerificationModalOpen: (open: boolean) => void;
  setDriverOnline: (online: boolean) => void;
  setCurrentLocation: (loc: LocationPoint) => void;
  setFullMap: React.Dispatch<React.SetStateAction<boolean>>;
  toggleFullMap: () => void;
  setVoiceEnabled: (enabled: boolean) => void;
  toggleVoiceEnabled: () => void;
  speak: (text: string) => void;
  startVoiceSearch: (onResult?: (text: string) => void) => void;
  stopVoiceSearch: () => void;
  getRealGpsPosition: () => Promise<LocationPoint>;
  setAuthenticatedUser: (userProfile: UserProfile) => void;

  // Actions
  loginAsRider: () => void;
  loginAsDriver: () => void;
  logout: () => void;
  deleteUser: () => void;
  createRideRequest: (params: {
    pickup: LocationPoint;
    dropoff: LocationPoint;
    category: RideCategory;
    genderPreference?: DriverGenderPreference;
    offeredFare: number;
    suggestedFare: number;
    comments: string;
    passengerCount: number;
    paymentMethod: 'cash' | 'card' | 'wallet' | 'payshap';
  }) => void;
  cancelRideRequest: (reason?: string) => void;
  acceptDriverBid: (bidId: string) => void;
  rejectDriverBid: (bidId: string) => void;
  raiseRiderOffer: (extraAmount: number) => void;
  driverSubmitBid: (rideId: string, amount: number, message?: string) => void;
  driverAcceptDirect: (rideId: string) => void;
  driverUpdateStatus: (status: RideStatus) => void;
  submitTripRating: (rating: number, tip: number, tags: string[]) => void;
  sendChatMessage: (text: string) => void;
  topUpWallet: (amount: number) => void;
  addEmergencyContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  removeEmergencyContact: (id: string) => void;
  uploadDriverDocument: (docKey: 'licenseUploaded' | 'rcUploaded' | 'insuranceUploaded' | 'photoUploaded') => void;
  startVoiceCall: (targetName: string, targetRole: string) => void;
  endVoiceCall: () => void;
  toggleCallMute: () => void;
  toggleCallSpeaker: () => void;
  updateRidePreferences: (prefs: RidePreferences) => Promise<void>;
  setDriverVehicleType: (vehicleType: RideCategory) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const token = localStorage.getItem('zolta_auth_token');
      return !!token;
    } catch {
      return false;
    }
  });

  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_USER) || localStorage.getItem('zolta_user_profile');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_RIDER;
  });

  const [mode, setModeState] = useState<AppMode>(user.mode);
  const [currentView, setCurrentViewState] = useState<AppView>('home');
  const [viewHistory, setViewHistory] = useState<AppView[]>(['home']);

  const setCurrentView = useCallback((view: AppView) => {
    setCurrentViewState(view);
    setViewHistory((prev) => {
      if (view === 'home') return ['home'];
      if (prev[prev.length - 1] === view) return prev;
      return [...prev, view];
    });
  }, []);

  const goBack = useCallback(() => {
    setViewHistory((prev) => {
      if (prev.length <= 1) {
        setCurrentViewState('home');
        return ['home'];
      }
      const newHist = [...prev];
      newHist.pop();
      const prevView = newHist[newHist.length - 1] || 'home';
      setCurrentViewState(prevView);
      return newHist;
    });
  }, []);
  const [showSplash, setShowSplash] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [isVoiceCallModalOpen, setVoiceCallModalOpen] = useState(false);
  const [isChatModalOpen, setChatModalOpen] = useState(false);
  const [isSafetyModalOpen, setSafetyModalOpen] = useState(false);
  const [isSosModalOpen, setSosModalOpen] = useState(false);
  const [isGenderModalOpen, setGenderModalOpen] = useState(false);
  const [isPreferencesModalOpen, setPreferencesModalOpen] = useState(false);
  const [isReceiptModalOpen, setReceiptModalOpen] = useState(false);
  const [isRatingModalOpen, setRatingModalOpen] = useState(false);
  const [isVerificationModalOpen, setVerificationModalOpen] = useState(false);
  const [driverOnline, setDriverOnline] = useState(true);
  const [fullMap, setFullMap] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [voiceEnabled, setVoiceEnabledState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('voiceEnabled') === 'true';
    } catch {
      return false;
    }
  });

  const speak = useCallback((text: string) => {
    let voiceOn = false;
    try {
      voiceOn = localStorage.getItem('voiceEnabled') === 'true';
    } catch {}
    if (!voiceOn) return;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = 'en-ZA';
        u.rate = 0.9;
        window.speechSynthesis.speak(u);
      } catch (e) {
        console.warn('SpeechSynthesis error:', e);
      }
    }
  }, []);

  const setVoiceEnabled = useCallback((enabled: boolean) => {
    setVoiceEnabledState(enabled);
    try {
      localStorage.setItem('voiceEnabled', String(enabled));
    } catch {}
  }, []);

  const toggleVoiceEnabled = useCallback(() => {
    setVoiceEnabledState((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('voiceEnabled', String(next));
      } catch {}
      if (next) {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance('Voice guidance enabled');
          u.lang = 'en-ZA';
          u.rate = 0.9;
          window.speechSynthesis.speak(u);
        }
      } else {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
      }
      return next;
    });
  }, []);
  const [currentLocation, setCurrentLocation] = useState<LocationPoint>(() => {
    try {
      const savedLat = localStorage.getItem('zolta_user_lat');
      const savedLng = localStorage.getItem('zolta_user_lng');
      const savedAddress = localStorage.getItem('zolta_pickup_address');
      const savedShort = localStorage.getItem('zolta_pickup_shortname');
      if (savedLat && savedLng) {
        const parsedLat = parseFloat(savedLat);
        const parsedLng = parseFloat(savedLng);
        if (
          typeof parsedLat === 'number' && !isNaN(parsedLat) && isFinite(parsedLat) &&
          typeof parsedLng === 'number' && !isNaN(parsedLng) && isFinite(parsedLng)
        ) {
          return {
            id: 'saved_gps_pickup',
            name: savedShort || 'Your location',
            shortName: savedShort || 'Your location',
            address: savedAddress || 'Your location',
            lat: parsedLat,
            lng: parsedLng,
          };
        }
      }
    } catch {}
    return POPULAR_LOCATIONS[0];
  });
  const [activeRide, setActiveRide] = useState<RideRequest | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  const toggleFullMap = useCallback(() => {
    setFullMap((prev) => !prev);
  }, []);

  const getRealGpsPosition = useCallback((): Promise<LocationPoint> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(currentLocation);
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position?.coords?.latitude;
          const lng = position?.coords?.longitude;

          if (typeof lat !== 'number' || isNaN(lat) || !isFinite(lat) || typeof lng !== 'number' || isNaN(lng) || !isFinite(lng)) {
            resolve(currentLocation);
            return;
          }

          try {
            localStorage.setItem('zolta_user_lat', String(lat));
            localStorage.setItem('zolta_user_lng', String(lng));
          } catch {}

          // Save lat/lng to Firebase zolta-45ce5 users/{uid}
          if (user?.id) {
            updateUserLocationInFirestore(user.id, lat, lng).catch(() => {});
          }

          try {
            const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
            const data = await res.json();
            const road =
              data.address?.road ||
              data.address?.pedestrian ||
              data.address?.suburb ||
              data.address?.neighbourhood ||
              data.address?.city ||
              data.display_name?.split(',')[0]?.trim() ||
              'Current Location';

            const fullAddress = data.display_name || `${road}, ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
            const cardLabel = `Your location • ${road}`;

            try {
              localStorage.setItem('zolta_pickup_address', fullAddress);
              localStorage.setItem('zolta_pickup_shortname', cardLabel);
              localStorage.setItem('zolta_pickup_road', road);
            } catch {}

            const newLoc: LocationPoint = {
              id: 'gps_current',
              name: cardLabel,
              shortName: cardLabel,
              address: fullAddress,
              lat,
              lng,
            };
            setCurrentLocation(newLoc);
            speak('Pickup set to your location');
            resolve(newLoc);
          } catch (err) {
            console.warn('Nominatim reverse geocode error:', err);
            const cardLabel = 'Your location';
            const fallbackLoc: LocationPoint = {
              id: 'gps_current',
              name: cardLabel,
              shortName: cardLabel,
              address: `Your location (${lat.toFixed(5)}, ${lng.toFixed(5)})`,
              lat,
              lng,
            };
            setCurrentLocation(fallbackLoc);
            speak('Pickup set to your location');
            resolve(fallbackLoc);
          }
        },
        () => {
          resolve(currentLocation);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  }, [currentLocation, user]);

  // Auto-detect GPS location on app open using OpenStreetMap Nominatim
  useEffect(() => {
    if (!navigator.geolocation) return;

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position?.coords?.latitude;
        const lng = position?.coords?.longitude;

        if (typeof lat !== 'number' || isNaN(lat) || !isFinite(lat) || typeof lng !== 'number' || isNaN(lng) || !isFinite(lng)) {
          return;
        }

        try {
          localStorage.setItem('zolta_user_lat', String(lat));
          localStorage.setItem('zolta_user_lng', String(lng));
        } catch {}

        if (user?.id) {
          updateUserLocationInFirestore(user.id, lat, lng).catch(() => {});
        }

        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
          const data = await res.json();
          const road =
            data.address?.road ||
            data.address?.pedestrian ||
            data.address?.suburb ||
            data.address?.neighbourhood ||
            data.address?.city ||
            data.display_name?.split(',')[0]?.trim() ||
            'Current Location';

          const fullAddress = data.display_name || `${road}, ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
          const cardLabel = `Your location • ${road}`;

          try {
            localStorage.setItem('zolta_pickup_address', fullAddress);
            localStorage.setItem('zolta_pickup_shortname', cardLabel);
            localStorage.setItem('zolta_pickup_road', road);
          } catch {}

          const gpsLoc: LocationPoint = {
            id: 'gps_current',
            name: cardLabel,
            shortName: cardLabel,
            address: fullAddress,
            lat,
            lng,
          };
          setCurrentLocation(gpsLoc);
        } catch (err) {
          console.warn('Nominatim startup reverse geocode error:', err);
          const cardLabel = 'Your location';
          const fallbackLoc: LocationPoint = {
            id: 'gps_current',
            name: cardLabel,
            shortName: cardLabel,
            address: `Your location (${lat.toFixed(5)}, ${lng.toFixed(5)})`,
            lat,
            lng,
          };
          setCurrentLocation(fallbackLoc);
        }
      },
      (err) => {
        console.warn('Geolocation auto-detect failed on startup:', err);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }, [user?.id]);

  const startVoiceSearch = useCallback((onResult?: (text: string) => void) => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const manualDest = prompt('Voice recognition not supported in this browser. Please enter destination:');
      if (manualDest && onResult) {
        onResult(manualDest);
      }
      return;
    }

    try {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.abort();
      }
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-ZA';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      setVoiceListening(true);
      setVoiceTranscript('Listening... Speak destination clearly');

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setVoiceTranscript(transcript);
        setVoiceListening(false);
        if (onResult) {
          onResult(transcript);
        }
      };

      recognition.onerror = () => {
        setVoiceListening(false);
        setVoiceTranscript('');
      };

      recognition.onend = () => {
        setVoiceListening(false);
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch {
      setVoiceListening(false);
    }
  }, []);

  const stopVoiceSearch = useCallback(() => {
    if (speechRecognitionRef.current) {
      try { speechRecognitionRef.current.abort(); } catch {}
    }
    setVoiceListening(false);
  }, []);

  const finishSplash = useCallback(() => {
    setShowSplash(false);
    setShowOnboarding(false);
  }, []);

  const finishOnboarding = useCallback(() => {
    setShowOnboarding(false);
  }, []);

  const [ridesHistory, setRidesHistory] = useState<RideRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_RIDES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const seen = new Set<string>();
          return parsed.filter((r) => {
            if (!r || !r.id || seen.has(r.id)) return false;
            seen.add(r.id);
            return true;
          });
        }
      } catch {}
    }
    return [];
  });

  const [driverFeedRides, setDriverFeedRides] = useState<RideRequest[]>([]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_0',
      rideId: 'system',
      senderId: 'system',
      senderName: 'ZOLTA Safety Assistant',
      senderRole: 'support',
      text: 'Welcome to ZOLTA. All rides and drivers are verified in South Africa for your safety.',
      timestamp: Date.now(),
    },
  ]);

  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_WALLET);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_CONTACTS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'ec_1',
        name: 'Thandi Ndlovu',
        phone: '+27 82 777 1234',
        relation: 'Sister',
      },
      {
        id: 'ec_2',
        name: 'Kabelo Dube',
        phone: '+27 71 888 4321',
        relation: 'Friend',
      },
    ];
  });

  const [voiceCallData, setVoiceCallData] = useState({
    active: false,
    targetName: '',
    targetRole: '',
    durationSec: 0,
    isMuted: false,
    isSpeaker: true,
  });

  const tripSimulationTimerRef = useRef<NodeJS.Timeout | null>(null);
  const callTimerRef = useRef<NodeJS.Timeout | null>(null);
  const unsubTripsRef = useRef<(() => void) | null>(null);
  const unsubDriverStatsRef = useRef<(() => void) | null>(null);

  // Sync to LocalStorage (only local, preventing circular Firestore triggers)
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_RIDES, JSON.stringify(ridesHistory));
  }, [ridesHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_WALLET, JSON.stringify(walletTransactions));
  }, [walletTransactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_CONTACTS, JSON.stringify(emergencyContacts));
  }, [emergencyContacts]);

  // Firebase Auth listener and user trips/wallet subscriber
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (fbUser) => {
      // Clean up any existing subscriptions
      if (unsubTripsRef.current) {
        unsubTripsRef.current();
        unsubTripsRef.current = null;
      }
      if (unsubDriverStatsRef.current) {
        unsubDriverStatsRef.current();
        unsubDriverStatsRef.current = null;
      }

      if (fbUser) {
        setIsAuthenticated(true);
        const uid = fbUser.uid;
        const email = fbUser.email || '';
        const name = fbUser.displayName || (email ? email.split('@')[0] : 'User');
        const avatar = fbUser.photoURL || '';

        setUser((prev) => ({
          ...prev,
          id: uid,
          name: name,
          email: email,
          avatar: avatar,
        }));

        unsubTripsRef.current = subscribeUserTripsAndWallet(uid, ({ tripsCount, walletBalance, userTrips }) => {
          setUser((prev) => {
            if (prev.totalTrips === tripsCount && prev.walletBalance === walletBalance) {
              return prev;
            }
            return {
              ...prev,
              totalTrips: tripsCount,
              walletBalance: walletBalance,
            };
          });
          if (userTrips && userTrips.length > 0) {
            setRidesHistory(userTrips);
          }
        });

        unsubDriverStatsRef.current = subscribeDriverDailyEarnings(uid, ({ earningsToday, tripsToday, totalEarnings, totalTrips }) => {
          setUser((prev) => {
            const hasChanged = 
              (prev.mode === 'driver' && prev.totalTrips !== totalTrips) ||
              prev.driverDetails?.earningsToday !== earningsToday ||
              prev.driverDetails?.tripsToday !== tripsToday;
            if (!hasChanged) return prev;

            return {
              ...prev,
              totalTrips: prev.mode === 'driver' ? totalTrips : prev.totalTrips,
              driverDetails: prev.driverDetails
                ? {
                    ...prev.driverDetails,
                    earningsToday: earningsToday,
                    tripsToday: tripsToday,
                  }
                : undefined,
            };
          });
        });
      } else {
        const storedToken = localStorage.getItem('zolta_auth_token');
        const storedUser = localStorage.getItem('zolta_user_profile');
        if (storedToken && storedUser) {
          try {
            const parsed = JSON.parse(storedUser);
            if (parsed && parsed.id) {
              setIsAuthenticated(true);
              setUser(parsed);
              return;
            }
          } catch {}
        }
        setIsAuthenticated(false);
        setUser(DEFAULT_RIDER);
        setRidesHistory([]);
      }
    });

    return () => {
      unsubAuth();
      if (unsubTripsRef.current) {
        unsubTripsRef.current();
        unsubTripsRef.current = null;
      }
      if (unsubDriverStatsRef.current) {
        unsubDriverStatsRef.current();
        unsubDriverStatsRef.current = null;
      }
    };
  }, []);

  // Real-time listener for active ride updates from Firestore
  useEffect(() => {
    if (!activeRide?.id) return;
    const unsub = subscribeToRideRequest(activeRide.id, (firestoreData) => {
      if (!firestoreData) return;
      setActiveRide((current) => {
        if (!current || current.id !== activeRide.id) return current;
        // Update status and acceptedDriver if Firestore data has driver acceptance
        let updatedStatus = current.status;
        if (firestoreData.status && firestoreData.status !== current.status) {
          updatedStatus = firestoreData.status as RideStatus;
        }

        let acceptedDriver = current.acceptedDriver;
        if (firestoreData.acceptedDriver) {
          acceptedDriver = firestoreData.acceptedDriver;
        }

        return {
          ...current,
          status: updatedStatus,
          acceptedDriver,
        };
      });
    });

    return () => unsub();
  }, [activeRide?.id]);

  // Track known ride IDs for notifying driver on new matching requests
  const knownRideIdsRef = useRef<Set<string>>(new Set());

  // Live real-time Firestore synchronization for Driver Feed
  useEffect(() => {
    const unsub = subscribeToAvailableRides((liveRides) => {
      const rides = liveRides || [];
      setDriverFeedRides(rides);

      // Check for newly arrived rides matching driver vehicle type
      if (mode === 'driver' && driverOnline) {
        const driverVehType = getDriverVehicleType(user);
        let hasNewMatchingRide = false;

        rides.forEach((ride) => {
          if (ride && ride.id && !knownRideIdsRef.current.has(ride.id)) {
            knownRideIdsRef.current.add(ride.id);
            if (matchCategoryToVehicle(ride.category, driverVehType)) {
              hasNewMatchingRide = true;
            }
          }
        });

        if (hasNewMatchingRide) {
          audioService.playIncomingRequestAlert();
          if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification('ZOLTA Ride Alert', {
                body: `New ${driverVehType.toUpperCase()} ride request available!`,
                icon: '/icon-192.png',
              });
            } catch {}
          }
        }
      } else {
        // Update known IDs without alerting when offline or in rider mode
        rides.forEach((r) => {
          if (r?.id) knownRideIdsRef.current.add(r.id);
        });
      }
    });

    return () => unsub();
  }, [mode, driverOnline, user]);

  // Voice call duration timer
  useEffect(() => {
    if (voiceCallData.active) {
      callTimerRef.current = setInterval(() => {
        setVoiceCallData((prev) => ({ ...prev, durationSec: prev.durationSec + 1 }));
      }, 1000);
    } else {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    }
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [voiceCallData.active]);

  // Mode switcher
  const setMode = useCallback((newMode: AppMode) => {
    setModeState(newMode);
    setUser((prev) => ({ ...prev, mode: newMode }));
  }, []);

  // Set authenticated user
  const setAuthenticatedUser = useCallback((userProfile: UserProfile) => {
    setUser(userProfile);
    setModeState(userProfile.mode || 'rider');
    setIsAuthenticated(true);
    setAuthModalOpen(false);
    try {
      localStorage.setItem('zolta_auth_token', 'zolta_jwt_' + userProfile.id);
      localStorage.setItem('zolta_user_profile', JSON.stringify(userProfile));
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(userProfile));
    } catch {}
  }, []);

  const loginAsRider = useCallback(() => {
    setUser(DEFAULT_RIDER);
    setModeState('rider');
    setIsAuthenticated(true);
    setAuthModalOpen(false);
    try {
      localStorage.setItem('zolta_auth_token', 'zolta_jwt_rider_demo');
      localStorage.setItem('zolta_user_profile', JSON.stringify(DEFAULT_RIDER));
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(DEFAULT_RIDER));
    } catch {}
  }, []);

  const loginAsDriver = useCallback(() => {
    setUser(DEFAULT_DRIVER_PROFILE);
    setModeState('driver');
    setIsAuthenticated(true);
    setAuthModalOpen(false);
    try {
      localStorage.setItem('zolta_auth_token', 'zolta_jwt_driver_demo');
      localStorage.setItem('zolta_user_profile', JSON.stringify(DEFAULT_DRIVER_PROFILE));
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(DEFAULT_DRIVER_PROFILE));
    } catch {}
  }, []);

  const logout = useCallback(() => {
    try {
      localStorage.removeItem('zolta_auth_token');
      localStorage.removeItem('zolta_user_profile');
      localStorage.removeItem(STORAGE_KEY_USER);
      localStorage.removeItem('zolta_active_ride');
    } catch {}
    setIsAuthenticated(false);
    setUser({
      ...DEFAULT_RIDER,
      id: 'guest_' + Math.random().toString(36).substring(2, 8),
      name: 'Guest Rider',
      walletBalance: 0,
    });
    setModeState('rider');
    setActiveRide(null);
    setCurrentView('home');
    setSidebarOpen(false);
  }, []);

  // Voice Call handlers
  const startVoiceCall = useCallback((targetName: string, targetRole: string) => {
    setVoiceCallData({
      active: true,
      targetName,
      targetRole,
      durationSec: 0,
      isMuted: false,
      isSpeaker: true,
    });
    setVoiceCallModalOpen(true);
  }, []);

  const endVoiceCall = useCallback(() => {
    setVoiceCallData((prev) => ({ ...prev, active: false }));
    setVoiceCallModalOpen(false);
  }, []);

  const toggleCallMute = useCallback(() => {
    setVoiceCallData((prev) => ({ ...prev, isMuted: !prev.isMuted }));
  }, []);

  const toggleCallSpeaker = useCallback(() => {
    setVoiceCallData((prev) => ({ ...prev, isSpeaker: !prev.isSpeaker }));
  }, []);

  const updateRidePreferences = useCallback(async (newPrefs: RidePreferences) => {
    setUser((prev) => ({
      ...prev,
      ridePreferences: newPrefs,
    }));

    // Update activeRide if currently present
    setActiveRide((current) => {
      if (!current) return null;
      return {
        ...current,
        preferences: newPrefs,
        genderPreference: newPrefs.driverPreference || current.genderPreference,
      };
    });

    // Update driverFeedRides for real-time local sync
    setDriverFeedRides((prev) =>
      prev.map((r) =>
        r.riderId === user.id || (activeRide && r.id === activeRide.id)
          ? { ...r, preferences: newPrefs, genderPreference: newPrefs.driverPreference || r.genderPreference }
          : r
      )
    );

    const uid = auth?.currentUser?.uid || user.id;
    if (uid) {
      await saveUserPreferencesInFirestore(uid, newPrefs);
    }
    if (activeRide?.id) {
      await updateRidePreferencesInFirestore(activeRide.id, newPrefs);
    }
  }, [user.id, activeRide]);

  // Create ride request
  const createRideRequest = useCallback((params: {
    pickup: LocationPoint;
    dropoff: LocationPoint;
    category: RideCategory;
    genderPreference?: DriverGenderPreference;
    offeredFare: number;
    suggestedFare: number;
    comments: string;
    passengerCount: number;
    paymentMethod: 'cash' | 'card' | 'wallet' | 'payshap';
  }) => {
    const distanceKm = calculateDistanceKm(
      params.pickup.lat,
      params.pickup.lng,
      params.dropoff.lat,
      params.dropoff.lng
    );
    const durationMins = calculateDurationMins(distanceKm);
    const genderPref = params.genderPreference || user.ridePreferences?.driverPreference || 'any';

    const effectivePreferences: RidePreferences = {
      ...DEFAULT_RIDE_PREFERENCES,
      ...(user.ridePreferences || {}),
      ...(params.genderPreference ? { driverPreference: params.genderPreference } : {}),
    };

    speak('Searching drivers near you');

    const newRide: RideRequest = {
      id: 'ride_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      riderId: user.id,
      riderName: user.name,
      riderRating: user.rating,
      riderPhone: user.phone,
      riderAvatar: user.avatar,
      pickup: params.pickup,
      dropoff: params.dropoff,
      distanceKm,
      durationMins,
      category: params.category,
      genderPreference: genderPref,
      preferences: effectivePreferences,
      offeredFare: params.offeredFare,
      suggestedFare: params.suggestedFare,
      currency: 'R',
      comments: params.comments,
      passengerCount: params.passengerCount,
      paymentMethod: params.paymentMethod,
      status: 'searching',
      bids: [],
      createdAt: Date.now(),
      driverRouteProgress: 0,
      driverEtaMins: 4,
    };

    // If paying via wallet, record transaction
    if (params.paymentMethod === 'wallet') {
      setWalletTransactions((prev) => [
        {
          id: 'tx_ride_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          type: 'ride_payment',
          amount: -params.offeredFare,
          description: `Trip Paid - R${newRide.offeredFare}`,
          date: 'Just now',
          timestamp: Date.now(),
          status: 'completed',
        },
        ...prev,
      ]);
    }

    setActiveRide(newRide);

    // If no driver found/accepted after 3 seconds: speak "No drivers nearby in Cape Town"
    setTimeout(() => {
      setActiveRide((current) => {
        if (current && current.id === newRide.id && current.status === 'searching') {
          if (!current.acceptedDriver && current.bids.length === 0) {
            speak('No drivers nearby in Cape Town');
          }
        }
        return current;
      });
    }, 3000);

    // Persist to Firestore & Realtime DB asynchronously
    try {
      createRealtimeRideRequest({
        rideId: newRide.id,
        pickup: newRide.pickup,
        dropoff: newRide.dropoff,
        category: newRide.category,
        offeredFare: newRide.offeredFare,
        suggestedFare: newRide.suggestedFare,
        comments: newRide.comments,
        passengerCount: newRide.passengerCount,
        riderName: newRide.riderName,
        riderPhone: newRide.riderPhone,
        riderAvatar: newRide.riderAvatar,
        paymentMethod: params.paymentMethod,
        preferences: effectivePreferences,
      }).catch((err) => console.warn('Firestore write warning:', err));

      if (rdb) {
        set(ref(rdb, `rides/${newRide.id}`), {
          status: 'searching',
          offeredFare: newRide.offeredFare,
          riderName: newRide.riderName,
        }).catch(() => {});
      }
    } catch {}

    // Also add to Driver Feed for peer simulation, deduplicating any existing
    setDriverFeedRides((prev) => [newRide, ...prev.filter((r) => r.id !== newRide.id)]);

    // Ride created and waiting for real driver offers in Firestore
  }, [user]);

  // Raise rider offer
  const raiseRiderOffer = useCallback((extraAmount: number) => {
    setActiveRide((current) => {
      if (!current) return null;
      const updatedFare = Math.min(300, Math.max(30, current.offeredFare + extraAmount));
      return {
        ...current,
        offeredFare: updatedFare,
      };
    });
  }, []);

  // Reject a driver's bid
  const rejectDriverBid = useCallback((bidId: string) => {
    setActiveRide((current) => {
      if (!current) return null;
      return {
        ...current,
        bids: current.bids.map((b) => (b.id === bidId ? { ...b, status: 'rejected' } : b)),
      };
    });
  }, []);

  // Live Driver Trip Simulation
  const startTripSimulation = useCallback((ride: RideRequest, driverInfo: NonNullable<RideRequest['acceptedDriver']>) => {
    if (tripSimulationTimerRef.current) clearInterval(tripSimulationTimerRef.current);

    const routePoints = generateRoutePoints(ride.pickup, ride.dropoff, 40);
    let step = 0;
    const totalSteps = routePoints.length;

    // Stage 1: Driver heading to pickup (3 seconds)
    setTimeout(() => {
      setActiveRide((curr) => {
        if (!curr || curr.status === 'cancelled') return curr;
        audioService.playArrivedAlert();
        return {
          ...curr,
          status: 'driver_arrived',
          driverEtaMins: 0,
        };
      });

      // Stage 2: Driver starts trip after 2.5 seconds
      setTimeout(() => {
        setActiveRide((curr) => {
          if (!curr || curr.status === 'cancelled') return curr;
          return {
            ...curr,
            status: 'in_progress',
            startedAt: Date.now(),
          };
        });

        // Stage 3: Smooth progress movement along route
        tripSimulationTimerRef.current = setInterval(() => {
          step++;
          const progress = Math.min(100, Math.round((step / totalSteps) * 100));
          const currentCoord = routePoints[Math.min(step, totalSteps - 1)];

          setActiveRide((curr) => {
            if (!curr || curr.status !== 'in_progress') {
              if (tripSimulationTimerRef.current) clearInterval(tripSimulationTimerRef.current);
              return curr;
            }

            const remainingMins = Math.max(1, Math.round((1 - progress / 100) * curr.durationMins));

            if (progress >= 100) {
              if (tripSimulationTimerRef.current) clearInterval(tripSimulationTimerRef.current);
              audioService.playAcceptChime();
              
              // Trip completed
              const completedRide: RideRequest = {
                ...curr,
                status: 'completed',
                completedAt: Date.now(),
                driverRouteProgress: 100,
                driverEtaMins: 0,
              };

              // Persist commission and driver payout in Firestore zolta-45ce5
              recordPaystackSuccessInFirestore({
                tripId: completedRide.id,
                amountZar: completedRide.offeredFare,
                category: completedRide.category,
                driverId: completedRide.acceptedDriver?.id,
                riderId: completedRide.riderId,
                riderName: completedRide.riderName,
                paymentReference: `PSTK_LIVE_${Date.now()}`,
              }).catch((err) => console.warn('Firestore commission settlement notice:', err));

              setRidesHistory((prev) => [completedRide, ...prev.filter((r) => r.id !== completedRide.id)]);
              setRatingModalOpen(true);
              return completedRide;
            }

            return {
              ...curr,
              driverRouteProgress: progress,
              driverEtaMins: remainingMins,
              acceptedDriver: curr.acceptedDriver
                ? { ...curr.acceptedDriver, currentLocation: currentCoord }
                : undefined,
            };
          });
        }, 800);
      }, 3000);
    }, 4000);
  }, []);

  // Accept a driver bid
  const acceptDriverBid = useCallback((bidId: string) => {
    setActiveRide((current) => {
      if (!current) return null;
      const selectedBid = current.bids.find((b) => b.id === bidId);
      if (!selectedBid) return current;

      speak('Driver is 8 minutes away');
      audioService.playAcceptChime();

      const pLat = (typeof current.pickup?.lat === 'number' && !isNaN(current.pickup.lat) && isFinite(current.pickup.lat)) ? current.pickup.lat : -34.0456;
      const pLng = (typeof current.pickup?.lng === 'number' && !isNaN(current.pickup.lng) && isFinite(current.pickup.lng)) ? current.pickup.lng : 18.6656;

      const acceptedDriver = {
        id: selectedBid.driverId,
        name: selectedBid.driverName,
        gender: selectedBid.driverGender,
        phone: '+27 72 890 1234',
        avatar: selectedBid.driverAvatar,
        rating: selectedBid.driverRating,
        carModel: selectedBid.driverCar,
        carColor: 'Midnight Metallic',
        licensePlate: selectedBid.driverPlate,
        currentLocation: {
          lat: pLat + 0.003,
          lng: pLng + 0.003,
        },
      };

      const updatedRide: RideRequest = {
        ...current,
        status: 'driver_assigned',
        acceptedBidId: bidId,
        offeredFare: selectedBid.amount, // Set fare to accepted bid price
        acceptedDriver,
        driverEtaMins: selectedBid.driverEtaMins,
        bids: current.bids.map((b) => ({
          ...b,
          status: b.id === bidId ? 'accepted' : 'rejected',
        })),
      };

      // Start automatic simulated driving
      startTripSimulation(updatedRide, acceptedDriver);

      return updatedRide;
    });
  }, [startTripSimulation]);

  // Cancel ride
  const cancelRideRequest = useCallback((reason?: string) => {
    if (tripSimulationTimerRef.current) clearInterval(tripSimulationTimerRef.current);
    setActiveRide((current) => {
      if (!current) return null;
      const cancelled: RideRequest = {
        ...current,
        status: 'cancelled',
        cancellationReason: reason || 'Cancelled by user',
      };
      setRidesHistory((prev) => [cancelled, ...prev.filter((r) => r.id !== cancelled.id)]);
      return null;
    });
  }, []);

  // Driver counter-offer / submit bid
  const driverSubmitBid = useCallback((rideId: string, amount: number, message?: string) => {
    setDriverFeedRides((prev) =>
      prev.map((r) => {
        if (r.id !== rideId) return r;
        const myBid: Bid = {
          id: `bid_${Date.now()}_me`,
          rideId,
          driverId: user.id,
          driverName: user.name,
          driverGender: user.driverDetails?.gender || 'male',
          driverAvatar: user.avatar,
          driverRating: user.driverDetails?.rating || 4.98,
          driverTrips: user.totalTrips,
          driverCar: user.driverDetails?.carModel || 'Toyota Corolla Cross 2024',
          driverPlate: user.driverDetails?.licensePlate || 'GP 482 ZL',
          driverDistanceKm: 1.2,
          driverEtaMins: 3,
          amount,
          status: 'pending',
          createdAt: Date.now(),
          message,
        };
        return {
          ...r,
          bids: [...r.bids, myBid],
        };
      })
    );

    // If active ride matches in Rider mode
    setActiveRide((curr) => {
      if (!curr || curr.id !== rideId) return curr;
      const myBid: Bid = {
        id: `bid_${Date.now()}_${user.id}`,
        rideId,
        driverId: user.id,
        driverName: user.name,
        driverGender: user.driverDetails?.gender || 'male',
        driverAvatar: user.avatar,
        driverRating: user.driverDetails?.rating || 4.98,
        driverTrips: user.totalTrips,
        driverCar: user.driverDetails?.carModel || 'Toyota Corolla Cross 2024',
        driverPlate: user.driverDetails?.licensePlate || 'GP 482 ZL',
        driverDistanceKm: 1.2,
        driverEtaMins: 3,
        amount,
        status: 'pending',
        createdAt: Date.now(),
        message,
      };

      submitDriverOfferInFirestore(rideId, myBid);
      audioService.playBidAlert();
      return {
        ...curr,
        bids: [...curr.bids, myBid],
      };
    });
  }, [user]);

  // Driver direct accept at rider's offered price
  const driverAcceptDirect = useCallback((rideId: string) => {
    const targetRide = driverFeedRides.find((r) => r.id === rideId) || activeRide;
    if (!targetRide) return;

    speak('Driver is 8 minutes away');
    audioService.playAcceptChime();

    const tLat = (typeof targetRide.pickup?.lat === 'number' && !isNaN(targetRide.pickup.lat) && isFinite(targetRide.pickup.lat)) ? targetRide.pickup.lat : -34.0456;
    const tLng = (typeof targetRide.pickup?.lng === 'number' && !isNaN(targetRide.pickup.lng) && isFinite(targetRide.pickup.lng)) ? targetRide.pickup.lng : 18.6656;

    const acceptedRide: RideRequest = {
      ...targetRide,
      status: 'driver_assigned',
      acceptedDriver: {
        id: user.id,
        name: user.name,
        gender: user.driverDetails?.gender || 'male',
        phone: user.phone,
        avatar: user.avatar,
        rating: user.driverDetails?.rating || 4.98,
        carModel: user.driverDetails?.carModel || 'Toyota Corolla Cross',
        carColor: user.driverDetails?.carColor || 'Midnight Black',
        licensePlate: user.driverDetails?.licensePlate || 'GP 482 ZL',
        currentLocation: { lat: tLat + 0.002, lng: tLng + 0.002 },
      },
    };

    setActiveRide(acceptedRide);
    setDriverFeedRides((prev) => prev.filter((r) => r.id !== rideId));

    // Update in Firestore
    try {
      driverAcceptRideInFirestore(rideId, {
        driverId: user.id,
        driverName: user.name,
        driverPhone: user.phone,
        carModel: user.driverDetails?.carModel || 'Toyota Corolla Cross',
        licensePlate: user.driverDetails?.licensePlate || 'GP 482 ZL',
        carColor: user.driverDetails?.carColor || 'Midnight Black',
        rating: user.driverDetails?.rating || 4.98,
        avatar: user.avatar,
      }).catch((err) => console.warn('Error updating accepted ride in Firestore:', err));
    } catch {}
  }, [driverFeedRides, activeRide, user]);

  // Driver update status manually
  const driverUpdateStatus = useCallback((status: RideStatus) => {
    setActiveRide((current) => {
      if (!current) return null;
      if (status === 'driver_arrived') audioService.playArrivedAlert();
      if (status === 'completed') {
        audioService.playAcceptChime();
        const completed: RideRequest = {
          ...current,
          status: 'completed',
          completedAt: Date.now(),
        };

        // Persist commission and driver payout in Firestore zolta-45ce5
        recordPaystackSuccessInFirestore({
          tripId: completed.id,
          amountZar: completed.offeredFare,
          category: completed.category,
          driverId: user.id,
          riderId: completed.riderId,
          riderName: completed.riderName,
          paymentReference: `PSTK_DRV_${Date.now()}`,
        }).catch((err) => console.warn('Firestore commission settlement notice:', err));

        setRidesHistory((prev) => [completed, ...prev.filter((r) => r.id !== completed.id)]);

        // Add earning to driver wallet
        const earning = current.offeredFare;
        setUser((prev) => ({
          ...prev,
          walletBalance: prev.walletBalance + earning,
          driverDetails: prev.driverDetails
            ? {
                ...prev.driverDetails,
                earningsToday: prev.driverDetails.earningsToday + earning,
                tripsToday: prev.driverDetails.tripsToday + 1,
              }
            : undefined,
        }));

        setWalletTransactions((prev) => [
          {
            id: 'tx_' + Date.now(),
            type: 'driver_earning',
            amount: earning,
            description: `Trip Paid - R${earning.toFixed(0)} - ${current.riderName}`,
            date: 'Today',
            timestamp: Date.now(),
            status: 'completed',
          },
          ...prev,
        ]);

        return completed;
      }
      return { ...current, status };
    });
  }, []);

  // Submit trip rating & tip
  const submitTripRating = useCallback((rating: number, tip: number, tags: string[]) => {
    if (activeRide) {
      const updated: RideRequest = {
        ...activeRide,
        ratingGiven: rating,
        tipGiven: tip,
        feedbackTags: tags,
      };
      setRidesHistory((prev) =>
        prev.map((r) => (r.id === activeRide.id ? updated : r))
      );
    }
    setRatingModalOpen(false);
    setActiveRide(null);
  }, [activeRide]);

  // Send chat message
  const sendChatMessage = useCallback((text: string) => {
    if (!text.trim()) return;
    const newMsg: ChatMessage = {
      id: 'msg_' + Date.now(),
      rideId: activeRide?.id || 'general',
      senderId: user.id,
      senderName: user.name,
      senderRole: mode,
      text: text.trim(),
      timestamp: Date.now(),
    };
    audioService.playMessagePop();
    setChatMessages((prev) => [...prev, newMsg]);

    // Simulated reply from other party after 2 seconds
    setTimeout(() => {
      const otherRole = mode === 'rider' ? 'driver' : 'rider';
      const otherName = mode === 'rider'
        ? activeRide?.acceptedDriver?.name || 'Driver'
        : activeRide?.riderName || 'Rider';

      const replies = [
        "Sharp sharp, I see you on the map!",
        "I am waiting right by the corner in the black vehicle with hazard lights on.",
        "Perfect, heading your way now.",
        "Thanks for the update, see you in 2 mins.",
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      const replyMsg: ChatMessage = {
        id: 'msg_' + Date.now() + '_reply',
        rideId: activeRide?.id || 'general',
        senderId: 'other_party',
        senderName: otherName,
        senderRole: otherRole,
        text: randomReply,
        timestamp: Date.now(),
      };
      audioService.playMessagePop();
      setChatMessages((prev) => [...prev, replyMsg]);
    }, 2000);
  }, [activeRide, mode, user]);

  // Top up wallet
  const topUpWallet = useCallback((amount: number) => {
    setUser((prev) => {
      const newBalance = (prev.walletBalance || 0) + amount;
      const uid = auth?.currentUser?.uid || prev.id;
      if (uid) {
        syncUserWalletAndTrips(uid, newBalance, prev.totalTrips).catch(() => {});
      }
      return { ...prev, walletBalance: newBalance };
    });
    setWalletTransactions((prev) => [
      {
        id: 'tx_' + Date.now(),
        type: 'topup',
        amount,
        description: `Wallet Top Up - R${amount.toFixed(2)}`,
        date: 'Today',
        timestamp: Date.now(),
        status: 'completed',
      },
      ...prev,
    ]);
  }, []);

  // Emergency contact management
  const addEmergencyContact = useCallback((contact: Omit<EmergencyContact, 'id'>) => {
    const newContact: EmergencyContact = {
      ...contact,
      id: 'ec_' + Date.now(),
    };
    setEmergencyContacts((prev) => [...prev, newContact]);
  }, []);

  const removeEmergencyContact = useCallback((id: string) => {
    setEmergencyContacts((prev) => prev.filter((c) => c.id !== id));
  }, []);

  // Upload driver documents
  const uploadDriverDocument = useCallback((docKey: 'licenseUploaded' | 'rcUploaded' | 'insuranceUploaded' | 'photoUploaded') => {
    setUser((prev) => {
      const currentDocs = prev.driverDetails?.documents || {
        licenseUploaded: false,
        rcUploaded: false,
        insuranceUploaded: false,
        photoUploaded: false,
      };
      const updatedDocs = { ...currentDocs, [docKey]: true };
      const allDone = Object.values(updatedDocs).every(Boolean);

      return {
        ...prev,
        isDriverVerified: allDone,
        driverDetails: prev.driverDetails
          ? { ...prev.driverDetails, documents: updatedDocs }
          : {
              carModel: 'Toyota Corolla Cross 2024',
              carColor: 'Midnight Black Metallic',
              licensePlate: 'GP 482 ZL',
              carType: 'comfort',
              earningsToday: 0,
              tripsToday: 0,
              acceptanceRate: 100,
              rating: 5.0,
              gender: 'male',
              documents: updatedDocs,
            },
      };
    });
  }, []);

  // Delete User Account Permanently (Google Play Compliance)
  const deleteUser = useCallback(() => {
    localStorage.clear();
    setUser({
      ...DEFAULT_RIDER,
      walletBalance: 0,
      totalTrips: 0,
    });
    setActiveRide(null);
    setRidesHistory([]);
    setWalletTransactions([]);
    setCurrentView('home');
    setSidebarOpen(false);
    setAuthModalOpen(false);
  }, []);

  const setDriverVehicleType = useCallback((vehicleType: RideCategory) => {
    const norm = normalizeCategory(vehicleType);
    setUser((prev) => {
      const updated: UserProfile = {
        ...prev,
        vehicleType: norm,
        driverDetails: {
          ...(prev.driverDetails || DEFAULT_DRIVER_PROFILE.driverDetails!),
          carType: norm,
          vehicleType: norm,
        },
      };
      try {
        localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(updated));
        localStorage.setItem('zolta_user_profile', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        mode,
        currentView,
        showSplash,
        showOnboarding,
        finishSplash,
        finishOnboarding,
        isSidebarOpen,
        isAuthModalOpen,
        isVoiceCallModalOpen,
        isChatModalOpen,
        isSafetyModalOpen,
        isSosModalOpen,
        isGenderModalOpen,
        isPreferencesModalOpen,
        isReceiptModalOpen,
        isRatingModalOpen,
        isVerificationModalOpen,
        driverOnline,
        currentLocation,
        activeRide,
        ridesHistory,
        driverFeedRides,
        chatMessages,
        walletTransactions,
        emergencyContacts,
        voiceCallData,
        fullMap,
        setFullMap,
        toggleFullMap,
        voiceListening,
        voiceTranscript,
        voiceEnabled,
        setVoiceEnabled,
        toggleVoiceEnabled,
        speak,
        isAuthenticated,
        startVoiceSearch,
        stopVoiceSearch,
        getRealGpsPosition,
        setAuthenticatedUser,
        setMode,
        setCurrentView,
        goBack,
        setSidebarOpen,
        setAuthModalOpen,
        setVoiceCallModalOpen,
        setChatModalOpen,
        setSafetyModalOpen,
        setSosModalOpen,
        setGenderModalOpen,
        setPreferencesModalOpen,
        setReceiptModalOpen,
        setRatingModalOpen,
        setVerificationModalOpen,
        setDriverOnline,
        setCurrentLocation,
        loginAsRider,
        loginAsDriver,
        logout,
        deleteUser,
        createRideRequest,
        cancelRideRequest,
        acceptDriverBid,
        rejectDriverBid,
        raiseRiderOffer,
        driverSubmitBid,
        driverAcceptDirect,
        driverUpdateStatus,
        submitTripRating,
        sendChatMessage,
        topUpWallet,
        addEmergencyContact,
        removeEmergencyContact,
        uploadDriverDocument,
        startVoiceCall,
        endVoiceCall,
        toggleCallMute,
        toggleCallSpeaker,
        updateRidePreferences,
        setDriverVehicleType,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { defineConfig, Plugin } from 'vite';

// Plugin to guarantee .well-known/assetlinks.json is copied to dist output
function copyWellKnownPlugin(): Plugin {
  return {
    name: 'copy-well-known',
    closeBundle() {
      try {
        const srcDir = path.resolve(__dirname, 'public/.well-known');
        const destDir = path.resolve(__dirname, 'dist/.well-known');
        if (fs.existsSync(srcDir)) {
          fs.mkdirSync(destDir, { recursive: true });
          const files = fs.readdirSync(srcDir);
          for (const file of files) {
            fs.copyFileSync(path.join(srcDir, file), path.join(destDir, file));
          }
        }
      } catch (err) {
        console.warn('Failed copying .well-known folder:', err);
      }
    },
  };
}

export default defineConfig(() => {
  return {
    base: './',
    publicDir: 'public',
    build: {
      outDir: 'dist',
    },
    plugins: [react(), tailwindcss(), copyWellKnownPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

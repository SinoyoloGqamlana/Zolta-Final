const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

async function generateAll() {
  console.log('Generating real PNG assets with sharp...');

  // Base 1024x1024 SVG for high quality gold shield with Z
  const masterSvg = `
  <svg width="1024" height="1024" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#000000" />
        <stop offset="50%" stop-color="#0d0d0d" />
        <stop offset="100%" stop-color="#1a1500" />
      </linearGradient>
      <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#FFE066" />
        <stop offset="25%" stop-color="#FFD60A" />
        <stop offset="50%" stop-color="#FFC107" />
        <stop offset="75%" stop-color="#D49B00" />
        <stop offset="100%" stop-color="#996D00" />
      </linearGradient>
      <linearGradient id="innerShieldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#1c1917" />
        <stop offset="100%" stop-color="#0a0a0a" />
      </linearGradient>
      <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="30" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="16" stdDeviation="20" flood-color="#FFD60A" flood-opacity="0.35"/>
      </filter>
    </defs>

    <!-- Background -->
    <rect width="1024" height="1024" fill="url(#bgGrad)" />

    <!-- Ambient Glow Circle -->
    <circle cx="512" cy="512" r="380" fill="#FFD60A" opacity="0.12" filter="url(#glow)" />

    <!-- Outer Gold Shield Border -->
    <path d="M 512,120 L 780,240 C 780,520 660,740 512,880 C 364,740 244,520 244,240 Z"
          fill="url(#goldGrad)" filter="url(#shadow)" stroke="#FFF" stroke-width="4" stroke-opacity="0.4" />

    <!-- Inner Dark Shield -->
    <path d="M 512,152 L 750,260 C 750,504 642,704 512,836 C 382,704 274,504 274,260 Z"
          fill="url(#innerShieldGrad)" />

    <!-- Shield Inner Rim Pattern -->
    <path d="M 512,180 L 720,278 C 720,490 620,670 512,790 C 404,670 304,490 304,278 Z"
          fill="none" stroke="url(#goldGrad)" stroke-width="8" opacity="0.6" />

    <!-- Bold Stylized Letter Z -->
    <path d="M 370,330 L 654,330 L 654,395 L 475,615 L 660,615 L 660,695 L 364,695 L 364,630 L 545,410 L 370,410 Z"
          fill="url(#goldGrad)" filter="url(#glow)" stroke="#FFE875" stroke-width="3" />

    <!-- Highlights and accents -->
    <circle cx="512" cy="230" r="14" fill="#FFE066" />
    <circle cx="440" cy="270" r="8" fill="#FFD60A" opacity="0.8" />
    <circle cx="584" cy="270" r="8" fill="#FFD60A" opacity="0.8" />
  </svg>
  `;

  // Foreground transparent SVG for Android adaptive icon
  const foregroundSvg = `
  <svg width="1024" height="1024" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#FFE066" />
        <stop offset="25%" stop-color="#FFD60A" />
        <stop offset="50%" stop-color="#FFC107" />
        <stop offset="75%" stop-color="#D49B00" />
        <stop offset="100%" stop-color="#996D00" />
      </linearGradient>
      <linearGradient id="innerShieldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#1c1917" />
        <stop offset="100%" stop-color="#0a0a0a" />
      </linearGradient>
    </defs>
    <!-- Scaled Shield in Center for Adaptive Icon Safe Zone -->
    <g transform="translate(102, 102) scale(0.8)">
      <path d="M 512,120 L 780,240 C 780,520 660,740 512,880 C 364,740 244,520 244,240 Z"
            fill="url(#goldGrad)" stroke="#FFF" stroke-width="4" stroke-opacity="0.4" />
      <path d="M 512,152 L 750,260 C 750,504 642,704 512,836 C 382,704 274,504 274,260 Z"
            fill="url(#innerShieldGrad)" />
      <path d="M 512,180 L 720,278 C 720,490 620,670 512,790 C 404,670 304,490 304,278 Z"
            fill="none" stroke="url(#goldGrad)" stroke-width="8" opacity="0.6" />
      <path d="M 370,330 L 654,330 L 654,395 L 475,615 L 660,615 L 660,695 L 364,695 L 364,630 L 545,410 L 370,410 Z"
            fill="url(#goldGrad)" stroke="#FFE875" stroke-width="3" />
    </g>
  </svg>
  `;

  // Splash SVG generator
  function createSplashSvg(width, height) {
    return `
    <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="splashBg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#000000" />
          <stop offset="50%" stop-color="#0a0a0a" />
          <stop offset="100%" stop-color="#141208" />
        </linearGradient>
        <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#FFE066" />
          <stop offset="25%" stop-color="#FFD60A" />
          <stop offset="50%" stop-color="#FFC107" />
          <stop offset="75%" stop-color="#D49B00" />
          <stop offset="100%" stop-color="#996D00" />
        </linearGradient>
        <linearGradient id="innerShieldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#1c1917" />
          <stop offset="100%" stop-color="#0a0a0a" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="25" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <rect width="${width}" height="${height}" fill="url(#splashBg)" />

      <!-- Center Logo Group -->
      <g transform="translate(${width/2 - 160}, ${height/2 - 200}) scale(0.3125)">
        <circle cx="512" cy="512" r="420" fill="#FFD60A" opacity="0.15" filter="url(#glow)" />
        <path d="M 512,120 L 780,240 C 780,520 660,740 512,880 C 364,740 244,520 244,240 Z"
              fill="url(#goldGrad)" stroke="#FFF" stroke-width="6" stroke-opacity="0.4" />
        <path d="M 512,152 L 750,260 C 750,504 642,704 512,836 C 382,704 274,504 274,260 Z"
              fill="url(#innerShieldGrad)" />
        <path d="M 370,330 L 654,330 L 654,395 L 475,615 L 660,615 L 660,695 L 364,695 L 364,630 L 545,410 L 370,410 Z"
              fill="url(#goldGrad)" stroke="#FFE875" stroke-width="4" />
      </g>

      <!-- Brand Text -->
      <text x="${width/2}" y="${height/2 + 150}"
            font-family="system-ui, -apple-system, sans-serif"
            font-size="42" font-weight="900" letter-spacing="8"
            fill="#FFFFFF" text-anchor="middle">ZOLTA</text>

      <text x="${width/2}" y="${height/2 + 195}"
            font-family="system-ui, -apple-system, sans-serif"
            font-size="16" font-weight="600" letter-spacing="4"
            fill="#FFD60A" text-anchor="middle">KASI RIDES • KHAYELITSHA</text>
    </svg>
    `;
  }

  // 1. Create master 1024x1024 png buffer
  const masterBuffer = await sharp(Buffer.from(masterSvg))
    .png({ compressionLevel: 9 })
    .toBuffer();

  const foregroundBuffer = await sharp(Buffer.from(foregroundSvg))
    .png({ compressionLevel: 9 })
    .toBuffer();

  // Write master logos
  fs.writeFileSync(path.join(__dirname, '../src/assets/images/logo.png'), masterBuffer);
  fs.writeFileSync(path.join(__dirname, '../public/logo.png'), masterBuffer);

  // Write Web / PWA icons
  await sharp(masterBuffer).resize(192, 192).png().toFile(path.join(__dirname, '../public/icon-192.png'));
  await sharp(masterBuffer).resize(512, 512).png().toFile(path.join(__dirname, '../public/icon-512.png'));
  await sharp(masterBuffer).resize(192, 192).png().toFile(path.join(__dirname, '../icon-192.png'));
  await sharp(masterBuffer).resize(512, 512).png().toFile(path.join(__dirname, '../icon-512.png'));

  // Android mipmap densities
  const densities = [
    { name: 'mdpi', size: 48, fgSize: 108 },
    { name: 'hdpi', size: 72, fgSize: 162 },
    { name: 'xhdpi', size: 96, fgSize: 216 },
    { name: 'xxhdpi', size: 144, fgSize: 324 },
    { name: 'xxxhdpi', size: 192, fgSize: 432 },
  ];

  for (const d of densities) {
    const dir = path.join(__dirname, `../android/app/src/main/res/mipmap-${d.name}`);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    // Square launcher icon
    await sharp(masterBuffer)
      .resize(d.size, d.size)
      .png()
      .toFile(path.join(dir, 'ic_launcher.png'));

    // Round launcher icon
    const roundedSvg = Buffer.from(`
      <svg width="${d.size}" height="${d.size}">
        <circle cx="${d.size/2}" cy="${d.size/2}" r="${d.size/2}" fill="#000" />
      </svg>
    `);
    await sharp(masterBuffer)
      .resize(d.size, d.size)
      .composite([{ input: roundedSvg, blend: 'dest-in' }])
      .png()
      .toFile(path.join(dir, 'ic_launcher_round.png'));

    // Foreground icon for adaptive icons
    await sharp(foregroundBuffer)
      .resize(d.fgSize, d.fgSize)
      .png()
      .toFile(path.join(dir, 'ic_launcher_foreground.png'));
  }

  // Splash screens
  const splashConfigs = [
    { file: 'android/app/src/main/res/drawable/splash.png', w: 1280, h: 720 },
    { file: 'android/app/src/main/res/drawable-land-mdpi/splash.png', w: 480, h: 320 },
    { file: 'android/app/src/main/res/drawable-land-hdpi/splash.png', w: 800, h: 480 },
    { file: 'android/app/src/main/res/drawable-land-xhdpi/splash.png', w: 1280, h: 720 },
    { file: 'android/app/src/main/res/drawable-land-xxhdpi/splash.png', w: 1600, h: 960 },
    { file: 'android/app/src/main/res/drawable-land-xxxhdpi/splash.png', w: 1920, h: 1080 },
    { file: 'android/app/src/main/res/drawable-port-mdpi/splash.png', w: 320, h: 480 },
    { file: 'android/app/src/main/res/drawable-port-hdpi/splash.png', w: 480, h: 800 },
    { file: 'android/app/src/main/res/drawable-port-xhdpi/splash.png', w: 720, h: 1280 },
    { file: 'android/app/src/main/res/drawable-port-xxhdpi/splash.png', w: 960, h: 1600 },
    { file: 'android/app/src/main/res/drawable-port-xxxhdpi/splash.png', w: 1080, h: 1920 },
  ];

  for (const s of splashConfigs) {
    const fullPath = path.join(__dirname, '..', s.file);
    const dir = path.dirname(fullPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const splashSvg = createSplashSvg(s.w, s.h);
    await sharp(Buffer.from(splashSvg))
      .png({ compressionLevel: 8 })
      .toFile(fullPath);
  }

  console.log('All real binary PNGs generated successfully!');
}

generateAll().catch((err) => {
  console.error('Error generating assets:', err);
  process.exit(1);
});

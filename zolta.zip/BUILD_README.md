# ZOLTA - Production APK/AAB Build & Firebase Guide

This project is fully configured for Play Store distribution and Android native build via Capacitor / Android Studio.

---

## 1. Application & Package Specifications
- **App Name:** ZOLTA
- **Package Name (Application ID):** `com.zolta.app`
- **Target SDK Version:** 34 / 36
- **Min SDK Version:** 24 (Android 7.0+)
- **Primary Features:** Real-time Kasi ride-hailing, Female driver filters, Towing assistance, Trailer hiring, Built-in Wallet with PayShap & Card support.

---

## 2. Firebase Configuration & `google-services.json` Setup

To connect your production Firebase console for Google Sign-In and Push Notifications:

1. Go to [Firebase Console](https://console.firebase.google.com/) and open or create project `zolta-prod` (or your chosen project ID).
2. Add an **Android App** with package name:
   ```text
   com.zolta.app
   ```
3. Generate your release signing SHA fingerprints:
   ```bash
   keytool -list -v -alias your-key-alias -keystore your-release-key.jks
   ```
4. Paste the **SHA-1** and **SHA-256** fingerprints into your Firebase Android App settings.
5. Download `google-services.json` from Firebase Console.
6. Replace the placeholder file at:
   ```text
   android/app/google-services.json
   ```

---

## 3. Web & App Environment Variables (`.env`)

For web / PWA or custom API endpoints, set in `.env`:
```env
VITE_GOOGLE_MAPS_API_KEY=AIzaSy...
VITE_FIREBASE_API_KEY=AIzaSy...
VITE_FIREBASE_AUTH_DOMAIN=zolta-prod.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=zolta-prod
VITE_FIREBASE_STORAGE_BUCKET=zolta-prod.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=509407124792
VITE_FIREBASE_APP_ID=1:509407124792:android:ee543b9ebfe333d9e735cd
```

---

## 4. How to Build APK / AAB

### Step 1: Build Web Bundle
```bash
npm run build
```

### Step 2: Sync Web Dist to Android Project
```bash
npx cap sync android
```

### Step 3: Open in Android Studio or Build via Command Line

**Option A — Command Line Release AAB (Play Store):**
```bash
cd android
./gradlew bundleRelease
```
The output `.aab` file will be generated in `android/app/build/outputs/bundle/release/app-release.aab`.

**Option B — Command Line Release APK:**
```bash
cd android
./gradlew assembleRelease
```
The output `.apk` file will be generated in `android/app/build/outputs/apk/release/app-release-unsigned.apk`.

**Option C — Open in Android Studio:**
```bash
npx cap open android
```

---

## 5. Verification Checklist
- [x] Package Name unified: `com.zolta.app`
- [x] `logo.png` (Gold Z Shield) unified as sole app icon
- [x] Android Manifest permissions configured (INTERNET, Fine/Coarse Location)
- [x] Zero TypeScript compilation errors (`npm run build`)
- [x] Zero Linter warnings (`npm run lint`)

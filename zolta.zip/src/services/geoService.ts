import { LocationPoint, RideCategory, RideCategoryInfo } from '../types';

export const NGABA_NGABA_LOCATION: LocationPoint = {
  id: 'ngaba_ngaba_crescent',
  name: 'Ngaba Ngaba Crescent',
  shortName: 'Ngaba Ngaba Cres',
  address: 'Ngaba Ngaba Crescent, Ilitha Park, Khayelitsha, Cape Town',
  lat: -34.0456,
  lng: 18.6656,
};

export const POPULAR_LOCATIONS: LocationPoint[] = [
  NGABA_NGABA_LOCATION,
  {
    address: '29 Sifutho St, Khayelitsha, Cape Town',
    shortName: '29 Sifutho St',
    lat: -34.0530,
    lng: 18.6850,
  },
  {
    address: 'Centre of Science and Technology, Hlobo St, Cape Town',
    shortName: 'Centre of Science',
    lat: -34.0385,
    lng: 18.6655,
  },
  {
    address: 'Sandton City Mall, Rivonia Rd, Sandton, Johannesburg',
    shortName: 'Sandton City',
    lat: -26.1076,
    lng: 28.0531,
  },
  {
    address: 'V&A Waterfront, Breakwater Blvd, Cape Town',
    shortName: 'V&A Waterfront',
    lat: -33.9036,
    lng: 18.4205,
  },
  {
    address: 'Mall of Africa, Magwa Cres, Waterfall City, Midrand',
    shortName: 'Mall of Africa',
    lat: -26.0153,
    lng: 28.1068,
  },
  {
    address: 'Cape Town International Airport (CPT), Matroosfontein',
    shortName: 'Cape Town Airport (CPT)',
    lat: -33.9715,
    lng: 18.6021,
  },
  {
    address: 'O.R. Tambo International Airport, Kempton Park, Gauteng',
    shortName: 'O.R. Tambo Airport (JNB)',
    lat: -26.1367,
    lng: 28.2411,
  },
  {
    address: 'Menlyn Park Shopping Centre, Atterbury Rd, Pretoria',
    shortName: 'Menlyn Park',
    lat: -25.7828,
    lng: 28.2758,
  },
  {
    address: 'Camps Bay Beach, Victoria Rd, Cape Town',
    shortName: 'Camps Bay',
    lat: -33.9514,
    lng: 18.3789,
  },
];

export const CATEGORIES_DATA: RideCategoryInfo[] = [
  {
    id: 'rider',
    name: 'RIDER',
    subtitle: 'Economy • Fast & affordable',
    basePriceMultiplier: 1.0,
    fixedDefaultPrice: 25,
    capacity: '4 seats',
    icon: 'Car',
    carExample: 'Toyota Starlet, Suzuki Swift, VW Polo Vivo',
  },
  {
    id: 'comfort',
    name: 'COMFORT',
    subtitle: 'Top rated drivers & extra comfort',
    basePriceMultiplier: 1.4,
    fixedDefaultPrice: 35,
    capacity: '4 seats',
    icon: 'Car',
    carExample: 'Toyota Corolla Cross, Honda Ballade, Hyundai Creta',
  },
  {
    id: 'xl',
    name: 'XL',
    subtitle: '6-seater for groups & large luggage',
    basePriceMultiplier: 1.52,
    fixedDefaultPrice: 38,
    capacity: '6 seats',
    icon: 'Users',
    carExample: 'Toyota Rumion, Suzuki Ertiga, Mitsubishi Xpander',
  },
  {
    id: 'bakkie',
    name: 'BAKKIE',
    subtitle: 'Goods, cargo & furniture transport',
    basePriceMultiplier: 6.0,
    fixedDefaultPrice: 150,
    capacity: '1 Ton Cargo',
    icon: 'Truck',
    badge: 'GOODS',
    carExample: 'Toyota Hilux, Isuzu D-Max, Nissan NP200',
  },
  {
    id: 'scooter',
    name: 'SCOOTER',
    subtitle: 'Quick single passenger & short hops',
    basePriceMultiplier: 0.8,
    fixedDefaultPrice: 20,
    capacity: '1 seat',
    icon: 'Bike',
    carExample: 'Honda Ace, 150cc Scooter',
  },
  {
    id: 'courier',
    name: 'COURIER',
    subtitle: 'Express parcel & package dispatch',
    basePriceMultiplier: 1.2,
    fixedDefaultPrice: 30,
    capacity: 'Up to 10kg',
    icon: 'Package',
    badge: 'PARCEL',
    carExample: 'Motorcycle courier, Delivery hatch',
  },
];

function parseCoord(val: any, fallback: number): number {
  if (typeof val === 'number' && !isNaN(val) && isFinite(val)) return val;
  if (typeof val === 'string') {
    const p = parseFloat(val);
    if (!isNaN(p) && isFinite(p)) return p;
  }
  return fallback;
}

// Calculate Haversine distance in km with NaN guards
export function calculateDistanceKm(
  lat1: any,
  lon1: any,
  lat2: any,
  lon2: any
): number {
  const pLat1 = parseCoord(lat1, -34.0456);
  const pLon1 = parseCoord(lon1, 18.6656);
  const pLat2 = parseCoord(lat2, -34.0378);
  const pLon2 = parseCoord(lon2, 18.6721);

  const R = 6371; // Earth radius in km
  const dLat = ((pLat2 - pLat1) * Math.PI) / 180;
  const dLon = ((pLon2 - pLon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((pLat1 * Math.PI) / 180) *
      Math.cos((pLat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.max(0.8, Number(d.toFixed(1)));
}

// Calculate estimated duration in minutes
export function calculateDurationMins(distanceKm: number): number {
  if (typeof distanceKm !== 'number' || isNaN(distanceKm) || !isFinite(distanceKm)) {
    return 8;
  }
  const mins = Math.round((distanceKm / 24) * 60) + 1;
  return Math.max(4, mins);
}

// Calculate fair suggested price in ZAR (R)
export function calculateSuggestedFare(
  distanceKm: number,
  category: RideCategory
): number {
  const safeDistance = (typeof distanceKm === 'number' && !isNaN(distanceKm) && isFinite(distanceKm)) ? distanceKm : 3.2;
  const cat = CATEGORIES_DATA.find((c) => c.id === category) || CATEGORIES_DATA[0];
  if (cat.fixedDefaultPrice) {
    if (Math.abs(safeDistance - 3.2) < 0.5) {
      return cat.fixedDefaultPrice;
    }
    const scaled = (cat.fixedDefaultPrice / 3.2) * safeDistance;
    return Math.max(15, Math.round(scaled));
  }
  const baseRate = 25;
  const perKmRate = 8.5;
  const rawFare = (baseRate + safeDistance * perKmRate) * cat.basePriceMultiplier;
  return Math.max(20, Math.round(rawFare / 5) * 5);
}

// Generate realistic intermediate curve path points between two coordinates
export function generateRoutePoints(
  start: { lat: any; lng: any },
  end: { lat: any; lng: any },
  segments = 30
): { lat: number; lng: number }[] {
  const safeStartLat = parseCoord(start?.lat, -34.0456);
  const safeStartLng = parseCoord(start?.lng, 18.6656);
  const safeEndLat = parseCoord(end?.lat, -34.0378);
  const safeEndLng = parseCoord(end?.lng, 18.6721);

  const points: { lat: number; lng: number }[] = [];
  
  const midLat = (safeStartLat + safeEndLat) / 2;
  const midLng = (safeStartLng + safeEndLng) / 2;
  const offsetLat = (safeEndLng - safeStartLng) * 0.12;
  const offsetLng = (safeStartLat - safeEndLat) * 0.12;

  const control1 = {
    lat: safeStartLat + (midLat - safeStartLat) * 0.8 + offsetLat,
    lng: safeStartLng + (midLng - safeStartLng) * 0.8 + offsetLng,
  };

  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const lat =
      (1 - t) * (1 - t) * safeStartLat +
      2 * (1 - t) * t * control1.lat +
      t * t * safeEndLat;
    const lng =
      (1 - t) * (1 - t) * safeStartLng +
      2 * (1 - t) * t * control1.lng +
      t * t * safeEndLng;
    if (!isNaN(lat) && !isNaN(lng) && isFinite(lat) && isFinite(lng)) {
      points.push({ lat, lng });
    }
  }

  return points.length > 0 ? points : [{ lat: safeStartLat, lng: safeStartLng }, { lat: safeEndLat, lng: safeEndLng }];
}

// Client-side search autocomplete using Photon / OpenStreetMap API with fallback
export async function searchPlaces(query: string): Promise<LocationPoint[]> {
  if (!query || query.trim().length < 2) {
    return POPULAR_LOCATIONS.slice(0, 5);
  }

  const cleanQuery = query.toLowerCase().trim();
  const matchedLocal = POPULAR_LOCATIONS.filter(
    (loc) =>
      loc.address.toLowerCase().includes(cleanQuery) ||
      (loc.shortName && loc.shortName.toLowerCase().includes(cleanQuery))
  );

  try {
    const res = await fetch(
      `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=5`
    );
    if (res.ok) {
      const data = await res.json();
      if (data && data.features && data.features.length > 0) {
        const apiResults: LocationPoint[] = data.features.map(
          (f: {
            geometry: { coordinates: [number, number] };
            properties: { name?: string; street?: string; city?: string; state?: string; country?: string };
          }) => {
            const props = f.properties;
            const name = props.name || props.street || query;
            const city = props.city || props.state || props.country || '';
            const fullAddress = city ? `${name}, ${city}` : name;
            const lat = (f.geometry && f.geometry.coordinates && typeof f.geometry.coordinates[1] === 'number' && !isNaN(f.geometry.coordinates[1]))
              ? f.geometry.coordinates[1]
              : -34.0456;
            const lng = (f.geometry && f.geometry.coordinates && typeof f.geometry.coordinates[0] === 'number' && !isNaN(f.geometry.coordinates[0]))
              ? f.geometry.coordinates[0]
              : 18.6656;
            return {
              address: fullAddress,
              shortName: name,
              lat,
              lng,
            };
          }
        );
        return [...matchedLocal, ...apiResults].slice(0, 7);
      }
    }
  } catch {
    // Fallback to local list
  }

  return matchedLocal.length > 0
    ? matchedLocal
    : [
        {
          address: `${query}, South Africa`,
          shortName: query,
          lat: -34.0456 + (Math.random() - 0.5) * 0.04,
          lng: 18.6656 + (Math.random() - 0.5) * 0.04,
        },
        ...POPULAR_LOCATIONS.slice(0, 3),
      ];
}

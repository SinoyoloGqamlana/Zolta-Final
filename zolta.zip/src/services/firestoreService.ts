import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  onSnapshot,
  orderBy,
  serverTimestamp,
  Unsubscribe
} from 'firebase/firestore';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, auth, storage } from '../firebase';
import { RideRequest, RideStatus, LocationPoint, RideCategory } from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

let hasReportedQuotaExceeded = false;
let isQuotaExceeded = false;

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  const isUnavailable =
    errMsg.toLowerCase().includes('unavailable') ||
    errMsg.toLowerCase().includes('offline') ||
    errMsg.toLowerCase().includes('could not reach') ||
    errMsg.toLowerCase().includes('failed-precondition');
  const isQuota = errMsg.toLowerCase().includes('quota') || errMsg.toLowerCase().includes('resource-exhausted');
  
  if (isQuota) {
    isQuotaExceeded = true;
    if (!hasReportedQuotaExceeded) {
      hasReportedQuotaExceeded = true;
      console.warn('Firestore Daily Quota has been reached on free tier. Switching to local resilient fallback mode.');
    }
  }

  const errInfo: FirestoreErrorInfo = {
    error: errMsg,
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  if (!isQuota && !isUnavailable) {
    console.error('Firestore Error:', JSON.stringify(errInfo));
  } else if (isUnavailable) {
    console.warn('Firestore connection state notice (offline/reconnecting):', errMsg);
  }
  return errInfo;
}

/**
 * Updates user current GPS location in Firestore
 */
export async function updateUserLocationInFirestore(uid: string, lat: number, lng: number) {
  if (!db || !uid || isQuotaExceeded) return;
  try {
    const userDoc = doc(db, 'users', uid);
    await setDoc(userDoc, {
      currentLat: lat,
      currentLng: lng,
      lastLocationUpdate: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
  }
}

/**
 * Saves Ride Preferences in Firestore
 */
export async function saveUserPreferencesInFirestore(uid: string, preferences: any) {
  if (!db || !uid || isQuotaExceeded) return;
  try {
    const userDoc = doc(db, 'users', uid);
    await setDoc(userDoc, {
      ridePreferences: preferences,
      genderPreference: preferences.driverPreference || 'any',
      lastPreferencesUpdate: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
  }
}

/**
 * Creates a real-time ride request in Firestore
 */
export async function createRealtimeRideRequest(params: {
  rideId: string;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  category: RideCategory;
  offeredFare: number;
  suggestedFare: number;
  comments: string;
  passengerCount: number;
  riderName: string;
  riderPhone: string;
  riderAvatar?: string;
  paymentMethod?: 'cash' | 'card' | 'wallet' | 'payshap';
}): Promise<string> {
  const currentUid = auth?.currentUser?.uid || 'rider_' + Math.random().toString(36).substring(2, 8);

  const commissionRate = 0.10;
  const total = Number(params.offeredFare || 25);
  const zoltaCommission = Number((total * commissionRate).toFixed(2));
  const paystackFee = params.paymentMethod === 'card' ? Number((total * 0.029 + 1.0).toFixed(2)) : 0;
  const driverPayout = Number(Math.max(0, total - zoltaCommission - paystackFee).toFixed(2));

  const tripPayload = {
    tripId: params.rideId,
    serviceType: params.category,
    category: params.category,
    pickup: {
      address: params.pickup.address || 'Ngaba Ngaba Crescent, Ilitha Park',
      shortName: params.pickup.shortName || 'Ilitha Park',
      lat: params.pickup.lat || -34.0456,
      lng: params.pickup.lng || 18.6656,
    },
    destination: {
      address: params.dropoff.address || 'Khayelitsha Mall',
      shortName: params.dropoff.shortName || 'Khayelitsha Mall',
      lat: params.dropoff.lat || -34.0385,
      lng: params.dropoff.lng || 18.6655,
    },
    total,
    zoltaCommission,
    driverPayout,
    paystackFee,
    commissionRate,
    currency: 'ZAR',
    status: 'searching',
    userId: currentUid,
    riderId: currentUid,
    riderName: params.riderName,
    riderPhone: params.riderPhone,
    paymentMethod: params.paymentMethod || 'cash',
    comments: params.comments || '',
    passengerCount: params.passengerCount || 1,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (db && !isQuotaExceeded) {
    try {
      // 1. Primary trips/{id} record
      const tripDocRef = doc(db, 'trips', params.rideId);
      await setDoc(tripDocRef, tripPayload, { merge: true });

      // 2. rideRequests/{id} for driver matching
      const rideDocRef = doc(db, 'rideRequests', params.rideId);
      await setDoc(rideDocRef, tripPayload, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `rideRequests/${params.rideId}`);
    }
  }

  return params.rideId;
}

/**
 * Driver accepts ride in Firestore
 */
export async function driverAcceptRideInFirestore(rideId: string, driverInfo: {
  driverId: string;
  driverName: string;
  driverPhone: string;
  carModel: string;
  licensePlate: string;
  carColor?: string;
  rating?: number;
  avatar?: string;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'rideRequests', rideId);
    await updateDoc(docRef, {
      status: 'accepted',
      driverId: driverInfo.driverId,
      acceptedDriver: {
        id: driverInfo.driverId,
        name: driverInfo.driverName,
        phone: driverInfo.driverPhone,
        carModel: driverInfo.carModel,
        licensePlate: driverInfo.licensePlate,
        carColor: driverInfo.carColor || 'Silver',
        rating: driverInfo.rating || 4.95,
        avatar: driverInfo.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      },
      acceptedAt: serverTimestamp(),
    });

    // Sync trips/{id}
    await updateDoc(doc(db, 'trips', rideId), {
      status: 'accepted',
      driverId: driverInfo.driverId,
      updatedAt: serverTimestamp(),
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, `rideRequests/${rideId}`);
  }
}

/**
 * Updates ride status in Firestore
 */
export async function updateRideStatusInFirestore(
  rideId: string,
  status: RideStatus,
  extraPayload?: Record<string, any>
) {
  if (!db || isQuotaExceeded) return;
  try {
    const rideRef = doc(db, 'rideRequests', rideId);
    await updateDoc(rideRef, {
      status,
      ...(extraPayload || {}),
      updatedAt: serverTimestamp(),
    });

    const tripRef = doc(db, 'trips', rideId);
    await updateDoc(tripRef, {
      status,
      ...(extraPayload || {}),
      updatedAt: serverTimestamp(),
    });
  } catch (e) {
    handleFirestoreError(e, OperationType.UPDATE, `rideRequests/${rideId}`);
  }
}

/**
 * Subscribes to real-time updates for a single ride and its driver offers
 */
export function subscribeToRideRequest(
  rideId: string,
  callback: (data: any) => void
): Unsubscribe {
  if (!db || isQuotaExceeded) {
    return () => {};
  }
  try {
    const rideRef = doc(db, 'rideRequests', rideId);
    const offersRef = collection(db, 'rideRequests', rideId, 'driversOffers');

    let rideData: any = null;
    let offersData: any[] = [];

    const notify = () => {
      if (rideData) {
        const docBids = rideData.bids || [];
        const combinedBids = [...docBids, ...offersData];
        const uniqueBidsMap = new Map();
        combinedBids.forEach((b) => {
          if (b && b.id) uniqueBidsMap.set(b.id, b);
        });
        callback({
          ...rideData,
          bids: Array.from(uniqueBidsMap.values()),
        });
      }
    };

    const unsubRide = onSnapshot(
      rideRef,
      (docSnap) => {
        if (docSnap.exists()) {
          rideData = { id: docSnap.id, ...docSnap.data() };
          notify();
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `rideRequests/${rideId}`);
      }
    );

    const unsubOffers = onSnapshot(
      offersRef,
      (snapshot) => {
        offersData = [];
        snapshot.forEach((d) => {
          offersData.push({ id: d.id, ...d.data() });
        });
        notify();
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `rideRequests/${rideId}/driversOffers`);
      }
    );

    return () => {
      unsubRide();
      unsubOffers();
    };
  } catch {
    return () => {};
  }
}

/**
 * Submits a driver offer / bid into Firestore driversOffers subcollection
 */
export async function submitDriverOfferInFirestore(rideId: string, offerData: any) {
  if (!db || !rideId || isQuotaExceeded) return;
  try {
    const offerDocRef = doc(db, 'rideRequests', rideId, 'driversOffers', offerData.id || `offer_${Date.now()}`);
    await setDoc(offerDocRef, {
      ...offerData,
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `rideRequests/${rideId}/driversOffers`);
  }
}

/**
 * Subscribes to available pending ride requests near driver
 */
export function subscribeToAvailableRides(
  callback: (rides: any[]) => void
): Unsubscribe {
  if (!db || isQuotaExceeded) {
    callback([]);
    return () => {};
  }
  try {
    const ridesRef = collection(db, 'rideRequests');
    const q = query(
      ridesRef,
      where('status', 'in', ['searching', 'bidding'])
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const items: any[] = [];
        snapshot.forEach((d) => {
          items.push({ id: d.id, ...d.data() });
        });
        items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        callback(items);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'rideRequests');
        callback([]);
      }
    );
  } catch {
    callback([]);
    return () => {};
  }
}

/**
 * Uploads a document to Firebase Storage
 */
export async function uploadDocumentToFirebase(
  uid: string,
  docKey: string,
  file: File
): Promise<{ storagePath: string; downloadUrl: string; fileName: string }> {
  const path = `drivers/${uid}/${docKey}_${Date.now()}_${file.name}`;
  try {
    if (storage) {
      const sRef = storageRef(storage, path);
      await uploadBytes(sRef, file);
      const url = await getDownloadURL(sRef);
      return { storagePath: path, downloadUrl: url, fileName: file.name };
    }
  } catch (err) {
    console.warn('Firebase Storage upload notice, falling back to path metadata:', err);
  }

  // Graceful fallback with valid storage path metadata
  return {
    storagePath: path,
    downloadUrl: '',
    fileName: file.name,
  };
}

/**
 * Saves a driver registration to Firestore `drivers` and `users` collections
 */
export async function saveDriverToFirestore(driverData: {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  vehicleType: string;
  carMakeModel: string;
  carYear: string;
  licensePlate: string;
  carColor: string;
  gender: string;
  identityDoc: string;
  licenseDoc: string;
  pdpDoc: string;
  vehicleRegDoc: string;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const driverRef = doc(db, 'drivers', driverData.id);
    await setDoc(driverRef, {
      ...driverData,
      isVerified: true,
      status: 'active',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });

    const userRef = doc(db, 'users', driverData.id);
    await setDoc(userRef, {
      id: driverData.id,
      name: driverData.name,
      email: driverData.email,
      phone: driverData.phone,
      mode: 'driver',
      isDriverVerified: true,
      vehicleType: driverData.vehicleType,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `drivers/${driverData.id}`);
  }
}

/**
 * Saves a Towing Assistance request to Firestore `towingRequests` collection
 */
export async function saveTowingRequestToFirestore(towingData: {
  id: string;
  userName: string;
  userPhone: string;
  location: string;
  problemType: string;
  carDetails: {
    makeModel: string;
    color: string;
    plate: string;
  };
  description: string;
  status: string;
  assignedTruck?: string;
  eta?: string;
  offeredPrice?: number;
  towerOffers?: any[];
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'towingRequests', towingData.id);
    await setDoc(docRef, {
      ...towingData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `towingRequests/${towingData.id}`);
  }
}

/**
 * Subscribes to real-time towing requests from Firestore `towingRequests` collection
 */
export function subscribeToTowingRequests(callback: (requests: any[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'towingRequests');
    return onSnapshot(colRef, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'towingRequests');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Saves a Towing Company registration to Firestore `assetOwners` collection
 */
export async function saveTowingCompanyToFirestore(companyData: {
  id: string;
  companyName: string;
  contactPerson: string;
  phone: string;
  fleetSize: string;
  coverageArea: string;
  is247: boolean;
  servicesOffered: string[];
  rating: number;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'assetOwners', companyData.id);
    await setDoc(docRef, {
      ...companyData,
      type: 'towing',
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `assetOwners/${companyData.id}`);
  }
}

/**
 * Subscribes to real-time asset owners from Firestore `assetOwners` collection
 */
export function subscribeToAssetOwners(callback: (owners: any[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'assetOwners');
    return onSnapshot(colRef, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'assetOwners');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Saves a trailer to Firestore `trailers` collection
 */
export async function saveTrailerToFirestore(trailerData: {
  id: string;
  name: string;
  kind: string;
  size: string;
  imageUrl: string;
  pricePerHour: number;
  pricePerDay: number;
  pricePerWeek: number;
  pricePerMonth: number;
  location: string;
  deposit: number;
  deliveryAvailable: boolean;
  deliveryFee: number;
  ownerName: string;
  ownerPhone: string;
  rating: number;
  totalTrips: number;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'trailers', trailerData.id);
    await setDoc(docRef, {
      ...trailerData,
      createdAt: serverTimestamp(),
    }, { merge: true });

    // Also record in assetOwners
    const assetRef = doc(db, 'assetOwners', trailerData.id);
    await setDoc(assetRef, {
      id: trailerData.id,
      name: trailerData.name,
      ownerName: trailerData.ownerName,
      ownerPhone: trailerData.ownerPhone,
      type: 'trailer',
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trailers/${trailerData.id}`);
  }
}

/**
 * Subscribes to real-time trailers from Firestore `trailers` collection
 */
export function subscribeToTrailers(callback: (trailers: any[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'trailers');
    return onSnapshot(colRef, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'trailers');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Saves a trailer hire booking to Firestore `trailer_requests` / `trips` collection
 */
export async function saveTrailerBookingToFirestore(bookingData: {
  id: string;
  trailerId: string;
  trailerName: string;
  ownerName: string;
  ownerPhone: string;
  hireDurationType: string;
  hireUnits: number;
  hireDeliveryChoice: string;
  totalAmount: number;
  offeredPrice?: number;
  ownerOffers?: any[];
  deposit: number;
  riderId: string;
  riderName: string;
  riderPhone?: string;
  status: string;
}) {
  if (!db || isQuotaExceeded) return;
  try {
    const docRef = doc(db, 'trailer_requests', bookingData.id);
    await setDoc(docRef, {
      ...bookingData,
      serviceType: 'trailer_hiring',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });

    // Also save in trips
    const tripRef = doc(db, 'trips', bookingData.id);
    await setDoc(tripRef, {
      ...bookingData,
      serviceType: 'trailer_hiring',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trailer_requests/${bookingData.id}`);
  }
}

/**
 * Subscribes to real-time trailer hire requests from Firestore `trailer_requests` collection
 */
export function subscribeToTrailerBookings(callback: (bookings: any[]) => void): Unsubscribe {
  if (!db || isQuotaExceeded) return () => {};
  try {
    const colRef = collection(db, 'trailer_requests');
    return onSnapshot(colRef, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() });
      });
      callback(items);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'trailer_requests');
      callback([]);
    });
  } catch {
    return () => {};
  }
}

/**
 * Initializes/Syncs user profile, wallet balance, and trips count in Firestore
 */
export async function syncUserWalletAndTrips(uid: string, walletBalance: number, totalTrips: number) {
  if (!db || !uid || isQuotaExceeded) return;
  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, {
      walletBalance,
      totalTrips,
      lastActive: serverTimestamp(),
    }, { merge: true });

    const walletRef = doc(db, 'wallets', uid);
    await setDoc(walletRef, {
      uid,
      balance: walletBalance,
      currency: 'ZAR',
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
  }
}

/**
 * Subscribes to real-time trips and wallet for a given user UID from Firestore
 */
export function subscribeUserTripsAndWallet(
  uid: string,
  onUpdate: (data: { tripsCount: number; walletBalance: number; userTrips: RideRequest[] }) => void
): Unsubscribe {
  if (!db || !uid || isQuotaExceeded) {
    onUpdate({ tripsCount: 0, walletBalance: 0, userTrips: [] });
    return () => {};
  }

  try {
    let currentTrips: RideRequest[] = [];
    let currentBalance: number = 0;

    const tripsRef = collection(db, 'trips');
    const qTrips = query(tripsRef, where('userId', '==', uid));

    const unsubTrips = onSnapshot(
      qTrips,
      (snapshot) => {
        currentTrips = [];
        snapshot.forEach((d) => {
          currentTrips.push({ id: d.id, ...d.data() } as RideRequest);
        });
        onUpdate({ tripsCount: currentTrips.length, walletBalance: currentBalance, userTrips: currentTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `trips (user=${uid})`);
      }
    );

    const walletRef = doc(db, 'wallets', uid);
    const unsubWallet = onSnapshot(
      walletRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (typeof data.balance === 'number') {
            currentBalance = data.balance;
          } else if (typeof data.walletBalance === 'number') {
            currentBalance = data.walletBalance;
          }
        }
        onUpdate({ tripsCount: currentTrips.length, walletBalance: currentBalance, userTrips: currentTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `wallets/${uid}`);
      }
    );

    const userRef = doc(db, 'users', uid);
    const unsubUser = onSnapshot(
      userRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (typeof data.walletBalance === 'number' && currentBalance === 0) {
            currentBalance = data.walletBalance;
          }
        }
        onUpdate({ tripsCount: currentTrips.length, walletBalance: currentBalance, userTrips: currentTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `users/${uid}`);
      }
    );

    return () => {
      unsubTrips();
      unsubWallet();
      unsubUser();
    };
  } catch {
    return () => {};
  }
}

/**
 * Subscribes to real-time daily earnings and trips count for a driver from Firestore `trips` collection
 */
export function subscribeDriverDailyEarnings(
  driverId: string,
  onUpdate: (data: { earningsToday: number; tripsToday: number; totalEarnings: number; totalTrips: number }) => void
): Unsubscribe {
  if (!db || !driverId || isQuotaExceeded) {
    onUpdate({ earningsToday: 0, tripsToday: 0, totalEarnings: 0, totalTrips: 0 });
    return () => {};
  }

  try {
    const tripsRef = collection(db, 'trips');
    const qDriverTrips = query(tripsRef, where('driverId', '==', driverId));

    return onSnapshot(
      qDriverTrips,
      (snapshot) => {
        let earningsToday = 0;
        let tripsToday = 0;
        let totalEarnings = 0;
        let totalTrips = 0;

        const now = new Date();
        const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

        snapshot.forEach((d) => {
          const trip = d.data();
          const fare = Number(trip.offeredFare || trip.amount || trip.fare || 0);
          let tripTime = 0;

          if (trip.createdAt?.toMillis) {
            tripTime = trip.createdAt.toMillis();
          } else if (typeof trip.createdAt === 'number') {
            tripTime = trip.createdAt;
          } else if (trip.date) {
            tripTime = new Date(trip.date).getTime();
          }

          totalTrips += 1;
          totalEarnings += fare;

          if (tripTime >= startOfDay) {
            earningsToday += fare;
            tripsToday += 1;
          }
        });

        onUpdate({ earningsToday, tripsToday, totalEarnings, totalTrips });
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `trips (driver=${driverId})`);
        onUpdate({ earningsToday: 0, tripsToday: 0, totalEarnings: 0, totalTrips: 0 });
      }
    );
  } catch {
    return () => {};
  }
}

export {
  paystackInit,
  calculateCommissionSplit,
  recordPaystackSuccessInFirestore,
  runPaystackCommissionTest
} from './paystackService';

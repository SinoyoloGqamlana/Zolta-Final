import {
  doc,
  setDoc,
  updateDoc,
  getDoc,
  increment,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../firebase';

export type SupportedRideCategory =
  | 'RIDER'
  | 'COMFORT'
  | 'XL'
  | 'SCOOTER'
  | 'STANDARD'
  | string;

export interface CommissionSplitResult {
  category: string;
  grossAmount: number;
  commissionRate: number; // 0.10
  zoltaCommission: number;
  driverPayout: number;
  paystackFee: number;
}

export interface PaystackInitOptions {
  tripId: string;
  amountZar: number;
  category: SupportedRideCategory;
  email: string;
  driverId?: string;
  riderId?: string;
  riderName?: string;
  phone?: string;
  callbackUrl?: string;
  metadata?: Record<string, any>;
}

export interface PaystackSettlementParams {
  tripId: string;
  amountZar: number;
  category: SupportedRideCategory;
  paymentReference?: string;
  driverId?: string;
  riderId?: string;
  riderName?: string;
}

export interface PaystackTestResult {
  success: boolean;
  testTripId: string;
  testDriverId: string;
  category: string;
  grossAmount: number;
  commissionRate: number;
  zoltaCommission: number;
  driverPayout: number;
  paystackFee: number;
  tripDocUpdated: any;
  driverDocUpdated?: any;
  timestamp: string;
  message: string;
}

/**
 * Returns the commission rate for rides: 10%
 */
export function getCommissionRateForCategory(_category: string): number {
  return 0.10;
}

/**
 * Calculates Paystack fees, Zolta commission (10%), and net driver payout
 */
export function calculateCommissionSplit(
  category: string,
  amountZar: number
): CommissionSplitResult {
  const cleanAmount = Math.max(0, Number(amountZar) || 0);
  const commissionRate = 0.10;

  // Standard SA Paystack processing fee: 1.5% + R2.00 (min R10 for R2 fee)
  const feePercent = cleanAmount * 0.015;
  const fixedFee = cleanAmount >= 10 ? 2.0 : 0.0;
  const paystackFee = Number((feePercent + fixedFee).toFixed(2));

  // Zolta platform commission (10%)
  const zoltaCommission = Number((cleanAmount * commissionRate).toFixed(2));

  // Driver Net Payout (Gross minus Zolta commission)
  const driverPayout = Number(Math.max(0, cleanAmount - zoltaCommission).toFixed(2));

  return {
    category: category.toUpperCase(),
    grossAmount: cleanAmount,
    commissionRate,
    zoltaCommission,
    driverPayout,
    paystackFee,
  };
}

/**
 * Initiates Paystack Transaction for a Trip
 */
export async function paystackInit(options: PaystackInitOptions): Promise<{
  reference: string;
  authorizationUrl?: string;
  accessCode?: string;
  split: CommissionSplitResult;
}> {
  const split = calculateCommissionSplit(options.category, options.amountZar);
  const reference = `zolta_${options.tripId}_${Date.now()}`;

  try {
    const res = await fetch('/api/paystack/initialize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reference,
        amount: Math.round(options.amountZar * 100),
        email: options.email || 'sgqamlana13@gmail.com',
        currency: 'ZAR',
        metadata: {
          tripId: options.tripId,
          category: options.category,
          driverId: options.driverId,
          riderId: options.riderId,
          commissionRate: split.commissionRate,
          zoltaCommission: split.zoltaCommission,
          driverPayout: split.driverPayout,
          paystackFee: split.paystackFee,
          ...(options.metadata || {}),
        },
      }),
    });

    if (res.ok) {
      const data = await res.json();
      return {
        reference,
        authorizationUrl: data.authorization_url,
        accessCode: data.access_code,
        split,
      };
    }
  } catch {
    // Graceful fallback for client environment
  }

  return {
    reference,
    split,
  };
}

/**
 * Core settlement function executed after Paystack success
 */
export async function recordPaystackSuccessInFirestore(
  params: PaystackSettlementParams
): Promise<CommissionSplitResult & { reference: string }> {
  const {
    tripId,
    amountZar,
    category,
    paymentReference = `paystack_ref_${Date.now()}`,
    driverId,
    riderId,
    riderName,
  } = params;

  const split = calculateCommissionSplit(category, amountZar);

  const firestoreDb = db;
  if (firestoreDb) {
    try {
      // 1. Update doc(db, "trips", tripId)
      const tripDocRef = doc(firestoreDb, 'trips', tripId);
      const tripPayload = {
        tripId,
        grossAmount: split.grossAmount,
        commissionRate: split.commissionRate,
        zoltaCommission: split.zoltaCommission,
        driverPayout: split.driverPayout,
        paystackFee: split.paystackFee,
        currency: 'ZAR',
        category: split.category,
        paymentStatus: 'paid',
        paymentGateway: 'paystack',
        paymentReference,
        driverId: driverId || null,
        riderId: riderId || null,
        riderName: riderName || 'Zolta Rider',
        status: 'completed',
        paidAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      await setDoc(tripDocRef, tripPayload, { merge: true });

      // Sync rideRequests
      await updateDoc(doc(firestoreDb, 'rideRequests', tripId), {
        paymentStatus: 'paid',
        zoltaCommission: split.zoltaCommission,
        driverPayout: split.driverPayout,
        paidAt: serverTimestamp(),
      }).catch(() => {});

      // 2. Update drivers/{driverId}
      if (driverId) {
        const driverDocRef = doc(firestoreDb, 'drivers', driverId);
        await setDoc(
          driverDocRef,
          {
            driverId,
            totalEarned: increment(split.driverPayout),
            zoltaFeesPaid: increment(split.zoltaCommission),
            totalTrips: increment(1),
            updatedAt: serverTimestamp(),
          },
          { merge: true }
        );
      }
    } catch (err) {
      console.warn('Firestore settlement notice (offline or quota reached):', err);
    }
  }

  return {
    ...split,
    reference: paymentReference,
  };
}

/**
 * Automated Test Function for Commission Split
 */
export async function runPaystackCommissionTest(
  category: 'RIDER' | 'COMFORT' | 'XL' | 'SCOOTER' = 'RIDER',
  amountZar: number = 100
): Promise<PaystackTestResult> {
  const firestoreDb = db;
  if (!firestoreDb) {
    throw new Error('Firestore not available for test');
  }

  const timestamp = Date.now();
  const testTripId = `test_trip_${timestamp}`;
  const testDriverId = `test_driver_${category.toLowerCase()}_${timestamp.toString().slice(-4)}`;

  // Step A: Seed initial test trip in Firestore
  const initialTripRef = doc(firestoreDb, 'trips', testTripId);
  await setDoc(initialTripRef, {
    tripId: testTripId,
    riderName: 'Test Rider (Ilitha Park)',
    riderPhone: '+27 82 555 1313',
    pickup: 'Ngaba Ngaba Crescent, Ilitha Park',
    dropoff: 'Khayelitsha Mall',
    category,
    initialFareZar: amountZar,
    status: 'completed',
    paymentStatus: 'pending',
    createdAt: serverTimestamp(),
  });

  // Step B: Seed driver doc
  const driverRef = doc(firestoreDb, 'drivers', testDriverId);
  await setDoc(
    driverRef,
    {
      driverId: testDriverId,
      name: 'Test Partner Driver',
      phone: '+27 73 987 6543',
      totalEarned: 0,
      zoltaFeesPaid: 0,
      totalTrips: 0,
      createdAt: serverTimestamp(),
    },
    { merge: true }
  );

  // Step C: Run Paystack settlement and commission distribution
  const splitResult = await recordPaystackSuccessInFirestore({
    tripId: testTripId,
    amountZar,
    category,
    paymentReference: `PSTK_TEST_${timestamp}`,
    driverId: testDriverId,
    riderId: 'test_rider_13',
    riderName: 'SGQAMLANA13',
  });

  // Step D: Fetch and verify updated documents
  const tripSnap = await getDoc(doc(firestoreDb, 'trips', testTripId));
  const driverSnap = await getDoc(doc(firestoreDb, 'drivers', testDriverId));

  const tripData = tripSnap.exists() ? tripSnap.data() : null;
  const driverData = driverSnap.exists() ? driverSnap.data() : null;

  return {
    success: true,
    testTripId,
    testDriverId,
    category: splitResult.category,
    grossAmount: splitResult.grossAmount,
    commissionRate: splitResult.commissionRate,
    zoltaCommission: splitResult.zoltaCommission,
    driverPayout: splitResult.driverPayout,
    paystackFee: splitResult.paystackFee,
    tripDocUpdated: tripData,
    driverDocUpdated: driverData,
    timestamp: new Date().toISOString(),
    message: `Successfully calculated & saved ${splitResult.commissionRate * 100}% commission split in Firestore!`,
  };
}

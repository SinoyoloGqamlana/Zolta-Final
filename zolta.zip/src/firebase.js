export { app, auth, db, rdb, storage, default } from './firebase.ts';

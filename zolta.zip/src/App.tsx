import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { SidebarDrawer } from './components/common/SidebarDrawer';
import { SplashScreen } from './components/common/SplashScreen';
import { Onboarding } from './components/common/Onboarding';
import { SignInView } from './components/auth/SignInView';
import { AuthModal } from './components/common/AuthModal';
import { SafetyModal } from './components/common/SafetyModal';
import { SosModal } from './components/common/SosModal';
import { ChatModal } from './components/common/ChatModal';
import { VoiceCallModal } from './components/common/VoiceCallModal';
import { ReceiptModal } from './components/common/ReceiptModal';
import { TripRatingModal } from './components/rider/TripRatingModal';
import { TripPreferencesModal } from './components/rider/TripPreferencesModal';
import { RiderDashboard } from './components/rider/RiderDashboard';
import { DriverDashboard } from './components/driver/DriverDashboard';
import { MyRidesView } from './components/views/MyRidesView';
import { WalletView } from './components/views/WalletView';
import { SafetyCenterView } from './components/views/SafetyCenterView';
import { SupportView } from './components/views/SupportView';
import { SettingsView } from './components/views/SettingsView';
import { InviteFriendsView } from './components/views/InviteFriendsView';
import { DriveWithZoltaView } from './components/views/DriveWithZoltaView';
import { AssetOwnerView } from './components/views/AssetOwnerView';
import { TrailerHiringView } from './components/views/TrailerHiringView';
import { TowingAssistanceView } from './components/views/TowingAssistanceView';
import { RidePreferencesView } from './components/views/RidePreferencesView';

const MainAppContent: React.FC = () => {
  const {
    showSplash,
    showOnboarding,
    isAuthenticated,
    mode,
    currentView,
    activeRide,
    isRatingModalOpen,
    isReceiptModalOpen,
    setReceiptModalOpen,
  } = useApp();

  // Splash Screen first
  if (showSplash) {
    return <SplashScreen />;
  }

  // Onboarding Slides next
  if (showOnboarding) {
    return <Onboarding />;
  }

  // If not authenticated, render SignIn page immediately
  if (!isAuthenticated) {
    return <SignInView />;
  }

  return (
    <div id="zolta-app-root" className="min-h-screen bg-[#FFFBEB] flex flex-col font-sans text-neutral-900 selection:bg-[#FFCC00] selection:text-black">
      {/* Top Navbar */}
      <Header />

      {/* Main View Router */}
      <main className="flex-1 relative flex flex-col">
        {currentView === 'home' && (
          mode === 'rider' ? <RiderDashboard /> : <DriverDashboard />
        )}

        {currentView === 'my_rides' && <MyRidesView />}
        {currentView === 'wallet' && <WalletView />}
        {currentView === 'drive_with_zolta' && <DriveWithZoltaView />}
        {currentView === 'asset_owner' && <AssetOwnerView />}
        {currentView === 'trailer_hiring' && <TrailerHiringView />}
        {currentView === 'towing' && <TowingAssistanceView />}
        {currentView === 'driver_earnings' && <DriverDashboard />}
        {currentView === 'safety' && <SafetyCenterView />}
        {currentView === 'support' && <SupportView />}
        {currentView === 'settings' && <SettingsView />}
        {currentView === 'invite' && <InviteFriendsView />}
        {currentView === 'ride_preferences' && <RidePreferencesView />}
      </main>

      {/* Global Interactive Modals */}
      <SidebarDrawer />
      <AuthModal />
      <SafetyModal />
      <SosModal />
      <ChatModal />
      <VoiceCallModal />
      <TripPreferencesModal />
      {isRatingModalOpen && <TripRatingModal />}
      {isReceiptModalOpen && activeRide && (
        <ReceiptModal ride={activeRide} onClose={() => setReceiptModalOpen(false)} />
      )}
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}

export default App;

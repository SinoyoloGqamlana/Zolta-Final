import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { RideRequest } from '../../types';
import { useApp } from '../../context/AppContext';
import { Star, Clock, Check, ArrowUpRight, Plus, Minus } from 'lucide-react';
import { db } from '../../firebase';
import { doc, onSnapshot } from 'firebase/firestore';

interface DriverRideCardProps {
  ride: RideRequest;
}

export const DriverRideCard: React.FC<DriverRideCardProps> = ({ ride }) => {
  const { driverSubmitBid, driverAcceptDirect } = useApp();
  const [isCountering, setIsCountering] = useState(false);
  const [customBidAmount, setCustomBidAmount] = useState(ride.offeredFare + 10);
  const [driverComment, setDriverComment] = useState('');
  const [riderProfile, setRiderProfile] = useState<{
    totalTrips?: number;
    rating?: number;
    createdAt?: any;
    joinedDate?: string;
  } | null>(null);

  useEffect(() => {
    if (!db || !ride.riderId) return;
    const userRef = doc(db, 'users', ride.riderId);
    const unsub = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        setRiderProfile(docSnap.data());
      }
    }, (err) => {
      console.warn('Error reading rider profile for safety badge:', err);
    });
    return () => unsub();
  }, [ride.riderId]);

  const handleSendCustomBid = () => {
    driverSubmitBid(ride.id, customBidAmount, driverComment || undefined);
    setIsCountering(false);
  };

  const totalTrips = typeof riderProfile?.totalTrips === 'number'
    ? riderProfile.totalTrips
    : (typeof (ride as any)?.riderTrips === 'number' ? (ride as any).riderTrips : 0);
  
  let joinedYear = 2024;
  if (riderProfile?.createdAt) {
    if (typeof riderProfile.createdAt.toDate === 'function') {
      joinedYear = riderProfile.createdAt.toDate().getFullYear();
    } else {
      const d = new Date(riderProfile.createdAt);
      if (!isNaN(d.getTime())) {
        joinedYear = d.getFullYear();
      }
    }
  } else if (riderProfile?.joinedDate) {
    const d = new Date(riderProfile.joinedDate);
    if (!isNaN(d.getTime())) {
      joinedYear = d.getFullYear();
    }
  }

  const riderRating = typeof riderProfile?.rating === 'number'
    ? riderProfile.rating
    : (typeof ride?.riderRating === 'number' ? ride.riderRating : 5.0);

  const shortPickup = ride.pickup.shortName || ride.pickup.address.split(',')[0];
  const shortDropoff = ride.dropoff.shortName || ride.dropoff.address.split(',')[0];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-white text-neutral-900 rounded-2xl p-3 sm:p-3.5 border border-neutral-200 shadow-xs relative overflow-hidden transition hover:border-neutral-300"
    >
      {/* Rider Info Header & Big Yellow Price Badge */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <img
            src={ride.riderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
            alt={ride.riderName || 'Rider'}
            referrerPolicy="no-referrer"
            className="w-11 h-11 rounded-full object-cover border border-neutral-200"
          />
          <div>
            <div className="flex items-center gap-1">
              <h4 className="font-black text-xs sm:text-sm text-neutral-900">{ride.riderName}</h4>
              <span className="bg-blue-500 text-white rounded-full p-0.5 inline-flex items-center justify-center w-4 h-4" title="Verified Rider">
                <Check className="w-2.5 h-2.5 stroke-[3]" />
              </span>
            </div>
            {/* Safety Badge under rider name */}
            <p className="text-[10px] text-neutral-500 font-bold leading-tight mt-0.5">
              {totalTrips} trips • Joined {joinedYear} • Verified
            </p>
            {/* Rating and payment info */}
            <div className="flex items-center gap-2 text-[11px] font-bold text-neutral-700 mt-1">
              <span className="flex items-center gap-0.5 text-neutral-900 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                <Star className="w-3 h-3 fill-[#FFD60A] text-[#FFD60A]" />
                {(riderRating || 5.0).toFixed(1)}
              </span>
              <span className="text-neutral-500 bg-neutral-100 px-1.5 py-0.5 rounded border border-neutral-200 uppercase">
                {ride.paymentMethod}
              </span>
            </div>
          </div>
        </div>

        {/* Offered Fare Big Display */}
        <div className="text-right bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-xl">
          <span className="text-[9px] font-black text-amber-800 uppercase tracking-wider block">RIDER OFFERS</span>
          <div className="text-lg sm:text-xl font-black text-black font-mono leading-tight">
            R {ride.offeredFare}
          </div>
        </div>
      </div>

      {/* Route (Shortened) */}
      <div className="text-xs font-bold text-neutral-800 bg-neutral-50 px-3 py-2 rounded-xl border border-neutral-150 flex items-center gap-1.5 truncate mb-2.5">
        <span className="text-emerald-700 truncate">{shortPickup}</span>
        <span className="text-neutral-400">→</span>
        <span className="text-red-700 truncate">{shortDropoff}</span>
      </div>

      {/* Duration & Category Row */}
      <div className="flex items-center justify-between text-[11px] font-bold text-neutral-500 mb-2.5 px-0.5">
        <span>{ride.durationMins} min • {ride.distanceKm} km</span>
        <span className="text-[9px] font-black uppercase bg-neutral-100 text-neutral-800 px-2 py-0.5 rounded border border-neutral-200">
          {ride.category.toUpperCase()}
        </span>
      </div>

      {/* Rider Note if any */}
      {ride.comments && (
        <p className="text-[11px] text-neutral-600 bg-amber-50/50 border border-amber-100 p-2 rounded-lg mb-2.5 italic">
          &quot;{ride.comments}&quot;
        </p>
      )}

      {/* Counter Offer Box */}
      {isCountering ? (
        <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-3 mb-2 space-y-2.5">
          <span className="text-xs font-bold text-neutral-900 block">Offer Counter Fare (ZAR)</span>
          
          <div className="flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => setCustomBidAmount((p) => Math.max(ride.offeredFare, p - 5))}
              className="w-8 h-8 rounded-lg bg-white hover:bg-neutral-100 border border-neutral-300 flex items-center justify-center font-bold text-black shadow-xs"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <div className="text-xl font-black text-black font-mono">R {customBidAmount}</div>
            <button
              type="button"
              onClick={() => setCustomBidAmount((p) => p + 5)}
              className="w-8 h-8 rounded-lg bg-white hover:bg-neutral-100 border border-neutral-300 flex items-center justify-center font-bold text-black shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex gap-1.5 justify-center">
            {[10, 20, 30].map((plus) => (
              <button
                key={plus}
                type="button"
                onClick={() => setCustomBidAmount(ride.offeredFare + plus)}
                className="text-[11px] font-bold bg-white hover:bg-neutral-100 border border-neutral-300 px-2 py-0.5 rounded-md text-black shadow-xs"
              >
                +R{plus} (R{ride.offeredFare + plus})
              </button>
            ))}
          </div>

          <input
            type="text"
            placeholder="Quick note (e.g. 2 mins away, AC on, boot space)"
            value={driverComment}
            onChange={(e) => setDriverComment(e.target.value)}
            className="w-full bg-white border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs text-black outline-none placeholder:text-neutral-400"
          />

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsCountering(false)}
              className="flex-1 text-xs font-bold text-neutral-600 py-1.5 hover:text-black"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSendCustomBid}
              className="flex-1 bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-1.5 px-3 rounded-lg shadow-xs"
            >
              Send Offer R {customBidAmount}
            </button>
          </div>
        </div>
      ) : (
        /* Action Buttons: Accept Direct vs Counter Offer */
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            id={`btn-driver-counter-${ride.id}`}
            onClick={() => setIsCountering(true)}
            className="bg-neutral-100 hover:bg-neutral-200 border border-neutral-200 text-neutral-900 font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1 transition active:scale-95 shadow-xs"
          >
            <ArrowUpRight className="w-3.5 h-3.5 text-neutral-800" />
            <span>Counter Offer</span>
          </button>

          <button
            type="button"
            id={`btn-driver-accept-${ride.id}`}
            onClick={() => driverAcceptDirect(ride.id)}
            className="bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1 shadow-xs transition active:scale-95"
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
            <span>Accept R {ride.offeredFare}</span>
          </button>
        </div>
      )}
    </motion.div>
  );
};


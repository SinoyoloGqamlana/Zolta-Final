import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { X, DollarSign, TrendingUp, Calendar, ArrowDownToLine, Check, Award, CreditCard, ShieldCheck } from 'lucide-react';

interface DriverEarningsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DriverEarningsModal: React.FC<DriverEarningsModalProps> = ({ isOpen, onClose }) => {
  const { user } = useApp();
  const [cashingOut, setCashingOut] = useState(false);
  const [cashoutSuccess, setCashoutSuccess] = useState(false);

  if (!isOpen) return null;

  const earningsToday = user.driverDetails?.earningsToday ?? 0;
  const tripsToday = user.driverDetails?.tripsToday ?? 0;
  const totalTrips = user.totalTrips ?? 0;
  const rating = user.rating ?? 5.0;
  const acceptanceRate = user.driverDetails?.acceptanceRate ?? 100;
  const walletBalance = user.walletBalance ?? 0;

  const handleInstantCashout = () => {
    setCashingOut(true);
    setTimeout(() => {
      setCashingOut(false);
      setCashoutSuccess(true);
      setTimeout(() => setCashoutSuccess(false), 3000);
    }, 1200);
  };

  return (
    <div id="driver-earnings-overlay" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-neutral-950 text-white w-full max-w-lg rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto border border-neutral-800"
      >
        {/* Close Button */}
        <button
          id="btn-close-earnings-modal"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-11 h-11 bg-neutral-900 border border-[#FFD60A]/40 text-[#FFD60A] rounded-2xl flex items-center justify-center font-black text-lg">
            R
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Driver Earnings & Payout</h3>
            <p className="text-xs text-neutral-400">0% Platform Fee • Instant Payouts</p>
          </div>
        </div>

        {/* Today's Big Balance Card */}
        <div className="bg-black text-white rounded-3xl p-5 mb-5 relative overflow-hidden shadow-xl border border-neutral-800">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold text-[#FFD60A] uppercase tracking-wider">Available for Payout</span>
              <div className="text-3xl sm:text-4xl font-black text-white font-mono mt-1">
                R{(walletBalance || 0).toFixed(2)}
              </div>
              <span className="text-xs text-neutral-400 mt-1 block">
                Today: R{(earningsToday || 0).toFixed(2)} ({tripsToday} trips completed)
              </span>
            </div>

            <div className="bg-neutral-900 border border-neutral-800 p-2 rounded-xl text-center">
              <span className="text-[10px] text-neutral-400 font-bold block uppercase">Commission</span>
              <span className="text-sm font-black text-[#FFD60A]">0% (Free)</span>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#FFD60A]" />
              <span className="text-xs font-semibold text-neutral-300">Bank Account Payout</span>
            </div>

            <button
              type="button"
              id="btn-instant-cashout"
              disabled={cashingOut || walletBalance <= 0}
              onClick={handleInstantCashout}
              className="bg-[#FFD60A] hover:bg-yellow-400 disabled:opacity-40 text-black font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 shadow transition transform active:scale-95"
            >
              {cashingOut ? (
                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
              ) : cashoutSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-black font-bold" />
                  <span>Transferred!</span>
                </>
              ) : (
                <>
                  <ArrowDownToLine className="w-3.5 h-3.5" />
                  <span>Instant Cashout</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Driver Stats Grid */}
        <div className="grid grid-cols-3 gap-2 mb-4 text-center">
          <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
            <span className="text-[10px] text-neutral-400 font-bold uppercase block">Acceptance</span>
            <p className="text-sm font-black text-[#FFD60A]">{acceptanceRate}%</p>
          </div>
          <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
            <span className="text-[10px] text-neutral-400 font-bold uppercase block">Rating</span>
            <p className="text-sm font-black text-[#FFD60A]">★ {(rating || 5.0).toFixed(2)}</p>
          </div>
          <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
            <span className="text-[10px] text-neutral-400 font-bold uppercase block">All Time</span>
            <p className="text-sm font-black text-white">{totalTrips} trips</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};


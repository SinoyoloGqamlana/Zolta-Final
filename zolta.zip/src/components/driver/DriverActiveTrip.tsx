import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Navigation,
  Phone,
  MessageSquare,
  Shield,
  CheckCircle,
  Car,
  Compass,
  CornerUpRight,
  AlertTriangle,
  Lock,
} from 'lucide-react';

export const DriverActiveTrip: React.FC = () => {
  const {
    activeRide,
    driverUpdateStatus,
    startVoiceCall,
    setChatModalOpen,
    setSafetyModalOpen,
    setSosModalOpen,
  } = useApp();

  if (!activeRide) return null;

  const status = activeRide.status;

  return (
    <div id="driver-active-trip-view" className="w-full max-w-xl mx-auto p-4 space-y-4">
      {/* Turn-by-Turn Navigation HUD */}
      <div className="bg-neutral-950 text-white rounded-3xl p-5 shadow-2xl border border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-[#FFD60A] text-black rounded-2xl flex items-center justify-center shadow-lg">
            <CornerUpRight className="w-8 h-8 stroke-[3]" />
          </div>
          <div>
            <span className="text-[11px] uppercase font-bold text-[#FFD60A] tracking-wider">In 200 meters</span>
            <h3 className="text-lg font-black text-white leading-tight">Turn right onto Rivonia Rd</h3>
            <p className="text-xs text-neutral-400">Then continue straight for 1.2 km</p>
          </div>
        </div>

        <div className="text-right border-l border-neutral-800 pl-4">
          <span className="text-[10px] text-neutral-400 font-bold uppercase">Speed</span>
          <p className="text-xl font-mono font-black text-white">48 <span className="text-xs text-neutral-400 font-normal">km/h</span></p>
        </div>
      </div>

      {/* Passenger Card & Controls */}
      <div className="bg-neutral-950 rounded-3xl p-5 shadow-xl border border-neutral-800 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <img
              src={activeRide.riderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
              alt={activeRide.riderName || 'Passenger'}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-full object-cover border-2 border-[#FFD60A]"
            />
            <div>
              <h4 className="font-extrabold text-sm text-white">{activeRide.riderName}</h4>
              <p className="text-xs text-neutral-400 font-medium">Passenger • ⭐️ {activeRide.riderRating}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-neutral-400">Trip Fare</span>
            <p className="text-2xl font-black text-[#FFD60A] font-mono">R {activeRide.offeredFare}</p>
          </div>
        </div>

        {/* Action Buttons: Call, Message, Safety */}
        <div className="grid grid-cols-3 gap-2 mb-5">
          <button
            type="button"
            onClick={() => startVoiceCall(activeRide.riderName, 'Passenger')}
            className="bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Call</span>
          </button>
          <button
            type="button"
            onClick={() => setChatModalOpen(true)}
            className="bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <MessageSquare className="w-3.5 h-3.5 text-blue-400" />
            <span>Chat</span>
          </button>
          <button
            type="button"
            onClick={() => setSosModalOpen(true)}
            className="bg-red-950 hover:bg-red-900 border border-red-600/40 text-red-400 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Shield className="w-3.5 h-3.5 text-red-400" />
            <span>SOS</span>
          </button>
        </div>

        {/* Stage Action Progression Buttons */}
        {status === 'driver_assigned' && (
          <button
            type="button"
            id="btn-driver-arrived"
            onClick={() => driverUpdateStatus('driver_arrived')}
            className="w-full bg-[#FFD60A] hover:bg-yellow-400 text-black font-black py-4 px-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg transition transform active:scale-95 text-sm"
          >
            <Car className="w-5 h-5 fill-black" />
            <span>I Have Arrived at Pickup</span>
          </button>
        )}

        {status === 'driver_arrived' && (
          <button
            type="button"
            id="btn-driver-start-trip"
            onClick={() => driverUpdateStatus('in_progress')}
            className="w-full bg-neutral-900 hover:bg-neutral-800 border border-[#FFD60A] text-[#FFD60A] font-black py-4 px-4 rounded-2xl flex items-center justify-center gap-2 shadow-xl transition transform active:scale-95 text-sm"
          >
            <Navigation className="w-5 h-5 text-[#FFD60A]" />
            <span>Start Trip to Destination</span>
          </button>
        )}

        {status === 'in_progress' && (
          <button
            type="button"
            id="btn-driver-complete-trip"
            onClick={() => driverUpdateStatus('completed')}
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-black py-4 px-4 rounded-2xl flex items-center justify-center gap-2 shadow-xl transition transform active:scale-95 text-sm"
          >
            <CheckCircle className="w-5 h-5" />
            <span>Complete Trip & Collect R {activeRide.offeredFare}</span>
          </button>
        )}
      </div>
    </div>
  );
};


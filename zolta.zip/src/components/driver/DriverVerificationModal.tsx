import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { X, Upload, CheckCircle2, ShieldCheck, FileText, AlertCircle, Camera, Award } from 'lucide-react';

export const DriverVerificationModal: React.FC = () => {
  const { isVerificationModalOpen, setVerificationModalOpen, user, uploadDriverDocument } = useApp();
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);

  if (!isVerificationModalOpen) return null;

  const docs = user.driverDetails?.documents || {
    licenseUploaded: false,
    rcUploaded: false,
    insuranceUploaded: false,
    photoUploaded: false,
  };

  const handleSimulateUpload = (key: 'licenseUploaded' | 'rcUploaded' | 'insuranceUploaded' | 'photoUploaded') => {
    setUploadingKey(key);
    setTimeout(() => {
      uploadDriverDocument(key);
      setUploadingKey(null);
    }, 1000);
  };

  const docList = [
    {
      key: 'licenseUploaded' as const,
      title: "Driver's License (PrDP / Code 8/10)",
      subtitle: 'Valid South African driving license with Professional Driving Permit',
      uploaded: docs.licenseUploaded,
    },
    {
      key: 'rcUploaded' as const,
      title: 'Vehicle Registration Certificate (NaTIS / RC1)',
      subtitle: 'Official eNaTIS registration disk & vehicle documentation',
      uploaded: docs.rcUploaded,
    },
    {
      key: 'insuranceUploaded' as const,
      title: 'Passenger Liability & Comprehensive Insurance',
      subtitle: 'Active insurance policy covering commercial/e-hailing transport',
      uploaded: docs.insuranceUploaded,
    },
    {
      key: 'photoUploaded' as const,
      title: 'Driver Portrait & License Plate Photo',
      subtitle: 'Clear front profile & vehicle license plate registration',
      uploaded: docs.photoUploaded,
    },
  ];

  const allCompleted = Object.values(docs).every(Boolean);

  return (
    <div id="driver-docs-modal-overlay" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-neutral-950 text-white w-full max-w-lg rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto border border-neutral-800"
      >
        {/* Close */}
        <button
          id="btn-close-verification"
          onClick={() => setVerificationModalOpen(false)}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-11 h-11 bg-neutral-900 border border-[#FFD60A]/40 text-[#FFD60A] rounded-2xl flex items-center justify-center font-bold">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">ZOLTA Driver Verification</h3>
            <p className="text-xs text-neutral-400">Upload documentation for verified Safe Ride driver status</p>
          </div>
        </div>

        {/* Status Alert Banner */}
        <div className={`p-3.5 rounded-2xl border mb-5 flex items-center gap-3 ${
          allCompleted
            ? 'bg-neutral-900 border-[#FFD60A]/40 text-neutral-200'
            : 'bg-neutral-900 border-amber-500/40 text-amber-300'
        }`}>
          {allCompleted ? (
            <ShieldCheck className="w-5 h-5 text-[#FFD60A] flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          )}
          <div className="text-xs font-semibold">
            {allCompleted
              ? 'All documents approved! Your ZOLTA Verified Driver badge is fully active.'
              : 'Complete document uploads to maintain top tier status & 0% platform fee.'}
          </div>
        </div>

        {/* Documents List */}
        <div className="space-y-3 mb-6">
          {docList.map((doc) => {
            const isCurrentUploading = uploadingKey === doc.key;

            return (
              <div
                key={doc.key}
                className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center mt-0.5 ${
                    doc.uploaded ? 'bg-black text-[#FFD60A] border border-[#FFD60A]/50' : 'bg-neutral-800 text-neutral-400'
                  }`}>
                    {doc.uploaded ? <CheckCircle2 className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                  </div>
                  <div>
                    <h5 className="font-bold text-xs text-white">{doc.title}</h5>
                    <p className="text-[11px] text-neutral-400">{doc.subtitle}</p>
                    <span className={`inline-block text-[10px] font-bold mt-1 px-2 py-0.5 rounded-full ${
                      doc.uploaded ? 'bg-black text-[#FFD60A] border border-[#FFD60A]/30' : 'bg-neutral-800 text-amber-400'
                    }`}>
                      {doc.uploaded ? 'Verified & Valid' : 'Action Required'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  id={`btn-upload-${doc.key}`}
                  disabled={isCurrentUploading}
                  onClick={() => handleSimulateUpload(doc.key)}
                  className={`text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition ${
                    doc.uploaded
                      ? 'bg-neutral-800 border border-neutral-700 text-neutral-300 hover:text-white'
                      : 'bg-[#FFD60A] text-black hover:bg-yellow-400 shadow-sm font-black'
                  }`}
                >
                  {isCurrentUploading ? (
                    <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Upload className="w-3.5 h-3.5" />
                      <span>{doc.uploaded ? 'Re-upload' : 'Upload'}</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* Done Button */}
        <button
          type="button"
          id="btn-done-verification"
          onClick={() => setVerificationModalOpen(false)}
          className="w-full bg-[#FFD60A] hover:bg-yellow-400 text-black font-black py-3.5 rounded-2xl text-xs transition"
        >
          Confirm & Close
        </button>
      </motion.div>
    </div>
  );
};

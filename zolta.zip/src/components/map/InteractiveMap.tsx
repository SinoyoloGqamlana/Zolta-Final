import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { LocationPoint, RideRequest } from '../../types';
import { generateRoutePoints } from '../../services/geoService';
import { Navigation2, Car, Plus, Minus, ChevronLeft, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';

// Safeguard Leaflet L.LatLng and L.latLng globally against NaN/invalid inputs
try {
  const OriginalLatLng = L.LatLng;

  function safeCoord(v: any, fallback: number): number {
    if (typeof v === 'number' && !isNaN(v) && isFinite(v)) return v;
    if (typeof v === 'string') {
      const p = parseFloat(v);
      if (!isNaN(p) && isFinite(p)) return p;
    }
    return fallback;
  }

  function safeLatCoord(v: any, fallback = -34.0456): number {
    const num = safeCoord(v, fallback);
    if (num < -90) return -90;
    if (num > 90) return 90;
    return num;
  }

  function safeLngCoord(v: any, fallback = 18.6656): number {
    const num = safeCoord(v, fallback);
    if (num < -180) return -180;
    if (num > 180) return 180;
    return num;
  }

  function extractLatAndLng(a: any, b?: any, fallbackLat = -34.0456, fallbackLng = 18.6656): [number, number] {
    let rawLat: any = a;
    let rawLng: any = b;

    if (a && typeof a === 'object') {
      if (Array.isArray(a)) {
        rawLat = a[0];
        rawLng = a[1];
      } else {
        rawLat = a.lat ?? a.latitude ?? a.y;
        rawLng = a.lng ?? a.lon ?? a.longitude ?? a.x;
      }
    }

    const finalLat = safeLatCoord(rawLat, fallbackLat);
    const finalLng = safeLngCoord(rawLng, fallbackLng);
    return [finalLat, finalLng];
  }

  // 1. Safe LatLng constructor wrapper
  function SafeLatLng(this: any, a: any, b?: any, c?: any) {
    const [sLat, sLng] = extractLatAndLng(a, b);
    return new (OriginalLatLng as any)(sLat, sLng, c);
  }
  SafeLatLng.prototype = OriginalLatLng.prototype;
  (L as any).LatLng = SafeLatLng;

  // 2. Safe latLng factory function
  (L as any).latLng = function (a: any, b?: any, c?: any) {
    try {
      if (a instanceof OriginalLatLng) {
        if (typeof a.lat !== 'number' || isNaN(a.lat) || !isFinite(a.lat) || typeof a.lng !== 'number' || isNaN(a.lng) || !isFinite(a.lng)) {
          return new (OriginalLatLng as any)(-34.0456, 18.6656, a.alt);
        }
        return a;
      }
      const [sLat, sLng] = extractLatAndLng(a, b);
      return new (OriginalLatLng as any)(sLat, sLng, c);
    } catch {
      return new (OriginalLatLng as any)(-34.0456, 18.6656, c);
    }
  };

  // 3. Patch L.marker factory
  if ((L as any).marker) {
    const origMarker = (L as any).marker;
    (L as any).marker = function (latlng: any, options?: any) {
      const safe = (L as any).latLng(latlng);
      return origMarker.call(L, safe, options);
    };
  }

  // 4. Patch L.polyline factory
  if ((L as any).polyline) {
    const origPolyline = (L as any).polyline;
    (L as any).polyline = function (latlngs: any, options?: any) {
      try {
        const makeSafe = (item: any): any => {
          if (Array.isArray(item)) {
            if (item.length >= 2 && typeof item[0] !== 'object' && typeof item[1] !== 'object') {
              return [safeLatCoord(item[0], -34.0456), safeLngCoord(item[1], 18.6656)];
            }
            return item.map(makeSafe);
          }
          if (item && typeof item === 'object') {
            return [safeLatCoord(item.lat ?? item.latitude, -34.0456), safeLngCoord(item.lng ?? item.lon ?? item.longitude, 18.6656)];
          }
          return [-34.0456, 18.6656];
        };
        if (Array.isArray(latlngs)) {
          const safeArr = latlngs.map(makeSafe);
          return origPolyline.call(L, safeArr, options);
        }
      } catch {}
      return origPolyline.call(L, latlngs, options);
    };
  }

  // 5. Patch L.Marker.prototype.setLatLng
  if (L.Marker && L.Marker.prototype) {
    const origMarkerSetLatLng = L.Marker.prototype.setLatLng;
    L.Marker.prototype.setLatLng = function (latlng: any) {
      const safe = (L as any).latLng(latlng);
      return origMarkerSetLatLng.call(this, safe);
    };
  }

  // 6. Patch L.Polyline.prototype.setLatLngs
  if (L.Polyline && L.Polyline.prototype) {
    const origPolylineSetLatLngs = L.Polyline.prototype.setLatLngs;
    L.Polyline.prototype.setLatLngs = function (latlngs: any) {
      try {
        const makeSafe = (item: any): any => {
          if (Array.isArray(item)) {
            if (item.length >= 2 && typeof item[0] !== 'object' && typeof item[1] !== 'object') {
              return [safeLatCoord(item[0], -34.0456), safeLngCoord(item[1], 18.6656)];
            }
            return item.map(makeSafe);
          }
          if (item && typeof item === 'object') {
            return [safeLatCoord(item.lat ?? item.latitude, -34.0456), safeLngCoord(item.lng ?? item.lon ?? item.longitude, 18.6656)];
          }
          return [-34.0456, 18.6656];
        };
        if (Array.isArray(latlngs)) {
          const safeArr = latlngs.map(makeSafe);
          return origPolylineSetLatLngs.call(this, safeArr);
        }
      } catch {}
      return origPolylineSetLatLngs.call(this, latlngs);
    };
  }

  // 7. Patch L.Polygon.prototype.setLatLngs if exists
  if (L.Polygon && L.Polygon.prototype) {
    const origPolygonSetLatLngs = L.Polygon.prototype.setLatLngs;
    if (origPolygonSetLatLngs) {
      L.Polygon.prototype.setLatLngs = function (latlngs: any) {
        try {
          const makeSafe = (item: any): any => {
            if (Array.isArray(item)) {
              if (item.length >= 2 && typeof item[0] !== 'object' && typeof item[1] !== 'object') {
                return [safeLatCoord(item[0], -34.0456), safeLngCoord(item[1], 18.6656)];
              }
              return item.map(makeSafe);
            }
            if (item && typeof item === 'object') {
              return [safeLatCoord(item.lat ?? item.latitude, -34.0456), safeLngCoord(item.lng ?? item.lon ?? item.longitude, 18.6656)];
            }
            return [-34.0456, 18.6656];
          };
          if (Array.isArray(latlngs)) {
            const safeArr = latlngs.map(makeSafe);
            return origPolygonSetLatLngs.call(this, safeArr);
          }
        } catch {}
        return origPolygonSetLatLngs.call(this, latlngs);
      };
    }
  }

  // 8. Patch L.Circle and L.CircleMarker if exists
  if (L.Circle && L.Circle.prototype) {
    const origCircleSetLatLng = L.Circle.prototype.setLatLng;
    if (origCircleSetLatLng) {
      L.Circle.prototype.setLatLng = function (latlng: any) {
        return origCircleSetLatLng.call(this, (L as any).latLng(latlng));
      };
    }
  }
  if (L.CircleMarker && L.CircleMarker.prototype) {
    const origCircleMarkerSetLatLng = L.CircleMarker.prototype.setLatLng;
    if (origCircleMarkerSetLatLng) {
      L.CircleMarker.prototype.setLatLng = function (latlng: any) {
        return origCircleMarkerSetLatLng.call(this, (L as any).latLng(latlng));
      };
    }
  }

  // 9. Patch Map prototype movement and projection methods
  if (L.Map && L.Map.prototype) {
    const origFlyTo = L.Map.prototype.flyTo;
    L.Map.prototype.flyTo = function (center: any, zoom?: any, options?: any) {
      const safe = (L as any).latLng(center);
      return origFlyTo.call(this, safe, zoom, options);
    };

    const origSetView = L.Map.prototype.setView;
    L.Map.prototype.setView = function (center: any, zoom?: any, options?: any) {
      const safe = (L as any).latLng(center);
      return origSetView.call(this, safe, zoom, options);
    };

    const origPanTo = L.Map.prototype.panTo;
    L.Map.prototype.panTo = function (center: any, options?: any) {
      const safe = (L as any).latLng(center);
      return origPanTo.call(this, safe, options);
    };

    const origLayerPointToLatLng = L.Map.prototype.layerPointToLatLng;
    L.Map.prototype.layerPointToLatLng = function (point: any) {
      try {
        if (!point || isNaN(point.x) || isNaN(point.y) || !isFinite(point.x) || !isFinite(point.y)) {
          return (L as any).latLng(-34.0456, 18.6656);
        }
        return origLayerPointToLatLng.call(this, point);
      } catch {
        return (L as any).latLng(-34.0456, 18.6656);
      }
    };

    const origContainerPointToLatLng = L.Map.prototype.containerPointToLatLng;
    L.Map.prototype.containerPointToLatLng = function (point: any) {
      try {
        if (!point || isNaN(point.x) || isNaN(point.y) || !isFinite(point.x) || !isFinite(point.y)) {
          return (L as any).latLng(-34.0456, 18.6656);
        }
        return origContainerPointToLatLng.call(this, point);
      } catch {
        return (L as any).latLng(-34.0456, 18.6656);
      }
    };

    const origUnproject = L.Map.prototype.unproject;
    L.Map.prototype.unproject = function (point: any, zoom?: any) {
      try {
        if (!point || isNaN(point.x) || isNaN(point.y) || !isFinite(point.x) || !isFinite(point.y)) {
          return (L as any).latLng(-34.0456, 18.6656);
        }
        return origUnproject.call(this, point, zoom);
      } catch {
        return (L as any).latLng(-34.0456, 18.6656);
      }
    };

    const origGetCenter = L.Map.prototype.getCenter;
    L.Map.prototype.getCenter = function () {
      try {
        const c = origGetCenter.call(this);
        if (!c || typeof c.lat !== 'number' || isNaN(c.lat) || !isFinite(c.lat) || typeof c.lng !== 'number' || isNaN(c.lng) || !isFinite(c.lng)) {
          return (L as any).latLng(-34.0456, 18.6656);
        }
        return c;
      } catch {
        return (L as any).latLng(-34.0456, 18.6656);
      }
    };
  }

  // 10. Patch CRS unproject and pointToLatLng
  if (L.CRS) {
    Object.values(L.CRS).forEach((crs: any) => {
      if (crs && typeof crs.pointToLatLng === 'function') {
        const origPointToLatLng = crs.pointToLatLng;
        crs.pointToLatLng = function (point: any, zoom: any) {
          try {
            if (!point || isNaN(point.x) || isNaN(point.y) || !isFinite(point.x) || !isFinite(point.y)) {
              return (L as any).latLng(-34.0456, 18.6656);
            }
            const res = origPointToLatLng.call(this, point, zoom);
            if (!res || isNaN(res.lat) || isNaN(res.lng)) {
              return (L as any).latLng(-34.0456, 18.6656);
            }
            return res;
          } catch {
            return (L as any).latLng(-34.0456, 18.6656);
          }
        };
      }
      if (crs && typeof crs.unproject === 'function') {
        const origUnproj = crs.unproject;
        crs.unproject = function (point: any) {
          try {
            if (!point || isNaN(point.x) || isNaN(point.y) || !isFinite(point.x) || !isFinite(point.y)) {
              return (L as any).latLng(-34.0456, 18.6656);
            }
            const res = origUnproj.call(this, point);
            if (!res || isNaN(res.lat) || isNaN(res.lng)) {
              return (L as any).latLng(-34.0456, 18.6656);
            }
            return res;
          } catch {
            return (L as any).latLng(-34.0456, 18.6656);
          }
        };
      }
    });
  }
} catch (e) {
  console.warn('Leaflet LatLng patch error:', e);
}

interface InteractiveMapProps {
  pickup?: LocationPoint;
  dropoff?: LocationPoint;
  activeRide?: RideRequest | null;
  onPickupChange?: (loc: LocationPoint) => void;
  draggablePickup?: boolean;
  className?: string;
  showNoCarsNearby?: boolean;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  pickup,
  dropoff,
  activeRide,
  onPickupChange,
  draggablePickup = false,
  className = '',
  showNoCarsNearby = false,
}) => {
  const {
    isSidebarOpen,
    currentView,
    mode,
    setCurrentView,
    goBack,
    cancelRideRequest,
    setFullMap,
    fullMap,
  } = useApp();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const dropoffMarkerRef = useRef<L.Marker | null>(null);
  const driverMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);

  const [mapReady, setMapReady] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [isRouteModalOpen, setIsRouteModalOpen] = useState(false);

  // Floating small 20% OFF badge top left under header (randomly shown, dismissible)
  const [showPromoBadge, setShowPromoBadge] = useState(() => {
    try {
      if (sessionStorage.getItem('zolta_dismiss_promo_badge') === 'true') return false;
    } catch {}
    return Math.random() < 0.8; // Shown sometimes randomly
  });

  // Handle top-left < Back button navigation
  const handleTopLeftBack = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isRouteModalOpen) {
      setIsRouteModalOpen(false);
      window.dispatchEvent(new CustomEvent('zolta_route_modal_toggle', { detail: { isOpen: false } }));
      return;
    }
    if (activeRide) {
      cancelRideRequest('Back navigation from map');
      return;
    }
    if (fullMap) {
      setFullMap(false);
      return;
    }
    if (currentView !== 'home') {
      setCurrentView('home');
      return;
    }
    goBack();
  };

  // Listen for route selector modal open/close to hide map buttons
  useEffect(() => {
    const handleRouteModalToggle = (e: any) => {
      if (e?.detail?.isOpen !== undefined) {
        setIsRouteModalOpen(e.detail.isOpen);
      }
    };
    window.addEventListener('zolta_route_modal_toggle', handleRouteModalToggle);
    return () => {
      window.removeEventListener('zolta_route_modal_toggle', handleRouteModalToggle);
    };
  }, []);

  useEffect(() => {
    if (showNoCarsNearby && !activeRide) {
      setShowToast(true);
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 3000);
      return () => clearTimeout(timer);
    } else {
      setShowToast(false);
    }
  }, [showNoCarsNearby, activeRide]);

  useEffect(() => {
    if (isSidebarOpen || currentView !== 'home' || mode !== 'rider') {
      setShowToast(false);
    }
  }, [isSidebarOpen, currentView, mode]);

  // Default coordinate: Ngaba Ngaba Crescent, Ilitha Park, Khayelitsha (-33.983, 18.668)
  const defaultLat = -33.983;
  const defaultLng = 18.668;

  const isValidCoord = (val: any): val is number => {
    if (typeof val === 'number') return !isNaN(val) && isFinite(val) && Math.abs(val) <= 180;
    if (typeof val === 'string') {
      const p = parseFloat(val);
      return !isNaN(p) && isFinite(p) && Math.abs(p) <= 180;
    }
    return false;
  };

  const safeLat = (val: any, fallback = defaultLat): number => {
    const validFallback = (typeof fallback === 'number' && !isNaN(fallback) && isFinite(fallback) && Math.abs(fallback) <= 90) ? fallback : defaultLat;
    if (typeof val === 'number' && !isNaN(val) && isFinite(val) && Math.abs(val) <= 90) return val;
    if (typeof val === 'string') {
      const p = parseFloat(val);
      if (!isNaN(p) && isFinite(p) && Math.abs(p) <= 90) return p;
    }
    return validFallback;
  };

  const safeLng = (val: any, fallback = defaultLng): number => {
    const validFallback = (typeof fallback === 'number' && !isNaN(fallback) && isFinite(fallback) && Math.abs(fallback) <= 180) ? fallback : defaultLng;
    if (typeof val === 'number' && !isNaN(val) && isFinite(val) && Math.abs(val) <= 180) return val;
    if (typeof val === 'string') {
      const p = parseFloat(val);
      if (!isNaN(p) && isFinite(p) && Math.abs(p) <= 180) return p;
    }
    return validFallback;
  };

  // Helper to safely format LatLng pair for Leaflet
  const safeLatLngPair = (lat: any, lng: any, fallbackLat = defaultLat, fallbackLng = defaultLng): [number, number] => {
    return [safeLat(lat, fallbackLat), safeLng(lng, fallbackLng)];
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    try {
      const centerCoords = safeLatLngPair(pickup?.lat, pickup?.lng, -33.983, 18.668);

      const map = L.map(mapContainerRef.current, {
        center: centerCoords,
        zoom: 15,
        zoomControl: false,
        attributionControl: false,
      });

      // Google Maps Roadmap tiles (Fast, high-resolution road labels & street names)
      const tileUrl = 'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}';
      const googleTiles = L.tileLayer(tileUrl, {
        maxZoom: 20,
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
        attribution: '&copy; Google Maps',
      });

      googleTiles.addTo(map);

      mapInstanceRef.current = map;
      setMapReady(true);

      // Force instant tile calculation after mount to eliminate white blank frames
      const t1 = setTimeout(() => {
        try { map.invalidateSize(); } catch {}
      }, 50);
      const t2 = setTimeout(() => {
        try { map.invalidateSize(); } catch {}
      }, 300);

      // Handle map container resizing safely
      const resizeObserver = new ResizeObserver(() => {
        try {
          if (mapInstanceRef.current && mapContainerRef.current && mapContainerRef.current.clientWidth > 0 && mapContainerRef.current.clientHeight > 0) {
            mapInstanceRef.current.invalidateSize();
          }
        } catch {}
      });
      resizeObserver.observe(mapContainerRef.current);

      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
        try {
          resizeObserver.disconnect();
          map.remove();
        } catch {}
        mapInstanceRef.current = null;
      };
    } catch (err) {
      console.warn('Map init error:', err);
    }
  }, []);

  // Update Pickup / YOU Marker & Fly to user's real location at zoom 16
  useEffect(() => {
    if (!mapReady || !mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    try {
      const pickupCoords = safeLatLngPair(pickup?.lat, pickup?.lng);

      // Center map to user's real lat/lng, zoom 15 when not on active driver tracking
      if (!activeRide || activeRide.status === 'searching' || activeRide.status === 'idle') {
        try {
          if (mapContainerRef.current && mapContainerRef.current.clientWidth > 0) {
            map.flyTo(pickupCoords, 15, { duration: 0.8 });
          }
        } catch {}
      }

      // Exact inDrive style Blue circle with Where from tooltip & YOU pin from user screenshot
      const pickupAddressShort = pickup?.shortName || pickup?.name || 'Ngaba Ngaba Cres 21';
      const youIcon = L.divIcon({
        html: `
          <div class="relative flex flex-col items-center justify-center -translate-x-1/2 -translate-y-[85%] select-none pointer-events-none">
            <!-- 1. Floating "Where from" pill (Exact inDrive screenshot style) -->
            <div class="bg-[#1C222B]/95 backdrop-blur-sm text-white px-2.5 py-1 rounded-xl shadow-2xl border border-white/20 flex items-center gap-1.5 mb-1.5 whitespace-nowrap animate-in fade-in zoom-in-95">
              <div class="flex flex-col text-left">
                <span class="text-[8px] text-neutral-400 font-semibold uppercase leading-none">Where from</span>
                <span class="text-[11px] font-bold text-white leading-tight mt-0.5">${pickupAddressShort}</span>
              </div>
              <svg class="w-3.5 h-3.5 text-neutral-400 ml-0.5 stroke-[2.5]" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </div>

            <!-- 2. Car Pin Badge on top of GPS point -->
            <div class="relative flex items-center justify-center">
              <!-- Outer pulsating radar ring -->
              <div class="absolute w-16 h-16 bg-blue-500/20 rounded-full animate-ping pointer-events-none"></div>
              <div class="absolute w-12 h-12 bg-blue-500/30 rounded-full border border-blue-400/50 pointer-events-none"></div>
              
              <!-- Car Badge container -->
              <div class="relative z-10 w-9 h-9 bg-white text-black border-2 border-neutral-900 rounded-full flex items-center justify-center shadow-xl font-bold">
                <svg class="w-5 h-5 fill-black" viewBox="0 0 24 24">
                  <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z"/>
                  <circle cx="7.5" cy="14.5" r="1.5" fill="black"/>
                  <circle cx="16.5" cy="14.5" r="1.5" fill="black"/>
                </svg>
              </div>

              <!-- Blue Location Dot Anchor -->
              <div class="absolute -bottom-2 w-3.5 h-3.5 bg-[#2563EB] border-2 border-white rounded-full shadow-md"></div>
            </div>
          </div>
        `,
        className: 'custom-you-marker',
        iconSize: [0, 0],
      });

      if (!pickupMarkerRef.current) {
        pickupMarkerRef.current = L.marker(pickupCoords, {
          icon: youIcon,
          draggable: draggablePickup,
        }).addTo(map);

        if (draggablePickup) {
          pickupMarkerRef.current.on('dragend', (e) => {
            try {
              const marker = e.target;
              if (marker && typeof marker.getLatLng === 'function') {
                const pos = marker.getLatLng();
                if (pos && onPickupChange && isValidCoord(pos.lat) && isValidCoord(pos.lng)) {
                  onPickupChange({
                    address: 'Current Location (Selected Pin)',
                    shortName: 'Current Location',
                    lat: pos.lat,
                    lng: pos.lng,
                  });
                }
              }
            } catch (err) {
              console.warn('Pickup dragend error:', err);
            }
          });
        }
      } else {
        pickupMarkerRef.current.setLatLng(pickupCoords);
      }
    } catch (err) {
      console.warn('Pickup marker update error:', err);
    }
  }, [mapReady, pickup, draggablePickup, onPickupChange, activeRide]);

  // Update Dropoff Marker & Route Line
  useEffect(() => {
    if (!mapReady || !mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    try {
      if (dropoff && isValidCoord(dropoff.lat) && isValidCoord(dropoff.lng)) {
        const dropoffCoords = safeLatLngPair(dropoff.lat, dropoff.lng);

        const dropoffIcon = L.divIcon({
          html: `
            <div class="relative flex flex-col items-center select-none">
              <div class="w-8 h-8 bg-red-600 text-white border-2 border-white rounded-full flex items-center justify-center shadow-lg font-bold text-xs ring-4 ring-red-500/30">
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
              </div>
              <div class="bg-black/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 shadow-md whitespace-nowrap border border-white/20">
                ${dropoff.shortName || 'Destination'}
              </div>
            </div>
          `,
          className: 'dropoff-custom-pin',
          iconSize: [60, 60],
          iconAnchor: [30, 24],
        });

        if (!dropoffMarkerRef.current) {
          dropoffMarkerRef.current = L.marker(dropoffCoords, {
            icon: dropoffIcon,
          }).addTo(map);
        } else {
          dropoffMarkerRef.current.setLatLng(dropoffCoords);
        }

        // Draw Route Polyline
        const startPoint = pickup && isValidCoord(pickup.lat) && isValidCoord(pickup.lng)
          ? pickup
          : { lat: defaultLat, lng: defaultLng, address: 'Current Location' };
        const points = generateRoutePoints(startPoint, dropoff, 30);
        const latLngs = points
          .filter((p) => isValidCoord(p.lat) && isValidCoord(p.lng))
          .map((p) => safeLatLngPair(p.lat, p.lng));

        if (latLngs.length > 0) {
          if (!routePolylineRef.current) {
            routePolylineRef.current = L.polyline(latLngs, {
              color: '#111827',
              weight: 5,
              opacity: 0.85,
              dashArray: '8, 6',
            }).addTo(map);
          } else {
            routePolylineRef.current.setLatLngs(latLngs);
          }
        }
      } else {
        if (dropoffMarkerRef.current) {
          try { dropoffMarkerRef.current.remove(); } catch {}
          dropoffMarkerRef.current = null;
        }
        if (routePolylineRef.current) {
          try { routePolylineRef.current.remove(); } catch {}
          routePolylineRef.current = null;
        }
      }
    } catch (err) {
      console.warn('Dropoff/route update error:', err);
    }
  }, [mapReady, pickup, dropoff]);

  // Update Live Driver Movement & Active Progress
  useEffect(() => {
    if (!mapReady || !mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    try {
      if (
        activeRide?.acceptedDriver?.currentLocation &&
        isValidCoord(activeRide.acceptedDriver.currentLocation.lat) &&
        isValidCoord(activeRide.acceptedDriver.currentLocation.lng) &&
        (activeRide.status === 'driver_assigned' ||
          activeRide.status === 'in_progress' ||
          activeRide.status === 'driver_arrived')
      ) {
        const driverLoc = activeRide.acceptedDriver.currentLocation;

        const activeDriverIcon = L.divIcon({
          html: `
            <div class="relative flex flex-col items-center">
              <div class="w-10 h-10 bg-[#FFD60A] text-black border-2 border-black rounded-full flex items-center justify-center shadow-2xl ring-4 ring-[#FFD60A]/50 animate-bounce">
                <svg class="w-5 h-5 fill-black" viewBox="0 0 24 24">
                  <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z"/>
                  <circle cx="7.5" cy="14.5" r="1.5" fill="#FFD60A"/>
                  <circle cx="16.5" cy="14.5" r="1.5" fill="#FFD60A"/>
                </svg>
              </div>
              <div class="bg-black text-[#FFD60A] text-[11px] font-bold px-2 py-0.5 rounded-full mt-1 shadow-lg whitespace-nowrap">
                ${activeRide.acceptedDriver.name.split(' ')[0]} (${activeRide.driverEtaMins || 1}m)
              </div>
            </div>
          `,
          className: 'active-driver-pin',
          iconSize: [80, 80],
          iconAnchor: [40, 30],
        });

        const driverCoords = safeLatLngPair(driverLoc.lat, driverLoc.lng);

        if (!driverMarkerRef.current) {
          driverMarkerRef.current = L.marker(driverCoords, {
            icon: activeDriverIcon,
            zIndexOffset: 1000,
          }).addTo(map);
        } else {
          driverMarkerRef.current.setIcon(activeDriverIcon);
          driverMarkerRef.current.setLatLng(driverCoords);
        }
      } else {
        if (driverMarkerRef.current) {
          try { driverMarkerRef.current.remove(); } catch {}
          driverMarkerRef.current = null;
        }
      }
    } catch (err) {
      console.warn('Driver marker update error:', err);
    }
  }, [mapReady, activeRide]);

  // Recenter handler
  const handleRecenter = () => {
    if (!mapInstanceRef.current) return;
    try {
      const pickupCoords = safeLatLngPair(pickup?.lat, pickup?.lng);
      mapInstanceRef.current.flyTo(pickupCoords, 16, { duration: 0.8 });
    } catch (err) {
      console.warn('Recenter flyTo error:', err);
    }
  };

  const handleZoomIn = () => {
    if (!mapInstanceRef.current) return;
    try {
      mapInstanceRef.current.zoomIn();
    } catch {}
  };

  const handleZoomOut = () => {
    if (!mapInstanceRef.current) return;
    try {
      mapInstanceRef.current.zoomOut();
    } catch {}
  };

  return (
    <div
      id="zolta-map-wrapper"
      className={`relative w-full h-full min-h-[300px] overflow-hidden ${className}`}
    >
      {/* Map Canvas */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Top Left < Back Arrow Button (White Circle, z-index 9999, Always Visible) */}
      <button
        type="button"
        id="btn-map-top-left-back"
        onClick={handleTopLeftBack}
        title="Go Back / Return Home"
        aria-label="Back"
        className="absolute top-3.5 left-3.5 z-[9999] w-10 h-10 rounded-full bg-white text-black shadow-2xl border border-neutral-300 hover:bg-neutral-100 active:scale-90 flex items-center justify-center transition cursor-pointer"
      >
        <ChevronLeft className="w-6 h-6 stroke-[3] text-black" />
      </button>

      {/* Floating 20% OFF Badge (Top Left of map under header, tiny 10px text, yellow bg, black text, rounded 6px, dismissible) */}
      {showPromoBadge && (
        <div
          id="badge-map-promo-20-off"
          className="absolute top-4 left-15 z-[9998] flex items-center gap-1 bg-[#FFCC00] text-black text-[10px] font-black font-mono px-2 py-0.5 rounded-[6px] shadow-md border border-black/10 animate-in fade-in slide-in-from-top-1 duration-200 select-none"
        >
          <span className="tracking-tight uppercase">20% OFF</span>
          <button
            type="button"
            id="btn-dismiss-promo-badge"
            onClick={(e) => {
              e.stopPropagation();
              setShowPromoBadge(false);
              try {
                sessionStorage.setItem('zolta_dismiss_promo_badge', 'true');
              } catch {}
            }}
            className="w-3.5 h-3.5 rounded-full hover:bg-black/10 active:scale-90 flex items-center justify-center transition cursor-pointer ml-0.5 text-black"
            aria-label="Dismiss discount badge"
            title="Dismiss"
          >
            <X className="w-2.5 h-2.5 stroke-[3]" />
          </button>
        </div>
      )}

      {/* Toast Overlay INSIDE Map */}
      {showToast && !isSidebarOpen && currentView === 'home' && mode === 'rider' && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-10 pointer-events-none text-center select-none animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="bg-black/75 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20 shadow-xl">
            <p className="text-white font-bold text-xs leading-tight drop-shadow-md">
              No cars nearby
            </p>
            <p className="text-neutral-300 text-[10px] mt-0.5 drop-shadow-sm font-mono">
              Try again in a few minutes
            </p>
          </div>
        </div>
      )}

      {/* Left Bottom: Street View / Satellite Thumbnail (Exact inDrive screenshot style) */}
      {!isRouteModalOpen && (
        <div
          id="map-streetview-thumbnail"
          className="absolute left-3.5 bottom-[120px] z-[30] flex flex-col gap-1 items-start select-none transition-all duration-200"
        >
          <div className="text-[11px] font-bold text-neutral-800 bg-white/70 backdrop-blur-xs px-1.5 py-0.5 rounded shadow-xs mb-1 font-sans">
            Google
          </div>
          <button
            type="button"
            id="btn-map-streetview-preview"
            onClick={handleRecenter}
            title="View Street / 360"
            className="w-12 h-12 rounded-xl overflow-hidden border-2 border-white shadow-2xl bg-neutral-800 relative group active:scale-95 transition cursor-pointer"
          >
            {/* Street visual thumbnail */}
            <div className="w-full h-full bg-gradient-to-tr from-sky-800 via-slate-700 to-amber-700 flex items-center justify-center">
              <div className="absolute inset-0 bg-black/25 group-hover:bg-transparent transition" />
              <div className="w-5 h-5 rounded-full bg-white/90 shadow-md flex items-center justify-center text-neutral-900 z-10">
                <svg className="w-3 h-3 stroke-[2.5]" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
              </div>
            </div>
          </button>
        </div>
      )}

      {/* Right Side 4 Floating Black Action Controls */}
      {!isRouteModalOpen && (
        <div
          id="map-floating-action-controls"
          className="absolute right-3.5 bottom-[120px] z-[30] flex flex-col gap-2 transition-all duration-200"
        >
          {/* 1. Compass / Orient Arrow */}
          <button
            id="btn-map-navigation"
            type="button"
            onClick={handleRecenter}
            title="Orient Map"
            className="w-10 h-10 bg-[#1C222B] hover:bg-[#252C36] border border-white/20 text-white rounded-full shadow-2xl flex items-center justify-center transition active:scale-90 cursor-pointer"
          >
            <Navigation2 className="w-4 h-4 stroke-[2.5] fill-white transform -rotate-45" />
          </button>

          {/* 2. Recenter Car Button */}
          <button
            id="btn-map-recenter-car"
            type="button"
            onClick={handleRecenter}
            title="Center Location"
            className="w-10 h-10 bg-[#1C222B] hover:bg-[#252C36] border border-white/20 text-[#FFD60A] rounded-full shadow-2xl flex items-center justify-center transition active:scale-90 cursor-pointer"
          >
            <Car className="w-4 h-4 stroke-[2.5]" />
          </button>

          {/* 3. Plus Zoom Button */}
          <button
            id="btn-map-zoom-in"
            type="button"
            onClick={handleZoomIn}
            title="Zoom In"
            className="w-10 h-10 bg-[#1C222B] hover:bg-[#252C36] border border-white/20 text-white rounded-full shadow-xl flex items-center justify-center transition active:scale-90 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
          </button>

          {/* 4. Minus Zoom Button */}
          <button
            id="btn-map-zoom-out"
            type="button"
            onClick={handleZoomOut}
            title="Zoom Out"
            className="w-10 h-10 bg-[#1C222B] hover:bg-[#252C36] border border-white/20 text-white rounded-full shadow-xl flex items-center justify-center transition active:scale-90 cursor-pointer"
          >
            <Minus className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      )}
    </div>
  );
};

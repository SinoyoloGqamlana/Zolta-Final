import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Gift, Copy, Check, Share2, ArrowLeft, Users, Sparkles, Award } from 'lucide-react';

export const InviteFriendsView: React.FC = () => {
  const { setCurrentView } = useApp();
  const [copied, setCopied] = useState(false);
  const referralCode = 'ZOLTA-RIDE99';

  const handleCopy = () => {
    navigator.clipboard?.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div id="invite-friends-view" className="max-w-3xl mx-auto p-4 sm:p-6 pb-20 text-center text-white">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5 text-left">
        <button
          type="button"
          onClick={() => setCurrentView('home')}
          className="p-2 -ml-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-full transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight">Invite & Earn Ride Credits</h2>
          <p className="text-xs text-neutral-400">Share ZOLTA & earn R50 ride credits</p>
        </div>
      </div>

      {/* Hero Banner */}
      <div className="bg-[#FFD60A] rounded-3xl p-8 mb-6 shadow-xl relative overflow-hidden text-black flex flex-col items-center">
        <div className="w-20 h-20 bg-black text-[#FFD60A] rounded-3xl flex items-center justify-center mb-4 shadow-lg">
          <Gift className="w-10 h-10 animate-bounce" />
        </div>

        <span className="text-xs font-black uppercase tracking-wider bg-black/10 px-3 py-1 rounded-full mb-2">
          R50 Referral Bonus Program
        </span>

        <h3 className="text-3xl font-black tracking-tight mb-2">
          Give R50, Get R50
        </h3>
        <p className="text-xs font-medium text-black/80 max-w-sm mb-6 leading-relaxed">
          Invite friends to experience safe, verified rides with ZOLTA. When they complete their first trip, you both receive R50 in your wallet.
        </p>

        {/* Promo Code Box */}
        <div className="bg-black text-white px-5 py-3 rounded-2xl flex items-center gap-4 shadow-lg border border-neutral-800">
          <div>
            <span className="text-[10px] font-bold text-[#FFD60A] uppercase tracking-wider block text-left">
              Your Referral Code
            </span>
            <span className="text-lg font-black font-mono tracking-widest">{referralCode}</span>
          </div>

          <button
            type="button"
            id="btn-copy-referral"
            onClick={handleCopy}
            className="bg-[#FFD60A] hover:bg-yellow-400 text-black p-2.5 rounded-xl font-bold text-xs transition active:scale-95 flex items-center gap-1"
          >
            {copied ? <Check className="w-4 h-4 text-black font-bold" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>

      {/* How It Works */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6 text-left">
        <div className="bg-neutral-950 p-4 rounded-2xl border border-neutral-800 shadow-xs">
          <span className="w-6 h-6 rounded-full bg-[#FFD60A] text-black font-black text-xs flex items-center justify-center mb-2">
            1
          </span>
          <h5 className="font-bold text-xs text-white mb-1">Send Your Link</h5>
          <p className="text-[11px] text-neutral-400">Share your invite code with friends via WhatsApp, SMS, or Telegram.</p>
        </div>

        <div className="bg-neutral-950 p-4 rounded-2xl border border-neutral-800 shadow-xs">
          <span className="w-6 h-6 rounded-full bg-[#FFD60A] text-black font-black text-xs flex items-center justify-center mb-2">
            2
          </span>
          <h5 className="font-bold text-xs text-white mb-1">They Offer Fare</h5>
          <p className="text-[11px] text-neutral-400">Your friend signs up, sets their fare in Rands, and completes their first ZOLTA ride.</p>
        </div>

        <div className="bg-neutral-950 p-4 rounded-2xl border border-neutral-800 shadow-xs">
          <span className="w-6 h-6 rounded-full bg-[#FFD60A] text-black font-black text-xs flex items-center justify-center mb-2">
            3
          </span>
          <h5 className="font-bold text-xs text-white mb-1">Earn R50 Credit</h5>
          <p className="text-[11px] text-neutral-400">R50 is automatically credited into your wallet.</p>
        </div>
      </div>
    </div>
  );
};


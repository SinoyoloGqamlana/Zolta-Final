import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldAlert,
  ArrowLeft,
  AlertTriangle,
  FileQuestion,
  PackageX,
  Phone,
} from 'lucide-react';

export const SafetyCenterView: React.FC = () => {
  const { setCurrentView, setMode } = useApp();

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
  };

  const handleDial = (num: string) => {
    window.location.href = `tel:${num}`;
  };

  return (
    <div id="safety-center-view" className="flex-1 bg-white text-[#111111] p-4 sm:p-6 max-w-3xl mx-auto w-full pb-24 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-5 pb-3 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-safety"
            onClick={handleGoToRiderPortal}
            className="w-10 h-10 rounded-2xl bg-neutral-100 border border-[#E5E7EB] text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-roman text-2xl sm:text-3xl font-bold text-[#111111] tracking-tight">
              Help & Safety Center
            </h1>
            <p className="font-mono text-[10px] uppercase text-[#8B8B8B] tracking-wider">
              24/7 Rapid Emergency & Rider Assistance South Africa
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoToRiderPortal}
          className="w-9 h-9 rounded-2xl bg-[#FFD60A] text-black font-black text-base flex items-center justify-center shadow-xs"
        >
          Z
        </button>
      </div>

      {/* 1. Small Red Button: CALL ZOLTA SUPPORT 0800 096 582 */}
      <button
        type="button"
        id="btn-call-zolta-support"
        onClick={() => handleDial('+27800096582')}
        className="w-full bg-[#DC2626] hover:bg-red-700 text-white font-mono text-xs font-bold py-3.5 px-5 rounded-2xl shadow-xs flex items-center justify-center gap-2 transition active:scale-95 mb-5 uppercase tracking-wider"
      >
        <Phone className="w-4 h-4" />
        <span>CALL ZOLTA SUPPORT: 0800 096 582</span>
      </button>

      {/* 2. EMERGENCY HOTLINES SOUTH AFRICA Card */}
      <div className="bg-white rounded-[20px] p-5 border border-[#E5E7EB] shadow-xs mb-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-50 border border-red-200 text-red-600 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-roman text-lg font-bold text-[#111111] tracking-tight">
                EMERGENCY HOTLINES SOUTH AFRICA
              </h2>
              <p className="font-mono text-[10px] text-emerald-700 font-bold uppercase">
                Calls are free even with no airtime
              </p>
            </div>
          </div>
          <span className="bg-red-50 text-red-700 border border-red-200 font-mono text-[9px] font-bold px-2 py-0.5 rounded-full uppercase">
            24/7 TOLL-FREE
          </span>
        </div>

        {/* Hotlines Grid: name left, yellow pill right */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* SAPS: 10111 */}
          <button
            type="button"
            id="btn-call-police-10111"
            onClick={() => handleDial('10111')}
            className="p-3.5 bg-neutral-50 hover:bg-neutral-100 rounded-2xl border border-[#E5E7EB] flex items-center justify-between transition active:scale-95 text-left"
          >
            <div>
              <p className="text-xs font-bold text-black">SAPS Police</p>
              <p className="font-mono text-[10px] text-neutral-500">Flying Squad & Dispatch</p>
            </div>
            <span className="font-mono text-xs font-bold text-black bg-[#FFD60A] px-3 py-1 rounded-xl shadow-xs border border-yellow-400">
              10111
            </span>
          </button>

          {/* Ambulance: 10177 */}
          <button
            type="button"
            id="btn-call-ambulance-10177"
            onClick={() => handleDial('10177')}
            className="p-3.5 bg-neutral-50 hover:bg-neutral-100 rounded-2xl border border-[#E5E7EB] flex items-center justify-between transition active:scale-95 text-left"
          >
            <div>
              <p className="text-xs font-bold text-black">Ambulance</p>
              <p className="font-mono text-[10px] text-neutral-500">National Health EMS</p>
            </div>
            <span className="font-mono text-xs font-bold text-black bg-[#FFD60A] px-3 py-1 rounded-xl shadow-xs border border-yellow-400">
              10177
            </span>
          </button>

          {/* All: 112 */}
          <button
            type="button"
            id="btn-call-emergency-112"
            onClick={() => handleDial('112')}
            className="p-3.5 bg-neutral-50 hover:bg-neutral-100 rounded-2xl border border-[#E5E7EB] flex items-center justify-between transition active:scale-95 text-left"
          >
            <div>
              <p className="text-xs font-bold text-black">All Emergencies</p>
              <p className="font-mono text-[10px] text-neutral-500">Mobile Cellular Link</p>
            </div>
            <span className="font-mono text-xs font-bold text-black bg-[#FFD60A] px-3 py-1 rounded-xl shadow-xs border border-yellow-400">
              112
            </span>
          </button>

          {/* Fire: 021 480 7700 */}
          <button
            type="button"
            id="btn-call-ct-fire"
            onClick={() => handleDial('0214807700')}
            className="p-3.5 bg-neutral-50 hover:bg-neutral-100 rounded-2xl border border-[#E5E7EB] flex items-center justify-between transition active:scale-95 text-left"
          >
            <div>
              <p className="text-xs font-bold text-black">Fire & Rescue</p>
              <p className="font-mono text-[10px] text-neutral-500">Disaster Operations</p>
            </div>
            <span className="font-mono text-xs font-bold text-black bg-[#FFD60A] px-2.5 py-1 rounded-xl shadow-xs border border-yellow-400">
              021 480 7700
            </span>
          </button>
        </div>
      </div>

      {/* 3. 1 Row 3 Columns Icons: [REPORT ISSUE] [LOST ITEM RECOVER] [FAQ VIEW] */}
      <div>
        <label className="font-mono text-[10px] font-bold uppercase text-[#8B8B8B] block mb-2.5">
          Rider Support Options
        </label>
        <div className="grid grid-cols-3 gap-2 sm:gap-3">
          {/* 1. REPORT ISSUE */}
          <button
            type="button"
            id="btn-report-issue"
            onClick={() => setCurrentView('support')}
            className="bg-white hover:bg-neutral-50 border border-[#E5E7EB] p-4 rounded-[20px] shadow-xs flex flex-col items-center text-center transition active:scale-95 cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-neutral-50 border border-[#E5E7EB] text-black flex items-center justify-center mb-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
            </div>
            <h4 className="font-mono text-[11px] font-bold text-black uppercase">REPORT ISSUE</h4>
            <p className="text-[10px] text-neutral-500 mt-0.5">Disputes & Safety</p>
          </button>

          {/* 2. LOST ITEM RECOVER */}
          <button
            type="button"
            id="btn-lost-item"
            onClick={() => setCurrentView('support')}
            className="bg-white hover:bg-neutral-50 border border-[#E5E7EB] p-4 rounded-[20px] shadow-xs flex flex-col items-center text-center transition active:scale-95 cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-neutral-50 border border-[#E5E7EB] text-black flex items-center justify-center mb-2">
              <PackageX className="w-5 h-5 text-blue-500" />
            </div>
            <h4 className="font-mono text-[11px] font-bold text-black uppercase">LOST ITEM</h4>
            <p className="text-[10px] text-neutral-500 mt-0.5">Recover Belongings</p>
          </button>

          {/* 3. FAQ VIEW */}
          <button
            type="button"
            id="btn-faq-articles"
            onClick={() => setCurrentView('support')}
            className="bg-white hover:bg-neutral-50 border border-[#E5E7EB] p-4 rounded-[20px] shadow-xs flex flex-col items-center text-center transition active:scale-95 cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-neutral-50 border border-[#E5E7EB] text-black flex items-center justify-center mb-2">
              <FileQuestion className="w-5 h-5 text-emerald-500" />
            </div>
            <h4 className="font-mono text-[11px] font-bold text-black uppercase">FAQ VIEW</h4>
            <p className="text-[10px] text-neutral-500 mt-0.5">Guides & Tariffs</p>
          </button>
        </div>
      </div>
    </div>
  );
};

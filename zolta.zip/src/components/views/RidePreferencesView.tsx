import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp, DEFAULT_RIDE_PREFERENCES } from '../../context/AppContext';
import { DriverGenderPreference, RidePreferences } from '../../types';
import {
  ArrowLeft,
  ShieldCheck,
  Shield,
  User,
  Users,
  Music,
  MessageSquare,
  Globe,
  ShoppingBag,
  Share2,
  Moon,
  MapPin,
  Check,
  Sliders,
  Sparkles,
} from 'lucide-react';

export const RidePreferencesView: React.FC = () => {
  const { user, updateRidePreferences, goBack, setCurrentView } = useApp();

  // Load current preferences or defaults
  const currentPrefs: RidePreferences = {
    ...DEFAULT_RIDE_PREFERENCES,
    ...(user.ridePreferences || {}),
  };

  const [driverPref, setDriverPref] = useState<DriverGenderPreference>(
    currentPrefs.driverPreference || 'any'
  );
  const [language, setLanguage] = useState<'Xhosa' | 'English' | 'Afrikaans' | 'Sesotho'>(
    currentPrefs.language || 'Xhosa'
  );
  const [music, setMusic] = useState<'Amapiano' | 'Gqom' | 'Gospel' | 'Quiet ride'>(
    currentPrefs.music || 'Amapiano'
  );
  const [chatLevel, setChatLevel] = useState<'Chatty' | 'Quiet' | 'Only directions'>(
    currentPrefs.chatLevel || 'Chatty'
  );
  const [stopAtSpaza, setStopAtSpaza] = useState<boolean>(currentPrefs.stopAtSpaza ?? false);
  const [shareTripFamily, setShareTripFamily] = useState<boolean>(currentPrefs.shareTripFamily ?? true);
  const [femaleDriverAtNight, setFemaleDriverAtNight] = useState<boolean>(currentPrefs.femaleDriverAtNight ?? true);
  const [avoidGravelRoads, setAvoidGravelRoads] = useState<boolean>(currentPrefs.avoidGravelRoads ?? false);

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    const updated: RidePreferences = {
      driverPreference: driverPref,
      language,
      music,
      chatLevel,
      stopAtSpaza,
      shareTripFamily,
      femaleDriverAtNight,
      avoidGravelRoads,
    };

    try {
      await updateRidePreferences(updated);
      setSavedSuccess(true);
      setTimeout(() => {
        setSavedSuccess(false);
      }, 2500);
    } catch (err) {
      console.error('Error saving preferences:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      id="ride-preferences-view"
      className="min-h-screen bg-neutral-50 text-neutral-900 pb-24 font-sans selection:bg-[#FFCC00] selection:text-black"
    >
      {/* Sticky Top Header Bar */}
      <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-neutral-200 px-4 py-3 shadow-xs">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <button
            type="button"
            id="btn-back-preferences"
            onClick={() => goBack()}
            className="w-10 h-10 -ml-1 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-black transition active:scale-95"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          </button>

          <div className="text-center flex-1 px-2">
            <h1 className="text-base font-black text-black tracking-tight flex items-center justify-center gap-1.5 font-sans">
              <Sliders className="w-4 h-4 text-[#FFCC00] fill-[#FFCC00]" />
              Ride Preferences
            </h1>
            <p className="text-[11px] text-neutral-500 font-medium">
              Make Zolta feel like home
            </p>
          </div>

          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 pt-4 space-y-5">
        {/* Save success banner */}
        {savedSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="bg-emerald-500 text-white p-3 rounded-2xl font-bold text-xs flex items-center justify-between shadow-md"
          >
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Preferences saved to your ZOLTA profile!</span>
            </div>
          </motion.div>
        )}

        {/* SECTION 1 - DRIVER CHOICE */}
        <section className="bg-white rounded-2xl p-4 shadow-sm border border-neutral-200 space-y-3">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-black flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-black" />
              </div>
              <div>
                <h2 className="text-sm font-black text-black uppercase tracking-wide">
                  Driver Preference
                </h2>
                <span className="text-[10px] text-neutral-500 font-mono">
                  Matching priority for your rides
                </span>
              </div>
            </div>
            <span className="text-[9px] font-black bg-[#FFCC00] text-black px-2 py-0.5 rounded-full uppercase font-mono">
              REQUIRED
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1">
            {/* All Drivers */}
            <button
              type="button"
              id="pref-driver-all"
              onClick={() => setDriverPref('any')}
              className={`p-3.5 rounded-2xl border text-center transition flex flex-col items-center justify-between min-h-[110px] relative ${
                driverPref === 'any'
                  ? 'bg-neutral-900 border-neutral-900 text-white shadow-md'
                  : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-neutral-200/40 flex items-center justify-center mb-1">
                <Users className={`w-4 h-4 ${driverPref === 'any' ? 'text-[#FFCC00]' : 'text-neutral-600'}`} />
              </div>
              <div>
                <span className="text-xs font-black block leading-tight">All Drivers</span>
                <span className={`text-[9px] font-mono mt-0.5 block ${driverPref === 'any' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                  Fastest ETA
                </span>
              </div>
              {driverPref === 'any' && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#FFCC00]" />
              )}
            </button>

            {/* Female Driver Only */}
            <button
              type="button"
              id="pref-driver-female"
              onClick={() => setDriverPref('female')}
              className={`p-3.5 rounded-2xl border text-center transition flex flex-col items-center justify-between min-h-[110px] relative ${
                driverPref === 'female'
                  ? 'bg-pink-500 border-pink-600 text-white shadow-md'
                  : 'bg-pink-50/60 border-pink-200 text-pink-900 hover:bg-pink-100/80'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center mb-1">
                <User className="w-4 h-4 text-pink-600 font-bold" />
              </div>
              <div>
                <span className="text-xs font-black block leading-tight">Female Driver Only</span>
                <span className={`text-[9px] font-mono mt-0.5 block ${driverPref === 'female' ? 'text-pink-100' : 'text-pink-600 font-semibold'}`}>
                  Safety Priority
                </span>
              </div>
              {driverPref === 'female' && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white" />
              )}
            </button>

            {/* Male Driver Only */}
            <button
              type="button"
              id="pref-driver-male"
              onClick={() => setDriverPref('male')}
              className={`p-3.5 rounded-2xl border text-center transition flex flex-col items-center justify-between min-h-[110px] relative ${
                driverPref === 'male'
                  ? 'bg-blue-600 border-blue-700 text-white shadow-md'
                  : 'bg-blue-50/60 border-blue-200 text-blue-900 hover:bg-blue-100/80'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mb-1">
                <User className="w-4 h-4 text-blue-600 font-bold" />
              </div>
              <div>
                <span className="text-xs font-black block leading-tight">Male Driver Only</span>
                <span className={`text-[9px] font-mono mt-0.5 block ${driverPref === 'male' ? 'text-blue-100' : 'text-blue-600 font-semibold'}`}>
                  Standard
                </span>
              </div>
              {driverPref === 'male' && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white" />
              )}
            </button>
          </div>

          <p className="text-[11px] text-neutral-500 bg-neutral-50 p-2.5 rounded-xl border border-neutral-200/80 font-mono flex items-center gap-1.5 mt-2">
            <Shield className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
            <span>Note: Female driver may take longer in your area - Khayelitsha</span>
          </p>
        </section>

        {/* SECTION 2 - KASI COMFORT */}
        <section className="bg-white rounded-2xl p-4 shadow-sm border border-neutral-200 space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-2.5">
            <div className="w-8 h-8 rounded-xl bg-yellow-100 text-black flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-700" />
            </div>
            <div>
              <h2 className="text-sm font-black text-black uppercase tracking-wide">
                Kasi Comfort
              </h2>
              <span className="text-[10px] text-neutral-500 font-mono">
                Set atmosphere, music & language
              </span>
            </div>
          </div>

          {/* Language Chips */}
          <div>
            <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5 mb-2">
              <Globe className="w-3.5 h-3.5 text-neutral-500" />
              <span>Preferred Language</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['Xhosa', 'English', 'Afrikaans', 'Sesotho'] as const).map((lang) => {
                const isActive = language === lang;
                return (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => setLanguage(lang)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition border ${
                      isActive
                        ? 'bg-[#FFCC00] border-black text-black shadow-xs'
                        : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    {lang}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Music Chips */}
          <div>
            <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5 mb-2">
              <Music className="w-3.5 h-3.5 text-neutral-500" />
              <span>In-Car Music Vibe</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['Amapiano', 'Gqom', 'Gospel', 'Quiet ride'] as const).map((m) => {
                const isActive = music === m;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMusic(m)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition border ${
                      isActive
                        ? 'bg-black text-[#FFCC00] border-black shadow-xs'
                        : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    {m}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Chat Level Chips */}
          <div>
            <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5 mb-2">
              <MessageSquare className="w-3.5 h-3.5 text-neutral-500" />
              <span>Chat Level</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Chatty', 'Quiet', 'Only directions'] as const).map((c) => {
                const isActive = chatLevel === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setChatLevel(c)}
                    className={`py-2 px-2.5 rounded-xl text-xs font-bold transition border text-center ${
                      isActive
                        ? 'bg-neutral-900 border-neutral-900 text-white shadow-xs'
                        : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    {c}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stop at Spaza Shop Toggle */}
          <div className="flex items-center justify-between bg-neutral-50 p-3 rounded-2xl border border-neutral-200">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center flex-shrink-0">
                <ShoppingBag className="w-4 h-4 text-black" />
              </div>
              <div>
                <span className="text-xs font-bold text-black block leading-tight">
                  Quick Stop at Spaza Shop?
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  Brief 3-min stop on route
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black bg-[#FFCC00] text-black px-1.5 py-0.5 rounded font-mono">
                +R5
              </span>
              <button
                type="button"
                id="toggle-spaza-shop"
                onClick={() => setStopAtSpaza(!stopAtSpaza)}
                className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-200 ease-in-out ${
                  stopAtSpaza ? 'bg-[#FFCC00]' : 'bg-neutral-300'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-black shadow-md transform transition-transform duration-200 ease-in-out ${
                    stopAtSpaza ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </section>

        {/* SECTION 3 - SAFETY KASI */}
        <section className="bg-white rounded-2xl p-4 shadow-sm border border-neutral-200 space-y-3.5">
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-2.5">
            <div className="w-8 h-8 rounded-xl bg-red-100 text-red-700 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-red-600" />
            </div>
            <div>
              <h2 className="text-sm font-black text-black uppercase tracking-wide">
                Safety Kasi
              </h2>
              <span className="text-[10px] text-neutral-500 font-mono">
                Personal security & routing rules
              </span>
            </div>
          </div>

          {/* Share trip with family toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Share2 className="w-4 h-4 text-neutral-600 flex-shrink-0" />
              <div>
                <span className="text-xs font-bold text-neutral-900 block leading-tight">
                  Share trip with family automatically
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  Sends live GPS link to emergency contacts
                </span>
              </div>
            </div>
            <button
              type="button"
              id="toggle-share-family"
              onClick={() => setShareTripFamily(!shareTripFamily)}
              className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-200 ease-in-out ${
                shareTripFamily ? 'bg-black' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-[#FFCC00] shadow-md transform transition-transform duration-200 ease-in-out ${
                  shareTripFamily ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="h-px bg-neutral-100" />

          {/* Female driver at night auto toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Moon className="w-4 h-4 text-neutral-600 flex-shrink-0" />
              <div>
                <span className="text-xs font-bold text-neutral-900 block leading-tight">
                  Female driver priority at night
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  Auto-enforce female drivers after 20:00
                </span>
              </div>
            </div>
            <button
              type="button"
              id="toggle-female-at-night"
              onClick={() => setFemaleDriverAtNight(!femaleDriverAtNight)}
              className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-200 ease-in-out ${
                femaleDriverAtNight ? 'bg-black' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-[#FFCC00] shadow-md transform transition-transform duration-200 ease-in-out ${
                  femaleDriverAtNight ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="h-px bg-neutral-100" />

          {/* Avoid gravel roads toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-neutral-600 flex-shrink-0" />
              <div>
                <span className="text-xs font-bold text-neutral-900 block leading-tight">
                  Avoid unpaved / gravel roads
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  Prefers tarred main roads in township
                </span>
              </div>
            </div>
            <button
              type="button"
              id="toggle-avoid-gravel"
              onClick={() => setAvoidGravelRoads(!avoidGravelRoads)}
              className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-200 ease-in-out ${
                avoidGravelRoads ? 'bg-black' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-[#FFCC00] shadow-md transform transition-transform duration-200 ease-in-out ${
                  avoidGravelRoads ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </section>

        {/* SAVE PREFERENCES BUTTON */}
        <div className="pt-2">
          <button
            type="button"
            id="btn-save-ride-preferences"
            onClick={handleSave}
            disabled={isSaving}
            className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-sm py-4 rounded-2xl shadow-lg border border-yellow-500/30 flex items-center justify-center gap-2 transition active:scale-98 disabled:opacity-50"
          >
            {isSaving ? (
              <span>Saving Preferences...</span>
            ) : (
              <>
                <Check className="w-5 h-5 stroke-[3]" />
                <span>SAVE PREFERENCES</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  User,
  Bell,
  Shield,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  X,
  Phone,
  Mail,
  Tag,
  Gift,
  Check,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { user, setCurrentView, setMode, logout, deleteUser } = useApp();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [safetyAutoShare, setSafetyAutoShare] = useState(true);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [isDeleted, setIsDeleted] = useState(false);

  // Admin Promo state
  const [promoActive, setPromoActive] = useState<boolean>(() => {
    try {
      return localStorage.getItem('promo20') === 'true';
    } catch {
      return false;
    }
  });
  const [promoToast, setPromoToast] = useState<string | null>(null);

  useEffect(() => {
    const handleSync = () => {
      try {
        setPromoActive(localStorage.getItem('promo20') === 'true');
      } catch {}
    };
    window.addEventListener('storage', handleSync);
    window.addEventListener('zolta_promo_updated', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('zolta_promo_updated', handleSync);
    };
  }, []);

  const handleGivePromo = () => {
    try {
      localStorage.setItem('promo20', 'true');
      setPromoActive(true);
      window.dispatchEvent(new Event('zolta_promo_updated'));
      setPromoToast('20% promo voucher granted! Users will get 20% discount on their next ride.');
      setTimeout(() => setPromoToast(null), 3000);
    } catch (e) {
      console.warn('Promo storage error:', e);
    }
  };

  const handleRevokePromo = () => {
    try {
      localStorage.setItem('promo20', 'false');
      setPromoActive(false);
      window.dispatchEvent(new Event('zolta_promo_updated'));
      setPromoToast('Promo voucher revoked.');
      setTimeout(() => setPromoToast(null), 3000);
    } catch (e) {
      console.warn('Promo storage error:', e);
    }
  };

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
  };

  const handleDeleteAccount = () => {
    deleteUser();
    setIsDeleted(true);
    setTimeout(() => {
      setShowDeleteModal(false);
      setIsDeleted(false);
      setCurrentView('home');
    }, 2000);
  };

  return (
    <div id="settings-view" className="flex-1 bg-white text-[#111111] p-4 sm:p-6 max-w-2xl mx-auto w-full pb-24 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-5 pb-3 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-settings"
            onClick={handleGoToRiderPortal}
            className="w-10 h-10 rounded-2xl bg-neutral-100 border border-[#E5E7EB] text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-roman text-2xl sm:text-3xl font-bold text-[#111111] tracking-tight">
              Settings & Account
            </h1>
            <p className="font-mono text-[10px] uppercase text-[#8B8B8B] tracking-wider">
              Profile, Safety & Google Play Compliance
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoToRiderPortal}
          className="w-9 h-9 rounded-2xl bg-[#FFD60A] text-black font-black text-base flex items-center justify-center shadow-xs"
        >
          Z
        </button>
      </div>

      <div className="space-y-4">
        {/* User Profile Info Card */}
        <div className="bg-white rounded-[20px] p-5 border border-[#E5E7EB] shadow-xs">
          <h3 className="font-roman text-lg font-bold text-black mb-3">User Profile</h3>
          <div className="flex items-center gap-3.5 mb-4">
            <div className="w-12 h-12 rounded-full bg-[#FFD60A] text-black font-black text-2xl flex items-center justify-center shadow-xs flex-shrink-0">
              S
            </div>
            <div>
              <h4 className="font-black text-sm text-black">SGQAMLANA13</h4>
              <p className="font-mono text-xs text-neutral-500">sgqamlana13@gmail.com</p>
              <div className="mt-1">
                <span className="bg-emerald-50 text-emerald-800 border border-emerald-300 font-mono text-[9px] font-bold px-2 py-0.5 rounded-full uppercase">
                  TIER 1 RIDER SAFETY
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
              <span className="text-[10px] text-[#8B8B8B] block uppercase">PHONE</span>
              <strong className="text-black">+27 82 555 1313</strong>
            </div>
            <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
              <span className="text-[10px] text-[#8B8B8B] block uppercase">COUNTRY</span>
              <strong className="text-black">South Africa (ZAR)</strong>
            </div>
          </div>
        </div>

        {/* Preferences */}
        <div className="bg-white rounded-[20px] p-5 border border-[#E5E7EB] shadow-xs space-y-3">
          <h3 className="font-roman text-lg font-bold text-black">App Preferences</h3>

          <div className="flex items-center justify-between py-2 border-b border-neutral-100">
            <div>
              <p className="text-xs font-bold text-black">Trip Push Notifications</p>
              <p className="font-mono text-[10px] text-neutral-500">Driver arrival, offers and receipt alerts</p>
            </div>
            <button
              type="button"
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className={`w-12 h-6 rounded-full relative transition ${notificationsEnabled ? 'bg-[#FFD60A]' : 'bg-neutral-200'}`}
            >
              <span className={`w-5 h-5 rounded-full absolute top-0.5 transition ${notificationsEnabled ? 'bg-black right-0.5' : 'bg-white left-0.5'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between py-2">
            <div>
              <p className="text-xs font-bold text-black">Automatic Safety GPS Sharing</p>
              <p className="font-mono text-[10px] text-neutral-500">Send live tracking link to emergency contact</p>
            </div>
            <button
              type="button"
              onClick={() => setSafetyAutoShare(!safetyAutoShare)}
              className={`w-12 h-6 rounded-full relative transition ${safetyAutoShare ? 'bg-[#FFD60A]' : 'bg-neutral-200'}`}
            >
              <span className={`w-5 h-5 rounded-full absolute top-0.5 transition ${safetyAutoShare ? 'bg-black right-0.5' : 'bg-white left-0.5'}`} />
            </button>
          </div>
        </div>

        {/* Admin Promo & Voucher Management */}
        <div className="bg-[#FAF5FF] rounded-[20px] p-5 border border-[#DDD6FE] shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-100 flex items-center justify-center">
                <Gift className="w-4 h-4 text-purple-700" />
              </div>
              <div>
                <h3 className="font-roman text-base font-bold text-purple-950">
                  Admin Promo Voucher Controls
                </h3>
                <p className="font-mono text-[10px] text-purple-700 uppercase">
                  Bolt-style 20% discount management
                </p>
              </div>
            </div>

            <span
              className={`font-mono text-[9px] font-black px-2 py-0.5 rounded-full uppercase border ${
                promoActive
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : 'bg-neutral-100 text-neutral-600 border-neutral-300'
              }`}
            >
              {promoActive ? 'PROMO ACTIVE (20%)' : 'NO ACTIVE PROMO'}
            </span>
          </div>

          <p className="text-xs text-purple-900 leading-relaxed font-medium">
            Grant a single-use 20% discount on the next scheduled ride (sets <code className="font-mono bg-purple-200/60 px-1 py-0.5 rounded text-[11px]">promo20 = true</code> in storage). When applied, users will see the purple Bolt banner, 20% reduced fares (e.g. R25 becomes R20), and 20% OFF badge on FIND OFFER.
          </p>

          {promoToast && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
              <span>{promoToast}</span>
            </div>
          )}

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              id="btn-admin-give-promo"
              onClick={handleGivePromo}
              className="flex-1 bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-mono font-bold text-xs py-3 rounded-xl transition active:scale-95 uppercase tracking-wider shadow-xs flex items-center justify-center gap-2"
            >
              <Tag className="w-4 h-4 text-white" />
              <span>GIVE USERS 20% PROMO</span>
            </button>

            {promoActive && (
              <button
                type="button"
                id="btn-admin-revoke-promo"
                onClick={handleRevokePromo}
                className="px-3.5 bg-white hover:bg-neutral-100 border border-purple-200 text-purple-800 font-mono font-bold text-xs py-3 rounded-xl transition active:scale-95 uppercase"
                title="Revoke promo"
              >
                REVOKE
              </button>
            )}
          </div>
        </div>

        {/* Legal & Data Safety (Google Play Ready) */}
        <div className="bg-white rounded-[20px] p-5 border border-[#E5E7EB] shadow-xs space-y-3">
          <h3 className="font-roman text-lg font-bold text-black">Legal & Data Safety</h3>

          <button
            type="button"
            id="btn-settings-view-privacy"
            onClick={() => setCurrentView('support')}
            className="w-full p-3 bg-neutral-50 hover:bg-neutral-100 rounded-xl border border-neutral-200 flex items-center justify-between transition text-left"
          >
            <div className="flex items-center gap-2.5">
              <Shield className="w-4 h-4 text-emerald-600" />
              <div>
                <span className="text-xs font-bold text-black block">Privacy Policy & POPIA Disclosure</span>
                <span className="text-[10px] text-neutral-500 font-mono">Data collection, location & retention rules</span>
              </div>
            </div>
            <span className="text-[10px] font-mono font-bold bg-[#FFD60A] text-black px-2 py-0.5 rounded-md">
              VIEW
            </span>
          </button>

          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between text-xs font-mono">
            <div>
              <span className="text-[10px] text-[#8B8B8B] block uppercase">APP VERSION</span>
              <strong className="text-black">v2.4.0 (Build 2026.08.24)</strong>
            </div>
            <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-full uppercase">
              PLAY STORE READY
            </span>
          </div>
        </div>

        {/* Account Deletion (Google Play Mandate) */}
        <div className="bg-red-50/50 rounded-[20px] p-5 border border-red-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <Trash2 className="w-5 h-5 text-red-600" />
            <h3 className="font-roman text-lg font-bold text-red-900">
              Delete Account Permanently
            </h3>
          </div>
          <p className="font-mono text-xs text-red-700 leading-relaxed">
            In compliance with Google Play Developer Policies, you may immediately erase all personal records, active requests, wallet balances, and trip history. This action cannot be undone.
          </p>
          <button
            type="button"
            id="btn-open-delete-account-modal"
            onClick={() => setShowDeleteModal(true)}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-mono font-bold text-xs py-3 rounded-xl transition active:scale-95 uppercase tracking-wider shadow-xs"
          >
            DELETE MY ZOLTA ACCOUNT
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] text-[#111111] w-full max-w-md rounded-[20px] p-6 shadow-2xl relative space-y-4">
            <button
              type="button"
              onClick={() => setShowDeleteModal(false)}
              className="absolute top-5 right-5 p-1 text-neutral-400 hover:text-black"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-roman text-xl font-bold text-black">Confirm Account Deletion</h4>
                <p className="font-mono text-[10px] text-neutral-500 uppercase">Irreversible action</p>
              </div>
            </div>

            {isDeleted ? (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-4 rounded-xl text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="font-bold text-sm">Account Permanently Deleted</p>
                <p className="text-xs text-emerald-700">All personal records have been erased in compliance with Google Play & POPIA. Redirecting...</p>
              </div>
            ) : (
              <>
                <p className="text-xs text-neutral-700 leading-relaxed">
                  Are you sure you want to delete profile <strong className="text-black">SGQAMLANA13</strong>? All data will be permanently wiped immediately.
                </p>

                <div className="space-y-2 pt-2">
                  <button
                    type="button"
                    id="btn-confirm-delete-account"
                    onClick={handleDeleteAccount}
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-mono font-bold text-xs py-3.5 rounded-xl uppercase tracking-wider transition active:scale-95 shadow-xs cursor-pointer"
                  >
                    YES, DELETE EVERYTHING NOW
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowDeleteModal(false)}
                    className="w-full bg-neutral-100 hover:bg-neutral-200 text-black font-mono font-bold text-xs py-3 rounded-xl transition cursor-pointer"
                  >
                    CANCEL
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

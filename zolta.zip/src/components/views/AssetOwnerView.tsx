import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Wrench,
  Package,
  ChevronRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const AssetOwnerView: React.FC = () => {
  const { setCurrentView, setMode } = useApp();

  const handleGoBack = () => {
    setMode('rider');
    setCurrentView('home');
  };

  return (
    <div id="asset-owner-view" className="max-w-4xl mx-auto p-4 sm:p-6 pb-24 text-neutral-900 bg-[#FFFBEB] select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-amber-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-asset-owner"
            onClick={handleGoBack}
            className="w-10 h-10 rounded-2xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight font-sans">
              Asset Owners
            </h1>
            <p className="font-mono text-[10px] uppercase text-neutral-500 tracking-wider">
              Community Services & Equipment • South Africa 🇿🇦
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoBack}
          className="w-9 h-9 rounded-2xl bg-[#FFCC00] text-black font-black text-base flex items-center justify-center shadow-xs"
        >
          Z
        </button>
      </div>

      {/* Safety Badge */}
      <div className="bg-neutral-900 text-white rounded-[24px] p-5 sm:p-6 mb-6 shadow-sm border border-neutral-800">
        <div className="flex items-center gap-2 text-[#FFCC00] text-xs font-mono font-bold uppercase mb-2">
          <ShieldCheck className="w-4 h-4" />
          <span>Vetted Community Network</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white font-sans mb-1">
          Community Equipment & Roadside Services
        </h2>
        <p className="text-xs text-neutral-300 font-sans leading-relaxed">
          Access or register trusted community services across South Africa. Choose from Towing Assistance or Trailer Hiring below.
        </p>
      </div>

      {/* EXACT 2 ITEMS ONLY: Towing Assistance & Trailer Hiring */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* ITEM 1: Towing Assistance */}
        <div
          id="asset-card-towing-assistance"
          className="bg-white rounded-[24px] p-6 border border-amber-200 shadow-xs flex flex-col justify-between hover:border-amber-400 transition"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center">
                <Wrench className="w-7 h-7" />
              </div>
              <span className="bg-amber-100 text-amber-900 border border-amber-300 font-mono text-[10px] font-bold px-3 py-1 rounded-full uppercase">
                24/7 ROADSIDE
              </span>
            </div>

            <h3 className="text-xl font-bold text-neutral-900 mb-1.5 font-sans">
              Towing Assistance
            </h3>
            <p className="text-xs text-neutral-600 mb-4 font-sans leading-relaxed">
              24/7 Breakdown, Accident rollback towing, battery jump starts, flat tyre replacement, and emergency recovery operators across South Africa.
            </p>

            <div className="bg-amber-50/60 p-3 rounded-xl border border-amber-200 text-xs font-mono text-neutral-700 space-y-1 mb-5">
              <div className="flex items-center gap-1.5 text-neutral-900 font-bold">
                <Zap className="w-3.5 h-3.5 text-[#FFCC00]" />
                <span>Fixed Transparent Rates</span>
              </div>
              <p className="text-[11px] text-neutral-500">• Fast GPS rollback dispatch</p>
              <p className="text-[11px] text-neutral-500">• Towing company operator portal</p>
            </div>
          </div>

          <button
            type="button"
            id="btn-open-towing-assistance"
            onClick={() => setCurrentView('towing')}
            className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3.5 rounded-xl uppercase tracking-wider font-mono shadow-xs transition active:scale-95 flex items-center justify-center gap-2"
          >
            <span>Open Towing Assistance</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* ITEM 2: Trailer Hiring */}
        <div
          id="asset-card-trailer-hiring"
          className="bg-white rounded-[24px] p-6 border border-amber-200 shadow-xs flex flex-col justify-between hover:border-amber-400 transition"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 text-black flex items-center justify-center">
                <Package className="w-7 h-7" />
              </div>
              <span className="bg-[#FFCC00] text-black font-mono text-[10px] font-bold px-3 py-1 rounded-full uppercase">
                EQUIPMENT HIRE
              </span>
            </div>

            <h3 className="text-xl font-bold text-neutral-900 mb-1.5 font-sans">
              Trailer Hiring
            </h3>
            <p className="text-xs text-neutral-600 mb-4 font-sans leading-relaxed">
              Rent luggage, utility, car transporter, flatbed, and double-axle trailers. View hour/day/week/month rates, fetch or request delivery.
            </p>

            <div className="bg-amber-50/60 p-3 rounded-xl border border-amber-200 text-xs font-mono text-neutral-700 space-y-1 mb-5">
              <div className="flex items-center gap-1.5 text-neutral-900 font-bold">
                <Zap className="w-3.5 h-3.5 text-[#FFCC00]" />
                <span>Hourly / Daily / Monthly Rates</span>
              </div>
              <p className="text-[11px] text-neutral-500">• Fetch trailer or deliver to you</p>
              <p className="text-[11px] text-neutral-500">• Trailer owner registration portal</p>
            </div>
          </div>

          <button
            type="button"
            id="btn-open-trailer-hiring"
            onClick={() => setCurrentView('trailer_hiring')}
            className="w-full bg-neutral-900 hover:bg-black text-white font-black text-xs py-3.5 rounded-xl uppercase tracking-wider font-mono shadow-xs transition active:scale-95 flex items-center justify-center gap-2"
          >
            <span>Open Trailer Hiring</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

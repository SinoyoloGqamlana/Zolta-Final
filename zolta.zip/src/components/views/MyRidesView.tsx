import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { RideRequest } from '../../types';
import { ReceiptModal } from '../common/ReceiptModal';
import { db, auth } from '../../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { Clock, Receipt, ArrowLeft, Loader2, RefreshCw } from 'lucide-react';

export const MyRidesView: React.FC = () => {
  const { user, mode, ridesHistory, setCurrentView, setMode, createRideRequest } = useApp();
  const [filter, setFilter] = useState<'all' | 'completed' | 'cancelled'>('all');
  const [selectedReceiptRide, setSelectedReceiptRide] = useState<RideRequest | null>(null);
  const [firestoreRides, setFirestoreRides] = useState<RideRequest[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const currentUid = auth?.currentUser?.uid || user.id;

  // Real-time Firestore subscription for trips (Rider or Driver mode)
  useEffect(() => {
    let unsubscribe: (() => void) | null = null;
    setIsLoading(true);

    if (!db || !currentUid) {
      setIsLoading(false);
      return;
    }

    try {
      const tripsRef = collection(db, 'trips');
      // For rider mode query by userId, for driver mode query by driverId
      const fieldToQuery = mode === 'driver' ? 'driverId' : 'userId';
      const q = query(tripsRef, where(fieldToQuery, '==', currentUid));

      unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const list: RideRequest[] = [];
          snapshot.forEach((docSnap) => {
            try {
              const data = docSnap.data();
              list.push({ id: docSnap.id, ...data } as RideRequest);
            } catch (e) {
              console.warn('Error parsing trip doc:', e);
            }
          });
          setFirestoreRides(list);
          setIsLoading(false);
        },
        (err) => {
          console.warn('Firestore rides subscription error:', err);
          setIsLoading(false);
        }
      );
    } catch (err) {
      console.warn('Failed to subscribe to rides:', err);
      setIsLoading(false);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [currentUid, mode]);

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
  };

  // Combine Firestore rides with context ridesHistory safely
  const rawRidesList = firestoreRides.length > 0 ? firestoreRides : ridesHistory;

  // Filter rides safely
  const filteredRides = (Array.isArray(rawRidesList) ? rawRidesList : []).filter((r) => {
    if (!r) return false;
    const status = (r.status || 'searching').toLowerCase();
    if (filter === 'all') return true;
    if (filter === 'completed') return status === 'completed';
    if (filter === 'cancelled') return status === 'cancelled';
    return true;
  });

  // Safe helper to format date
  const formatRideDate = (ride: RideRequest) => {
    try {
      let rawDate: any = ride.createdAt;
      if (!rawDate) return 'Recent Trip';
      if (typeof rawDate === 'object' && rawDate.seconds) {
        rawDate = rawDate.seconds * 1000;
      }
      const d = new Date(rawDate);
      if (isNaN(d.getTime())) return 'Recent Trip';
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return 'Recent Trip';
    }
  };

  // Safe helper to format pickup address
  const getPickupAddr = (ride: RideRequest) => {
    try {
      return ride.pickup?.address || (ride as any).pickupLocation?.address || 'Ngaba Ngaba Crescent, Ilitha Park';
    } catch {
      return 'Ilitha Park, Khayelitsha';
    }
  };

  // Safe helper to format dropoff address
  const getDropoffAddr = (ride: RideRequest) => {
    try {
      return ride.dropoff?.address || (ride as any).destination?.address || 'Khayelitsha Mall';
    } catch {
      return 'Khayelitsha';
    }
  };

  return (
    <div id="my-rides-view" className="max-w-3xl mx-auto p-4 sm:p-6 pb-24 text-[#111111] bg-white select-none min-h-[80vh]">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-my-trips"
            onClick={handleGoToRiderPortal}
            className="w-10 h-10 rounded-2xl bg-neutral-100 border border-[#E5E7EB] text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-roman text-2xl sm:text-3xl font-bold text-[#111111] tracking-tight">
              My Trips & Receipts
            </h1>
            <p className="font-mono text-[10px] uppercase text-[#8B8B8B] tracking-wider">
              {mode === 'driver' ? 'Driver Accepted Rides' : 'Rider History & Receipts'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoToRiderPortal}
          className="w-9 h-9 rounded-2xl bg-[#FFD60A] text-black font-black text-sm flex items-center justify-center shadow-xs hover:bg-yellow-400 transition"
        >
          Z
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-6">
        {(['all', 'completed', 'cancelled'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            id={`filter-rides-${tab}`}
            onClick={() => setFilter(tab)}
            className={`capitalize px-4 py-2 rounded-xl text-xs font-black font-mono transition ${
              filter === tab
                ? 'bg-[#FFD60A] text-black shadow-xs'
                : 'bg-neutral-100 text-neutral-600 border border-neutral-200 hover:bg-neutral-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Loading Spinner State */}
      {isLoading ? (
        <div className="bg-neutral-50 rounded-3xl p-12 text-center border border-neutral-200 shadow-xs flex flex-col items-center justify-center my-8">
          <Loader2 className="w-8 h-8 text-[#FFD60A] animate-spin mb-3 stroke-[2.5]" />
          <p className="text-xs font-mono font-bold text-neutral-600">Loading your trips...</p>
        </div>
      ) : filteredRides.length === 0 ? (
        /* Empty State UI */
        <div className="bg-neutral-50 rounded-3xl p-10 sm:p-12 text-center border border-neutral-200 shadow-xs my-4">
          <div className="w-16 h-16 rounded-3xl bg-amber-100/80 text-amber-900 flex items-center justify-center mx-auto mb-4">
            <Clock className="w-8 h-8 text-black stroke-[2]" />
          </div>
          <h4 className="font-bold text-base text-neutral-900 mb-1">
            No trips yet - Your first Kasi ride awaits
          </h4>
          <p className="text-xs text-neutral-500 mb-6 font-mono max-w-sm mx-auto">
            Your rides from Ilitha Park will appear here
          </p>
          <button
            type="button"
            id="btn-request-first-ride"
            onClick={handleGoToRiderPortal}
            className="bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs px-6 py-3 rounded-2xl shadow-md transition active:scale-95 font-mono uppercase tracking-wide inline-flex items-center gap-2"
          >
            Request First Ride
          </button>
        </div>
      ) : (
        /* Rides List */
        <div className="space-y-4">
          {filteredRides.map((ride, idx) => {
            const fare = ride.offeredFare || (ride as any).total || 0;
            const categoryName = (ride.category || (ride as any).serviceType || 'rider').toString().toUpperCase();
            const rideStatus = (ride.status || 'searching').toString().toUpperCase();

            return (
              <div
                key={`${ride.id || 'ride'}_${idx}`}
                className="bg-white rounded-3xl p-5 border border-neutral-200 shadow-xs hover:border-neutral-400 transition flex flex-col justify-between gap-4"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[11px] font-mono font-bold text-neutral-500">
                      {formatRideDate(ride)}
                    </span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="font-black text-base text-[#111111] capitalize font-roman">
                        {categoryName}
                      </span>
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                          rideStatus === 'COMPLETED'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                            : rideStatus === 'CANCELLED'
                            ? 'bg-red-50 text-red-700 border border-red-200'
                            : 'bg-amber-50 text-amber-800 border border-amber-300'
                        }`}
                      >
                        {rideStatus}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xl font-black text-[#111111] font-mono">
                      R{fare.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-neutral-500 uppercase font-mono font-semibold block">
                      {ride.paymentMethod || 'cash'}
                    </span>
                  </div>
                </div>

                {/* Route Summary */}
                <div className="bg-neutral-50 p-3 rounded-2xl space-y-2 text-xs border border-neutral-200 font-mono">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#FFD60A] flex-shrink-0" />
                    <span className="text-neutral-800 font-medium truncate">{getPickupAddr(ride)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
                    <span className="text-neutral-800 font-medium truncate">{getDropoffAddr(ride)}</span>
                  </div>
                </div>

                {/* Driver & Action Footer */}
                <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
                  {ride.acceptedDriver ? (
                    <div className="flex items-center gap-2">
                      <img
                        src={ride.acceptedDriver.avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'}
                        alt={ride.acceptedDriver.name || 'Driver'}
                        referrerPolicy="no-referrer"
                        className="w-7 h-7 rounded-full object-cover border border-[#FFD60A]"
                      />
                      <span className="text-xs font-bold text-neutral-800">
                        {ride.acceptedDriver.name} ({ride.acceptedDriver.carModel || 'VW Polo'})
                      </span>
                    </div>
                  ) : (
                    <span className="text-xs text-neutral-500">Driver unassigned</span>
                  )}

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedReceiptRide(ride)}
                      className="text-xs font-bold text-neutral-700 hover:text-black border border-neutral-200 px-3 py-1.5 rounded-xl hover:bg-neutral-100 transition flex items-center gap-1 font-mono"
                    >
                      <Receipt className="w-3.5 h-3.5" />
                      <span>Receipt</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        createRideRequest({
                          pickup: ride.pickup,
                          dropoff: ride.dropoff,
                          category: ride.category || 'rider',
                          offeredFare: fare,
                          suggestedFare: ride.suggestedFare || fare,
                          comments: ride.comments || '',
                          passengerCount: ride.passengerCount || 1,
                          paymentMethod: ride.paymentMethod || 'cash',
                        });
                        handleGoToRiderPortal();
                      }}
                      className="text-xs font-black bg-[#FFD60A] text-black px-3 py-1.5 rounded-xl hover:bg-yellow-400 transition shadow-xs font-mono"
                    >
                      Re-Offer
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Receipt Modal */}
      {selectedReceiptRide && (
        <ReceiptModal
          ride={selectedReceiptRide}
          onClose={() => setSelectedReceiptRide(null)}
        />
      )}
    </div>
  );
};

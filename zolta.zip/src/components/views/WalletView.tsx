import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { auth, db } from '../../firebase';
import { doc, onSnapshot, collection, query, where } from 'firebase/firestore';
import {
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  CreditCard,
  Building,
  ArrowLeft,
  CheckCircle2,
  X,
  ShieldCheck,
  Zap,
  RefreshCw,
  Database,
  Layers,
  Check,
} from 'lucide-react';
import {
  calculateCommissionSplit,
  runPaystackCommissionTest,
  PaystackTestResult,
} from '../../services/paystackService';

export interface FirestoreTransaction {
  id: string;
  type?: string;
  amount?: number;
  description?: string;
  date?: string | number;
  timestamp?: number;
  createdAt?: any;
}

export const WalletView: React.FC = () => {
  const { user, walletTransactions, topUpWallet, setCurrentView, setMode } = useApp();
  const [balance, setBalance] = useState<number>(0);
  const [transactions, setTransactions] = useState<FirestoreTransaction[]>([]);
  const [isTopUpModalOpen, setIsTopUpModalOpen] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState(150);

  // Live Commission Test State
  const [testCategory, setTestCategory] = useState<'RIDER' | 'COMFORT' | 'XL' | 'SCOOTER'>('RIDER');
  const [testAmount, setTestAmount] = useState(150);
  const [isTestingCommission, setIsTestingCommission] = useState(false);
  const [testResult, setTestResult] = useState<PaystackTestResult | null>(null);
  const [testError, setTestError] = useState<string | null>(null);

  // 1 & 2. Listen to wallets/{uid} doc from Firestore
  useEffect(() => {
    const currentUser = auth?.currentUser;
    const uid = currentUser?.uid || user?.id;
    if (!db || !uid) {
      setBalance(0);
      return;
    }

    const walletRef = doc(db, 'wallets', uid);
    const unsubWallet = onSnapshot(
      walletRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (typeof data.balance === 'number') {
            setBalance(data.balance);
          } else if (typeof data.walletBalance === 'number') {
            setBalance(data.walletBalance);
          } else {
            setBalance(0);
          }
        } else {
          setBalance(0);
        }
      },
      (err) => {
        console.warn('Error fetching wallet in WalletView:', err);
        setBalance(0);
      }
    );

    return () => unsubWallet();
  }, [user?.id]);

  // 5. Fetch transactions from Firestore where userId == uid
  useEffect(() => {
    const currentUser = auth?.currentUser;
    const uid = currentUser?.uid || user?.id;
    if (!db || !uid) {
      setTransactions([]);
      return;
    }

    const txRef = collection(db, 'transactions');
    const q = query(txRef, where('userId', '==', uid));

    const unsubTx = onSnapshot(
      q,
      (snapshot) => {
        const txList: FirestoreTransaction[] = [];
        snapshot.forEach((d) => {
          txList.push({ id: d.id, ...d.data() } as FirestoreTransaction);
        });
        // Sort by timestamp or date desc client-side
        txList.sort((a, b) => {
          const timeA = a.timestamp || (a.createdAt?.toMillis ? a.createdAt.toMillis() : (a.date ? new Date(a.date).getTime() : 0));
          const timeB = b.timestamp || (b.createdAt?.toMillis ? b.createdAt.toMillis() : (b.date ? new Date(b.date).getTime() : 0));
          return timeB - timeA;
        });
        setTransactions(txList);
      },
      (err) => {
        console.warn('Error fetching transactions from Firestore:', err);
        setTransactions([]);
      }
    );

    return () => unsubTx();
  }, [user?.id]);

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
  };

  const handleTopUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    topUpWallet(topUpAmount);
    setIsTopUpModalOpen(false);
  };

  const handleExecuteTest = async () => {
    setIsTestingCommission(true);
    setTestError(null);
    try {
      const res = await runPaystackCommissionTest(testCategory, testAmount);
      setTestResult(res);
    } catch (err: any) {
      console.error('Test commission error:', err);
      setTestError(err?.message || 'Failed to complete commission test in Firestore');
    } finally {
      setIsTestingCommission(false);
    }
  };

  const currentPreviewSplit = calculateCommissionSplit(testCategory, testAmount);

  const displayTransactions = transactions.length > 0 ? transactions : walletTransactions;

  return (
    <div id="wallet-view" className="max-w-3xl mx-auto p-4 sm:p-6 pb-24 text-neutral-900 bg-[#FFFBEB] select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-amber-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-wallet"
            onClick={handleGoToRiderPortal}
            className="w-10 h-10 rounded-2xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight font-sans">
              ZOLTA Wallet
            </h1>
            <p className="font-mono text-[10px] uppercase text-neutral-500 tracking-wider">
              Instant Payouts & Driver Earnings (ZAR)
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoToRiderPortal}
          className="w-9 h-9 rounded-2xl bg-[#FFCC00] text-black font-black text-base flex items-center justify-center shadow-xs"
        >
          Z
        </button>
      </div>

      {/* Balance Card */}
      <div className="bg-neutral-950 text-white rounded-[24px] p-6 sm:p-8 mb-6 relative overflow-hidden shadow-lg border border-neutral-800">
        <div className="flex justify-between items-start mb-6">
          <div>
            <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-widest block mb-1">
              Available Balance
            </span>
            <div className="text-4xl sm:text-5xl font-black text-white font-mono tracking-tight">
              R {(balance || 0).toFixed(2)}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-400">
              <ShieldCheck className="w-4 h-4 text-[#FFCC00]" />
              <span>South African Rand (ZAR) • Instant Settlement</span>
            </div>
          </div>

          <button
            type="button"
            id="btn-open-topup"
            onClick={() => setIsTopUpModalOpen(true)}
            className="bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 shadow-sm transition active:scale-95 font-mono"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Top Up</span>
          </button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-neutral-800 text-xs font-mono">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-800/50 flex items-center justify-center text-emerald-400">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-neutral-400 block">Total Credited</span>
              <span className="font-bold text-white">R {(balance || 0).toFixed(2)}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-950 border border-amber-800/50 flex items-center justify-center text-[#FFCC00]">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-neutral-400 block">Commission Rate</span>
              <span className="font-bold text-white">10% Platform Fee</span>
            </div>
          </div>
        </div>
      </div>

      {/* Paystack Commission Details */}
      <div className="bg-neutral-900 text-white rounded-[24px] p-6 mb-6 border border-neutral-800 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-mono text-sm font-bold text-white">
                Paystack Commission Distribution (10%)
              </h3>
              <p className="font-mono text-[10px] text-neutral-400">
                Automated Firestore settlement on trip completion
              </p>
            </div>
          </div>
        </div>

        {/* Commission Rate Summary */}
        <div className="bg-neutral-800/80 p-3 rounded-xl border border-neutral-700/60 mb-4">
          <div className="flex items-center justify-between mb-1">
            <span className="font-mono text-[11px] font-bold text-neutral-300 uppercase">
              Rides Commission
            </span>
            <span className="bg-[#FFCC00] text-black font-mono text-[10px] font-black px-2 py-0.5 rounded">
              10% COMMISSION
            </span>
          </div>
          <p className="text-[10px] text-neutral-400 font-mono">
            RIDER, COMFORT, XL, SCOOTER
          </p>
        </div>

        {/* Live Test Console */}
        <div className="bg-black/60 p-4 rounded-xl border border-neutral-700">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono font-bold text-neutral-300 uppercase flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-[#FFCC00]" />
              <span>TEST LIVE COMMISSION SPLIT</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase mb-1">
                Select Ride Category:
              </label>
              <select
                value={testCategory}
                onChange={(e) => setTestCategory(e.target.value as any)}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-2 text-xs font-mono text-white outline-none focus:border-[#FFCC00]"
              >
                <option value="RIDER">RIDER (10% Commission)</option>
                <option value="COMFORT">COMFORT (10% Commission)</option>
                <option value="XL">XL (10% Commission)</option>
                <option value="SCOOTER">SCOOTER (10% Commission)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase mb-1">
                Trip Amount (ZAR):
              </label>
              <div className="flex items-center gap-2">
                {[100, 250, 500].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setTestAmount(amt)}
                    className={`flex-1 py-2 rounded-lg text-xs font-mono font-bold transition ${
                      testAmount === amt
                        ? 'bg-[#FFCC00] text-black'
                        : 'bg-neutral-800 text-neutral-300 border border-neutral-700 hover:bg-neutral-700'
                    }`}
                  >
                    R{amt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Mathematical preview */}
          <div className="bg-neutral-900 p-3 rounded-lg border border-neutral-800 mb-3 grid grid-cols-3 gap-2 text-center font-mono">
            <div>
              <span className="text-[9px] text-neutral-400 uppercase block">Gross Fare</span>
              <span className="text-xs font-bold text-white">R {(currentPreviewSplit?.grossAmount || 0).toFixed(2)}</span>
            </div>
            <div>
              <span className="text-[9px] text-amber-400 uppercase block">Zolta (10%)</span>
              <span className="text-xs font-bold text-[#FFCC00]">R {(currentPreviewSplit?.zoltaCommission || 0).toFixed(2)}</span>
            </div>
            <div>
              <span className="text-[9px] text-emerald-400 uppercase block">Driver Payout</span>
              <span className="text-xs font-bold text-emerald-400">R {(currentPreviewSplit?.driverPayout || 0).toFixed(2)}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleExecuteTest}
            disabled={isTestingCommission}
            className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-mono font-black text-xs py-2.5 rounded-lg flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            {isTestingCommission ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Running Settlement Test...</span>
              </>
            ) : (
              <>
                <Zap className="w-3.5 h-3.5" />
                <span>RUN LIVE TEST</span>
              </>
            )}
          </button>

          {testResult && (
            <div className="mt-3 p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-lg text-[11px] font-mono text-emerald-200 space-y-1">
              <p className="font-bold flex items-center gap-1 text-emerald-400">
                <Check className="w-3.5 h-3.5" /> {testResult.message}
              </p>
              <p>• Trip ID: {testResult.testTripId}</p>
              <p>• Driver Payout: R {(testResult.driverPayout || 0).toFixed(2)}</p>
              <p>• Zolta 10% Commission: R {(testResult.zoltaCommission || 0).toFixed(2)}</p>
            </div>
          )}

          {testError && (
            <div className="mt-3 p-3 bg-red-950 border border-red-500/40 rounded-lg text-xs text-red-300 font-mono">
              {testError}
            </div>
          )}
        </div>
      </div>

      {/* Transaction History */}
      <div className="bg-white rounded-[24px] p-6 border border-amber-200 shadow-xs">
        <h3 className="font-bold text-base text-neutral-900 mb-4 font-sans">
          Recent Activity
        </h3>

        {displayTransactions.length === 0 ? (
          <div className="py-8 text-center text-neutral-400 text-xs font-mono">
            No transactions yet. Complete trips to view earnings.
          </div>
        ) : (
          <div className="space-y-3">
            {displayTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-3 rounded-xl bg-amber-50/50 border border-amber-100"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    tx.type === 'topup' ? 'bg-emerald-100 text-emerald-700' : 'bg-neutral-100 text-neutral-700'
                  }`}>
                    {tx.type === 'topup' ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-neutral-900">{tx.description || 'Transaction'}</h4>
                    <span className="text-[10px] text-neutral-500 font-mono">
                      {tx.timestamp ? new Date(tx.timestamp).toLocaleDateString('en-ZA') : (tx.date ? String(tx.date) : 'Recent')}
                    </span>
                  </div>
                </div>

                <div className={`text-xs font-black font-mono ${
                  tx.type === 'topup' ? 'text-emerald-700' : 'text-neutral-900'
                }`}>
                  {tx.type === 'topup' ? '+' : '-'}R {(tx.amount || 0).toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Top Up Modal */}
      {isTopUpModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white text-neutral-900 w-full max-w-sm rounded-[24px] p-6 shadow-xl border border-amber-200 relative">
            <button
              type="button"
              onClick={() => setIsTopUpModalOpen(false)}
              className="absolute top-4 right-4 p-1 text-neutral-400 hover:text-black"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black mb-1 font-sans">Top Up Wallet</h3>
            <p className="text-xs text-neutral-500 mb-4 font-mono">
              Add funds securely via Paystack / Card / EFT
            </p>

            <form onSubmit={handleTopUpSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-mono font-bold uppercase text-neutral-600 block mb-1">
                  Amount in ZAR (R)
                </label>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {[50, 150, 300].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setTopUpAmount(amt)}
                      className={`py-2 rounded-xl text-xs font-mono font-bold border ${
                        topUpAmount === amt
                          ? 'bg-[#FFCC00] text-black border-yellow-400'
                          : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                      }`}
                    >
                      R{amt}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="20"
                  max="5000"
                  value={topUpAmount}
                  onChange={(e) => setTopUpAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm font-bold font-mono outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs py-3.5 rounded-xl uppercase tracking-wider transition"
              >
                Confirm Top Up (R {topUpAmount})
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};


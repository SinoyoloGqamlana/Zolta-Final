import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  HelpCircle,
  Send,
  ArrowLeft,
  MessageSquare,
  ShieldCheck,
  ChevronDown,
  Lock,
  FileText,
  Trash2,
  CheckCircle2,
} from 'lucide-react';

interface SupportMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export const SupportView: React.FC = () => {
  const { setCurrentView, setMode } = useApp();
  const [activeTab, setActiveTab] = useState<'chat' | 'privacy'>('privacy');
  const [messages, setMessages] = useState<SupportMessage[]>([
    {
      id: 'bot_1',
      sender: 'bot',
      text: 'Hello! I am your ZOLTA Support Assistant. How can I assist you with your rides, safety verification, or account today?',
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
  };

  const faqs = [
    {
      q: 'How does ZOLTA verify drivers?',
      a: 'All ZOLTA drivers undergo South African ID and driver license verification before they can accept rides on the platform.',
    },
    {
      q: 'How does phone verification protect me?',
      a: 'Every rider and driver signs in with a verified South African phone number (+27) via SMS OTP, ensuring safety and accountability.',
    },
    {
      q: 'How is my data protected under POPIA?',
      a: 'Your personal data is encrypted and processed in strict compliance with South Africa’s Protection of Personal Information Act (POPIA). We never sell your data.',
    },
  ];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg: SupportMessage = {
      id: 'u_' + Date.now(),
      sender: 'user',
      text: input,
      timestamp: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');

    setTimeout(() => {
      const botMsg: SupportMessage = {
        id: 'b_' + Date.now(),
        sender: 'bot',
        text: 'Thank you for reaching out. A ZOLTA support specialist will assist you promptly. Your safety and privacy are our top priorities.',
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, botMsg]);
    }, 600);
  };

  return (
    <div id="support-view" className="flex-1 bg-[#FFFBEB] text-neutral-900 p-4 sm:p-6 max-w-2xl mx-auto w-full pb-24 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-5 pb-3 border-b border-amber-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="btn-back-support"
            onClick={handleGoToRiderPortal}
            className="w-10 h-10 rounded-2xl bg-white border border-amber-200 text-neutral-800 hover:text-black flex items-center justify-center transition active:scale-95 shadow-xs"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight font-sans">
              Privacy Policy & Support
            </h1>
            <p className="font-mono text-[10px] uppercase text-neutral-500 tracking-wider">
              Safety First • Trusted in SA 🇿🇦
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleGoToRiderPortal}
          className="w-9 h-9 rounded-2xl bg-[#FFCC00] text-black font-black text-base flex items-center justify-center shadow-xs"
        >
          Z
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 mb-5 bg-amber-100/60 p-1.5 rounded-2xl font-mono text-xs">
        <button
          type="button"
          id="tab-support-privacy"
          onClick={() => setActiveTab('privacy')}
          className={`flex-1 py-2.5 rounded-xl font-bold transition flex items-center justify-center gap-2 ${
            activeTab === 'privacy'
              ? 'bg-[#FFCC00] text-black shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>PRIVACY POLICY & TERMS</span>
        </button>
        <button
          type="button"
          id="tab-support-chat"
          onClick={() => setActiveTab('chat')}
          className={`flex-1 py-2.5 rounded-xl font-bold transition flex items-center justify-center gap-2 ${
            activeTab === 'chat'
              ? 'bg-[#FFCC00] text-black shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>24/7 SUPPORT</span>
        </button>
      </div>

      {activeTab === 'privacy' ? (
        <div className="space-y-4">
          {/* Main Privacy Statement */}
          <div className="bg-white rounded-[24px] p-6 border border-amber-200 shadow-sm space-y-5">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-emerald-600" />
              <h2 className="text-xl font-black text-neutral-900 font-sans">
                PRIVACY POLICY & TERMS
              </h2>
            </div>
            
            {/* Required exact text */}
            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-4 font-sans text-xs text-neutral-800 leading-relaxed">
              <p className="text-sm font-semibold text-neutral-900">
                ZOLTA is a safe ride app connecting riders with verified drivers in South Africa.
              </p>

              <div className="space-y-1.5">
                <h4 className="font-bold text-xs uppercase tracking-wide text-neutral-900">1. DATA WE COLLECT:</h4>
                <ul className="space-y-1 list-disc list-inside text-neutral-700 pl-1">
                  <li><strong>Email Address:</strong> For account login and trip receipts (Firebase Auth)</li>
                  <li><strong>Phone Number:</strong> For verification, driver contact during trip, and SOS safety</li>
                  <li><strong>Location:</strong> Pickup and destination lat/lng when you request a ride (OpenStreetMap + GPS)</li>
                  <li><strong>Trip Data:</strong> Fare, route, distance, status (searching, accepted, completed) stored in Firebase Firestore zolta-45ce5</li>
                  <li><strong>Wallet:</strong> Balance and transaction history - new users start at R0.00</li>
                  <li><strong>Ratings:</strong> Stars 1-5 and comments after completed trips</li>
                  <li><strong>Payment:</strong> Paystack processes card payments - we never store your card number</li>
                </ul>
              </div>

              <div className="space-y-1.5">
                <h4 className="font-bold text-xs uppercase tracking-wide text-neutral-900">2. HOW WE USE YOUR DATA:</h4>
                <ul className="space-y-1 list-disc list-inside text-neutral-700 pl-1">
                  <li>Create and secure your account with email and phone</li>
                  <li>Match you with nearby drivers using your location</li>
                  <li>Calculate fare and 10% ZOLTA commission</li>
                  <li>Safety, support, and trip history</li>
                </ul>
              </div>

              <div className="space-y-1.5">
                <h4 className="font-bold text-xs uppercase tracking-wide text-neutral-900">3. THIRD PARTIES:</h4>
                <ul className="space-y-1 list-disc list-inside text-neutral-700 pl-1">
                  <li><strong>Firebase (Google)</strong> - Authentication, Firestore database, Storage</li>
                  <li><strong>Paystack</strong> - Secure card payments</li>
                  <li><strong>OpenStreetMap / Nominatim</strong> - Free maps and address search</li>
                </ul>
              </div>

              <div className="space-y-1.5">
                <h4 className="font-bold text-xs uppercase tracking-wide text-neutral-900">4. POPIA PROTECTION:</h4>
                <p className="text-neutral-700">
                  Your personal information is encrypted and never sold to third parties. You have the right to access, correct, or delete your data.
                </p>
              </div>

              <div className="space-y-1.5">
                <h4 className="font-bold text-xs uppercase tracking-wide text-neutral-900">5. ACCOUNT & DATA DELETION:</h4>
                <p className="text-neutral-700">
                  You have the right to erase your account and all data at any time in Settings &gt; Delete Account. This deletes your email, phone, trips, wallet, and ratings from Firestore within 30 days. Contact: <a href="mailto:support@zolta.co.za" className="text-blue-600 underline font-medium">support@zolta.co.za</a>
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <h3 className="font-bold text-sm text-neutral-900">Key Safety Commitments</h3>
              <ul className="text-xs text-neutral-700 space-y-2 leading-relaxed font-sans">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <span><strong>Verified Drivers:</strong> Every driver on ZOLTA is vetted and identity-verified</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <span><strong>Phone & Email Verified:</strong> Every account verified for safety</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <span><strong>POPIA Protection:</strong> Your personal information is encrypted and never sold to third parties.</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Account Deletion */}
          <div className="bg-white rounded-[24px] p-5 border border-amber-200 shadow-sm space-y-2">
            <div className="flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-red-600" />
              <h3 className="font-bold text-sm text-neutral-900">Account & Data Deletion</h3>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              You have the right to erase your account and all associated data at any time in Settings.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          {/* Support Chat */}
          <div className="bg-white rounded-[24px] border border-amber-200 shadow-sm overflow-hidden flex flex-col h-[380px]">
            <div className="bg-neutral-900 text-white p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 bg-[#FFCC00] text-black rounded-xl flex items-center justify-center font-bold text-xs font-sans">
                  Z
                </div>
                <div>
                  <h4 className="font-bold text-xs text-white">ZOLTA Support</h4>
                  <span className="text-[10px] text-[#FFCC00] font-semibold">● Online • South Africa</span>
                </div>
              </div>
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-neutral-50 text-xs">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl ${
                      m.sender === 'user'
                        ? 'bg-[#FFCC00] text-black font-semibold rounded-br-none shadow-xs'
                        : 'bg-white text-neutral-900 border border-neutral-200 rounded-bl-none shadow-xs'
                    }`}
                  >
                    {m.text}
                  </div>
                  <span className="text-[9px] text-neutral-400 mt-1 px-1">{m.timestamp}</span>
                </div>
              ))}
            </div>

            <form onSubmit={handleSend} className="p-3 bg-white border-t border-neutral-200 flex gap-2">
              <input
                type="text"
                id="input-support-chat"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a question..."
                className="flex-1 bg-neutral-50 border border-neutral-200 px-4 py-2 rounded-xl text-xs outline-none text-neutral-900 placeholder:text-neutral-400 focus:border-black font-medium"
              />
              <button
                type="submit"
                id="btn-send-support-msg"
                disabled={!input.trim()}
                className="w-10 h-10 bg-[#FFCC00] hover:bg-yellow-400 disabled:opacity-40 text-black rounded-xl flex items-center justify-center transition shadow-xs flex-shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* FAQs */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-neutral-900 mb-2 font-sans">Common Questions</h3>
            {faqs.map((faq, idx) => {
              const isOpen = activeFaq === idx;
              return (
                <div key={idx} className="bg-white rounded-2xl border border-amber-200 shadow-xs overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setActiveFaq(isOpen ? null : idx)}
                    className="w-full p-3.5 text-left font-bold text-xs text-neutral-900 flex items-center justify-between gap-2"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-neutral-400 transition-transform ${isOpen ? 'rotate-180 text-black' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="p-3.5 pt-0 text-xs text-neutral-600 leading-relaxed border-t border-neutral-100 bg-neutral-50/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Menu, Wifi, Battery, MapPin, Signal } from 'lucide-react';

export const SplashScreen: React.FC = () => {
  const { finishSplash, setSosModalOpen, setSidebarOpen } = useApp();
  const [timeString, setTimeString] = useState('19:04');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      setTimeString(`${hours}:${mins}`);
    };
    updateTime();

    const timer = setTimeout(() => {
      finishSplash();
    }, 2800);
    return () => clearTimeout(timer);
  }, [finishSplash]);

  const handleSosClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    finishSplash();
    setSosModalOpen(true);
  };

  const handleMenuClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    finishSplash();
    setSidebarOpen(true);
  };

  return (
    <AnimatePresence>
      <motion.div
        id="zolta-splash-screen"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0, scale: 0.98 }}
        transition={{ duration: 0.35 }}
        onClick={finishSplash}
        className="fixed inset-0 z-50 bg-[#FFFBEB] flex flex-col justify-between select-none cursor-pointer overflow-hidden font-sans"
      >
        {/* Top Dark Header */}
        <div className="w-full bg-[#0A2A5A] pt-2 pb-4 px-4 sm:px-6 shadow-md z-10 flex flex-col">
          {/* Status Bar Row */}
          <div className="flex items-center justify-between text-white/90 text-xs font-semibold mb-2">
            <div className="flex items-center gap-1.5">
              <span className="border border-white/60 text-[9px] font-bold px-1 py-0.2 rounded leading-tight">
                VoLTE
              </span>
              <span className="font-mono tracking-tight font-bold">{timeString}</span>
            </div>

            <div className="flex items-center gap-2 text-white/90">
              <MapPin className="w-3.5 h-3.5 fill-current" />
              <Wifi className="w-3.5 h-3.5 stroke-[2.5]" />
              <div className="flex items-center gap-0.5">
                <span className="text-[9px] font-extrabold tracking-tighter">4G</span>
                <Signal className="w-3 h-3 stroke-[2.5]" />
              </div>
              <Battery className="w-4 h-4 fill-current stroke-[2]" />
            </div>
          </div>

          <div className="flex items-center justify-start">
            <button
              type="button"
              id="splash-menu-button"
              onClick={handleMenuClick}
              className="w-10 h-10 rounded-full bg-[#133663] hover:bg-[#1a447c] border border-[#204e8d] flex items-center justify-center shadow-inner transition active:scale-95 text-white"
              aria-label="Navigation Menu"
            >
              <Menu className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col items-center justify-between py-6 px-4 max-w-lg mx-auto w-full relative">
          {/* Top Center Floating Badge */}
          <motion.div
            initial={{ y: -10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="bg-white rounded-full px-5 py-1.5 shadow-sm border border-amber-200/80 flex items-center gap-2"
          >
            <div className="w-5 h-5 rounded-full bg-amber-50 flex items-center justify-center text-[#FFCC00]">
              <ShieldCheck className="w-4 h-4 text-black stroke-[2.5]" />
            </div>
            <span className="text-[11px] sm:text-xs font-black tracking-widest text-neutral-800 uppercase">
              SOUTH AFRICA 🇿🇦
            </span>
          </motion.div>

          {/* Center Brand Identity */}
          <div className="flex flex-col items-center justify-center text-center my-auto">
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', damping: 14, stiffness: 130 }}
              className="w-36 h-36 rounded-3xl bg-black border-4 border-[#FFCC00] relative overflow-hidden flex flex-col items-center justify-center shadow-2xl"
            >
              <span className="text-7xl font-black text-[#FFCC00] tracking-tighter leading-none font-sans">
                Z
              </span>
            </motion.div>

            {/* Exact Splash Screen Text Requested */}
            <motion.h1
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-3xl sm:text-4xl font-black tracking-tight text-neutral-900 mt-5 font-sans"
            >
              ZOLTA - Your Safe Ride
            </motion.h1>

            <motion.p
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-xs sm:text-sm font-bold tracking-wider text-neutral-600 uppercase mt-1.5 font-mono"
            >
              Verified Drivers • Safety First
            </motion.p>

            {/* Spinner */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.45 }}
              className="flex flex-col items-center justify-center mt-6"
            >
              <div className="w-7 h-7 rounded-full border-3 border-neutral-200 border-t-[#FFCC00] border-r-[#FFCC00] animate-spin mb-2" />
              <span className="text-[10px] font-mono font-bold tracking-wider text-neutral-500 uppercase">
                Connecting nearby verified drivers...
              </span>
            </motion.div>
          </div>

          {/* Bottom Area: Red SOS Emergency Button */}
          <div className="flex flex-col items-center justify-center w-full mt-auto pt-2 pb-2">
            <motion.button
              type="button"
              id="splash-sos-emergency-btn"
              onClick={handleSosClick}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-b from-[#FF2B2B] to-[#B30000] flex flex-col items-center justify-center text-white cursor-pointer select-none border-2 border-red-400 shadow-lg"
              aria-label="Emergency SOS"
            >
              <span className="text-xl sm:text-2xl font-black tracking-wider leading-tight text-white drop-shadow-md">
                SOS
              </span>
              <span className="text-[9px] font-black tracking-widest text-white/95 uppercase">
                EMERGENCY
              </span>
            </motion.button>

            <div className="flex items-center justify-center gap-1.5 mt-3 text-center">
              <span className="text-xs">🚨</span>
              <span className="text-[10px] font-bold tracking-wider text-neutral-600 uppercase font-sans">
                TAP SOS FOR IMMEDIATE RIDER SAFETY & SUPPORT
              </span>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

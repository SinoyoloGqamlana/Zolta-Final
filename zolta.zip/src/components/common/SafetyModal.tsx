import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldAlert,
  Share2,
  PhoneCall,
  Mic,
  Check,
  UserPlus,
  Trash2,
  AlertTriangle,
  ShieldCheck,
} from 'lucide-react';

export const SafetyModal: React.FC = () => {
  const {
    isSafetyModalOpen,
    setSafetyModalOpen,
    activeRide,
    emergencyContacts,
    addEmergencyContact,
    removeEmergencyContact,
  } = useApp();

  const [copiedLink, setCopiedLink] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [sosAlertSent, setSosAlertSent] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '', relation: 'Family' });

  if (!isSafetyModalOpen) return null;

  const handleCopyShareLink = () => {
    const fakeLiveUrl = `https://zolta.app/track/live?trip=${activeRide?.id || 'demo'}`;
    navigator.clipboard?.writeText(fakeLiveUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleTriggerSOS = () => {
    setSosAlertSent(true);
  };

  const handleAddContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContact.name || !newContact.phone) return;
    addEmergencyContact(newContact);
    setNewContact({ name: '', phone: '', relation: 'Family' });
    setShowAddContact(false);
  };

  return (
    <div id="safety-modal-overlay" className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white text-neutral-900 w-full max-w-md rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto border border-neutral-200"
      >
        {/* Close Button */}
        <button
          id="btn-close-safety-modal"
          onClick={() => setSafetyModalOpen(false)}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-black hover:bg-neutral-100 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-red-50 border border-red-200 text-red-600 rounded-2xl flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-black">ZOLTA Safety Hub</h3>
            <p className="text-xs text-neutral-500">24/7 Security Protocols & Emergency Protection</p>
          </div>
        </div>

        {/* SOS Emergency Button */}
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 mb-5 text-center">
          <h4 className="text-sm font-bold text-red-700 mb-1 flex items-center justify-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            Emergency SOS Assistance (10111)
          </h4>
          <p className="text-xs text-neutral-600 mb-3 leading-relaxed">
            Transmits live GPS beacon, vehicle license plate, and driver identity to national police.
          </p>

          <button
            type="button"
            id="btn-trigger-sos"
            onClick={handleTriggerSOS}
            className={`w-full font-black py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-xs transition transform active:scale-95 text-xs cursor-pointer ${
              sosAlertSent
                ? 'bg-red-800 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>{sosAlertSent ? 'SOS BEACON ACTIVE (TRANSMITTING)' : 'HOLD FOR EMERGENCY SOS'}</span>
          </button>

          {sosAlertSent && (
            <div className="mt-3 p-3 bg-red-100/80 border border-red-300 rounded-xl text-left space-y-2 text-red-950">
              <div className="flex items-center gap-2 font-bold text-xs">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
                <span>SAPS Police (10111) & Emergency Response Alerted</span>
              </div>
              <p className="text-[11px] text-red-900 leading-tight">
                Live GPS coordinates, vehicle registration, and emergency contacts are now actively transmitting over encrypted telemetry.
              </p>
              <a
                href="tel:10111"
                className="inline-flex items-center justify-center gap-1.5 w-full bg-red-700 hover:bg-red-800 text-white font-bold text-xs py-2 rounded-lg transition"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call 10111 Direct Line</span>
              </a>
            </div>
          )}
        </div>

        {/* Feature Cards */}
        <div className="space-y-2.5 mb-6">
          {/* Share Live Ride */}
          <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white border border-neutral-200 text-black rounded-xl flex items-center justify-center">
                <Share2 className="w-4 h-4" />
              </div>
              <div>
                <h5 className="font-bold text-xs text-black">Share Live GPS Route</h5>
                <p className="text-[11px] text-neutral-500">Live moving map link for friends/family</p>
              </div>
            </div>
            <button
              type="button"
              id="btn-share-live-trip"
              onClick={handleCopyShareLink}
              className="bg-[#FFD60A] hover:bg-yellow-400 text-black text-xs font-black px-3 py-1.5 rounded-xl flex items-center gap-1 transition shadow-xs border border-yellow-300"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-black" /> : null}
              <span>{copiedLink ? 'Copied' : 'Share'}</span>
            </button>
          </div>

          {/* In-Trip Audio Recording */}
          <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isRecording ? 'bg-red-600 text-white animate-pulse' : 'bg-white border border-neutral-200 text-black'}`}>
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <h5 className="font-bold text-xs text-black">In-Trip Audio Recording</h5>
                <p className="text-[11px] text-neutral-500">Encrypted on-device safety track</p>
              </div>
            </div>
            <button
              type="button"
              id="btn-toggle-recording"
              onClick={() => setIsRecording(!isRecording)}
              className={`text-xs font-bold px-3 py-1.5 rounded-xl transition ${
                isRecording
                  ? 'bg-red-600 text-white'
                  : 'bg-white border border-neutral-300 text-black hover:bg-neutral-100'
              }`}
            >
              {isRecording ? 'Stop Rec' : 'Start'}
            </button>
          </div>
        </div>

        {/* Trusted Emergency Contacts */}
        <div>
          <div className="flex justify-between items-center mb-3">
            <h5 className="font-extrabold text-sm text-black">Trusted Contacts</h5>
            <button
              type="button"
              id="btn-add-contact-toggle"
              onClick={() => setShowAddContact(!showAddContact)}
              className="text-xs font-bold text-black hover:underline flex items-center gap-1"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>

          {showAddContact && (
            <form onSubmit={handleAddContactSubmit} className="bg-neutral-50 p-3 rounded-2xl border border-neutral-200 mb-3 space-y-2">
              <input
                type="text"
                placeholder="Contact Name"
                value={newContact.name}
                onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                className="w-full bg-white px-3 py-2 text-xs rounded-xl border border-neutral-300 text-black placeholder:text-neutral-400 outline-none"
                required
              />
              <input
                type="tel"
                placeholder="Phone Number (+27...)"
                value={newContact.phone}
                onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                className="w-full bg-white px-3 py-2 text-xs rounded-xl border border-neutral-300 text-black placeholder:text-neutral-400 outline-none"
                required
              />
              <button
                type="submit"
                id="btn-save-contact"
                className="w-full bg-[#FFD60A] text-black text-xs font-black py-2 rounded-xl hover:bg-yellow-400 transition shadow-xs border border-yellow-300"
              >
                Save Contact
              </button>
            </form>
          )}

          <div className="space-y-2">
            {emergencyContacts.map((contact) => (
              <div key={contact.id} className="flex items-center justify-between p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                <div>
                  <h6 className="font-bold text-xs text-black">{contact.name} ({contact.relation})</h6>
                  <span className="text-[11px] text-neutral-500">{contact.phone}</span>
                </div>
                <button
                  type="button"
                  onClick={() => removeEmergencyContact(contact.id)}
                  className="p-1 text-neutral-400 hover:text-red-600 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};


import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { X, Smartphone, ArrowRight, CheckCircle2, Lock, AlertCircle, ShieldCheck } from 'lucide-react';
import { verifyPhoneOtp, loginWithGoogle } from '../../services/authService';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setAuthModalOpen, setAuthenticatedUser } = useApp();
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');
  const [countryCode, setCountryCode] = useState('+27');
  const [otp, setOtp] = useState(['', '', '', '']);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const digitsOnly = phone.replace(/\D/g, '');
    if (!phone || digitsOnly.length < 9) {
      setErrorMessage('Please enter a valid South African phone number');
      return;
    }
    setStep('otp');
  };

  const handleVerifyOtp = async () => {
    setErrorMessage(null);
    const code = otp.join('');
    if (code.length < 4) {
      setErrorMessage('Please enter all 4 digits of the SMS code');
      return;
    }

    setIsVerifying(true);
    const fullPhone = `${countryCode} ${phone.trim()}`;
    const res = await verifyPhoneOtp(fullPhone, code);
    setIsVerifying(false);

    if (res.success && res.user) {
      setAuthenticatedUser(res.user);
      setAuthModalOpen(false);
      setStep('phone');
    } else {
      setErrorMessage(res.error || 'Verification failed');
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setIsVerifying(true);
    const res = await loginWithGoogle();
    setIsVerifying(false);
    if (res.success && res.user) {
      setAuthenticatedUser(res.user);
      setAuthModalOpen(false);
    } else {
      setErrorMessage(res.error || 'Google sign in interrupted');
    }
  };

  return (
    <div id="auth-modal-overlay" className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white text-[#111111] w-full max-w-md rounded-[28px] p-6 sm:p-8 shadow-2xl border border-[#E5E7EB] relative overflow-hidden"
      >
        {/* Close Button */}
        <button
          id="btn-close-auth-modal"
          onClick={() => setAuthModalOpen(false)}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-black hover:bg-neutral-100 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-gradient-to-br from-[#FFD60A] to-[#111111] p-[2px] rounded-xl shadow-xs">
            <div className="w-full h-full bg-[#0A0A0A] rounded-[10px] flex items-center justify-center font-black text-[#FFD60A] text-lg">
              Z
            </div>
          </div>
          <div>
            <h3 className="font-roman font-bold text-lg text-[#111111] leading-tight">ZOLTA Access</h3>
            <p className="text-xs text-neutral-500 flex items-center gap-1 font-mono">
              <ShieldCheck className="w-3.5 h-3.5 text-[#FFD60A]" />
              Safety First • Trusted in SA 🇿🇦
            </p>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2 text-xs text-red-700 font-medium">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {step === 'phone' ? (
          <div>
            <p className="text-xs text-neutral-600 mb-5 leading-relaxed">
              Enter your mobile number. You will receive a real 4-digit SMS OTP verification code to securely access your ZOLTA account.
            </p>

            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="flex rounded-[16px] border border-[#E5E7EB] focus-within:border-black focus-within:ring-2 focus-within:ring-[#FFD60A]/40 overflow-hidden bg-[#F8F9FA] transition">
                <select
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  className="bg-[#F1F3F5] font-mono font-bold text-xs px-3.5 py-3.5 border-r border-[#E5E7EB] outline-none text-black cursor-pointer"
                >
                  <option value="+27">🇿🇦 +27</option>
                  <option value="+264">🇳🇦 +264</option>
                  <option value="+267">🇧🇼 +267</option>
                </select>

                <input
                  type="tel"
                  id="input-auth-phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="082 000 0000"
                  className="flex-1 bg-transparent px-4 py-3.5 text-sm font-bold font-mono outline-none text-black placeholder:text-neutral-400"
                  required
                />
              </div>

              <button
                type="submit"
                id="btn-submit-phone"
                className="w-full bg-gradient-to-r from-[#FFD60A] to-[#FFC300] hover:brightness-105 text-black font-black py-3.5 px-4 rounded-[16px] flex items-center justify-center gap-2 shadow-[0_4px_14px_rgba(255,214,10,0.35)] transition active:scale-[0.98] text-xs tracking-wide"
              >
                <span>Continue with Phone</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </button>
            </form>

            <div className="relative my-5 flex items-center justify-center">
              <div className="border-t border-[#E5E7EB] w-full" />
              <span className="bg-white px-3 text-[10px] font-mono text-neutral-400 font-bold uppercase tracking-wider absolute">
                or continue with
              </span>
            </div>

            {/* Google Sign In */}
            <button
              type="button"
              id="btn-auth-google"
              onClick={handleGoogleSignIn}
              disabled={isVerifying}
              className="w-full bg-white hover:bg-neutral-50 border border-[#E5E7EB] py-3 px-4 rounded-[16px] flex items-center justify-center gap-3 font-bold text-xs text-neutral-900 transition active:scale-[0.98] shadow-xs"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span>Continue with Google</span>
            </button>
          </div>
        ) : (
          <div>
            <div className="mb-4 text-center">
              <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider font-mono">SMS Code sent to</span>
              <p className="text-base font-black text-black font-mono mt-0.5">{countryCode} {phone}</p>
            </div>

            {/* OTP Input Boxes */}
            <div className="flex justify-center gap-2.5 mb-6">
              {[0, 1, 2, 3].map((idx) => (
                <input
                  key={idx}
                  id={`otp-modal-input-${idx}`}
                  type="text"
                  maxLength={1}
                  value={otp[idx] || ''}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    const newOtp = [...otp];
                    newOtp[idx] = val;
                    setOtp(newOtp);
                    if (val && idx < 3) {
                      const next = document.getElementById(`otp-modal-input-${idx + 1}`);
                      next?.focus();
                    }
                  }}
                  className="w-12 h-14 bg-[#F8F9FA] border-2 border-[#E5E7EB] focus:border-black focus:ring-2 focus:ring-[#FFD60A]/40 rounded-2xl text-center text-xl font-mono font-black text-black outline-none transition"
                />
              ))}
            </div>

            <button
              type="button"
              id="btn-verify-otp"
              disabled={isVerifying}
              onClick={handleVerifyOtp}
              className="w-full bg-gradient-to-r from-[#FFD60A] to-[#FFC300] hover:brightness-105 text-black font-black py-3.5 px-4 rounded-[16px] flex items-center justify-center gap-2 shadow-[0_4px_14px_rgba(255,214,10,0.35)] transition active:scale-[0.98] mb-3 text-xs tracking-wide"
            >
              {isVerifying ? (
                <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Verify & Access Account</span>
                  <CheckCircle2 className="w-4 h-4" />
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setStep('phone')}
              className="w-full text-xs font-semibold text-neutral-500 hover:text-black py-2 underline"
            >
              Change Phone Number
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
};


import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { X, Receipt, CheckCircle, Download, Share2, MapPin, Calendar, CreditCard, ShieldCheck } from 'lucide-react';
import { RideRequest } from '../../types';

interface ReceiptModalProps {
  ride?: RideRequest | null;
  onClose?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ ride: propRide, onClose }) => {
  const { isReceiptModalOpen, setReceiptModalOpen, activeRide, ridesHistory } = useApp();

  const ride = propRide || activeRide || ridesHistory[0];

  if (!propRide && !isReceiptModalOpen) return null;

  const handleClose = () => {
    if (onClose) onClose();
    setReceiptModalOpen(false);
  };

  if (!ride) return null;

  const fareVal = Number(ride.offeredFare || 0);
  const tipVal = Number(ride.tipGiven || 0);

  const baseFare = Number((fareVal * 0.75).toFixed(2));
  const distanceFare = Number((fareVal * 0.20).toFixed(2));
  const serviceFee = Number((fareVal * 0.05).toFixed(2));
  const total = fareVal + tipVal;

  return (
    <div id="receipt-modal-overlay" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-neutral-950 text-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-neutral-800 relative overflow-hidden"
      >
        {/* Close Button */}
        <button
          id="btn-close-receipt"
          onClick={handleClose}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Icon & Title */}
        <div className="text-center pb-4 border-b border-neutral-800">
          <div className="w-12 h-12 bg-neutral-900 text-[#FFD60A] border border-[#FFD60A]/30 rounded-2xl flex items-center justify-center mx-auto mb-2">
            <Receipt className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-white">ZOLTA Trip Receipt</h3>
          <p className="text-xs text-neutral-400">Security Reference #ZP-{ride.id.substring(0, 8).toUpperCase()}</p>
        </div>

        {/* Total Price Big */}
        <div className="text-center py-4 bg-neutral-900 rounded-2xl my-4 border border-neutral-800">
          <span className="text-xs font-bold text-[#FFD60A] uppercase tracking-wider">Total Paid</span>
          <div className="text-3xl font-black text-white mt-0.5 font-mono">
            R{total.toFixed(2)}
          </div>
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-neutral-900 bg-[#FFD60A] px-2.5 py-0.5 rounded-full mt-1.5">
            <ShieldCheck className="w-3 h-3" />
            Settled via {ride.paymentMethod.toUpperCase()} • Verified
          </span>
        </div>

        {/* Route Details */}
        <div className="space-y-3 mb-4 text-xs">
          <div className="flex items-start gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FFD60A] mt-1 ring-2 ring-[#FFD60A]/40 flex-shrink-0" />
            <div>
              <span className="font-semibold text-neutral-400">Pickup</span>
              <p className="font-bold text-white">{ride.pickup.address}</p>
            </div>
          </div>
          <div className="flex items-start gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 mt-1 ring-2 ring-red-300 flex-shrink-0" />
            <div>
              <span className="font-semibold text-neutral-400">Destination</span>
              <p className="font-bold text-white">{ride.dropoff.address}</p>
            </div>
          </div>
        </div>

        {/* Fare Breakdown */}
        <div className="border-t border-b border-neutral-800 py-3 space-y-1.5 text-xs">
          <div className="flex justify-between text-neutral-400">
            <span>Agreed Bid Fare</span>
            <span className="font-medium text-white">R{baseFare.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span>Distance & Route ({ride.distanceKm} km)</span>
            <span className="font-medium text-white">R{distanceFare.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span>ZOLTA Service Fee (0% Driver Comm.)</span>
            <span className="font-medium text-[#FFD60A]">R{serviceFee.toFixed(2)}</span>
          </div>
          {ride.tipGiven ? (
            <div className="flex justify-between text-[#FFD60A] font-bold">
              <span>Driver Gratuity</span>
              <span>+R{(ride.tipGiven || 0).toFixed(2)}</span>
            </div>
          ) : null}
        </div>

        {/* Driver Summary */}
        {ride.acceptedDriver && (
          <div className="flex items-center gap-3 pt-3 mb-5">
            <img
              src={ride.acceptedDriver.avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'}
              alt={ride.acceptedDriver.name || 'Driver'}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover border border-[#FFD60A]"
            />
            <div className="flex-1">
              <h5 className="font-bold text-xs text-white">{ride.acceptedDriver.name}</h5>
              <p className="text-[11px] text-neutral-400">{ride.acceptedDriver.carModel} • {ride.acceptedDriver.licensePlate}</p>
            </div>
            <div className="text-right">
              <span className="text-[11px] text-neutral-400">Date</span>
              <p className="text-xs font-bold text-neutral-200">
                {new Date(ride.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => {
              const element = document.createElement('a');
              const file = new Blob([
                `ZOLTA TRIP TAX INVOICE & RECEIPT\n` +
                `Receipt No: ZP-${ride.id.substring(0, 8).toUpperCase()}\n` +
                `Date: ${new Date(ride.createdAt).toLocaleString()}\n` +
                `Passenger: ${ride.riderName}\n` +
                `Category: ${ride.category.toUpperCase()}\n` +
                `Pickup: ${ride.pickup.address}\n` +
                `Destination: ${ride.dropoff.address}\n` +
                `Fare: R${fareVal.toFixed(2)}\n` +
                `Driver: ${ride.acceptedDriver?.name || 'Assigned Driver'} (${ride.acceptedDriver?.licensePlate || 'N/A'})\n` +
                `Status: PAID (${ride.paymentMethod.toUpperCase()})\n` +
                `ZOLTA Mobility (Pty) Ltd - Reg: 2026/08912/07 - Cape Town, South Africa`
              ], { type: 'text/plain' });
              element.href = URL.createObjectURL(file);
              element.download = `Zolta_Receipt_${ride.id.substring(0, 8)}.txt`;
              document.body.appendChild(element);
              element.click();
              document.body.removeChild(element);
            }}
            className="border border-neutral-700 bg-neutral-900 hover:bg-neutral-800 font-bold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 text-white transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>
          <button
            type="button"
            onClick={handleClose}
            className="bg-[#FFD60A] hover:bg-yellow-400 font-bold text-xs py-2.5 px-3 rounded-xl text-black transition text-center"
          >
            Done
          </button>
        </div>
      </motion.div>
    </div>
  );
};


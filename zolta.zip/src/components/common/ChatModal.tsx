import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { X, Send, Phone, ShieldCheck, Sparkles, Lock } from 'lucide-react';

export const ChatModal: React.FC = () => {
  const {
    isChatModalOpen,
    setChatModalOpen,
    chatMessages,
    sendChatMessage,
    user,
    mode,
    activeRide,
    startVoiceCall,
  } = useApp();

  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickChips = [
    "Where are you?",
    "I'm coming",
    "I'm outside",
    "Please come out",
    "I have arrived",
  ];

  const otherPersonName = mode === 'rider'
    ? activeRide?.acceptedDriver?.name || 'Driver'
    : activeRide?.riderName || 'Rider';

  const defaultAvatar = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80';
  const defaultDriverAvatar = 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80';

  const otherPersonAvatar = mode === 'rider'
    ? (activeRide?.acceptedDriver?.avatar || defaultDriverAvatar)
    : (activeRide?.riderAvatar || user.avatar || defaultAvatar);

  useEffect(() => {
    if (isChatModalOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isChatModalOpen]);

  if (!isChatModalOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    sendChatMessage(input);
    setInput('');
  };

  return (
    <div id="chat-modal-overlay" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="bg-neutral-950 text-white w-full max-w-lg h-[90vh] sm:h-[600px] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-neutral-800 flex flex-col overflow-hidden"
      >
        {/* Chat Header */}
        <div className="bg-black text-white p-4 flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <img
              src={otherPersonAvatar}
              alt={otherPersonName}
              className="w-10 h-10 rounded-full object-cover border-2 border-[#FFD60A]"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="font-bold text-sm text-white">{otherPersonName}</h4>
                <ShieldCheck className="w-3.5 h-3.5 text-[#FFD60A]" />
              </div>
              <span className="text-[11px] text-neutral-400 font-medium capitalize">
                {mode === 'rider' ? 'ZOLTA Verified Driver' : 'Verified Passenger'} • Safety First
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-chat-call"
              onClick={() => {
                setChatModalOpen(false);
                startVoiceCall(otherPersonName, mode === 'rider' ? 'Driver' : 'Passenger');
              }}
              className="p-2.5 bg-neutral-900 hover:bg-neutral-800 text-[#FFD60A] rounded-full transition border border-neutral-700"
              title="Voice Call"
            >
              <Phone className="w-4 h-4" />
            </button>
            <button
              type="button"
              id="btn-close-chat"
              onClick={() => setChatModalOpen(false)}
              className="p-2.5 text-neutral-400 hover:text-white rounded-full transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-neutral-900">
          {chatMessages.map((msg) => {
            const isMe = msg.senderId === user.id;
            const isSystem = msg.senderRole === 'support';

            if (isSystem) {
              return (
                <div key={msg.id} className="flex justify-center my-2">
                  <div className="bg-neutral-950 text-[#FFD60A] border border-[#FFD60A]/40 text-xs px-3.5 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm max-w-xs text-center font-bold">
                    <Lock className="w-3.5 h-3.5 text-[#FFD60A] flex-shrink-0" />
                    <span>{msg.text}</span>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[78%] px-4 py-2.5 rounded-2xl text-sm ${
                    isMe
                      ? 'bg-[#FFD60A] text-black font-semibold rounded-br-none shadow-md'
                      : 'bg-neutral-800 text-white border border-neutral-700 rounded-bl-none shadow-sm'
                  }`}
                >
                  <p className="leading-relaxed">{msg.text}</p>
                </div>
                <span className="text-[10px] text-neutral-500 mt-1 px-1">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-2.5 bg-neutral-950 border-t border-neutral-800 flex gap-2 overflow-x-auto whitespace-nowrap no-scrollbar">
          {quickChips.map((chip, i) => (
            <button
              key={i}
              type="button"
              onClick={() => sendChatMessage(chip)}
              className="h-[32px] px-3.5 bg-neutral-900 hover:bg-neutral-800 hover:text-[#FFD60A] border border-neutral-800 text-neutral-200 text-[12px] font-medium rounded-full whitespace-nowrap transition shrink-0 flex items-center justify-center"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 bg-black border-t border-neutral-800 flex gap-2">
          <input
            type="text"
            id="input-chat-message"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-neutral-900 border border-neutral-700 px-4 py-2.5 rounded-full text-sm outline-none focus:border-[#FFD60A] text-white placeholder:text-neutral-500"
          />
          <button
            type="submit"
            id="btn-send-message"
            disabled={!input.trim()}
            className="w-10 h-10 bg-[#FFD60A] hover:bg-yellow-400 disabled:opacity-40 text-black rounded-full flex items-center justify-center transition active:scale-95 shadow-md flex-shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </motion.div>
    </div>
  );
};


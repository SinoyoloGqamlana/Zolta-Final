import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, ArrowRight, Zap, Award, Lock } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Onboarding: React.FC = () => {
  const { finishOnboarding } = useApp();
  const [slide, setSlide] = useState(0);

  const slides = [
    {
      title: 'Offer Your Own Fare',
      desc: 'Set your price in South African Rands (ZAR). Clean, transparent pricing for all South African riders and verified drivers.',
      badge: 'Fair Pricing',
      icon: <Zap className="w-8 h-8 text-black" />,
      color: 'bg-[#FFCC00]',
    },
    {
      title: 'ZOLTA Verified Safety',
      desc: 'Every trip is with a verified driver. SMS verification and POPIA protection ensure complete safety.',
      badge: 'Fully Protected',
      icon: <Lock className="w-8 h-8 text-black" />,
      color: 'bg-[#FFCC00]',
    },
    {
      title: 'Safety & Gender Choice',
      desc: 'Select preferred driver gender (Female / Male / Any), instant 10111 SAPS SOS dispatch, and real-time live route tracking.',
      badge: '24/7 Shield',
      icon: <ShieldCheck className="w-8 h-8 text-black" />,
      color: 'bg-[#FFD60A]',
    },
  ];

  return (
    <div id="onboarding-container" className="fixed inset-0 z-40 bg-black text-white flex flex-col justify-between p-6 max-w-md mx-auto">
      <div className="flex justify-between items-center pt-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-black border border-[#FFD60A] text-[#FFD60A] rounded-lg flex items-center justify-center font-black text-sm zolta-shield-glow">
            Z
          </div>
          <span className="font-black text-sm tracking-tight text-white">ZOLTA</span>
        </div>
        <button
          id="btn-skip-onboarding"
          onClick={finishOnboarding}
          className="text-xs font-semibold text-neutral-400 hover:text-white py-1 px-3 rounded-full hover:bg-neutral-800 transition"
        >
          Skip
        </button>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={slide}
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -40 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col items-center text-center my-auto px-4"
        >
          <div className={`w-28 h-28 ${slides[slide].color} rounded-3xl flex items-center justify-center shadow-xl mb-8 transform -rotate-3 ring-8 ring-neutral-900 zolta-shield-glow`}>
            {slides[slide].icon}
          </div>

          <span className="bg-neutral-900 text-[#FFD60A] border border-neutral-800 text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider mb-3">
            {slides[slide].badge}
          </span>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mb-3">
            {slides[slide].title}
          </h2>

          <p className="text-sm text-neutral-400 leading-relaxed max-w-xs">
            {slides[slide].desc}
          </p>
        </motion.div>
      </AnimatePresence>

      <div className="pb-4 flex flex-col gap-5">
        {/* Pagination Dots */}
        <div className="flex justify-center gap-2">
          {slides.map((_, idx) => (
            <div
              key={idx}
              className={`h-2 rounded-full transition-all duration-300 ${
                slide === idx ? 'w-8 bg-[#FFD60A]' : 'w-2 bg-neutral-800'
              }`}
            />
          ))}
        </div>

        <button
          id="btn-next-onboarding"
          type="button"
          onClick={() => {
            if (slide < slides.length - 1) {
              setSlide(slide + 1);
            } else {
              finishOnboarding();
            }
          }}
          className="w-full bg-[#FFD60A] hover:bg-yellow-400 text-black font-black py-4 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-xl transition-transform active:scale-[0.98]"
        >
          <span>{slide === slides.length - 1 ? 'Get Started' : 'Next'}</span>
          <ArrowRight className="w-4 h-4 stroke-[3]" />
        </button>
      </div>
    </div>
  );
};


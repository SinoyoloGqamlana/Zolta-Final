import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Menu,
  Shield,
  Volume2,
  MapPin,
  AlertOctagon,
  ArrowLeft,
  X,
} from 'lucide-react';

interface HeaderProps {
  onToggleVoice?: () => void;
  onToggleViewMap?: () => void;
}

const getPageTitle = (view: string): string => {
  switch (view) {
    case 'wallet':
      return 'My Wallet';
    case 'my_rides':
      return 'My Trips';
    case 'support':
    case 'safety':
      return 'Help & Safety';
    case 'drive_with_zolta':
      return 'Drive With Zolta';
    case 'asset_owner':
      return 'Asset Owners Portal';
    case 'trailer_hiring':
      return 'Trailer Hiring';
    case 'towing':
      return 'Towing & Breakdown';
    case 'settings':
      return 'Settings';
    case 'invite':
      return 'Invite Friends';
    case 'driver_earnings':
      return 'Driver Earnings';
    case 'driver_documents':
      return 'Driver Documents';
    default:
      return 'ZOLTA';
  }
};

export const Header: React.FC<HeaderProps> = ({ onToggleVoice, onToggleViewMap }) => {
  const {
    mode,
    setMode,
    setSidebarOpen,
    setSosModalOpen,
    setSafetyModalOpen,
    setCurrentView,
    currentView,
    goBack,
    fullMap,
    setFullMap,
    toggleFullMap,
    voiceEnabled,
    toggleVoiceEnabled,
  } = useApp();

  const handleGoToRiderPortal = () => {
    setMode('rider');
    setCurrentView('home');
    setFullMap(false);
  };

  const handleToggleViewMap = () => {
    if (onToggleViewMap) {
      onToggleViewMap();
    } else {
      if (currentView !== 'home' || mode !== 'rider') {
        setMode('rider');
        setCurrentView('home');
        setFullMap(true);
      } else {
        toggleFullMap();
      }
    }
  };

  const handleToggleVoice = () => {
    if (onToggleVoice) {
      onToggleVoice();
    } else {
      toggleVoiceEnabled();
    }
  };

  // 56px Sticky Top Bar for ALL Pages Except Main Map ('home')
  if (currentView !== 'home') {
    return (
      <header
        id="subpage-app-header"
        className="h-[56px] min-h-[56px] bg-white text-black border-b border-neutral-200 sticky top-0 z-40 px-3 sm:px-4 flex items-center justify-between shadow-xs select-none w-full"
      >
        {/* Left: Back Arrow (24px) */}
        <button
          type="button"
          id="btn-nav-header-back"
          onClick={goBack}
          className="w-10 h-10 -ml-2 rounded-full hover:bg-neutral-100 flex items-center justify-center text-black transition active:scale-95"
          title="Back"
          aria-label="Back"
        >
          <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
        </button>

        {/* Middle: Page Title */}
        <h1 className="text-base sm:text-lg font-bold text-black text-center truncate flex-1 px-2 font-sans">
          {getPageTitle(currentView)}
        </h1>

        {/* Right: X Close Button (24px) */}
        <button
          type="button"
          id="btn-nav-header-close"
          onClick={() => setCurrentView('home')}
          className="w-10 h-10 -mr-2 rounded-full hover:bg-neutral-100 flex items-center justify-center text-black transition active:scale-95"
          title="Close to Home"
          aria-label="Close"
        >
          <X className="w-6 h-6 stroke-[2.5]" />
        </button>
      </header>
    );
  }

  // Standard Header for Main Map ('home')
  return (
    <header
      id="main-app-header"
      className="h-[40px] bg-white text-neutral-900 border-b border-neutral-200 sticky top-0 z-40 px-2 sm:px-3 flex items-center justify-between shadow-xs select-none"
    >
      {/* Left: Hamburger & ZOLTA Brand Logo */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Hamburger Menu Button */}
        <button
          type="button"
          id="btn-toggle-sidebar"
          onClick={() => setSidebarOpen(true)}
          className="w-7 h-7 rounded-lg bg-neutral-100 hover:bg-neutral-200 border border-neutral-200 text-neutral-900 flex items-center justify-center transition active:scale-95 shadow-xs"
          title="Open ZOLTA Menu"
          aria-label="Navigation Menu"
        >
          <Menu className="w-4 h-4 stroke-[2.5]" />
        </button>

        {/* Z Icon (Yellow Square with Black Z, 26px) -> Goes to Rider Portal Homepage */}
        <button
          type="button"
          id="btn-header-logo-icon"
          onClick={handleGoToRiderPortal}
          title="Go to Rider Portal (Home)"
          className="w-[26px] h-[26px] rounded-lg bg-[#FFD60A] text-black font-black text-sm flex items-center justify-center shadow-xs active:scale-95 transition font-sans"
        >
          Z
        </button>

        {/* ZOLTA Brand Text */}
        <button
          type="button"
          id="btn-header-logo-text"
          onClick={handleGoToRiderPortal}
          title="Go to Rider Portal (Home)"
          className="font-black text-base sm:text-lg tracking-wider text-black hover:text-neutral-700 transition font-sans mr-0.5"
        >
          ZOLTA
        </button>
      </div>

      {/* Right: Action Pills & Icons */}
      <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {/* Rider Portal quick button if in driver mode or sub-view */}
        {(mode === 'driver' || currentView !== 'home') && (
          <button
            type="button"
            id="btn-header-rider-portal"
            onClick={handleGoToRiderPortal}
            className="h-[28px] bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-[10px] sm:text-[11px] px-2.5 rounded-lg flex items-center gap-1 transition shadow-xs active:scale-95 whitespace-nowrap border border-yellow-400 font-mono"
            title="Go to Rider Portal"
          >
            <span>RIDER PORTAL</span>
          </button>
        )}

        {/* 1. VOICE Pill */}
        <button
          type="button"
          id="btn-header-voice"
          onClick={handleToggleVoice}
          className={`h-[28px] ${
            voiceEnabled
              ? 'bg-[#FFD60A] hover:bg-yellow-400 text-black border-yellow-400 font-black'
              : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-600 border-neutral-300 font-bold'
          } text-[10px] sm:text-[11px] px-2 sm:px-2.5 rounded-lg flex items-center gap-1 transition shadow-xs active:scale-95 whitespace-nowrap border font-mono`}
        >
          <Volume2 className="w-3 h-3 stroke-[2.5]" />
          <span>{voiceEnabled ? 'VOICE ON' : 'VOICE'}</span>
        </button>

        {/* 2. VIEW MAP / CLOSE MAP Pill -> Toggles Full Screen Map */}
        <button
          type="button"
          id="btn-header-view-map"
          onClick={handleToggleViewMap}
          className={`h-[28px] ${
            fullMap
              ? 'bg-[#FFD60A] text-black border-yellow-400'
              : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-900 border-neutral-200'
          } border font-black text-[10px] sm:text-[11px] px-2 sm:px-2.5 rounded-lg flex items-center gap-1 transition shadow-xs active:scale-95 whitespace-nowrap font-mono`}
        >
          <MapPin className="w-3 h-3 stroke-[2.5] text-black" />
          <span>{fullMap ? 'CLOSE MAP' : 'VIEW MAP'}</span>
        </button>

        {/* 3. SOS Red Pill */}
        <button
          type="button"
          id="btn-header-sos"
          onClick={() => setSosModalOpen(true)}
          className="h-[28px] bg-red-50 hover:bg-red-100 text-red-600 border border-red-500 font-black text-[10px] sm:text-[11px] px-2 sm:px-2.5 rounded-lg flex items-center gap-1 transition shadow-xs active:scale-95 whitespace-nowrap animate-pulse font-mono"
        >
          <AlertOctagon className="w-3 h-3 stroke-[2.5]" />
          <span>SOS</span>
        </button>

        {/* 4. Shield Icon Button */}
        <button
          type="button"
          id="btn-header-shield"
          onClick={() => setSafetyModalOpen(true)}
          className="w-7 h-7 rounded-lg bg-neutral-100 border border-neutral-200 hover:border-[#FFD60A] text-neutral-900 flex items-center justify-center transition active:scale-95 shadow-xs flex-shrink-0"
          title="ZOLTA Safety Protection"
        >
          <Shield className="w-3.5 h-3.5 stroke-[2.5] text-[#D97706]" />
        </button>
      </div>
    </header>
  );
};


import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { PhoneOff, Mic, MicOff, Volume2, VolumeX, Shield, PhoneCall } from 'lucide-react';

export const VoiceCallModal: React.FC = () => {
  const {
    isVoiceCallModalOpen,
    voiceCallData,
    endVoiceCall,
    toggleCallMute,
    toggleCallSpeaker,
  } = useApp();

  if (!isVoiceCallModalOpen) return null;

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div id="voice-call-overlay" className="fixed inset-0 z-50 bg-gray-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-gray-900 border border-gray-800 w-full max-w-sm rounded-3xl p-6 text-white text-center shadow-2xl flex flex-col items-center justify-between min-h-[460px]"
      >
        {/* Call Security Badge */}
        <div className="flex items-center gap-1.5 bg-gray-800/80 text-emerald-400 text-xs font-semibold px-3 py-1 rounded-full border border-gray-700">
          <Shield className="w-3.5 h-3.5" />
          <span>Encrypted inDrive VoIP Call</span>
        </div>

        {/* Target Info & Waves */}
        <div className="flex flex-col items-center my-auto">
          <div className="relative mb-6">
            <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#a3e635] to-emerald-500 flex items-center justify-center p-1 shadow-2xl">
              <div className="w-full h-full rounded-full bg-gray-900 flex items-center justify-center">
                <PhoneCall className="w-10 h-10 text-[#a3e635] animate-pulse" />
              </div>
            </div>
            {/* Animated Wave Rings */}
            <div className="absolute inset-0 rounded-full border-2 border-[#a3e635]/40 animate-ping" />
          </div>

          <h3 className="text-xl font-bold text-white mb-1">
            {voiceCallData.targetName || 'Driver'}
          </h3>
          <span className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
            {voiceCallData.targetRole}
          </span>

          <div className="text-2xl font-mono font-bold text-[#a3e635] bg-gray-800/60 px-4 py-1.5 rounded-xl border border-gray-700">
            {formatDuration(voiceCallData.durationSec)}
          </div>
        </div>

        {/* Audio Wave Sim */}
        <div className="flex items-center gap-1 h-8 mb-6">
          {[40, 70, 90, 60, 30, 80, 100, 50, 70, 30].map((h, i) => (
            <motion.div
              key={i}
              animate={{ height: [`${h * 0.3}%`, `${h}%`, `${h * 0.4}%`] }}
              transition={{ repeat: Infinity, duration: 0.8 + (i % 3) * 0.2, ease: 'easeInOut' }}
              className="w-1 bg-[#a3e635] rounded-full"
            />
          ))}
        </div>

        {/* Call Action Buttons */}
        <div className="w-full flex items-center justify-center gap-6 pt-2">
          {/* Mute Toggle */}
          <button
            type="button"
            id="btn-call-mute"
            onClick={toggleCallMute}
            className={`w-13 h-13 rounded-full flex items-center justify-center transition ${
              voiceCallData.isMuted
                ? 'bg-red-500 text-white'
                : 'bg-gray-800 hover:bg-gray-700 text-gray-200'
            }`}
          >
            {voiceCallData.isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          </button>

          {/* End Call Button */}
          <button
            type="button"
            id="btn-call-hangup"
            onClick={endVoiceCall}
            className="w-16 h-16 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center shadow-lg transition transform active:scale-95"
          >
            <PhoneOff className="w-7 h-7" />
          </button>

          {/* Speaker Toggle */}
          <button
            type="button"
            id="btn-call-speaker"
            onClick={toggleCallSpeaker}
            className={`w-13 h-13 rounded-full flex items-center justify-center transition ${
              voiceCallData.isSpeaker
                ? 'bg-[#a3e635] text-black font-bold'
                : 'bg-gray-800 hover:bg-gray-700 text-gray-200'
            }`}
          >
            {voiceCallData.isSpeaker ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

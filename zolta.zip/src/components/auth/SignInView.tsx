import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  Smartphone,
  Mail,
  Lock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  User,
  Users,
} from 'lucide-react';
import {
  loginWithEmail,
  registerWithEmail,
  loginWithGoogle,
  verifyPhoneOtp,
} from '../../services/authService';
import logoImg from '../../assets/images/logo.png';

export const SignInView: React.FC = () => {
  const { setAuthenticatedUser } = useApp();

  const [authTab, setAuthTab] = useState<'phone' | 'email'>('phone');
  const [emailMode, setEmailMode] = useState<'signin' | 'signup'>('signin');

  // Phone tab states
  const [countryCode, setCountryCode] = useState('+27');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState(['', '', '', '']);
  const [phoneTimer, setPhoneTimer] = useState(30);

  // Email tab states
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);

  // Status & loading
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Phone OTP Flow
  const handleSendCode = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    if (!phoneNumber || digitsOnly.length < 9) {
      setErrorMessage('Please enter a valid South African phone number (e.g. 082 123 4567)');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setOtpSent(true);
      setPhoneTimer(30);
    }, 500);
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const code = otpCode.join('');
    if (code.length < 4) {
      setErrorMessage('Please enter all 4 digits of the SMS verification code');
      return;
    }

    setIsLoading(true);
    const fullPhone = `${countryCode} ${phoneNumber.trim()}`;
    const res = await verifyPhoneOtp(fullPhone, code);
    setIsLoading(false);

    if (res.success && res.user) {
      setAuthenticatedUser(res.user);
    } else {
      setErrorMessage(res.error || 'Invalid OTP code. Please try again.');
    }
  };

  // Email Flow
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email || !password) {
      setErrorMessage('Please enter your email address and password');
      return;
    }

    setIsLoading(true);
    if (emailMode === 'signin') {
      const res = await loginWithEmail(email.trim(), password);
      setIsLoading(false);
      if (res.success && res.user) {
        setAuthenticatedUser(res.user);
      } else {
        setErrorMessage(res.error || 'Failed to sign in. Please verify credentials.');
      }
    } else {
      if (!fullName) {
        setIsLoading(false);
        setErrorMessage('Please enter your full name');
        return;
      }
      const res = await registerWithEmail(fullName.trim(), email.trim(), password);
      setIsLoading(false);
      if (res.success && res.user) {
        setAuthenticatedUser(res.user);
      } else {
        setErrorMessage(res.error || 'Failed to create account.');
      }
    }
  };

  // Google Flow
  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setIsLoading(true);
    const res = await loginWithGoogle();
    setIsLoading(false);
    if (res.success && res.user) {
      setAuthenticatedUser(res.user);
    } else {
      setErrorMessage(res.error || 'Google sign-in was interrupted');
    }
  };

  return (
    <div
      id="signin-view"
      className="min-h-screen bg-[#FFFBEB] flex flex-col items-center justify-center p-4 sm:p-6 text-neutral-900 select-none relative overflow-hidden"
    >
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="w-full max-w-md bg-white rounded-[28px] border border-amber-200/80 shadow-[0_12px_40px_-12px_rgba(0,0,0,0.08)] p-6 sm:p-8 relative overflow-hidden z-10"
      >
        {/* Top: Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          {/* Logo: Gold Z shield image with ambient gold glow */}
          <div className="relative mb-3 group">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#FFD60A] via-amber-400 to-[#FFCC00] rounded-2xl blur-md opacity-80 group-hover:opacity-100 transition duration-500"></div>
            <div className="relative w-16 h-16 rounded-2xl bg-black p-1 shadow-xl border border-amber-300/50 flex items-center justify-center overflow-hidden">
              <img
                src={logoImg}
                alt="ZOLTA Gold Shield Logo"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <div className="absolute -bottom-1 -right-1 bg-[#FFCC00] text-black rounded-full p-1 shadow-md border-2 border-white">
              <ShieldCheck className="w-3.5 h-3.5 stroke-[2.5]" />
            </div>
          </div>

          <h1 className="text-3xl font-black tracking-tight text-neutral-900 font-sans">
            ZOLTA
          </h1>
          <p className="text-[11px] uppercase text-neutral-500 tracking-wider mt-0.5 font-bold font-mono">
            SAFE RIDE + COMMUNITY SERVICE • VERIFIED DRIVERS
          </p>
        </div>

        {/* Error Alert Box */}
        {errorMessage && (
          <div className="mb-4 p-3.5 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-xs text-red-700 shadow-xs">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
            <span className="font-medium">{errorMessage}</span>
          </div>
        )}

        {/* Tabs: PHONE (SMS) | EMAIL & PASS - yellow active tab */}
        <div className="flex items-center gap-1.5 p-1 bg-neutral-100 rounded-2xl border border-neutral-200 mb-5 font-mono text-xs shadow-inner">
          <button
            type="button"
            id="tab-auth-phone"
            onClick={() => {
              setAuthTab('phone');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
              authTab === 'phone'
                ? 'bg-[#FFCC00] text-black shadow-sm'
                : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>PHONE (SMS)</span>
          </button>

          <button
            type="button"
            id="tab-auth-email"
            onClick={() => {
              setAuthTab('email');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
              authTab === 'email'
                ? 'bg-[#FFCC00] text-black shadow-sm'
                : 'text-neutral-600 hover:text-black'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>EMAIL & PASS</span>
          </button>
        </div>

        {/* TAB 1: PHONE SMS OTP */}
        {authTab === 'phone' && (
          <div className="space-y-4">
            {!otpSent ? (
              <form onSubmit={handleSendCode} className="space-y-4">
                <div>
                  <label className="font-mono text-[10px] font-bold uppercase text-neutral-600 block mb-1.5 tracking-wider">
                    SOUTH AFRICA MOBILE NUMBER
                  </label>
                  <div className="flex rounded-[16px] border border-neutral-300 focus-within:border-black focus-within:ring-2 focus-within:ring-[#FFCC00]/50 bg-neutral-50 overflow-hidden shadow-xs transition">
                    <div className="flex items-center gap-1.5 bg-neutral-100 px-3.5 py-3 border-r border-neutral-300 text-xs font-bold text-neutral-800">
                      <span>🇿🇦</span>
                      <span className="font-mono font-bold">+27</span>
                    </div>
                    <input
                      type="tel"
                      id="input-phone-auth"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="082 123 4567"
                      autoFocus
                      className="flex-1 px-3.5 py-3 text-sm font-bold text-neutral-900 bg-transparent outline-none placeholder:text-neutral-400 font-mono"
                      required
                    />
                  </div>
                </div>

                {/* Primary SEND CODE button -> yellow #FFCC00 black text */}
                <button
                  type="submit"
                  id="btn-send-phone-otp"
                  disabled={isLoading}
                  className="w-full bg-[#FFCC00] hover:bg-[#e6b800] disabled:opacity-50 text-black font-black text-xs py-3.5 px-4 rounded-[16px] flex items-center justify-center gap-2 shadow-md transition active:scale-[0.98]"
                >
                  <span className="tracking-wide">{isLoading ? 'SENDING SMS CODE...' : 'SEND CODE (SMS OTP)'}</span>
                  <ArrowRight className="w-4 h-4 stroke-[3]" />
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-4">
                <div className="text-center">
                  <span className="text-xs text-neutral-600">
                    Code sent to <strong>{countryCode} {phoneNumber}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="block mx-auto text-[11px] text-black font-bold mt-1 underline hover:text-neutral-700"
                  >
                    Change phone number
                  </button>
                </div>

                {/* 4-digit OTP Inputs */}
                <div className="flex justify-center gap-2.5 my-2">
                  {otpCode.map((digit, idx) => (
                    <input
                      key={idx}
                      id={`otp-input-${idx}`}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        const newArr = [...otpCode];
                        newArr[idx] = val;
                        setOtpCode(newArr);
                        if (val && idx < 3) {
                          document.getElementById(`otp-input-${idx + 1}`)?.focus();
                        }
                      }}
                      className="w-12 h-14 text-center font-mono font-black text-xl border-2 border-neutral-300 focus:border-black focus:ring-2 focus:ring-[#FFCC00]/40 rounded-2xl bg-neutral-50 outline-none text-black transition"
                    />
                  ))}
                </div>

                <button
                  type="submit"
                  id="btn-verify-phone-otp"
                  disabled={isLoading}
                  className="w-full bg-[#FFCC00] hover:bg-[#e6b800] disabled:opacity-50 text-black font-black text-xs py-3.5 px-4 rounded-[16px] flex items-center justify-center gap-2 shadow-md transition active:scale-[0.98]"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="tracking-wide">{isLoading ? 'VERIFYING...' : 'VERIFY & ENTER ZOLTA'}</span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: EMAIL & PASSWORD */}
        {authTab === 'email' && (
          <form onSubmit={handleEmailSubmit} className="space-y-3.5">
            {emailMode === 'signup' && (
              <div>
                <label className="font-mono text-[10px] font-bold uppercase text-neutral-600 block mb-1 tracking-wider">
                  FULL NAME
                </label>
                <div className="flex items-center gap-2 px-3 py-2.5 rounded-[16px] border border-neutral-300 focus-within:border-black focus-within:ring-2 focus-within:ring-[#FFCC00]/40 bg-neutral-50 shadow-xs transition">
                  <User className="w-4 h-4 text-neutral-400" />
                  <input
                    type="text"
                    id="input-signup-name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Siyabonga Qamlana"
                    className="flex-1 text-xs font-bold text-neutral-900 bg-transparent outline-none placeholder:text-neutral-400"
                    required={emailMode === 'signup'}
                  />
                </div>
              </div>
            )}

            <div>
              <label className="font-mono text-[10px] font-bold uppercase text-neutral-600 block mb-1 tracking-wider">
                EMAIL ADDRESS
              </label>
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-[16px] border border-neutral-300 focus-within:border-black focus-within:ring-2 focus-within:ring-[#FFCC00]/40 bg-neutral-50 shadow-xs transition">
                <Mail className="w-4 h-4 text-neutral-400" />
                <input
                  type="email"
                  id="input-auth-email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.co.za"
                  className="flex-1 text-xs font-bold text-neutral-900 bg-transparent outline-none placeholder:text-neutral-400"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-mono text-[10px] font-bold uppercase text-neutral-600 tracking-wider">
                  PASSWORD
                </label>
                {emailMode === 'signin' && (
                  <button
                    type="button"
                    onClick={() => {
                      setForgotSent(true);
                      setTimeout(() => setForgotSent(false), 3000);
                    }}
                    className="text-[10px] font-mono font-bold text-neutral-500 hover:text-black"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-[16px] border border-neutral-300 focus-within:border-black focus-within:ring-2 focus-within:ring-[#FFCC00]/40 bg-neutral-50 shadow-xs transition">
                <Lock className="w-4 h-4 text-neutral-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="input-auth-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="flex-1 text-xs font-bold text-neutral-900 bg-transparent outline-none placeholder:text-neutral-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-neutral-400 hover:text-black p-1"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {forgotSent && (
              <p className="text-[11px] text-emerald-700 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 text-center font-mono font-medium">
                Password reset link sent to your email!
              </p>
            )}

            <button
              type="submit"
              id="btn-submit-email-auth"
              disabled={isLoading}
              className="w-full bg-[#FFCC00] hover:bg-[#e6b800] disabled:opacity-50 text-black font-black text-xs py-3.5 px-4 rounded-[16px] flex items-center justify-center gap-2 shadow-md transition active:scale-[0.98] mt-2"
            >
              <span className="tracking-wide">
                {isLoading
                  ? 'PROCESSING...'
                  : emailMode === 'signin'
                  ? 'SIGN IN TO ZOLTA'
                  : 'CREATE ACCOUNT & START'}
              </span>
              <ArrowRight className="w-4 h-4 stroke-[3]" />
            </button>

            {/* Toggle Sign In / Sign Up */}
            <div className="text-center pt-1">
              <button
                type="button"
                id="btn-toggle-signup"
                onClick={() => {
                  setEmailMode(emailMode === 'signin' ? 'signup' : 'signin');
                  setErrorMessage(null);
                }}
                className="text-xs text-neutral-600 hover:text-black font-medium"
              >
                {emailMode === 'signin' ? (
                  <>
                    Don't have an account? <strong className="text-black underline">Sign Up</strong>
                  </>
                ) : (
                  <>
                    Already have an account? <strong className="text-black underline">Sign In</strong>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* Divider: OR CONTINUE WITH */}
        <div className="relative my-5 flex items-center justify-center">
          <div className="border-t border-neutral-200 w-full" />
          <span className="bg-white px-3 font-mono text-[10px] text-neutral-400 font-bold uppercase tracking-wider absolute">
            OR CONTINUE WITH
          </span>
        </div>

        {/* Button: Continue with Google with G logo */}
        <button
          type="button"
          id="btn-google-signin"
          onClick={handleGoogleSignIn}
          disabled={isLoading}
          className="w-full bg-white hover:bg-neutral-50 border border-neutral-300 py-3 px-4 rounded-[16px] flex items-center justify-center gap-3 font-bold text-xs text-neutral-900 transition active:scale-[0.98] shadow-xs"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        {/* Footer: Safety First • Trusted in SA */}
        <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-center gap-1.5 text-center">
          <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
          <p className="text-[11px] font-mono font-medium text-neutral-500">
            Safety First • Trusted in SA 🇿🇦
          </p>
        </div>
      </motion.div>
    </div>
  );
};

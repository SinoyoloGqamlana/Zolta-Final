import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { DriverGenderPreference } from '../../types';
import { X, ArrowLeft, Users, User, ShieldCheck, Star, CreditCard, Banknote, Zap, Check } from 'lucide-react';

interface TripPreferencesModalProps {
  onClose?: () => void;
}

export const TripPreferencesModal: React.FC<TripPreferencesModalProps> = ({ onClose }) => {
  const { isPreferencesModalOpen, setPreferencesModalOpen, user } = useApp();
  const [driverPref, setDriverPref] = useState<DriverGenderPreference>('any');
  const [ratingFilter, setRatingFilter] = useState<'all' | '4.0' | '4.5' | '4.8'>('all');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'payshap'>('cash');

  if (!isPreferencesModalOpen) return null;

  const handleClose = () => {
    setPreferencesModalOpen(false);
    if (onClose) onClose();
  };

  const handleApply = () => {
    handleClose();
  };

  return (
    <div id="trip-preferences-modal-overlay" className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white border border-[#E5E7EB] text-[#111111] w-full max-w-lg rounded-none sm:rounded-[20px] shadow-2xl relative overflow-hidden my-auto"
      >
        {/* Sticky 56px Top Header Bar */}
        <div className="h-[56px] min-h-[56px] bg-white border-b border-neutral-200 px-4 flex items-center justify-between text-black sticky top-0 z-10">
          <button
            type="button"
            id="btn-back-trip-preferences"
            onClick={handleClose}
            className="w-10 h-10 -ml-2 rounded-full hover:bg-neutral-100 flex items-center justify-center text-black transition active:scale-95"
            title="Back"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <h2 className="text-base font-bold text-black text-center truncate flex-1 px-2 font-sans">
            Trip Preferences
          </h2>
          <button
            id="btn-close-trip-preferences"
            type="button"
            onClick={handleClose}
            className="w-10 h-10 -mr-2 rounded-full hover:bg-neutral-100 flex items-center justify-center text-black transition active:scale-95"
            title="Close"
          >
            <X className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6">
          <p className="font-mono text-[10px] uppercase text-[#8B8B8B] tracking-wider mb-5">
            Select preferred driver gender profile & trip filters
          </p>

        <div className="space-y-5">
          {/* SECTION 1: DRIVER PREFERENCE */}
          <div>
            <label className="font-mono text-[10px] font-bold uppercase text-[#8B8B8B] block mb-2 tracking-wider">
              DRIVER PREFERENCE
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'any', label: 'All Drivers', icon: Users, sub: 'Fastest ETA' },
                { id: 'female', label: 'Female Only', icon: ShieldCheck, sub: 'Safety Priority' },
                { id: 'male', label: 'Male Only', icon: User, sub: 'Standard' },
              ].map((opt) => {
                const isSelected = driverPref === opt.id;
                const IconComponent = opt.icon;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setDriverPref(opt.id as DriverGenderPreference)}
                    className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center ${
                      isSelected
                        ? 'bg-[#FFD60A] border-[#FFD60A] text-black shadow-xs font-bold'
                        : 'bg-neutral-50 border-[#E5E7EB] text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    <IconComponent className="w-4 h-4 mb-1.5" />
                    <span className="text-xs font-black block leading-tight">{opt.label}</span>
                    <span className="text-[9px] font-mono uppercase text-neutral-600 mt-0.5">{opt.sub}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 2: DRIVER RATING FILTER */}
          <div>
            <label className="font-mono text-[10px] font-bold uppercase text-[#8B8B8B] block mb-2 tracking-wider">
              DRIVER RATING FILTER
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'all', label: 'All Ratings' },
                { id: '4.0', label: '4.0+ ⭐' },
                { id: '4.5', label: '4.5+ ⭐' },
                { id: '4.8', label: '4.8+ Top' },
              ].map((rt) => {
                const isSelected = ratingFilter === rt.id;
                return (
                  <button
                    key={rt.id}
                    type="button"
                    onClick={() => setRatingFilter(rt.id as any)}
                    className={`py-2.5 px-2 rounded-xl border text-center text-xs transition ${
                      isSelected
                        ? 'bg-[#FFD60A] border-[#FFD60A] text-black font-black shadow-xs'
                        : 'bg-neutral-50 border-[#E5E7EB] text-neutral-700 hover:bg-neutral-100 font-semibold'
                    }`}
                  >
                    {rt.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 3: PAYMENT METHOD */}
          <div>
            <label className="font-mono text-[10px] font-bold uppercase text-[#8B8B8B] block mb-2 tracking-wider">
              PAYMENT METHOD
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'cash', label: 'Cash', icon: Banknote },
                { id: 'card', label: 'Card', icon: CreditCard },
                { id: 'payshap', label: 'PayShap', icon: Zap },
              ].map((pm) => {
                const isSelected = paymentMethod === pm.id;
                const IconComponent = pm.icon;
                return (
                  <button
                    key={pm.id}
                    id={`pay-pref-${pm.id}`}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id as any)}
                    className={`p-3 rounded-2xl border text-center transition flex items-center justify-center gap-2 ${
                      isSelected
                        ? 'bg-neutral-900 border-neutral-900 text-white font-bold shadow-xs'
                        : 'bg-neutral-50 border-[#E5E7EB] text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    <IconComponent className={`w-4 h-4 ${isSelected ? 'text-[#FFD60A]' : 'text-neutral-500'}`} />
                    <span className="text-xs font-black">{pm.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* APPLY PREFERENCES BUTTON */}
          <button
            id="btn-apply-trip-preferences"
            type="button"
            onClick={handleApply}
            className="w-full bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-3.5 rounded-2xl shadow-xs transition active:scale-98 uppercase tracking-wider flex items-center justify-center gap-2 border border-yellow-300"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>APPLY PREFERENCES</span>
          </button>
        </div>
      </div>
      </motion.div>
    </div>
  );
};

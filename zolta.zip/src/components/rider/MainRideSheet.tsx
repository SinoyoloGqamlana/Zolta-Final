import React, { useState, useEffect, useRef } from 'react';
import { LocationPoint, RideCategory } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  CATEGORIES_DATA,
  searchPlaces,
  calculateDistanceKm,
  calculateSuggestedFare,
  calculateDurationMins,
  POPULAR_LOCATIONS,
  NGABA_NGABA_LOCATION,
} from '../../services/geoService';
import {
  Search,
  Clock,
  MapPin,
  X,
  Minus,
  Plus,
  SlidersHorizontal,
  Check,
  Tag,
  Navigation,
  ArrowRight,
  ChevronRight,
  ArrowLeft,
  Loader2,
} from 'lucide-react';
import { VehicleGraphic } from './VehicleIcons';

interface MainRideSheetProps {
  pickup: LocationPoint;
  dropoff: LocationPoint | null;
  category: RideCategory;
  onSelectPickup: (loc: LocationPoint) => void;
  onSelectDropoff: (loc: LocationPoint | null) => void;
  onSelectCategory: (cat: RideCategory) => void;
  onRequestRide: (fare: number, paymentMethod: 'cash' | 'card' | 'payshap') => void;
}

// Real user recent destinations stored after rides
const DEFAULT_RECENT_DESTINATIONS: LocationPoint[] = [];

export const MainRideSheet: React.FC<MainRideSheetProps> = ({
  pickup,
  dropoff,
  category,
  onSelectPickup,
  onSelectDropoff,
  onSelectCategory,
  onRequestRide,
}) => {
  const { setPreferencesModalOpen, getRealGpsPosition, speak, activeRide } = useApp();

  // State: whether the "Find Offer" / Bidding Proposal bottom sheet is popped up
  const [isOfferSheetOpen, setIsOfferSheetOpen] = useState(false);

  // Route Popup Modal State (Opens when clicking Where to or Change destination)
  const [isRouteModalOpen, setIsRouteModalOpen] = useState(false);
  const [activeInputFocus, setActiveInputFocus] = useState<'pickup' | 'dropoff'>('dropoff');

  // Anti-spam & loading state for FIND OFFER (5 sec disable on tap)
  const [isBroadcasting, setIsBroadcasting] = useState(false);

  useEffect(() => {
    window.dispatchEvent(
      new CustomEvent('zolta_route_modal_toggle', {
        detail: { isOpen: isRouteModalOpen || isOfferSheetOpen },
      })
    );
  }, [isRouteModalOpen, isOfferSheetOpen]);

  // Inputs inside the Route Popup
  const [pickupText, setPickupText] = useState(pickup?.address || 'Ngaba Ngaba Crescent, Khayelitsha');
  const [destQuery, setDestQuery] = useState(dropoff?.address || '');
  const [searchResults, setSearchResults] = useState<LocationPoint[]>([]);
  const [isGpsLoading, setIsGpsLoading] = useState(false);

  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'payshap'>('cash');
  const [showPromoDetails, setShowPromoDetails] = useState(false);
  const [isBannerDismissed, setIsBannerDismissed] = useState(false);

  const destInputRef = useRef<HTMLInputElement | null>(null);
  const pickupInputRef = useRef<HTMLInputElement | null>(null);

  // Sync pickupText when pickup changes
  useEffect(() => {
    if (pickup?.address) {
      setPickupText(pickup.address);
    }
  }, [pickup]);

  // Sync destQuery when dropoff changes
  useEffect(() => {
    if (dropoff?.address) {
      setDestQuery(dropoff.address);
    }
  }, [dropoff]);

  // Focus appropriate input when modal opens
  useEffect(() => {
    if (isRouteModalOpen) {
      setTimeout(() => {
        if (activeInputFocus === 'pickup') {
          pickupInputRef.current?.focus();
          pickupInputRef.current?.select();
        } else {
          destInputRef.current?.focus();
          destInputRef.current?.select();
        }
      }, 150);
    }
  }, [isRouteModalOpen, activeInputFocus]);

  // Real recent trips saved from completed bookings
  const [recentTrips, setRecentTrips] = useState<LocationPoint[]>(() => {
    try {
      const saved = localStorage.getItem('zolta_recent_trips');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.slice(0, 5);
        }
      }
    } catch {}
    return [];
  });

  // Promo20 state from localStorage
  const [hasPromo, setHasPromo] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('promo20');
      if (stored === null) {
        localStorage.setItem('promo20', 'true');
        return true;
      }
      return stored === 'true';
    } catch {
      return true;
    }
  });

  // Sync promo updates across window events
  useEffect(() => {
    const handlePromoSync = () => {
      try {
        const stored = localStorage.getItem('promo20');
        setHasPromo(stored === 'true');
      } catch {}
    };
    window.addEventListener('storage', handlePromoSync);
    window.addEventListener('zolta_promo_updated', handlePromoSync);
    return () => {
      window.removeEventListener('storage', handlePromoSync);
      window.removeEventListener('zolta_promo_updated', handlePromoSync);
    };
  }, []);

  // Distance & fare calculations
  const distanceKm = dropoff
    ? calculateDistanceKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng)
    : 1.9;
  const durationMins = calculateDurationMins(distanceKm);

  // Base fare calculation
  const rawBaseFare = dropoff
    ? calculateSuggestedFare(distanceKm, category)
    : (CATEGORIES_DATA.find((c) => c.id === category)?.fixedDefaultPrice || 25);

  // Effective fare with 20% discount if promo is active (Min R20, Max R1000)
  const calculateEffectiveFare = (base: number, promoActive: boolean) => {
    let price = base;
    if (promoActive) {
      price = Math.round((base * 0.8) / 5) * 5 || Math.round(base * 0.8);
    }
    return Math.max(20, Math.min(1000, price));
  };

  const [fare, setFare] = useState<number>(() => calculateEffectiveFare(rawBaseFare, hasPromo));

  useEffect(() => {
    const effective = calculateEffectiveFare(rawBaseFare, hasPromo);
    setFare(effective);
  }, [dropoff, category, distanceKm, hasPromo, rawBaseFare]);

  // Search handlers for Pickup and Destination
  const handlePickupTextChange = async (text: string) => {
    setPickupText(text);
    setActiveInputFocus('pickup');
    if (text.trim().length > 1) {
      const results = await searchPlaces(text);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const handleSearchChange = async (text: string) => {
    setDestQuery(text);
    setActiveInputFocus('dropoff');
    if (text.trim().length > 1) {
      const results = await searchPlaces(text);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  // Select place from suggestions / recent list
  const handleSelectPlace = (place: LocationPoint) => {
    if (activeInputFocus === 'pickup') {
      onSelectPickup(place);
      setPickupText(place.shortName || place.name || place.address);
      setSearchResults([]);
      setActiveInputFocus('dropoff');
      destInputRef.current?.focus();
    } else {
      onSelectDropoff(place);
      setDestQuery(place.shortName || place.name || place.address);
      setSearchResults([]);
      setIsRouteModalOpen(false);
      setIsOfferSheetOpen(true);
      try {
        localStorage.setItem('zolta_saved_dest', JSON.stringify(place));
      } catch {}
    }
  };

  // Custom typed location handler
  const handleSelectCustomTyped = () => {
    if (!destQuery.trim()) return;
    const trimmed = destQuery.trim();
    const isNgaba = trimmed.toLowerCase().includes('ngaba');
    const pLat =
      pickup && typeof pickup.lat === 'number' && !isNaN(pickup.lat) && isFinite(pickup.lat)
        ? pickup.lat
        : -34.0456;
    const pLng =
      pickup && typeof pickup.lng === 'number' && !isNaN(pickup.lng) && isFinite(pickup.lng)
        ? pickup.lng
        : 18.6656;
    const customLoc: LocationPoint = {
      id: `custom_dest_${Date.now()}`,
      name: trimmed.split(',')[0],
      shortName: trimmed.split(',')[0],
      address:
        isNgaba && !trimmed.toLowerCase().includes('khayelitsha')
          ? `${trimmed}, Ilitha Park, Khayelitsha, Cape Town`
          : trimmed,
      lat: isNgaba ? -34.0456 : pLat + 0.015,
      lng: isNgaba ? 18.6656 : pLng + 0.015,
    };
    handleSelectPlace(customLoc);
  };

  // Handle Pickup GPS fetch
  const handlePickupGps = async () => {
    setIsGpsLoading(true);
    try {
      const pos = await getRealGpsPosition();
      if (
        pos &&
        typeof pos.lat === 'number' &&
        !isNaN(pos.lat) &&
        typeof pos.lng === 'number' &&
        !isNaN(pos.lng)
      ) {
        onSelectPickup(pos);
        setPickupText(pos.address);
        speak('Updated pickup to your current GPS location');
      }
    } catch (err) {
      console.warn('GPS error:', err);
    } finally {
      setIsGpsLoading(false);
    }
  };

  // Handle Pickup text change manually
  const handlePickupBlur = () => {
    if (!pickupText.trim()) {
      setPickupText(pickup?.address || 'Ngaba Ngaba Crescent, Khayelitsha');
      return;
    }
    if (pickupText !== pickup?.address) {
      const pLat =
        pickup && typeof pickup.lat === 'number' && !isNaN(pickup.lat) && isFinite(pickup.lat)
          ? pickup.lat
          : -34.0456;
      const pLng =
        pickup && typeof pickup.lng === 'number' && !isNaN(pickup.lng) && isFinite(pickup.lng)
          ? pickup.lng
          : 18.6656;
      const updated: LocationPoint = {
        ...pickup,
        id: `custom_pickup_${Date.now()}`,
        name: pickupText.split(',')[0],
        shortName: pickupText.split(',')[0],
        address: pickupText,
        lat: pLat,
        lng: pLng,
      };
      onSelectPickup(updated);
    }
  };

  // Price adjustment with min R20, max R1000, debounce 500ms
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleFareDecrease = () => {
    if (fare <= 20) return;
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    debounceTimerRef.current = setTimeout(() => {
      setFare((prev) => Math.max(20, prev - 5));
    }, 50);
  };

  const handleFareIncrease = () => {
    if (fare >= 1000) return;
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    debounceTimerRef.current = setTimeout(() => {
      setFare((prev) => Math.min(1000, prev + 5));
    }, 50);
  };

  const handleFareQuickAdd = (amount: number) => {
    if (fare >= 1000) return;
    setFare((prev) => Math.min(1000, Math.max(20, prev + amount)));
  };

  // Handle Finding Offer (Protected with 5-sec cooldown & Single active ride check)
  const handleFindOfferSubmit = () => {
    if (isBroadcasting) return;
    if (activeRide && activeRide.status === 'searching') return;

    setIsBroadcasting(true);

    // Save to recent trips
    if (dropoff) {
      try {
        const updatedRecent = [
          dropoff,
          ...recentTrips.filter((r) => r.address !== dropoff.address),
        ].slice(0, 5);
        localStorage.setItem('zolta_recent_trips', JSON.stringify(updatedRecent));
        setRecentTrips(updatedRecent);
      } catch {}
    }

    // Single use promo logic
    if (hasPromo) {
      try {
        localStorage.setItem('promo20', 'false');
        setHasPromo(false);
        window.dispatchEvent(new Event('zolta_promo_updated'));
      } catch {}
    }

    speak('Broadcasting offer to verified drivers');
    onRequestRide(fare, paymentMethod);

    // Disable button for 5 seconds to prevent double click spam
    setTimeout(() => {
      setIsBroadcasting(false);
    }, 5000);
  };

  const strikePrice = hasPromo ? rawBaseFare : null;

  return (
    <div id="zolta-main-ride-sheet-container" className="w-full relative select-none">
      {/* 1. FLOATING DISCOUNT BANNER (White card with crisp green voucher badge) */}
      {hasPromo && !isBannerDismissed && !isOfferSheetOpen && (
        <div
          id="promo-banner-indrive"
          className="w-full mb-2.5 bg-white hover:bg-neutral-50 border border-neutral-200 text-black rounded-2xl px-3.5 py-2.5 flex items-center justify-between shadow-lg transition cursor-pointer animate-in fade-in slide-in-from-bottom-2 duration-150"
          onClick={() => setShowPromoDetails(true)}
        >
          <div className="flex items-center gap-3 min-w-0 flex-1">
            {/* Voucher Icon */}
            <div className="w-10 h-10 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/30 flex items-center justify-center flex-shrink-0">
              <div className="w-7 h-7 rounded-lg bg-[#22C55E] text-black font-black text-xs flex items-center justify-center shadow-xs">
                %
              </div>
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="text-[13px] font-bold text-black leading-tight">
                Check your discount!
              </div>
              <div className="text-[11px] text-neutral-500 font-medium truncate mt-0.5">
                Tap to get 20% off at Zolta MAX
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
            <ChevronRight className="w-5 h-5 text-neutral-400" />
            <button
              type="button"
              id="btn-dismiss-discount-banner"
              onClick={(e) => {
                e.stopPropagation();
                setIsBannerDismissed(true);
              }}
              className="w-6 h-6 rounded-full hover:bg-neutral-200 text-neutral-400 hover:text-black flex items-center justify-center transition ml-1"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 2. MAIN BOTTOM SHEET CONTAINER (Clean White Background #FFFFFF with Black Text) */}
      <div
        id="zolta-main-ride-sheet"
        className="bg-white text-black rounded-t-[28px] sm:rounded-[28px] shadow-2xl p-3.5 sm:p-4 border-t sm:border border-neutral-200 select-none animate-in fade-in slide-in-from-bottom-3 duration-200 relative space-y-3 max-h-[45vh] overflow-y-auto no-scrollbar"
      >
        {/* Top subtle drag handle bar */}
        <div className="w-10 h-1 rounded-full bg-neutral-300 mx-auto -mt-1 mb-1" />

        {/* ------------------------------------------------------------- */}
        {/* VIEW A: DEFAULT / BROWSE SCREEN                               */}
        {/* ------------------------------------------------------------- */}
        {!isOfferSheetOpen ? (
          <>
            {/* A.1 TOP HORIZONTAL SCROLL 6 PILLS (Ride, Comfort, XL, Bakkie, Scooter, Courier) */}
            <div className="relative">
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 px-0.5">
                {CATEGORIES_DATA.map((cat) => {
                  const isSelected = category === cat.id;
                  const displayName =
                    cat.id === 'rider'
                      ? 'Ride'
                      : cat.id === 'comfort'
                      ? 'Comfort'
                      : cat.id === 'xl'
                      ? 'XL'
                      : cat.id === 'bakkie'
                      ? 'Bakkie'
                      : cat.id === 'scooter'
                      ? 'Scooter'
                      : 'Courier';

                  return (
                    <button
                      key={cat.id}
                      type="button"
                      id={`btn-cat-${cat.id}`}
                      onClick={() => onSelectCategory(cat.id)}
                      className={`flex flex-col items-center justify-between min-w-[78px] sm:min-w-[84px] h-[80px] p-1.5 rounded-2xl transition-all duration-150 active:scale-95 flex-shrink-0 cursor-pointer ${
                        isSelected
                          ? 'bg-[#FFCC00] border-2 border-black/80 shadow-md ring-2 ring-amber-400/40 text-black'
                          : 'bg-[#F5F5F5] hover:bg-neutral-200 border border-neutral-200/80 text-neutral-700'
                      }`}
                    >
                      {/* Real Cars PNG 48x48 transparent glossy */}
                      <div className="w-full flex items-center justify-center flex-1">
                        <VehicleGraphic category={cat.id} isSelected={isSelected} className="w-12 h-12" />
                      </div>
                      <span
                        className={`text-[12px] tracking-tight leading-none mt-0.5 ${
                          isSelected ? 'text-black font-black' : 'text-neutral-700 font-bold'
                        }`}
                      >
                        {displayName}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* A.2 1 BIG "WHERE TO" BUTTON (Height 60px, White bg, Black 16px bold text, Search icon left, Arrow > right showing destination) */}
            <div className="pt-1">
              <button
                type="button"
                id="btn-where-to-main"
                onClick={() => {
                  setActiveInputFocus('dropoff');
                  setIsRouteModalOpen(true);
                }}
                className="w-full h-[60px] min-h-[60px] bg-white hover:bg-neutral-50 active:scale-[0.99] border-2 border-neutral-200 hover:border-black rounded-2xl px-4 py-3 flex items-center justify-between transition cursor-pointer shadow-md group text-left"
              >
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-xl bg-neutral-100 group-hover:bg-[#FFCC00] border border-neutral-200 group-hover:border-black flex items-center justify-center flex-shrink-0 transition">
                    <Search className="w-5 h-5 text-neutral-800 group-hover:text-black stroke-[2.5]" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[16px] font-bold text-black truncate block">
                      {dropoff?.shortName || dropoff?.name ? (
                        <span className="text-black">{dropoff.shortName || dropoff.name}</span>
                      ) : (
                        <span className="text-neutral-900 font-extrabold">Where to?</span>
                      )}
                    </span>
                    <span className="text-[11px] text-neutral-500 font-medium block truncate">
                      {pickup?.shortName || pickup?.address || 'Ngaba Ngaba Crescent'}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
                  <ChevronRight className="w-6 h-6 text-neutral-400 group-hover:text-black transition" />
                </div>
              </button>
            </div>

            {/* A.3 RECENT DESTINATIONS LIST */}
            <div className="space-y-1 pt-1 divide-y divide-neutral-100">
              {recentTrips.slice(0, 4).map((place, idx) => (
                <button
                  key={idx}
                  type="button"
                  id={`btn-recent-dest-${idx}`}
                  onClick={() => handleSelectPlace(place)}
                  className="w-full flex items-center gap-3.5 py-2.5 px-2 hover:bg-neutral-100 rounded-xl transition text-left group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-[#F5F5F5] group-hover:bg-neutral-200 border border-neutral-200 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-4 h-4 text-neutral-500 group-hover:text-black" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-bold text-black truncate group-hover:text-amber-600 transition">
                      {place.shortName || place.name || place.address}
                    </div>
                    <div className="text-[11px] text-neutral-500 truncate mt-0.5">
                      {place.address}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </>
        ) : (
          /* ------------------------------------------------------------- */
          /* VIEW B: FIND OFFER SHEET (Appears when route is selected)      */
          /* ------------------------------------------------------------- */
          <div id="find-offer-popup-content" className="space-y-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
            {/* Header: Bigger Tappable Back & Edit Route Buttons */}
            <div className="flex items-center justify-between border-b border-neutral-200 pb-2.5">
              <button
                type="button"
                id="btn-back-to-browse"
                onClick={() => setIsOfferSheetOpen(false)}
                className="h-10 px-3 rounded-xl bg-neutral-100 hover:bg-neutral-200 active:scale-95 text-black font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-neutral-200 shadow-xs z-[9999]"
              >
                <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                <span>Back</span>
              </button>

              <button
                type="button"
                id="btn-change-route"
                onClick={() => {
                  setActiveInputFocus('dropoff');
                  setIsRouteModalOpen(true);
                }}
                className="h-10 px-3.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:scale-95 text-blue-600 font-bold text-xs flex items-center gap-1 transition border border-blue-200 shadow-xs cursor-pointer z-[9999]"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Edit route</span>
              </button>
            </div>

            {/* Selected Route Summary (Green Pickup & Red Dropoff 56px cards) */}
            <div className="space-y-1.5">
              {/* Pickup */}
              <button
                type="button"
                onClick={() => {
                  setActiveInputFocus('pickup');
                  setIsRouteModalOpen(true);
                }}
                className="w-full h-[52px] bg-[#F9FAFB] hover:bg-neutral-100 rounded-2xl border border-neutral-200 px-3.5 py-2 flex items-center justify-between transition cursor-pointer text-left"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20 flex-shrink-0" />
                  <span className="text-xs font-semibold text-neutral-800 truncate">
                    {pickup?.address || 'Ngaba Ngaba Crescent, Khayelitsha'}
                  </span>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-400 flex-shrink-0 ml-2" />
              </button>

              {/* Dropoff */}
              <button
                type="button"
                onClick={() => {
                  setActiveInputFocus('dropoff');
                  setIsRouteModalOpen(true);
                }}
                className="w-full h-[52px] bg-[#F9FAFB] hover:bg-neutral-100 rounded-2xl border border-neutral-200 px-3.5 py-2 flex items-center justify-between transition cursor-pointer text-left"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-3 h-3 rounded-full bg-red-500 ring-4 ring-red-500/20 flex-shrink-0" />
                  <span className="text-xs font-bold text-black truncate">
                    {dropoff?.shortName || dropoff?.name || dropoff?.address || '48 Beethoven St, Delft South'}
                  </span>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-400 flex-shrink-0 ml-2" />
              </button>
            </div>

            {/* Trip Preferences, Quick Fare Bumps (+R3, +R5, +R10), and Payment method */}
            <div className="flex items-center justify-between gap-2 px-0.5">
              {/* Quick Fare Increment Pills (+R3, +R5, +R10) */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono font-bold text-neutral-500 uppercase">Raise:</span>
                <button
                  type="button"
                  id="btn-quick-add-3"
                  onClick={() => handleFareQuickAdd(3)}
                  className="h-[24px] px-2 bg-neutral-100 hover:bg-[#FFCC00] text-black border border-neutral-200 text-[10px] font-black rounded-lg transition active:scale-95 cursor-pointer font-mono"
                >
                  +R3
                </button>
                <button
                  type="button"
                  id="btn-quick-add-5"
                  onClick={() => handleFareQuickAdd(5)}
                  className="h-[24px] px-2 bg-neutral-100 hover:bg-[#FFCC00] text-black border border-neutral-200 text-[10px] font-black rounded-lg transition active:scale-95 cursor-pointer font-mono"
                >
                  +R5
                </button>
                <button
                  type="button"
                  id="btn-quick-add-10"
                  onClick={() => handleFareQuickAdd(10)}
                  className="h-[24px] px-2 bg-neutral-100 hover:bg-[#FFCC00] text-black border border-neutral-200 text-[10px] font-black rounded-lg transition active:scale-95 cursor-pointer font-mono"
                >
                  +R10
                </button>
              </div>

              {/* Cash / Card / PayShap Toggle */}
              <div className="flex items-center gap-1 bg-[#F5F5F5] p-0.5 rounded-xl border border-neutral-200">
                <button
                  type="button"
                  id="btn-toggle-pay-cash"
                  onClick={() => setPaymentMethod('cash')}
                  className={`h-[22px] px-2.5 rounded-lg text-[10px] font-bold flex items-center transition cursor-pointer ${
                    paymentMethod === 'cash'
                      ? 'bg-[#FFCC00] text-black shadow-xs font-black'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  CASH
                </button>
                <button
                  type="button"
                  id="btn-toggle-pay-card"
                  onClick={() => setPaymentMethod('card')}
                  className={`h-[22px] px-2.5 rounded-lg text-[10px] font-bold flex items-center transition cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'bg-[#FFCC00] text-black shadow-xs font-black'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  CARD
                </button>
                <button
                  type="button"
                  id="btn-toggle-pay-payshap"
                  onClick={() => setPaymentMethod('payshap')}
                  className={`h-[22px] px-2.5 rounded-lg text-[10px] font-bold flex items-center transition cursor-pointer ${
                    paymentMethod === 'payshap'
                      ? 'bg-[#FFCC00] text-black shadow-xs font-black'
                      : 'text-neutral-600 hover:text-black'
                  }`}
                >
                  PAYSHAP
                </button>
              </div>
            </div>

            {/* UNIFIED YELLOW BOOKING BLOCK: PRICE ADJUSTER BAR + FIND OFFER BUTTON */}
            <div id="unified-yellow-booking-block" className="w-full flex flex-col shadow-xl z-50 pb-2">
              {/* Top half: Yellow Price Adjuster Bar (Min R20, Max R1000, Debounced) */}
              <div className="h-[48px] px-3.5 bg-[#FFD60A] rounded-t-2xl border-t border-x border-yellow-400 flex items-center justify-between">
                {/* Minus button (-R5, disabled at min R20) */}
                <button
                  type="button"
                  id="btn-fare-minus"
                  onClick={handleFareDecrease}
                  disabled={fare <= 20}
                  className={`w-8 h-8 rounded-full bg-black/10 hover:bg-black/20 text-black flex items-center justify-center transition active:scale-90 cursor-pointer ${
                    fare <= 20 ? 'opacity-35 cursor-not-allowed pointer-events-none' : ''
                  }`}
                  title="Decrease fare (Min R20)"
                >
                  <Minus className="w-4 h-4 stroke-[3]" />
                </button>

                {/* Center Price Display */}
                <div className="text-center flex items-center justify-center gap-2">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-[20px] font-black text-black font-mono tracking-tight leading-none">
                      R{fare}
                    </span>
                    {hasPromo && strikePrice && strikePrice > fare && (
                      <span className="line-through text-neutral-700 font-mono text-xs font-bold">
                        R{strikePrice}
                      </span>
                    )}
                  </div>
                  {hasPromo && (
                    <span className="bg-[#4C1D95] text-white font-mono text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                      -20%
                    </span>
                  )}
                  <span className="text-[11px] text-neutral-900 font-mono font-bold">
                    ~{durationMins} min • {distanceKm}km
                  </span>
                </div>

                {/* Plus button (+R5, disabled at max R1000) */}
                <button
                  type="button"
                  id="btn-fare-plus"
                  onClick={handleFareIncrease}
                  disabled={fare >= 1000}
                  className={`w-8 h-8 rounded-full bg-black/10 hover:bg-black/20 text-black flex items-center justify-center transition active:scale-90 cursor-pointer ${
                    fare >= 1000 ? 'opacity-35 cursor-not-allowed pointer-events-none' : ''
                  }`}
                  title="Increase fare (Max R1000)"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                </button>
              </div>

              {/* Bottom half: Yellow FIND OFFER Button */}
              <button
                type="button"
                id="btn-find-offer"
                onClick={handleFindOfferSubmit}
                disabled={isBroadcasting || (activeRide && activeRide.status === 'searching')}
                className={`w-full h-[52px] bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-[15px] sm:text-[16px] rounded-b-2xl active:scale-[0.99] transition flex items-center justify-center gap-2 border-b border-x border-t border-yellow-400/60 uppercase tracking-wider font-mono shadow-md -mt-px cursor-pointer ${
                  isBroadcasting ? 'opacity-80 cursor-wait' : ''
                }`}
              >
                {isBroadcasting ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                    <span>Broadcasting Offer (R{fare})...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span>FIND OFFER (R{fare} • {paymentMethod.toUpperCase()})</span>
                    {hasPromo && (
                      <span className="bg-[#4C1D95] text-white text-[9px] font-black font-mono px-1.5 py-0.5 rounded-md uppercase tracking-tight shadow-xs">
                        20% OFF
                      </span>
                    )}
                  </div>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* POP UP MODAL: PICK UP & DROP ROUTE SELECTOR (z-index: 9999)               */}
      {/* ========================================================================= */}
      {isRouteModalOpen && (
        <div
          id="route-popup-modal-overlay"
          className="fixed inset-0 z-[9999] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150"
          onClick={() => setIsRouteModalOpen(false)}
        >
          <div
            id="route-popup-modal-container"
            className="bg-white text-black w-full sm:max-w-md rounded-t-[28px] sm:rounded-[28px] p-4 sm:p-5 shadow-2xl border border-neutral-200 text-left space-y-3.5 relative animate-in slide-in-from-bottom-5 duration-200 max-h-[85vh] flex flex-col z-[10000]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header with Prominent X close button */}
            <div className="flex items-center justify-between pb-2 border-b border-neutral-200 relative">
              <span className="text-xs font-black uppercase font-mono tracking-wider text-black flex items-center gap-2">
                <Search className="w-4 h-4 text-amber-600" />
                Select Route
              </span>
              <button
                type="button"
                id="btn-close-route-popup"
                onClick={() => setIsRouteModalOpen(false)}
                className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 active:scale-95 text-neutral-700 hover:text-black flex items-center justify-center transition shadow-xs cursor-pointer z-[9999] ml-4 border border-neutral-200"
                title="Close"
                aria-label="Close route selector"
              >
                <X className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            {/* Connected Dual Input Box (Top: Green Pickup 64px, Bottom: Red Dropoff 64px) */}
            <div className="space-y-3 relative">
              {/* TOP ROW: PICKUP LOCATION INPUT (Height 64px, BIG white bg, shadow, rounded 12px, black text 16px, GREEN pin dot left, real GPS button) */}
              <div className="w-full h-[64px] min-h-[64px] bg-white rounded-xl shadow-md border border-neutral-200 px-3.5 flex items-center gap-3.5 focus-within:border-[#FFCC00] focus-within:ring-2 focus-within:ring-[#FFCC00]/30 transition">
                {/* Green Pin Dot */}
                <div className="w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20 flex-shrink-0 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white" />
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-center">
                  <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase leading-tight">
                    PICKUP LOCATION
                  </span>
                  <input
                    ref={pickupInputRef}
                    type="text"
                    id="input-popup-pickup"
                    value={pickupText}
                    onFocus={() => setActiveInputFocus('pickup')}
                    onChange={(e) => handlePickupTextChange(e.target.value)}
                    onBlur={handlePickupBlur}
                    placeholder="Your location • Ngaba Ngaba Crescent"
                    className="w-full bg-transparent text-[16px] font-bold text-black outline-none border-none p-0 truncate placeholder:text-neutral-400"
                  />
                </div>

                {/* Yellow GPS Button */}
                <button
                  type="button"
                  id="btn-popup-gps-locate"
                  onClick={handlePickupGps}
                  disabled={isGpsLoading}
                  className="h-9 px-3 bg-[#FFCC00] hover:bg-yellow-400 text-black border border-yellow-500 font-black text-xs font-mono rounded-lg flex items-center gap-1.5 transition active:scale-95 shadow-xs flex-shrink-0 cursor-pointer"
                  title="Current GPS"
                >
                  <Navigation className={`w-3.5 h-3.5 fill-black ${isGpsLoading ? 'animate-spin' : ''}`} />
                  <span>GPS</span>
                </button>
              </div>

              {/* BOTTOM ROW: DESTINATION INPUT (Height 64px, BIG white bg, shadow, rounded 12px, black text 16px, RED pin dot left, placeholder "Where to?") */}
              <div className="w-full h-[64px] min-h-[64px] bg-white rounded-xl shadow-md border border-neutral-200 px-3.5 flex items-center gap-3.5 focus-within:border-black focus-within:ring-2 focus-within:ring-black/10 transition">
                {/* Red Pin Dot */}
                <div className="w-4 h-4 rounded-full bg-red-500 ring-4 ring-red-500/20 flex-shrink-0 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white" />
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-center">
                  <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase leading-tight">
                    DESTINATION
                  </span>
                  <input
                    ref={destInputRef}
                    type="text"
                    id="input-popup-dropoff"
                    value={destQuery}
                    onFocus={() => setActiveInputFocus('dropoff')}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && destQuery.trim()) {
                        handleSelectCustomTyped();
                      }
                    }}
                    placeholder="Where to?"
                    className="w-full bg-transparent text-[16px] font-bold text-black outline-none border-none p-0 truncate placeholder:text-neutral-400"
                  />
                </div>

                {destQuery.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setDestQuery('');
                      setSearchResults([]);
                    }}
                    className="w-6 h-6 rounded-full bg-neutral-200 hover:bg-neutral-300 text-black flex items-center justify-center transition cursor-pointer flex-shrink-0"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Quick select custom typed destination option */}
            {destQuery.trim().length > 0 && (
              <button
                type="button"
                id="btn-popup-select-typed-dest"
                onClick={handleSelectCustomTyped}
                className="w-full text-left p-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 flex items-center justify-between transition shadow-xs cursor-pointer"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <Check className="w-4 h-4 text-amber-600 stroke-[3] flex-shrink-0" />
                  <span className="text-xs font-bold text-black truncate">
                    Set destination: &quot;{destQuery}&quot;
                  </span>
                </div>
                <span className="text-[10px] font-mono font-black bg-[#FFCC00] text-black px-2 py-0.5 rounded-lg flex-shrink-0">
                  CONFIRM
                </span>
              </button>
            )}

            {/* Search Results / Recent Trips */}
            <div className="overflow-y-auto no-scrollbar flex-1 space-y-1 divide-y divide-neutral-100">
              {searchResults.length > 0 ? (
                <div>
                  <div className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider px-1 py-1">
                    Matching Locations
                  </div>
                  {searchResults.map((place, idx) => (
                    <button
                      key={idx}
                      type="button"
                      id={`popup-search-result-${idx}`}
                      onClick={() => handleSelectPlace(place)}
                      className="w-full flex items-center gap-3 py-2 px-2 hover:bg-neutral-100 rounded-xl transition text-left group cursor-pointer"
                    >
                      <div className="w-7 h-7 rounded-full bg-[#F5F5F5] group-hover:bg-neutral-200 border border-neutral-200 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-3.5 h-3.5 text-neutral-500 group-hover:text-amber-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-black truncate">
                          {place.shortName || place.name || place.address}
                        </p>
                        <p className="text-[10px] text-neutral-500 truncate">{place.address}</p>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider px-1 py-1 flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-neutral-500" />
                    <span>Recent & Popular Destinations</span>
                  </div>
                  {recentTrips.map((place, idx) => (
                    <button
                      key={idx}
                      type="button"
                      id={`popup-recent-trip-${idx}`}
                      onClick={() => handleSelectPlace(place)}
                      className="w-full flex items-center gap-3 py-2 px-2 hover:bg-neutral-100 rounded-xl transition text-left group cursor-pointer"
                    >
                      <div className="w-7 h-7 rounded-full bg-[#F5F5F5] border border-neutral-200 flex items-center justify-center flex-shrink-0">
                        <Clock className="w-3.5 h-3.5 text-neutral-500 group-hover:text-black" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-black truncate">
                          {place.shortName || place.name}
                        </p>
                        <p className="text-[10px] text-neutral-500 truncate">{place.address}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Done / Confirm Button */}
            <button
              type="button"
              id="btn-confirm-popup-route"
              onClick={() => {
                if (destQuery.trim()) {
                  handleSelectCustomTyped();
                } else {
                  setIsRouteModalOpen(false);
                }
              }}
              className="w-full h-11 bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs font-mono uppercase tracking-wider rounded-2xl shadow-xs transition active:scale-98 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>DONE / CONFIRM ROUTE</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Promo Details Modal */}
      {showPromoDetails && (
        <div
          id="promo-details-modal-overlay"
          className="fixed inset-0 z-[10001] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowPromoDetails(false)}
        >
          <div
            className="bg-white text-black rounded-3xl p-5 w-full max-w-sm shadow-2xl border border-neutral-200 text-left space-y-3.5 relative animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-neutral-200 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-100 border border-purple-200 flex items-center justify-center">
                  <Tag className="w-4 h-4 text-purple-600 fill-purple-600" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-black">20% Promo Voucher</h3>
                  <p className="text-[10px] font-mono text-purple-700 font-bold uppercase">Zolta MAX Offer</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPromoDetails(false)}
                className="w-7 h-7 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-neutral-700 font-medium">
              <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 space-y-1">
                <p className="font-bold text-black">20% off 1 Scheduled Ride</p>
                <p className="text-[11px] text-purple-900">
                  Enjoy 20% automatic discount on your next ride across Cape Town. Valid for Ride, Comfort, XL, Bakkies, Scooter, and Courier.
                </p>
              </div>

              <div className="text-[11px] text-neutral-500 space-y-1 font-mono">
                <p>• Automatically applied on your next booking.</p>
                <p>• Single-use voucher: expires after 1 completed trip.</p>
                <p>• Stackable with Cash, Card, and PayShap payments.</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowPromoDetails(false)}
              className="w-full h-10 bg-[#FFCC00] text-black font-black text-xs rounded-xl font-mono uppercase tracking-wider transition active:scale-95 shadow-xs cursor-pointer"
            >
              GOT IT, THANKS
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { InteractiveMap } from '../map/InteractiveMap';
import { MainRideSheet } from './MainRideSheet';
import { BiddingRadar } from './BiddingRadar';
import { ActiveTripSheet } from './ActiveTripSheet';
import { LocationPoint, RideCategory } from '../../types';
import { NGABA_NGABA_LOCATION, POPULAR_LOCATIONS } from '../../services/geoService';

// Default destination matching the standard homepage layout (29 Sifutho St)
const DEFAULT_HOMEPAGE_DROPOFF: LocationPoint = POPULAR_LOCATIONS[1] || {
  address: '29 Sifutho St, Khayelitsha, Cape Town',
  shortName: '29 Sifutho St',
  lat: -34.0530,
  lng: 18.6850,
};

export const RiderDashboard: React.FC = () => {
  const {
    activeRide,
    currentLocation,
    createRideRequest,
    driverGenderPreference,
    fullMap,
    setFullMap,
  } = useApp();

  // Initialize pickup with saved localStorage address, currentLocation, or default Ngaba Ngaba Crescent
  const [pickup, setPickup] = useState<LocationPoint>(() => {
    try {
      const savedLat = localStorage.getItem('zolta_user_lat');
      const savedLng = localStorage.getItem('zolta_user_lng');
      const savedAddress = localStorage.getItem('zolta_pickup_address');
      const savedShort = localStorage.getItem('zolta_pickup_shortname');
      if (savedLat && savedLng) {
        const pLat = parseFloat(savedLat);
        const pLng = parseFloat(savedLng);
        if (
          typeof pLat === 'number' && !isNaN(pLat) && isFinite(pLat) &&
          typeof pLng === 'number' && !isNaN(pLng) && isFinite(pLng)
        ) {
          return {
            id: 'saved_pickup',
            name: savedShort || 'Your location',
            shortName: savedShort || 'Your location',
            address: savedAddress || 'Your location',
            lat: pLat,
            lng: pLng,
          };
        }
      }
    } catch {}
    if (
      currentLocation &&
      typeof currentLocation.lat === 'number' && !isNaN(currentLocation.lat) && isFinite(currentLocation.lat) &&
      typeof currentLocation.lng === 'number' && !isNaN(currentLocation.lng) && isFinite(currentLocation.lng)
    ) {
      return currentLocation;
    }
    return NGABA_NGABA_LOCATION;
  });

  // Initial dropoff is null for fresh install state ("Where to?")
  const [dropoff, setDropoff] = useState<LocationPoint | null>(() => {
    try {
      const savedDest = localStorage.getItem('zolta_saved_dest');
      if (savedDest) {
        const parsed = JSON.parse(savedDest);
        if (parsed && parsed.address) return parsed;
      }
    } catch {}
    return null;
  });

  const [category, setCategory] = useState<RideCategory>('rider');

  useEffect(() => {
    if (
      currentLocation &&
      typeof currentLocation.lat === 'number' &&
      !isNaN(currentLocation.lat) &&
      isFinite(currentLocation.lat) &&
      typeof currentLocation.lng === 'number' &&
      !isNaN(currentLocation.lng) &&
      isFinite(currentLocation.lng)
    ) {
      setPickup(currentLocation);
    }
  }, [currentLocation]);

  // Determine current active bottom sheet state
  const isBidding = activeRide && activeRide.status === 'searching';
  const isActiveTrip =
    activeRide &&
    ['driver_assigned', 'driver_arrived', 'in_progress'].includes(
      activeRide.status
    );

  const handleRequestRide = (fare: number, paymentMethod: 'cash' | 'card' | 'payshap' = 'cash') => {
    const finalDropoff = dropoff || DEFAULT_HOMEPAGE_DROPOFF;
    createRideRequest({
      pickup,
      dropoff: finalDropoff,
      category,
      offeredFare: fare,
      suggestedFare: fare,
      comments: '',
      paymentMethod,
      driverGenderPreference: driverGenderPreference || 'any',
      passengersCount: 1,
    } as any);
  };

  return (
    <div
      id="rider-dashboard-view"
      className="relative w-full h-[calc(100vh-40px)] min-h-[calc(100vh-40px)] flex flex-col justify-between bg-neutral-100 overflow-hidden"
    >
      {/* 1. TOP: Big clean map with YOU blue dot (55vh height) */}
      <div className="relative w-full h-[55vh] flex-shrink-0 overflow-hidden">
        <InteractiveMap
          pickup={activeRide ? activeRide.pickup : pickup}
          dropoff={activeRide ? activeRide.dropoff : (dropoff || DEFAULT_HOMEPAGE_DROPOFF)}
          activeRide={activeRide}
          draggablePickup={!activeRide}
          onPickupChange={(loc) => setPickup(loc)}
          showNoCarsNearby={false}
        />
      </div>

      {/* Foreground Bottom Sheet (45vh max height) */}
      <div className="relative z-10 w-full max-w-xl mx-auto px-2.5 sm:px-4 pb-2 sm:pb-3 pointer-events-auto flex-shrink-0 h-[45vh] max-h-[45vh] overflow-y-auto">
        {fullMap ? (
          <div className="bg-white/95 backdrop-blur-md p-3 rounded-2xl shadow-xl border border-neutral-200 flex items-center justify-between animate-in fade-in slide-in-from-bottom-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB] animate-pulse" />
              <span className="font-mono text-xs font-bold text-neutral-900">
                Viewing Live GPS & Route
              </span>
            </div>
            <button
              type="button"
              id="btn-close-full-map-sheet"
              onClick={() => setFullMap(false)}
              className="bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs font-mono px-3.5 py-1.5 rounded-xl shadow-xs active:scale-95 transition"
            >
              CLOSE MAP & BOOK
            </button>
          </div>
        ) : isBidding ? (
          <BiddingRadar />
        ) : isActiveTrip ? (
          <ActiveTripSheet />
        ) : (
          <MainRideSheet
            pickup={pickup}
            dropoff={dropoff}
            category={category}
            onSelectPickup={(loc) => setPickup(loc)}
            onSelectDropoff={(loc) => setDropoff(loc)}
            onSelectCategory={(cat) => setCategory(cat)}
            onRequestRide={handleRequestRide}
          />
        )}
      </div>
    </div>
  );
};

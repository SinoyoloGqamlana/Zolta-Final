import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { Star, Heart, ThumbsUp, DollarSign, Check, Award, Sparkles, ShieldCheck } from 'lucide-react';

export const TripRatingModal: React.FC = () => {
  const { isRatingModalOpen, submitTripRating, activeRide, setReceiptModalOpen } = useApp();
  const [rating, setRating] = useState(5);
  const [tip, setTip] = useState(0);
  const [selectedTags, setSelectedTags] = useState<string[]>(['Clean Car', 'Smooth Driving']);

  useEffect(() => {
    if (isRatingModalOpen) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#FFD60A', '#FFFFFF', '#000000', '#F59E0B'],
      });
    }
  }, [isRatingModalOpen]);

  if (!isRatingModalOpen) return null;

  const compliments = [
    'Clean Vehicle ✨',
    'Great Music 🎵',
    'Smooth Driving 🛡️',
    'Polite Driver 🤝',
    'On Time ⏱️',
    'Cold AC ❄️',
  ];

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleFinish = () => {
    submitTripRating(rating, tip, selectedTags);
  };

  const driverName = activeRide?.acceptedDriver?.name || 'David Ndlovu';
  const driverAvatar = activeRide?.acceptedDriver?.avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80';
  const driverCar = activeRide?.acceptedDriver?.carModel || 'Toyota Corolla Quest';
  const fare = activeRide?.offeredFare || 85;

  return (
    <div id="rating-modal-overlay" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-neutral-950 text-white border border-neutral-800 w-full max-w-md rounded-3xl p-6 shadow-2xl text-center relative max-h-[95vh] overflow-y-auto"
      >
        {/* Top Celebration Badge */}
        <div className="w-16 h-16 bg-[#FFD60A] text-black rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg ring-8 ring-[#FFD60A]/20 animate-bounce">
          <Award className="w-8 h-8" />
        </div>

        <h3 className="text-2xl font-black text-white tracking-tight">
          You Have Arrived!
        </h3>
        <p className="text-xs text-neutral-400 mb-4">
          Trip completed • Paid R{(fare || 0).toFixed(2)}
        </p>

        {/* Driver Card */}
        <div className="flex items-center justify-center gap-3 p-3 bg-neutral-900 rounded-2xl mb-5 border border-neutral-800">
          <img
            src={driverAvatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'}
            alt={driverName || 'Driver'}
            referrerPolicy="no-referrer"
            className="w-12 h-12 rounded-full object-cover border-2 border-[#FFD60A]"
          />
          <div className="text-left">
            <h5 className="font-bold text-sm text-white">{driverName}</h5>
            <p className="text-xs text-neutral-400">{driverCar}</p>
          </div>
        </div>

        {/* Interactive Star Rating */}
        <div className="mb-6">
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-2">
            Rate your experience
          </span>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                id={`btn-star-${star}`}
                onClick={() => setRating(star)}
                className="p-1.5 transition transform hover:scale-125 active:scale-95"
              >
                <Star
                  className={`w-9 h-9 ${
                    star <= rating
                      ? 'fill-[#FFD60A] text-[#FFD60A] drop-shadow-sm'
                      : 'text-neutral-700'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        {/* Compliment Tags */}
        <div className="mb-5">
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-2">
            Give a Compliment
          </span>
          <div className="flex flex-wrap justify-center gap-1.5">
            {compliments.map((tag) => {
              const active = selectedTags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-full transition ${
                    active
                      ? 'bg-[#FFD60A] text-black'
                      : 'bg-neutral-900 text-neutral-300 border border-neutral-800 hover:bg-neutral-800'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tip Driver */}
        <div className="mb-6">
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-2">
            Add Driver Gratuity (Optional)
          </span>
          <div className="flex justify-center gap-2">
            {[0, 10, 20, 50].map((tipOption) => (
              <button
                key={tipOption}
                type="button"
                id={`btn-tip-${tipOption}`}
                onClick={() => setTip(tipOption)}
                className={`py-2 px-4 rounded-xl text-xs font-black transition ${
                  tip === tipOption
                    ? 'bg-[#FFD60A] text-black ring-2 ring-white'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                {tipOption === 0 ? 'No Tip' : `+R${tipOption}`}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            type="button"
            id="btn-submit-rating"
            onClick={handleFinish}
            className="w-full bg-[#FFD60A] hover:bg-yellow-400 text-black font-black py-3.5 px-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg transition transform active:scale-95"
          >
            <span>Submit Feedback</span>
            <Check className="w-4 h-4 text-black" />
          </button>

          <button
            type="button"
            id="btn-view-receipt-from-rating"
            onClick={() => {
              setReceiptModalOpen(true);
            }}
            className="w-full text-xs font-bold text-neutral-400 hover:text-white py-2"
          >
            View ZOLTA Trip Receipt
          </button>
        </div>
      </motion.div>
    </div>
  );
};


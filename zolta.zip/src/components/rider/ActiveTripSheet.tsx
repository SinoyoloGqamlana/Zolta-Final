import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  Phone,
  MessageSquare,
  Shield,
  Star,
  Car,
  Navigation,
  CheckCircle2,
  X,
  AlertTriangle,
  Lock,
} from 'lucide-react';

export const ActiveTripSheet: React.FC = () => {
  const {
    activeRide,
    setChatModalOpen,
    startVoiceCall,
    setSafetyModalOpen,
    setSosModalOpen,
    cancelRideRequest,
  } = useApp();

  if (!activeRide) return null;

  const driver = activeRide.acceptedDriver;
  const status = activeRide.status;
  const etaMins = activeRide.driverEtaMins ?? 3;
  const progress = activeRide.driverRouteProgress ?? 0;

  const getStatusBadge = () => {
    switch (status) {
      case 'driver_assigned':
        return {
          title: `ZOLTA Driver En Route • ${etaMins} min`,
          subtitle: 'Arriving at pickup location',
          color: 'bg-white text-black border-[#FFD60A] shadow-xs',
        };
      case 'driver_arrived':
        return {
          title: '🚗 Driver Has Arrived!',
          subtitle: 'Waiting outside for you at pickup point',
          color: 'bg-[#FFD60A] text-black border-black font-extrabold shadow-sm',
        };
      case 'in_progress':
        return {
          title: `Trip In Progress • ~${etaMins} min left`,
          subtitle: 'Heading safely to destination • Protected Trip',
          color: 'bg-neutral-50 text-black border-[#E5E7EB]',
        };
      default:
        return {
          title: 'Trip Connected',
          subtitle: 'Enjoy your ride',
          color: 'bg-white text-black border-[#E5E7EB]',
        };
    }
  };

  const statusInfo = getStatusBadge();

  return (
    <div id="active-trip-sheet" className="bg-white text-[#111111] rounded-t-[24px] sm:rounded-[24px] shadow-2xl p-5 border-t sm:border border-[#E5E7EB] max-h-[85vh] overflow-y-auto">
      {/* Live Status Banner */}
      <div className={`p-3.5 rounded-2xl border mb-4 text-center ${statusInfo.color}`}>
        <h4 className="font-black text-sm tracking-tight font-roman">{statusInfo.title}</h4>
        <p className="text-xs text-[#666666] mt-0.5 font-mono">{statusInfo.subtitle}</p>
      </div>

      {/* Progress Bar (During trip) */}
      {status === 'in_progress' && (
        <div className="mb-4">
          <div className="flex justify-between text-[11px] font-bold text-[#666666] mb-1 font-mono">
            <span>Pickup: {activeRide.pickup.shortName || 'Origin'}</span>
            <span className="text-black font-mono font-bold">{progress}% En Route</span>
          </div>
          <div className="w-full h-2.5 bg-neutral-100 rounded-full overflow-hidden border border-neutral-200">
            <div
              className="h-full bg-[#FFD60A] transition-all duration-700 rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Driver Info Card */}
      {driver && (
        <div className="bg-white rounded-2xl p-4 border border-[#E5E7EB] shadow-xs mb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <img
                src={driver.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                alt={driver.name || 'Driver'}
                referrerPolicy="no-referrer"
                className="w-14 h-14 rounded-full object-cover border-2 border-[#FFD60A] shadow-xs"
              />
              <div>
                <h4 className="font-extrabold text-base text-[#111111] font-roman">{driver.name}</h4>
                <div className="flex items-center gap-1 text-xs font-black text-black">
                  <Star className="w-3.5 h-3.5 fill-[#FFD60A] text-[#FFD60A]" />
                  <span>{driver.rating}</span>
                  <span className="text-[#666666] font-normal ml-1 font-mono">• 1,420 trips</span>
                </div>
                <div className="mt-1 text-xs font-semibold text-[#666666] flex items-center gap-1.5 font-mono">
                  <Car className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{driver.carModel}</span>
                </div>
              </div>
            </div>

            {/* License Plate Badge */}
            <div className="bg-white border-2 border-[#FFD60A] text-black px-3 py-1.5 rounded-xl text-center shadow-xs">
              <span className="text-[9px] uppercase font-bold text-[#8B8B8B] block font-mono">Plate</span>
              <span className="font-mono font-black text-xs text-black tracking-wider">{driver.licensePlate}</span>
            </div>
          </div>
        </div>
      )}

      {/* Action Controls Grid: Call, Message, Safety, SOS */}
      <div className="grid grid-cols-3 gap-2.5 mb-4">
        <button
          type="button"
          id="btn-active-call"
          onClick={() => startVoiceCall(driver?.name || 'Driver', 'Driver')}
          className="bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 text-black py-3 rounded-2xl flex flex-col items-center justify-center gap-1 font-bold text-xs transition active:scale-95 shadow-xs"
        >
          <div className="w-9 h-9 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center">
            <Phone className="w-4 h-4" />
          </div>
          <span className="font-mono text-[11px] font-bold">Call</span>
        </button>

        <button
          type="button"
          id="btn-active-chat"
          onClick={() => setChatModalOpen(true)}
          className="bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 text-black py-3 rounded-2xl flex flex-col items-center justify-center gap-1 font-bold text-xs transition active:scale-95 shadow-xs"
        >
          <div className="w-9 h-9 rounded-full bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center">
            <MessageSquare className="w-4 h-4" />
          </div>
          <span className="font-mono text-[11px] font-bold">Chat</span>
        </button>

        <button
          type="button"
          id="btn-active-safety"
          onClick={() => setSafetyModalOpen(true)}
          className="bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 text-black py-3 rounded-2xl flex flex-col items-center justify-center gap-1 font-bold text-xs transition active:scale-95 shadow-xs"
        >
          <div className="w-9 h-9 rounded-full bg-red-50 border border-red-200 text-red-700 flex items-center justify-center">
            <Shield className="w-4 h-4" />
          </div>
          <span className="font-mono text-[11px] font-bold">Safety & SOS</span>
        </button>
      </div>

      {/* Price Summary */}
      <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-200 flex items-center justify-between mb-4 text-xs font-mono">
        <div>
          <span className="text-[#666666] font-bold flex items-center gap-1">
            <Lock className="w-3 h-3 text-black" /> Agreed Fare
          </span>
          <p className="text-base font-black text-black font-mono">R {activeRide.offeredFare}</p>
        </div>
        <div className="text-right">
          <span className="text-[#666666] font-bold">ZOLTA Safety</span>
          <p className="font-bold text-emerald-700 uppercase">Verified Trip</p>
        </div>
      </div>

      {/* Cancel Trip Button */}
      {status !== 'completed' && (
        <button
          type="button"
          id="btn-cancel-active-trip"
          onClick={() => {
            if (confirm('Are you sure you want to cancel this trip?')) {
              cancelRideRequest('Cancelled by passenger');
            }
          }}
          className="w-full text-xs font-bold text-[#666666] hover:text-red-600 hover:bg-red-50 py-2.5 rounded-xl transition text-center"
        >
          Cancel Ride
        </button>
      )}
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { Bid } from '../../types';
import {
  Radar,
  Star,
  Clock,
  Check,
  X,
  Plus,
  ShieldCheck,
  RotateCcw,
  TrendingUp,
} from 'lucide-react';

export const BiddingRadar: React.FC = () => {
  const {
    activeRide,
    acceptDriverBid,
    rejectDriverBid,
    raiseRiderOffer,
    cancelRideRequest,
  } = useApp();

  const [bidTimers, setBidTimers] = useState<Record<string, number>>({});
  const [broadcastRemaining, setBroadcastRemaining] = useState<number>(60);
  const [isTimedOut, setIsTimedOut] = useState<boolean>(false);

  const bids = activeRide?.bids.filter((b) => b.status === 'pending') || [];
  const offeredFare = activeRide?.offeredFare || 30;

  // 60-second broadcast timer
  useEffect(() => {
    setBroadcastRemaining(60);
    setIsTimedOut(false);

    const timer = setInterval(() => {
      setBroadcastRemaining((prev) => {
        if (prev <= 1) {
          setIsTimedOut(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeRide?.id]);

  // Countdown timer for individual bids
  useEffect(() => {
    const interval = setInterval(() => {
      setBidTimers((prev) => {
        const next: Record<string, number> = {};
        bids.forEach((b) => {
          const elapsed = (Date.now() - b.createdAt) / 1000;
          const remaining = Math.max(0, 25 - elapsed);
          next[b.id] = remaining;
          if (remaining === 0) {
            rejectDriverBid(b.id);
          }
        });
        return next;
      });
    }, 500);

    return () => clearInterval(interval);
  }, [bids, rejectDriverBid]);

  const handleRetryBroadcast = () => {
    setBroadcastRemaining(60);
    setIsTimedOut(false);
    raiseRiderOffer(5); // Proactively raise slightly on retry
  };

  return (
    <div
      id="bidding-radar-container"
      className="bg-white text-[#111111] rounded-t-[28px] sm:rounded-[28px] shadow-2xl p-4 sm:p-5 border-t sm:border border-neutral-200 max-h-[85vh] overflow-y-auto z-[9999]"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-neutral-200 relative">
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="relative flex-shrink-0">
            <div className="w-3.5 h-3.5 bg-[#FFD60A] rounded-full animate-ping" />
            <div className="w-3.5 h-3.5 bg-[#FFD60A] rounded-full absolute inset-0" />
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="font-roman text-sm font-bold text-[#111111] leading-tight truncate">
              Looking for ZOLTA Drivers
            </h4>
            <span className="text-[11px] text-[#666666] font-medium font-mono truncate block">
              Your offer: <strong className="text-black bg-neutral-100 px-1.5 py-0.5 rounded border border-neutral-200">R {offeredFare}</strong> • {broadcastRemaining}s left
            </span>
          </div>
        </div>

        {/* Right actions: Quick Raise Pills + X Close Button */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0 ml-2">
          <div className="hidden xs:flex sm:flex items-center gap-1">
            <span className="text-[9px] font-bold text-neutral-400 uppercase font-mono">Raise</span>
            <button
              type="button"
              id="btn-raise-5"
              onClick={() => raiseRiderOffer(5)}
              className="bg-neutral-100 hover:bg-[#FFD60A] text-black border border-neutral-200 text-[11px] font-black px-2 py-0.5 rounded-lg transition active:scale-95 cursor-pointer font-mono"
            >
              +R5
            </button>
            <button
              type="button"
              id="btn-raise-10"
              onClick={() => raiseRiderOffer(10)}
              className="bg-neutral-100 hover:bg-[#FFD60A] text-black border border-neutral-200 text-[11px] font-black px-2 py-0.5 rounded-lg transition active:scale-95 cursor-pointer font-mono"
            >
              +R10
            </button>
          </div>

          {/* Top Right X Close Button (z-index 9999) */}
          <button
            type="button"
            id="btn-close-bidding-header-x"
            onClick={() => cancelRideRequest('User closed search via top X')}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 active:scale-95 text-neutral-700 hover:text-black flex items-center justify-center transition border border-neutral-200 shadow-xs cursor-pointer z-[9999]"
            title="Cancel & Return Home"
            aria-label="Close search"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>

      {/* Driver Bids Stream or Radar Animation */}
      <div className="my-4 space-y-3">
        {bids.length === 0 ? (
          <div className="py-6 text-center flex flex-col items-center">
            {/* Animated Radar Pulse */}
            <div className="relative w-16 h-16 flex items-center justify-center mb-3">
              <div className="absolute inset-0 rounded-full bg-[#FFD60A]/20 animate-ping" />
              <div className="absolute inset-2 rounded-full bg-[#FFD60A]/10" />
              <div className="relative w-11 h-11 bg-white border-2 border-[#FFD60A] text-black rounded-full flex items-center justify-center shadow-md">
                <Radar className="w-5 h-5 animate-spin text-amber-500" style={{ animationDuration: '3s' }} />
              </div>
            </div>

            <p className="text-sm font-black text-black">Broadcasting Safe Ride Request...</p>

            {isTimedOut ? (
              <div className="mt-3 p-3 bg-amber-50 rounded-2xl border border-amber-300 w-full max-w-xs space-y-2">
                <p className="text-xs font-bold text-amber-900">
                  No drivers accepted in 60s. Drivers are requesting higher offers during peak hours.
                </p>
                <div className="flex items-center gap-2 justify-center">
                  <button
                    type="button"
                    onClick={handleRetryBroadcast}
                    className="h-8 px-3 bg-[#FFCC00] hover:bg-yellow-400 text-black font-black text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition active:scale-95 font-mono cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>RAISE +R5 & RETRY</span>
                  </button>
                </div>
              </div>
            ) : (
              <>
                <p className="text-xs font-bold text-black bg-[#FFCC00] px-3 py-1 rounded-full mt-2 shadow-xs font-mono">
                  Searching Cape Town Drivers ({broadcastRemaining}s)
                </p>
                <p className="text-xs text-neutral-500 mt-2 max-w-xs">
                  Verified drivers nearby are reviewing your route. Direct Safe Ride offers will appear below!
                </p>
              </>
            )}
          </div>
        ) : (
          <AnimatePresence>
            {bids.map((bid, idx) => {
              const remainingSec = Math.round(bidTimers[bid.id] ?? 25);
              const progressPercent = (remainingSec / 25) * 100;
              const isHigher = bid.amount > offeredFare;

              return (
                <motion.div
                  key={`${bid.id || 'bid'}_${idx}`}
                  initial={{ opacity: 0, y: 15, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.25 }}
                  className="bg-white rounded-2xl p-3.5 sm:p-4 border border-neutral-200 shadow-sm relative overflow-hidden transition"
                >
                  {/* Expiration Timer Bar */}
                  <div
                    className="absolute top-0 left-0 h-1 bg-[#FFD60A] transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  />

                  <div className="flex items-start justify-between gap-3">
                    {/* Driver Avatar & Rating */}
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={
                            bid.driverAvatar ||
                            'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
                          }
                          alt={bid.driverName || 'Driver'}
                          referrerPolicy="no-referrer"
                          className="w-11 h-11 rounded-full object-cover border-2 border-[#FFD60A]"
                        />
                        <div className="absolute -bottom-1 -right-1 bg-black text-[#FFD60A] rounded-full p-0.5 shadow">
                          <ShieldCheck className="w-3 h-3" />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <h5 className="font-extrabold text-sm text-[#111111]">{bid.driverName}</h5>
                          <div className="flex items-center gap-0.5 text-xs font-black text-black bg-[#FFD60A] px-1.5 py-0.2 rounded-md">
                            <Star className="w-3 h-3 fill-black" />
                            <span>{bid.driverRating}</span>
                          </div>
                        </div>

                        <p className="text-[11px] text-[#666666] font-medium">
                          {bid.driverCar} • <span className="font-mono text-black font-bold">{bid.driverPlate}</span>
                        </p>

                        <div className="flex items-center gap-2 text-[11px] text-[#666666] mt-0.5">
                          <span className="flex items-center gap-1 font-semibold text-emerald-700">
                            <Clock className="w-3 h-3" />
                            {bid.driverEtaMins} min away ({bid.driverDistanceKm} km)
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bid Amount Pill */}
                    <div className="text-right">
                      <div className="text-xl font-black text-black font-mono">
                        R {bid.amount}
                      </div>
                      {isHigher ? (
                        <span className="text-[10px] font-bold text-amber-900 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded-full">
                          +R {bid.amount - offeredFare} Counter
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-1.5 py-0.5 rounded-full">
                          Matches Offer
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Driver Note if any */}
                  {bid.message && (
                    <div className="mt-2 text-[11px] text-neutral-800 bg-[#F8F9FA] px-2.5 py-1 rounded-lg border border-neutral-200 italic">
                      💬 &quot;{bid.message}&quot;
                    </div>
                  )}

                  {/* Accept / Decline Buttons */}
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-neutral-200">
                    <button
                      type="button"
                      id={`btn-decline-bid-${bid.id}`}
                      onClick={() => rejectDriverBid(bid.id)}
                      className="p-2.5 rounded-xl border border-neutral-300 hover:bg-red-50 hover:border-red-400 text-neutral-500 hover:text-red-600 transition cursor-pointer"
                      title="Decline"
                    >
                      <X className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      id={`btn-accept-bid-${bid.id}`}
                      onClick={() => acceptDriverBid(bid.id)}
                      className="flex-1 bg-[#FFD60A] hover:bg-yellow-400 text-black font-black text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 shadow-md transition transform active:scale-[0.98] cursor-pointer font-mono"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Accept for R {bid.amount} ({remainingSec}s)</span>
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>

      {/* Prominent Red CANCEL REQUEST Button */}
      <button
        type="button"
        id="btn-cancel-search"
        onClick={() => cancelRideRequest('User cancelled search')}
        className="w-full py-3.5 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-black text-xs uppercase tracking-wider rounded-2xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer font-mono z-[9999]"
      >
        <X className="w-4 h-4 stroke-[3]" />
        <span>CANCEL REQUEST</span>
      </button>
    </div>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { DriverGenderPreference } from '../../types';
import { X, Users, User, ShieldCheck, Sparkles, HeartHandshake, Check } from 'lucide-react';

interface GenderChoiceModalProps {
  selectedGender: DriverGenderPreference;
  onSelectGender: (gender: DriverGenderPreference) => void;
  onClose: () => void;
}

export const GenderChoiceModal: React.FC<GenderChoiceModalProps> = ({
  selectedGender,
  onSelectGender,
  onClose,
}) => {
  const options: {
    id: DriverGenderPreference;
    title: string;
    badge: string;
    subtitle: string;
    icon: React.ReactNode;
    highlightColor: string;
  }[] = [
    {
      id: 'any',
      title: 'Any Driver',
      badge: 'Fastest ETA',
      subtitle: 'Dispatch to all verified ZOLTA drivers nearby for fastest response.',
      icon: <Users className="w-6 h-6" />,
      highlightColor: 'bg-black text-[#FFD60A]',
    },
    {
      id: 'female',
      title: 'Female Driver (ZOLTA Queen)',
      badge: 'Safety Priority',
      subtitle: 'Female-to-female safety priority ride with top-rated female drivers.',
      icon: <ShieldCheck className="w-6 h-6 text-pink-400" />,
      highlightColor: 'bg-pink-950 border-pink-500 text-pink-300',
    },
    {
      id: 'male',
      title: 'Male Driver',
      badge: 'Verified Driver',
      subtitle: 'Connect with verified top-rated male drivers in the local network.',
      icon: <User className="w-6 h-6 text-blue-400" />,
      highlightColor: 'bg-blue-950 border-blue-500 text-blue-300',
    },
  ];

  return (
    <div id="gender-choice-overlay" className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-black border border-neutral-800 text-white w-full max-w-md rounded-3xl p-6 shadow-2xl relative overflow-hidden"
      >
        {/* Close Button */}
        <button
          id="btn-close-gender-modal"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-9 h-9 bg-[#FFD60A] text-black rounded-xl flex items-center justify-center font-black">
            Z
          </div>
          <div>
            <h3 className="font-extrabold text-lg text-white">Choose Driver Gender</h3>
            <p className="text-xs text-neutral-400">Customise your driver preference</p>
          </div>
        </div>

        <div className="my-4 space-y-3">
          {options.map((opt) => {
            const isSelected = selectedGender === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                id={`btn-select-gender-${opt.id}`}
                onClick={() => {
                  onSelectGender(opt.id);
                  onClose();
                }}
                className={`w-full text-left p-4 rounded-2xl border transition relative flex items-start gap-3.5 ${
                  isSelected
                    ? 'bg-neutral-900 border-[#FFD60A] ring-2 ring-[#FFD60A]/40'
                    : 'bg-neutral-950/80 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className={`p-2.5 rounded-xl border border-neutral-800 flex items-center justify-center ${isSelected ? 'bg-[#FFD60A] text-black' : 'bg-neutral-900 text-white'}`}>
                  {opt.icon}
                </div>

                <div className="flex-1 min-w-0 pr-4">
                  <div className="flex items-center gap-2 mb-0.5">
                    <h4 className="font-bold text-sm text-white">{opt.title}</h4>
                    <span className={`text-[10px] font-black px-2 py-0.2 rounded-full uppercase tracking-wider ${
                      isSelected ? 'bg-[#FFD60A] text-black' : 'bg-neutral-800 text-neutral-300'
                    }`}>
                      {opt.badge}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {opt.subtitle}
                  </p>
                </div>

                {isSelected && (
                  <div className="absolute right-4 top-4 w-6 h-6 rounded-full bg-[#FFD60A] text-black flex items-center justify-center font-black">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Info notice */}
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-3 text-[11px] text-neutral-300 flex items-center gap-2">
          <HeartHandshake className="w-4 h-4 text-[#FFD60A] flex-shrink-0" />
          <span>All drivers undergo background checks and safety telemetry verification.</span>
        </div>
      </motion.div>
    </div>
  );
};

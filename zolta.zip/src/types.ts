export type AppMode = 'rider' | 'driver';

export type AppView = 
  | 'home' 
  | 'my_rides' 
  | 'wallet' 
  | 'drive_with_zolta'
  | 'trailer_hiring'
  | 'towing'
  | 'asset_owner'
  | 'safety' 
  | 'support' 
  | 'settings' 
  | 'invite' 
  | 'driver_earnings' 
  | 'driver_documents'
  | 'ride_preferences';

export type RideCategory = 
  | 'rider' 
  | 'comfort' 
  | 'xl' 
  | 'scooter'
  | 'bakkie'
  | 'courier';

export type DriverGenderPreference = 'any' | 'female' | 'male';

export interface RidePreferences {
  driverPreference: DriverGenderPreference;
  language: 'Xhosa' | 'English' | 'Afrikaans' | 'Sesotho';
  music: 'Amapiano' | 'Gqom' | 'Gospel' | 'Quiet ride';
  chatLevel: 'Chatty' | 'Quiet' | 'Only directions';
  stopAtSpaza: boolean;
  shareTripFamily: boolean;
  femaleDriverAtNight: boolean;
  avoidGravelRoads: boolean;
}

export interface RideCategoryInfo {
  id: RideCategory;
  name: string;
  subtitle: string;
  basePriceMultiplier: number;
  fixedDefaultPrice?: number;
  capacity: string;
  icon: string;
  badge?: string;
  carExample: string;
}

export interface LocationPoint {
  id?: string;
  name?: string;
  address: string;
  lat: number;
  lng: number;
  shortName?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string;
  rating: number;
  totalTrips: number;
  mode: AppMode;
  isDriverVerified: boolean;
  walletBalance: number;
  gender?: 'male' | 'female';
  joinedDate?: string;
  ridePreferences?: RidePreferences;
  driverDetails?: {
    carModel: string;
    carColor: string;
    licensePlate: string;
    carType: RideCategory;
    earningsToday: number;
    tripsToday: number;
    acceptanceRate: number;
    rating: number;
    gender: 'male' | 'female';
    documents: {
      licenseUploaded: boolean;
      rcUploaded: boolean;
      insuranceUploaded: boolean;
      photoUploaded: boolean;
    };
  };
}

export type RideStatus = 
  | 'searching' 
  | 'driver_assigned' 
  | 'driver_arrived' 
  | 'in_progress' 
  | 'completed' 
  | 'cancelled';

export interface Bid {
  id: string;
  rideId: string;
  driverId: string;
  driverName: string;
  driverGender: 'male' | 'female';
  driverAvatar: string;
  driverRating: number;
  driverTrips: number;
  driverCar: string;
  driverPlate: string;
  driverDistanceKm: number;
  driverEtaMins: number;
  amount: number;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
  message?: string;
}

export interface RideRequest {
  id: string;
  riderId: string;
  riderName: string;
  riderRating: number;
  riderPhone: string;
  riderAvatar: string;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  distanceKm: number;
  durationMins: number;
  category: RideCategory;
  genderPreference: DriverGenderPreference;
  offeredFare: number;
  suggestedFare: number;
  currency: string;
  comments: string;
  passengerCount: number;
  paymentMethod: 'cash' | 'card' | 'wallet' | 'payshap';
  status: RideStatus;
  cancellationReason?: string;
  bids: Bid[];
  acceptedBidId?: string;
  acceptedDriver?: {
    id: string;
    name: string;
    gender: 'male' | 'female';
    phone: string;
    avatar: string;
    rating: number;
    carModel: string;
    carColor: string;
    licensePlate: string;
    currentLocation: { lat: number; lng: number };
  };
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  driverRouteProgress?: number; // 0 to 100%
  driverEtaMins?: number;
  ratingGiven?: number;
  tipGiven?: number;
  feedbackTags?: string[];
}

export interface ChatMessage {
  id: string;
  rideId: string;
  senderId: string;
  senderName: string;
  senderRole: 'rider' | 'driver' | 'support';
  text: string;
  timestamp: number;
}

export interface WalletTransaction {
  id: string;
  type: 'topup' | 'ride_payment' | 'driver_earning' | 'bonus';
  amount: number;
  description: string;
  date: string;
  timestamp: number;
  status: 'completed' | 'pending';
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

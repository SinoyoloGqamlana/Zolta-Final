package com.zolta.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
